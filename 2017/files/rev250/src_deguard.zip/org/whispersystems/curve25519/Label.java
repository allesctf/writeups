package org.whispersystems.curve25519;

import org.whispersystems.curve25519.asm.Edge;
import org.whispersystems.curve25519.asm.FieldWriter;
import org.whispersystems.curve25519.asm.l;

abstract class Label
  implements Object
{
  private final Edge e;
  private SecureRandomProvider i;
  
  protected Label(Edge paramEdge, SecureRandomProvider paramSecureRandomProvider)
  {
    e = paramEdge;
    i = paramSecureRandomProvider;
  }
  
  public byte[] a()
  {
    return a(a(32));
  }
  
  public byte[] a(int paramInt)
  {
    byte[] arrayOfByte = new byte[paramInt];
    i.a(arrayOfByte);
    return arrayOfByte;
  }
  
  public byte[] a(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = new byte[32];
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, 32);
    arrayOfByte[0] = ((byte)(arrayOfByte[0] & 0xF8));
    arrayOfByte[31] = ((byte)(arrayOfByte[31] & 0x7F));
    arrayOfByte[31] = ((byte)(arrayOfByte[31] | 0x40));
    return arrayOfByte;
  }
  
  public void b(SecureRandomProvider paramSecureRandomProvider)
  {
    i = paramSecureRandomProvider;
  }
  
  public byte[] calculateAgreement(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    byte[] arrayOfByte = new byte[32];
    l.a(arrayOfByte, paramArrayOfByte1, paramArrayOfByte2);
    return arrayOfByte;
  }
  
  public byte[] generatePublicKey(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = new byte[32];
    FieldWriter.a(arrayOfByte, paramArrayOfByte);
    return arrayOfByte;
  }
}

package org.whispersystems.curve25519;

abstract interface Object
{
  public abstract byte[] a();
  
  public abstract void b(SecureRandomProvider paramSecureRandomProvider);
  
  public abstract byte[] calculateAgreement(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public abstract byte[] generatePublicKey(byte[] paramArrayOfByte);
}

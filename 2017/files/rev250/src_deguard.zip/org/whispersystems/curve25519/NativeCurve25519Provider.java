package org.whispersystems.curve25519;

class NativeCurve25519Provider
  implements Object
{
  private static boolean c = false;
  private static Throwable e = null;
  private SecureRandomProvider b = new JCESecureRandomProvider();
  
  static
  {
    try
    {
      System.loadLibrary("curve25519");
      c = true;
      return;
    }
    catch (UnsatisfiedLinkError localUnsatisfiedLinkError)
    {
      c = false;
      e = localUnsatisfiedLinkError;
      return;
    }
    catch (SecurityException localSecurityException)
    {
      for (;;) {}
    }
  }
  
  NativeCurve25519Provider()
  {
    if (!c) {
      throw new NoSuchProviderException(e);
    }
    try
    {
      smokeCheck(31337);
      return;
    }
    catch (UnsatisfiedLinkError localUnsatisfiedLinkError)
    {
      throw new NoSuchProviderException(localUnsatisfiedLinkError);
    }
  }
  
  private native boolean smokeCheck(int paramInt);
  
  public byte[] a()
  {
    return generatePrivateKey(putByte(32));
  }
  
  public void b(SecureRandomProvider paramSecureRandomProvider)
  {
    b = paramSecureRandomProvider;
  }
  
  public native byte[] calculateAgreement(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public native byte[] generatePrivateKey(byte[] paramArrayOfByte);
  
  public native byte[] generatePublicKey(byte[] paramArrayOfByte);
  
  public byte[] putByte(int paramInt)
  {
    byte[] arrayOfByte = new byte[paramInt];
    b.a(arrayOfByte);
    return arrayOfByte;
  }
}

package org.whispersystems.curve25519;

public class NoSuchProviderException
  extends RuntimeException
{
  private final Throwable error;
  
  public NoSuchProviderException(String paramString)
  {
    super(paramString);
    error = null;
  }
  
  public NoSuchProviderException(Throwable paramThrowable)
  {
    error = paramThrowable;
  }
}

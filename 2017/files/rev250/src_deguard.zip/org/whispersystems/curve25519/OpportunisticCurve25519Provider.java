package org.whispersystems.curve25519;

public class OpportunisticCurve25519Provider
  implements Object
{
  private Object d;
  
  OpportunisticCurve25519Provider()
  {
    try
    {
      NativeCurve25519Provider localNativeCurve25519Provider = new NativeCurve25519Provider();
      d = localNativeCurve25519Provider;
      return;
    }
    catch (NoSuchProviderException localNoSuchProviderException)
    {
      d = new JavaCurve25519Provider();
    }
  }
  
  public byte[] a()
  {
    return d.a();
  }
  
  public void b(SecureRandomProvider paramSecureRandomProvider)
  {
    d.b(paramSecureRandomProvider);
  }
  
  public byte[] calculateAgreement(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return d.calculateAgreement(paramArrayOfByte1, paramArrayOfByte2);
  }
  
  public byte[] generatePublicKey(byte[] paramArrayOfByte)
  {
    return d.generatePublicKey(paramArrayOfByte);
  }
}

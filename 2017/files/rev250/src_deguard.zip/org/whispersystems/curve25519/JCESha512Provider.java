package org.whispersystems.curve25519;

import org.whispersystems.curve25519.asm.Edge;

public class JCESha512Provider
  implements Edge
{
  public JCESha512Provider() {}
}

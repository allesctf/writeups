package org.whispersystems.curve25519;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class JCESecureRandomProvider
  implements SecureRandomProvider
{
  public JCESecureRandomProvider() {}
  
  public void a(byte[] paramArrayOfByte)
  {
    try
    {
      SecureRandom.getInstance("SHA1PRNG").nextBytes(paramArrayOfByte);
      return;
    }
    catch (NoSuchAlgorithmException paramArrayOfByte)
    {
      throw new AssertionError(paramArrayOfByte);
    }
  }
}

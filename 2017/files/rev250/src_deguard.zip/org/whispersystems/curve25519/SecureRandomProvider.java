package org.whispersystems.curve25519;

public abstract interface SecureRandomProvider
{
  public abstract void a(byte[] paramArrayOfByte);
}

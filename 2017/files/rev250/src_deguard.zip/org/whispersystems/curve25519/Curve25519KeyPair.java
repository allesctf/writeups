package org.whispersystems.curve25519;

public class Curve25519KeyPair
{
  private final byte[] buf;
  private final byte[] d;
  
  Curve25519KeyPair(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    buf = paramArrayOfByte1;
    d = paramArrayOfByte2;
  }
  
  public byte[] a()
  {
    return d;
  }
  
  public byte[] get()
  {
    return buf;
  }
}

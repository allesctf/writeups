package org.whispersystems.curve25519;

public class Curve25519
{
  private final Object v;
  
  private Curve25519(Object paramObject)
  {
    v = paramObject;
  }
  
  private static Object add(SecureRandomProvider paramSecureRandomProvider)
  {
    return get("NativeCurve25519Provider", paramSecureRandomProvider);
  }
  
  public static Curve25519 get(String paramString)
  {
    return init(paramString, null);
  }
  
  private static Object get(String paramString, SecureRandomProvider paramSecureRandomProvider)
  {
    try
    {
      paramString = Class.forName("org.whispersystems.curve25519." + paramString).newInstance();
      paramString = (Object)paramString;
      if (paramSecureRandomProvider != null)
      {
        paramString.b(paramSecureRandomProvider);
        return paramString;
      }
    }
    catch (InstantiationException paramString)
    {
      throw new NoSuchProviderException(paramString);
    }
    catch (IllegalAccessException paramString)
    {
      throw new NoSuchProviderException(paramString);
    }
    catch (ClassNotFoundException paramString)
    {
      throw new NoSuchProviderException(paramString);
    }
    return paramString;
  }
  
  private static Object getQ(SecureRandomProvider paramSecureRandomProvider)
  {
    return get("J2meCurve25519Provider", paramSecureRandomProvider);
  }
  
  private static Object getService(SecureRandomProvider paramSecureRandomProvider)
  {
    return get("JavaCurve25519Provider", paramSecureRandomProvider);
  }
  
  public static Curve25519 init(String paramString, SecureRandomProvider paramSecureRandomProvider)
  {
    if ("native".equals(paramString)) {
      return new Curve25519(add(paramSecureRandomProvider));
    }
    if ("java".equals(paramString)) {
      return new Curve25519(getService(paramSecureRandomProvider));
    }
    if ("j2me".equals(paramString)) {
      return new Curve25519(getQ(paramSecureRandomProvider));
    }
    if ("best".equals(paramString)) {
      return new Curve25519(select(paramSecureRandomProvider));
    }
    throw new NoSuchProviderException(paramString);
  }
  
  private static Object select(SecureRandomProvider paramSecureRandomProvider)
  {
    return get("OpportunisticCurve25519Provider", paramSecureRandomProvider);
  }
  
  public Curve25519KeyPair add()
  {
    byte[] arrayOfByte = v.a();
    return new Curve25519KeyPair(v.generatePublicKey(arrayOfByte), arrayOfByte);
  }
  
  public byte[] add(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 == null)) {
      throw new IllegalArgumentException("Keys must not be null!");
    }
    if ((paramArrayOfByte1.length != 32) || (paramArrayOfByte2.length != 32)) {
      throw new IllegalArgumentException("Keys must be 32 bytes!");
    }
    return v.calculateAgreement(paramArrayOfByte2, paramArrayOfByte1);
  }
}

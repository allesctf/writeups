package org.whispersystems.curve25519;

public class JavaCurve25519Provider
  extends Label
{
  protected JavaCurve25519Provider()
  {
    super(new JCESha512Provider(), new JCESecureRandomProvider());
  }
}

package org.whispersystems.curve25519;

public class VrfSignatureVerificationFailedException
  extends Exception
{
  public VrfSignatureVerificationFailedException() {}
}

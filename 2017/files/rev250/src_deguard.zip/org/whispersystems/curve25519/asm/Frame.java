package org.whispersystems.curve25519.asm;

public class Frame
{
  public static void a(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    int i = paramArrayOfInt2[0];
    int j = paramArrayOfInt2[1];
    int k = paramArrayOfInt2[2];
    int m = paramArrayOfInt2[3];
    int n = paramArrayOfInt2[4];
    int i1 = paramArrayOfInt2[5];
    int i2 = paramArrayOfInt2[6];
    int i3 = paramArrayOfInt2[7];
    int i4 = paramArrayOfInt2[8];
    int i5 = paramArrayOfInt2[9];
    int i6 = paramArrayOfInt3[0];
    int i7 = paramArrayOfInt3[1];
    int i8 = paramArrayOfInt3[2];
    int i9 = paramArrayOfInt3[3];
    int i10 = paramArrayOfInt3[4];
    int i11 = paramArrayOfInt3[5];
    int i12 = paramArrayOfInt3[6];
    int i13 = paramArrayOfInt3[7];
    int i14 = paramArrayOfInt3[8];
    int i15 = paramArrayOfInt3[9];
    paramArrayOfInt1[0] = (i + i6);
    paramArrayOfInt1[1] = (j + i7);
    paramArrayOfInt1[2] = (k + i8);
    paramArrayOfInt1[3] = (m + i9);
    paramArrayOfInt1[4] = (n + i10);
    paramArrayOfInt1[5] = (i1 + i11);
    paramArrayOfInt1[6] = (i2 + i12);
    paramArrayOfInt1[7] = (i3 + i13);
    paramArrayOfInt1[8] = (i4 + i14);
    paramArrayOfInt1[9] = (i5 + i15);
  }
}

package org.whispersystems.curve25519.asm;

public class l
{
  public static int a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    byte[] arrayOfByte = new byte[32];
    int[] arrayOfInt1 = new int[10];
    int[] arrayOfInt2 = new int[10];
    int[] arrayOfInt3 = new int[10];
    int[] arrayOfInt4 = new int[10];
    int[] arrayOfInt5 = new int[10];
    int[] arrayOfInt6 = new int[10];
    int[] arrayOfInt7 = new int[10];
    int i = 0;
    while (i < 32)
    {
      arrayOfByte[i] = paramArrayOfByte2[i];
      i += 1;
    }
    Attribute.a(arrayOfInt1, paramArrayOfByte3);
    ClassReader.a(arrayOfInt2);
    p.a(arrayOfInt3);
    AnnotationVisitor.a(arrayOfInt4, arrayOfInt1);
    ClassReader.a(arrayOfInt5);
    i = 254;
    int k;
    for (int j = 0; i >= 0; j = k)
    {
      k = arrayOfByte[(i / 8)] >>> (i & 0x7) & 0x1;
      j ^= k;
      j.a(arrayOfInt2, arrayOfInt4, j);
      j.a(arrayOfInt3, arrayOfInt5, j);
      k.a(arrayOfInt6, arrayOfInt4, arrayOfInt5);
      k.a(arrayOfInt7, arrayOfInt2, arrayOfInt3);
      Frame.a(arrayOfInt2, arrayOfInt2, arrayOfInt3);
      Frame.a(arrayOfInt3, arrayOfInt4, arrayOfInt5);
      SignatureReader.a(arrayOfInt5, arrayOfInt6, arrayOfInt2);
      SignatureReader.a(arrayOfInt3, arrayOfInt3, arrayOfInt7);
      i.a(arrayOfInt6, arrayOfInt7);
      i.a(arrayOfInt7, arrayOfInt2);
      Frame.a(arrayOfInt4, arrayOfInt5, arrayOfInt3);
      k.a(arrayOfInt3, arrayOfInt5, arrayOfInt3);
      SignatureReader.a(arrayOfInt2, arrayOfInt7, arrayOfInt6);
      k.a(arrayOfInt7, arrayOfInt7, arrayOfInt6);
      i.a(arrayOfInt3, arrayOfInt3);
      b.a(arrayOfInt5, arrayOfInt7);
      i.a(arrayOfInt4, arrayOfInt4);
      Frame.a(arrayOfInt6, arrayOfInt6, arrayOfInt5);
      SignatureReader.a(arrayOfInt5, arrayOfInt1, arrayOfInt3);
      SignatureReader.a(arrayOfInt3, arrayOfInt7, arrayOfInt6);
      i -= 1;
    }
    j.a(arrayOfInt2, arrayOfInt4, j);
    j.a(arrayOfInt3, arrayOfInt5, j);
    AnnotationWriter.a(arrayOfInt3, arrayOfInt3);
    SignatureReader.a(arrayOfInt2, arrayOfInt2, arrayOfInt3);
    FieldVisitor.encryptBlock(paramArrayOfByte1, arrayOfInt2);
    return 0;
  }
}

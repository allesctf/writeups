package org.whispersystems.curve25519.asm;

public class FieldWriter
{
  public static void a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    x localX = new x();
    int[] arrayOfInt1 = new int[10];
    int[] arrayOfInt2 = new int[10];
    int[] arrayOfInt3 = new int[10];
    int[] arrayOfInt4 = new int[10];
    MethodWriter.a(localX, paramArrayOfByte2);
    Frame.a(arrayOfInt1, d, a);
    k.a(arrayOfInt2, a, d);
    AnnotationWriter.a(arrayOfInt3, arrayOfInt2);
    SignatureReader.a(arrayOfInt4, arrayOfInt1, arrayOfInt3);
    FieldVisitor.encryptBlock(paramArrayOfByte1, arrayOfInt4);
  }
}

package org.whispersystems.curve25519.asm;

public class j
{
  public static void a(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt)
  {
    int i = paramArrayOfInt1[0];
    int j = paramArrayOfInt1[1];
    int k = paramArrayOfInt1[2];
    int m = paramArrayOfInt1[3];
    int n = paramArrayOfInt1[4];
    int i1 = paramArrayOfInt1[5];
    int i2 = paramArrayOfInt1[6];
    int i3 = paramArrayOfInt1[7];
    int i4 = paramArrayOfInt1[8];
    int i5 = paramArrayOfInt1[9];
    int i6 = paramArrayOfInt2[0];
    int i7 = paramArrayOfInt2[1];
    int i8 = paramArrayOfInt2[2];
    int i9 = paramArrayOfInt2[3];
    int i10 = paramArrayOfInt2[4];
    int i11 = paramArrayOfInt2[5];
    int i12 = paramArrayOfInt2[6];
    int i13 = paramArrayOfInt2[7];
    int i14 = paramArrayOfInt2[8];
    int i15 = paramArrayOfInt2[9];
    int i24 = -paramInt;
    paramInt = (i ^ i6) & i24;
    int i16 = (j ^ i7) & i24;
    int i17 = (k ^ i8) & i24;
    int i18 = (m ^ i9) & i24;
    int i19 = (n ^ i10) & i24;
    int i20 = (i1 ^ i11) & i24;
    int i21 = (i2 ^ i12) & i24;
    int i22 = (i3 ^ i13) & i24;
    int i23 = (i4 ^ i14) & i24;
    i24 = (i5 ^ i15) & i24;
    paramArrayOfInt1[0] = (i ^ paramInt);
    paramArrayOfInt1[1] = (j ^ i16);
    paramArrayOfInt1[2] = (k ^ i17);
    paramArrayOfInt1[3] = (m ^ i18);
    paramArrayOfInt1[4] = (n ^ i19);
    paramArrayOfInt1[5] = (i1 ^ i20);
    paramArrayOfInt1[6] = (i2 ^ i21);
    paramArrayOfInt1[7] = (i3 ^ i22);
    paramArrayOfInt1[8] = (i4 ^ i23);
    paramArrayOfInt1[9] = (i5 ^ i24);
    paramArrayOfInt2[0] = (i6 ^ paramInt);
    paramArrayOfInt2[1] = (i7 ^ i16);
    paramArrayOfInt2[2] = (i8 ^ i17);
    paramArrayOfInt2[3] = (i9 ^ i18);
    paramArrayOfInt2[4] = (i10 ^ i19);
    paramArrayOfInt2[5] = (i11 ^ i20);
    paramArrayOfInt2[6] = (i12 ^ i21);
    paramArrayOfInt2[7] = (i13 ^ i22);
    paramArrayOfInt2[8] = (i14 ^ i23);
    paramArrayOfInt2[9] = (i15 ^ i24);
  }
}

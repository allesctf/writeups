package org.whispersystems.curve25519.asm;

public class x
{
  public int[] a = new int[10];
  public int[] b = new int[10];
  public int[] c = new int[10];
  public int[] d = new int[10];
  
  public x() {}
}

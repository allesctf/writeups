package org.whispersystems.curve25519.asm;

public class w
{
  public static void a(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int j = paramArrayOfInt2[0];
    int m = paramArrayOfInt2[1];
    int i1 = paramArrayOfInt2[2];
    int i3 = paramArrayOfInt2[3];
    int i5 = paramArrayOfInt2[4];
    int i4 = paramArrayOfInt2[5];
    int i2 = paramArrayOfInt2[6];
    int n = paramArrayOfInt2[7];
    int k = paramArrayOfInt2[8];
    int i = paramArrayOfInt2[9];
    j = -j;
    m = -m;
    i1 = -i1;
    i3 = -i3;
    i5 = -i5;
    i4 = -i4;
    i2 = -i2;
    n = -n;
    k = -k;
    i = -i;
    paramArrayOfInt1[0] = j;
    paramArrayOfInt1[1] = m;
    paramArrayOfInt1[2] = i1;
    paramArrayOfInt1[3] = i3;
    paramArrayOfInt1[4] = i5;
    paramArrayOfInt1[5] = i4;
    paramArrayOfInt1[6] = i2;
    paramArrayOfInt1[7] = n;
    paramArrayOfInt1[8] = k;
    paramArrayOfInt1[9] = i;
  }
}

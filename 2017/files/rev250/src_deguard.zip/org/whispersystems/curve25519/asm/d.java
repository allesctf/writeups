package org.whispersystems.curve25519.asm;

public class d
{
  public static void b(ClassWriter paramClassWriter, x paramX)
  {
    a localA = new a();
    h.a(localA, paramX);
    Label.a(paramClassWriter, localA);
  }
}

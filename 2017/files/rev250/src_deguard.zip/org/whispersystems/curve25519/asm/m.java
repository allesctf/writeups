package org.whispersystems.curve25519.asm;

public class m
{
  public static void a(e paramE)
  {
    ClassReader.a(f);
    ClassReader.a(e);
    p.a(d);
  }
}

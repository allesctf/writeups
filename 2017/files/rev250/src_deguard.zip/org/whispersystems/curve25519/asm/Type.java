package org.whispersystems.curve25519.asm;

public class Type
{
  public static void a(a paramA, ClassWriter paramClassWriter)
  {
    SignatureReader.a(f, d, c);
    SignatureReader.a(e, e, f);
    SignatureReader.a(d, f, c);
  }
}

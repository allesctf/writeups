package org.whispersystems.curve25519.asm;

public class p
{
  public static void a(int[] paramArrayOfInt)
  {
    paramArrayOfInt[0] = 0;
    paramArrayOfInt[1] = 0;
    paramArrayOfInt[2] = 0;
    paramArrayOfInt[3] = 0;
    paramArrayOfInt[4] = 0;
    paramArrayOfInt[5] = 0;
    paramArrayOfInt[6] = 0;
    paramArrayOfInt[7] = 0;
    paramArrayOfInt[8] = 0;
    paramArrayOfInt[9] = 0;
  }
}

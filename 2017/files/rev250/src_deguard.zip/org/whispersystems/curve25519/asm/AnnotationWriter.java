package org.whispersystems.curve25519.asm;

public class AnnotationWriter
{
  public static void a(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int j = 1;
    int[] arrayOfInt1 = new int[10];
    int[] arrayOfInt2 = new int[10];
    int[] arrayOfInt3 = new int[10];
    int[] arrayOfInt4 = new int[10];
    i.a(arrayOfInt1, paramArrayOfInt2);
    i.a(arrayOfInt2, arrayOfInt1);
    int i = 1;
    while (i < 2)
    {
      i.a(arrayOfInt2, arrayOfInt2);
      i += 1;
    }
    SignatureReader.a(arrayOfInt2, paramArrayOfInt2, arrayOfInt2);
    SignatureReader.a(arrayOfInt1, arrayOfInt1, arrayOfInt2);
    i.a(arrayOfInt3, arrayOfInt1);
    SignatureReader.a(arrayOfInt2, arrayOfInt2, arrayOfInt3);
    i.a(arrayOfInt3, arrayOfInt2);
    i = 1;
    while (i < 5)
    {
      i.a(arrayOfInt3, arrayOfInt3);
      i += 1;
    }
    SignatureReader.a(arrayOfInt2, arrayOfInt3, arrayOfInt2);
    i.a(arrayOfInt3, arrayOfInt2);
    i = 1;
    while (i < 10)
    {
      i.a(arrayOfInt3, arrayOfInt3);
      i += 1;
    }
    SignatureReader.a(arrayOfInt3, arrayOfInt3, arrayOfInt2);
    i.a(arrayOfInt4, arrayOfInt3);
    i = 1;
    while (i < 20)
    {
      i.a(arrayOfInt4, arrayOfInt4);
      i += 1;
    }
    SignatureReader.a(arrayOfInt3, arrayOfInt4, arrayOfInt3);
    i.a(arrayOfInt3, arrayOfInt3);
    i = 1;
    while (i < 10)
    {
      i.a(arrayOfInt3, arrayOfInt3);
      i += 1;
    }
    SignatureReader.a(arrayOfInt2, arrayOfInt3, arrayOfInt2);
    i.a(arrayOfInt3, arrayOfInt2);
    i = 1;
    while (i < 50)
    {
      i.a(arrayOfInt3, arrayOfInt3);
      i += 1;
    }
    SignatureReader.a(arrayOfInt3, arrayOfInt3, arrayOfInt2);
    i.a(arrayOfInt4, arrayOfInt3);
    i = 1;
    while (i < 100)
    {
      i.a(arrayOfInt4, arrayOfInt4);
      i += 1;
    }
    SignatureReader.a(arrayOfInt3, arrayOfInt4, arrayOfInt3);
    i.a(arrayOfInt3, arrayOfInt3);
    i = 1;
    while (i < 50)
    {
      i.a(arrayOfInt3, arrayOfInt3);
      i += 1;
    }
    SignatureReader.a(arrayOfInt2, arrayOfInt3, arrayOfInt2);
    i.a(arrayOfInt2, arrayOfInt2);
    i = j;
    while (i < 5)
    {
      i.a(arrayOfInt2, arrayOfInt2);
      i += 1;
    }
    SignatureReader.a(paramArrayOfInt1, arrayOfInt2, arrayOfInt1);
  }
}

package org.whispersystems.curve25519.asm;

public class FieldVisitor
{
  public static void encryptBlock(byte[] paramArrayOfByte, int[] paramArrayOfInt)
  {
    int i5 = paramArrayOfInt[0];
    int j = paramArrayOfInt[1];
    int m = paramArrayOfInt[2];
    int i1 = paramArrayOfInt[3];
    int i3 = paramArrayOfInt[4];
    int i4 = paramArrayOfInt[5];
    int i2 = paramArrayOfInt[6];
    int n = paramArrayOfInt[7];
    int k = paramArrayOfInt[8];
    int i = paramArrayOfInt[9];
    int i6 = i5 + (((((((((((i * 19 + 16777216 >> 25) + i5 >> 26) + j >> 25) + m >> 26) + i1 >> 25) + i3 >> 26) + i4 >> 25) + i2 >> 26) + n >> 25) + k >> 26) + i >> 25) * 19;
    int i7 = i6 >> 26;
    i5 = j + i7;
    j = i6 - (i7 << 26);
    i7 = i5 >> 25;
    i6 = m + i7;
    m = i5 - (i7 << 25);
    i7 = i6 >> 26;
    i5 = i1 + i7;
    i1 = i6 - (i7 << 26);
    i7 = i5 >> 25;
    i6 = i3 + i7;
    i3 = i5 - (i7 << 25);
    i7 = i6 >> 26;
    i5 = i4 + i7;
    i4 = i6 - (i7 << 26);
    i7 = i5 >> 25;
    i6 = i2 + i7;
    i2 = i5 - (i7 << 25);
    i7 = i6 >> 26;
    i5 = n + i7;
    n = i6 - (i7 << 26);
    i6 = i5 >> 25;
    k += i6;
    i5 -= (i6 << 25);
    i6 = k >> 26;
    i += i6;
    k -= (i6 << 26);
    i -= (i >> 25 << 25);
    paramArrayOfByte[0] = ((byte)(j >> 0));
    paramArrayOfByte[1] = ((byte)(j >> 8));
    paramArrayOfByte[2] = ((byte)(j >> 16));
    paramArrayOfByte[3] = ((byte)(j >> 24 | m << 2));
    paramArrayOfByte[4] = ((byte)(m >> 6));
    paramArrayOfByte[5] = ((byte)(m >> 14));
    paramArrayOfByte[6] = ((byte)(m >> 22 | i1 << 3));
    paramArrayOfByte[7] = ((byte)(i1 >> 5));
    paramArrayOfByte[8] = ((byte)(i1 >> 13));
    paramArrayOfByte[9] = ((byte)(i1 >> 21 | i3 << 5));
    paramArrayOfByte[10] = ((byte)(i3 >> 3));
    paramArrayOfByte[11] = ((byte)(i3 >> 11));
    paramArrayOfByte[12] = ((byte)(i3 >> 19 | i4 << 6));
    paramArrayOfByte[13] = ((byte)(i4 >> 2));
    paramArrayOfByte[14] = ((byte)(i4 >> 10));
    paramArrayOfByte[15] = ((byte)(i4 >> 18));
    paramArrayOfByte[16] = ((byte)(i2 >> 0));
    paramArrayOfByte[17] = ((byte)(i2 >> 8));
    paramArrayOfByte[18] = ((byte)(i2 >> 16));
    paramArrayOfByte[19] = ((byte)(i2 >> 24 | n << 1));
    paramArrayOfByte[20] = ((byte)(n >> 7));
    paramArrayOfByte[21] = ((byte)(n >> 15));
    paramArrayOfByte[22] = ((byte)(n >> 23 | i5 << 3));
    paramArrayOfByte[23] = ((byte)(i5 >> 5));
    paramArrayOfByte[24] = ((byte)(i5 >> 13));
    paramArrayOfByte[25] = ((byte)(i5 >> 21 | k << 4));
    paramArrayOfByte[26] = ((byte)(k >> 4));
    paramArrayOfByte[27] = ((byte)(k >> 12));
    paramArrayOfByte[28] = ((byte)(k >> 20 | i << 6));
    paramArrayOfByte[29] = ((byte)(i >> 2));
    paramArrayOfByte[30] = ((byte)(i >> 10));
    paramArrayOfByte[31] = ((byte)(i >> 18));
  }
}

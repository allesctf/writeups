package org.whispersystems.curve25519.asm;

public class h
{
  public static void a(a paramA, x paramX)
  {
    AnnotationVisitor.a(f, c);
    AnnotationVisitor.a(e, d);
    AnnotationVisitor.a(d, a);
  }
}

package org.whispersystems.curve25519.asm;

public class MethodWriter
{
  static int a(byte paramByte)
  {
    return (int)(paramByte >>> 63);
  }
  
  static void a(e paramE, int paramInt, byte paramByte)
  {
    e[][] arrayOfE;
    if (paramInt <= 7) {
      arrayOfE = c.d;
    }
    for (;;)
    {
      e localE = new e();
      int i = a(paramByte);
      int j = paramByte - ((-i & paramByte) << 1);
      m.a(paramE);
      a(paramE, arrayOfE[paramInt][0], put((byte)j, (byte)1));
      a(paramE, arrayOfE[paramInt][1], put((byte)j, (byte)2));
      a(paramE, arrayOfE[paramInt][2], put((byte)j, (byte)3));
      a(paramE, arrayOfE[paramInt][3], put((byte)j, (byte)4));
      a(paramE, arrayOfE[paramInt][4], put((byte)j, (byte)5));
      a(paramE, arrayOfE[paramInt][5], put((byte)j, (byte)6));
      a(paramE, arrayOfE[paramInt][6], put((byte)j, (byte)7));
      a(paramE, arrayOfE[paramInt][7], put((byte)j, (byte)8));
      AnnotationVisitor.a(f, e);
      AnnotationVisitor.a(e, f);
      w.a(d, d);
      a(paramE, localE, i);
      return;
      if (paramInt <= 15) {
        arrayOfE = f.D;
      } else if (paramInt <= 23) {
        arrayOfE = GOST28147Engine.S;
      } else {
        arrayOfE = YPositionMetric.a.S;
      }
    }
  }
  
  static void a(e paramE1, e paramE2, int paramInt)
  {
    g.a(f, f, paramInt);
    g.a(e, e, paramInt);
    g.a(d, d, paramInt);
  }
  
  public static void a(x paramX, byte[] paramArrayOfByte)
  {
    int k = 0;
    byte[] arrayOfByte = new byte[64];
    ClassWriter localClassWriter = new ClassWriter();
    a localA = new a();
    e localE = new e();
    int i = 0;
    while (i < 32)
    {
      arrayOfByte[(i * 2 + 0)] = ((byte)(paramArrayOfByte[i] >>> 0 & 0xF));
      arrayOfByte[(i * 2 + 1)] = ((byte)(paramArrayOfByte[i] >>> 4 & 0xF));
      i += 1;
    }
    i = 0;
    int j = 0;
    while (i < 63)
    {
      arrayOfByte[i] = ((byte)(j + arrayOfByte[i]));
      j = (byte)((byte)(arrayOfByte[i] + 8) >> 4);
      arrayOfByte[i] = ((byte)(arrayOfByte[i] - (j << 4)));
      i += 1;
    }
    arrayOfByte[63] = ((byte)(arrayOfByte[63] + j));
    Handler.a(paramX);
    i = 1;
    while (i < 64)
    {
      a(localE, i / 2, arrayOfByte[i]);
      ByteVector.a(localClassWriter, paramX, localE);
      Item.a(paramX, localClassWriter);
      i += 2;
    }
    d.b(localClassWriter, paramX);
    Type.a(localA, localClassWriter);
    Label.a(localClassWriter, localA);
    Type.a(localA, localClassWriter);
    Label.a(localClassWriter, localA);
    Type.a(localA, localClassWriter);
    Label.a(localClassWriter, localA);
    Item.a(paramX, localClassWriter);
    i = k;
    while (i < 64)
    {
      a(localE, i / 2, arrayOfByte[i]);
      ByteVector.a(localClassWriter, paramX, localE);
      Item.a(paramX, localClassWriter);
      i += 2;
    }
  }
  
  static int put(byte paramByte1, byte paramByte2)
  {
    return (paramByte1 ^ paramByte2) - 1 >>> 31;
  }
}

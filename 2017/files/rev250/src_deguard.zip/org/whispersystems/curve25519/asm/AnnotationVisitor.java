package org.whispersystems.curve25519.asm;

public class AnnotationVisitor
{
  public static void a(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int i = paramArrayOfInt2[0];
    int j = paramArrayOfInt2[1];
    int k = paramArrayOfInt2[2];
    int m = paramArrayOfInt2[3];
    int n = paramArrayOfInt2[4];
    int i1 = paramArrayOfInt2[5];
    int i2 = paramArrayOfInt2[6];
    int i3 = paramArrayOfInt2[7];
    int i4 = paramArrayOfInt2[8];
    int i5 = paramArrayOfInt2[9];
    paramArrayOfInt1[0] = i;
    paramArrayOfInt1[1] = j;
    paramArrayOfInt1[2] = k;
    paramArrayOfInt1[3] = m;
    paramArrayOfInt1[4] = n;
    paramArrayOfInt1[5] = i1;
    paramArrayOfInt1[6] = i2;
    paramArrayOfInt1[7] = i3;
    paramArrayOfInt1[8] = i4;
    paramArrayOfInt1[9] = i5;
  }
}

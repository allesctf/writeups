package org.whispersystems.curve25519.asm;

public class Item
{
  public static void a(x paramX, ClassWriter paramClassWriter)
  {
    SignatureReader.a(c, d, c);
    SignatureReader.a(d, e, f);
    SignatureReader.a(a, f, c);
    SignatureReader.a(b, d, e);
  }
}

package org.whispersystems.curve25519.asm;

public class ClassWriter
{
  public int[] c = new int[10];
  public int[] d = new int[10];
  public int[] e = new int[10];
  public int[] f = new int[10];
  
  public ClassWriter() {}
}

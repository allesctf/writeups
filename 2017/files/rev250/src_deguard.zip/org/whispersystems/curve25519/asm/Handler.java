package org.whispersystems.curve25519.asm;

public class Handler
{
  public static void a(x paramX)
  {
    p.a(c);
    ClassReader.a(d);
    ClassReader.a(a);
    p.a(b);
  }
}

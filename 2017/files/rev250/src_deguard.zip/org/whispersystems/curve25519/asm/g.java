package org.whispersystems.curve25519.asm;

public class g
{
  public static void a(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt)
  {
    int i = paramArrayOfInt1[0];
    int j = paramArrayOfInt1[1];
    int k = paramArrayOfInt1[2];
    int m = paramArrayOfInt1[3];
    int n = paramArrayOfInt1[4];
    int i1 = paramArrayOfInt1[5];
    int i2 = paramArrayOfInt1[6];
    int i3 = paramArrayOfInt1[7];
    int i4 = paramArrayOfInt1[8];
    int i5 = paramArrayOfInt1[9];
    int i6 = paramArrayOfInt2[0];
    int i7 = paramArrayOfInt2[1];
    int i8 = paramArrayOfInt2[2];
    int i9 = paramArrayOfInt2[3];
    int i10 = paramArrayOfInt2[4];
    int i11 = paramArrayOfInt2[5];
    int i12 = paramArrayOfInt2[6];
    int i13 = paramArrayOfInt2[7];
    int i14 = paramArrayOfInt2[8];
    int i15 = paramArrayOfInt2[9];
    paramInt = -paramInt;
    paramArrayOfInt1[0] = (i ^ (i6 ^ i) & paramInt);
    paramArrayOfInt1[1] = (j ^ (i7 ^ j) & paramInt);
    paramArrayOfInt1[2] = (k ^ (i8 ^ k) & paramInt);
    paramArrayOfInt1[3] = (m ^ (i9 ^ m) & paramInt);
    paramArrayOfInt1[4] = (n ^ (i10 ^ n) & paramInt);
    paramArrayOfInt1[5] = (i1 ^ (i11 ^ i1) & paramInt);
    paramArrayOfInt1[6] = (i2 ^ (i12 ^ i2) & paramInt);
    paramArrayOfInt1[7] = (i3 ^ (i13 ^ i3) & paramInt);
    paramArrayOfInt1[8] = (i4 ^ (i14 ^ i4) & paramInt);
    paramArrayOfInt1[9] = (i5 ^ (i15 ^ i5) & paramInt);
  }
}

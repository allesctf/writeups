package org.whispersystems.curve25519.asm;

public class Attribute
{
  public static void a(int[] paramArrayOfInt, byte[] paramArrayOfByte)
  {
    long l7 = getValue(paramArrayOfByte, 0);
    long l1 = write(paramArrayOfByte, 4) << 6;
    long l9 = write(paramArrayOfByte, 7);
    long l2 = write(paramArrayOfByte, 10) << 3;
    long l11 = write(paramArrayOfByte, 13);
    long l3 = getValue(paramArrayOfByte, 16);
    long l13 = write(paramArrayOfByte, 20);
    long l4 = write(paramArrayOfByte, 23) << 5;
    long l15 = write(paramArrayOfByte, 26);
    long l5 = (write(paramArrayOfByte, 29) & 0x7FFFFF) << 2;
    long l6 = 16777216L + l5 >> 25;
    l7 += 19L * l6;
    long l8 = 16777216L + l1 >> 25;
    l9 = (l9 << 5) + l8;
    long l10 = 16777216L + l2 >> 25;
    l11 = (l11 << 2) + l10;
    long l12 = 16777216L + l3 >> 25;
    l13 = (l13 << 7) + l12;
    long l14 = 16777216L + l4 >> 25;
    l15 = (l15 << 4) + l14;
    long l16 = 33554432L + l7 >> 26;
    long l17 = 33554432L + l9 >> 26;
    long l18 = 33554432L + l11 >> 26;
    long l19 = 33554432L + l13 >> 26;
    long l20 = 33554432L + l15 >> 26;
    paramArrayOfInt[0] = ((int)(l7 - (l16 << 26)));
    paramArrayOfInt[1] = ((int)(l1 - (l8 << 25) + l16));
    paramArrayOfInt[2] = ((int)(l9 - (l17 << 26)));
    paramArrayOfInt[3] = ((int)(l2 - (l10 << 25) + l17));
    paramArrayOfInt[4] = ((int)(l11 - (l18 << 26)));
    paramArrayOfInt[5] = ((int)(l3 - (l12 << 25) + l18));
    paramArrayOfInt[6] = ((int)(l13 - (l19 << 26)));
    paramArrayOfInt[7] = ((int)(l4 - (l14 << 25) + l19));
    paramArrayOfInt[8] = ((int)(l15 - (l20 << 26)));
    paramArrayOfInt[9] = ((int)(l5 - (l6 << 25) + l20));
  }
  
  public static long getValue(byte[] paramArrayOfByte, int paramInt)
  {
    return paramArrayOfByte[(paramInt + 0)] & 0xFF | paramArrayOfByte[(paramInt + 1)] << 8 & 0xFF00 | paramArrayOfByte[(paramInt + 2)] << 16 & 0xFF0000 | paramArrayOfByte[(paramInt + 3)] << 24 & 0xFF000000;
  }
  
  public static long write(byte[] paramArrayOfByte, int paramInt)
  {
    return paramArrayOfByte[(paramInt + 0)] & 0xFF | paramArrayOfByte[(paramInt + 1)] << 8 & 0xFF00 | paramArrayOfByte[(paramInt + 2)] << 16 & 0xFF0000;
  }
}

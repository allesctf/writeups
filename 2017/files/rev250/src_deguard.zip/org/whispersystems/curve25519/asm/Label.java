package org.whispersystems.curve25519.asm;

public class Label
{
  public static void a(ClassWriter paramClassWriter, a paramA)
  {
    int[] arrayOfInt = new int[10];
    i.a(d, f);
    i.a(f, e);
    n.a(c, d);
    Frame.a(e, f, e);
    i.a(arrayOfInt, e);
    Frame.a(e, f, d);
    k.a(f, f, d);
    k.a(d, arrayOfInt, e);
    k.a(c, c, f);
  }
}

package org.whispersystems.curve25519.asm;

public class e
{
  public int[] d;
  public int[] e;
  public int[] f;
  
  public e()
  {
    f = new int[10];
    e = new int[10];
    d = new int[10];
  }
  
  public e(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    f = paramArrayOfInt1;
    e = paramArrayOfInt2;
    d = paramArrayOfInt3;
  }
}

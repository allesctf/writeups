package org.whispersystems.curve25519.asm;

public class SignatureReader
{
  public static void a(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    paramArrayOfInt2 = a(paramArrayOfInt2, paramArrayOfInt3);
    long l2 = paramArrayOfInt2[0];
    long l1 = paramArrayOfInt2[1];
    long l6 = paramArrayOfInt2[2];
    long l11 = paramArrayOfInt2[3];
    long l16 = paramArrayOfInt2[4];
    long l4 = paramArrayOfInt2[5];
    long l9 = paramArrayOfInt2[6];
    long l13 = paramArrayOfInt2[7];
    long l15 = paramArrayOfInt2[8];
    long l8 = paramArrayOfInt2[9];
    long l3 = 33554432L + l2 >> 26;
    l1 += l3;
    long l17 = 33554432L + l16 >> 26;
    l4 += l17;
    long l5 = 16777216L + l1 >> 25;
    l6 += l5;
    long l7 = 16777216L + l4 >> 25;
    l9 += l7;
    long l10 = 33554432L + l6 >> 26;
    l11 += l10;
    long l12 = 33554432L + l9 >> 26;
    l13 += l12;
    long l14 = 16777216L + l11 >> 25;
    l16 = l16 - (l17 << 26) + l14;
    l17 = 16777216L + l13 >> 25;
    l15 += l17;
    long l18 = 33554432L + l16 >> 26;
    long l19 = 33554432L + l15 >> 26;
    l8 += l19;
    long l20 = 16777216L + l8 >> 25;
    l2 = l2 - (l3 << 26) + 19L * l20;
    l3 = 33554432L + l2 >> 26;
    paramArrayOfInt1[0] = ((int)(l2 - (l3 << 26)));
    paramArrayOfInt1[1] = ((int)(l1 - (l5 << 25) + l3));
    paramArrayOfInt1[2] = ((int)(l6 - (l10 << 26)));
    paramArrayOfInt1[3] = ((int)(l11 - (l14 << 25)));
    paramArrayOfInt1[4] = ((int)(l16 - (l18 << 26)));
    paramArrayOfInt1[5] = ((int)(l4 - (l7 << 25) + l18));
    paramArrayOfInt1[6] = ((int)(l9 - (l12 << 26)));
    paramArrayOfInt1[7] = ((int)(l13 - (l17 << 25)));
    paramArrayOfInt1[8] = ((int)(l15 - (l19 << 26)));
    paramArrayOfInt1[9] = ((int)(l8 - (l20 << 25)));
  }
  
  /* Error */
  public static long[] a(int[] arg0, int[] arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: iaload
    //   3: istore_2
    //   4: aload_0
    //   5: iconst_1
    //   6: iaload
    //   7: istore_3
    //   8: aload_0
    //   9: iconst_2
    //   10: iaload
    //   11: istore 4
    //   13: aload_0
    //   14: iconst_3
    //   15: iaload
    //   16: istore 5
    //   18: aload_0
    //   19: iconst_4
    //   20: iaload
    //   21: istore 6
    //   23: aload_0
    //   24: iconst_5
    //   25: iaload
    //   26: istore 7
    //   28: aload_0
    //   29: bipush 6
    //   31: iaload
    //   32: istore 8
    //   34: aload_0
    //   35: bipush 7
    //   37: iaload
    //   38: istore 9
    //   40: aload_0
    //   41: bipush 8
    //   43: iaload
    //   44: istore 10
    //   46: aload_0
    //   47: bipush 9
    //   49: iaload
    //   50: istore 11
    //   52: aload_1
    //   53: iconst_0
    //   54: iaload
    //   55: istore 12
    //   57: aload_1
    //   58: iconst_1
    //   59: iaload
    //   60: istore 13
    //   62: aload_1
    //   63: iconst_2
    //   64: iaload
    //   65: istore 14
    //   67: aload_1
    //   68: iconst_3
    //   69: iaload
    //   70: istore 15
    //   72: aload_1
    //   73: iconst_4
    //   74: iaload
    //   75: istore 16
    //   77: aload_1
    //   78: iconst_5
    //   79: iaload
    //   80: istore 17
    //   82: aload_1
    //   83: bipush 6
    //   85: iaload
    //   86: istore 18
    //   88: aload_1
    //   89: bipush 7
    //   91: iaload
    //   92: istore 19
    //   94: aload_1
    //   95: bipush 8
    //   97: iaload
    //   98: istore 20
    //   100: aload_1
    //   101: bipush 9
    //   103: iaload
    //   104: istore 21
    //   106: iload 14
    //   108: bipush 19
    //   110: imul
    //   111: istore 22
    //   113: iload 15
    //   115: bipush 19
    //   117: imul
    //   118: istore 23
    //   120: iload 16
    //   122: bipush 19
    //   124: imul
    //   125: istore 24
    //   127: iload 17
    //   129: bipush 19
    //   131: imul
    //   132: istore 25
    //   134: iload 18
    //   136: bipush 19
    //   138: imul
    //   139: istore 26
    //   141: iload 19
    //   143: bipush 19
    //   145: imul
    //   146: istore 27
    //   148: iload 20
    //   150: bipush 19
    //   152: imul
    //   153: istore 28
    //   155: iload 21
    //   157: bipush 19
    //   159: imul
    //   160: istore 29
    //   162: iload_3
    //   163: iconst_2
    //   164: imul
    //   165: istore 30
    //   167: iload 5
    //   169: iconst_2
    //   170: imul
    //   171: istore 31
    //   173: iload 7
    //   175: iconst_2
    //   176: imul
    //   177: istore 32
    //   179: iload 9
    //   181: iconst_2
    //   182: imul
    //   183: istore 33
    //   185: iload 11
    //   187: iconst_2
    //   188: imul
    //   189: istore 34
    //   191: iload_2
    //   192: i2l
    //   193: lstore 35
    //   195: iload 12
    //   197: i2l
    //   198: lstore 37
    //   200: iload_2
    //   201: i2l
    //   202: lstore 39
    //   204: iload 13
    //   206: i2l
    //   207: lstore 41
    //   209: iload_2
    //   210: i2l
    //   211: lstore 43
    //   213: iload 14
    //   215: i2l
    //   216: lstore 45
    //   218: iload_2
    //   219: i2l
    //   220: lstore 47
    //   222: iload 15
    //   224: i2l
    //   225: lstore 49
    //   227: iload_2
    //   228: i2l
    //   229: lstore 51
    //   231: iload 16
    //   233: i2l
    //   234: lstore 53
    //   236: iload_2
    //   237: i2l
    //   238: lstore 55
    //   240: iload 17
    //   242: i2l
    //   243: lstore 57
    //   245: iload_2
    //   246: i2l
    //   247: lstore 59
    //   249: iload 18
    //   251: i2l
    //   252: lstore 61
    //   254: iload_2
    //   255: i2l
    //   256: lstore 63
    //   258: iload 19
    //   260: i2l
    //   261: lstore 65
    //   263: iload_2
    //   264: i2l
    //   265: lstore 67
    //   267: iload 20
    //   269: i2l
    //   270: lstore 69
    //   272: iload_2
    //   273: i2l
    //   274: lstore 71
    //   276: iload 21
    //   278: i2l
    //   279: lstore 73
    //   281: iload_3
    //   282: i2l
    //   283: lstore 75
    //   285: iload 12
    //   287: i2l
    //   288: lstore 77
    //   290: iload 30
    //   292: i2l
    //   293: lstore 79
    //   295: iload 13
    //   297: i2l
    //   298: lstore 81
    //   300: iload_3
    //   301: i2l
    //   302: lstore 83
    //   304: iload 14
    //   306: i2l
    //   307: lstore 85
    //   309: iload 30
    //   311: i2l
    //   312: lstore 87
    //   314: iload 15
    //   316: i2l
    //   317: lstore 89
    //   319: iload_3
    //   320: i2l
    //   321: lstore 91
    //   323: iload 16
    //   325: i2l
    //   326: lstore 93
    //   328: iload 30
    //   330: i2l
    //   331: lstore 95
    //   333: iload 17
    //   335: i2l
    //   336: lstore 97
    //   338: iload_3
    //   339: i2l
    //   340: lstore 99
    //   342: iload 18
    //   344: i2l
    //   345: lstore 101
    //   347: iload 30
    //   349: i2l
    //   350: lstore 103
    //   352: iload 19
    //   354: i2l
    //   355: lstore 105
    //   357: iload_3
    //   358: i2l
    //   359: lstore 107
    //   361: iload 20
    //   363: i2l
    //   364: lstore 109
    //   366: iload 30
    //   368: i2l
    //   369: lstore 111
    //   371: iload 29
    //   373: i2l
    //   374: lstore 113
    //   376: iload 4
    //   378: i2l
    //   379: lstore 115
    //   381: iload 12
    //   383: i2l
    //   384: lstore 117
    //   386: iload 4
    //   388: i2l
    //   389: lstore 119
    //   391: iload 13
    //   393: i2l
    //   394: lstore 121
    //   396: iload 4
    //   398: i2l
    //   399: lstore 123
    //   401: iload 14
    //   403: i2l
    //   404: lstore 125
    //   406: iload 4
    //   408: i2l
    //   409: lstore 127
    //   411: iload 15
    //   413: i2l
    //   414: lstore -127
    //   416: iload 4
    //   418: i2l
    //   419: lstore -125
    //   421: iload 16
    //   423: i2l
    //   424: lstore -123
    //   426: iload 4
    //   428: i2l
    //   429: lstore -121
    //   431: iload 17
    //   433: i2l
    //   434: lstore -119
    //   436: iload 4
    //   438: i2l
    //   439: lstore -117
    //   441: iload 18
    //   443: i2l
    //   444: lstore -115
    //   446: iload 4
    //   448: i2l
    //   449: lstore -113
    //   451: iload 19
    //   453: i2l
    //   454: lstore -111
    //   456: iload 4
    //   458: i2l
    //   459: lstore -109
    //   461: iload 28
    //   463: i2l
    //   464: lstore -107
    //   466: iload 4
    //   468: i2l
    //   469: lstore -105
    //   471: iload 29
    //   473: i2l
    //   474: lstore -103
    //   476: iload 5
    //   478: i2l
    //   479: lstore -101
    //   481: iload 12
    //   483: i2l
    //   484: lstore -99
    //   486: iload 31
    //   488: i2l
    //   489: lstore -97
    //   491: iload 13
    //   493: i2l
    //   494: lstore -95
    //   496: iload 5
    //   498: i2l
    //   499: lstore -93
    //   501: iload 14
    //   503: i2l
    //   504: lstore -91
    //   506: iload 31
    //   508: i2l
    //   509: lstore -89
    //   511: iload 15
    //   513: i2l
    //   514: lstore -87
    //   516: iload 5
    //   518: i2l
    //   519: lstore -85
    //   521: iload 16
    //   523: i2l
    //   524: lstore -83
    //   526: iload 31
    //   528: i2l
    //   529: lstore -81
    //   531: iload 17
    //   533: i2l
    //   534: lstore -79
    //   536: iload 5
    //   538: i2l
    //   539: lstore -77
    //   541: iload 18
    //   543: i2l
    //   544: lstore -75
    //   546: iload 31
    //   548: i2l
    //   549: lstore -73
    //   551: iload 27
    //   553: i2l
    //   554: lstore -71
    //   556: iload 5
    //   558: i2l
    //   559: lstore -69
    //   561: iload 28
    //   563: i2l
    //   564: lstore -67
    //   566: iload 31
    //   568: i2l
    //   569: lstore -65
    //   571: iload 29
    //   573: i2l
    //   574: lstore -63
    //   576: iload 6
    //   578: i2l
    //   579: lstore -61
    //   581: iload 12
    //   583: i2l
    //   584: lstore -59
    //   586: iload 6
    //   588: i2l
    //   589: lstore -57
    //   591: iload 13
    //   593: i2l
    //   594: lstore -55
    //   596: iload 6
    //   598: i2l
    //   599: lstore -53
    //   601: iload 14
    //   603: i2l
    //   604: lstore -51
    //   606: iload 6
    //   608: i2l
    //   609: lstore -49
    //   611: iload 15
    //   613: i2l
    //   614: lstore -47
    //   616: iload 6
    //   618: i2l
    //   619: lstore -45
    //   621: iload 16
    //   623: i2l
    //   624: lstore -43
    //   626: iload 6
    //   628: i2l
    //   629: lstore -41
    //   631: iload 17
    //   633: i2l
    //   634: lstore -39
    //   636: iload 6
    //   638: i2l
    //   639: lstore -37
    //   641: iload 26
    //   643: i2l
    //   644: lstore -35
    //   646: iload 6
    //   648: i2l
    //   649: lstore -33
    //   651: iload 27
    //   653: i2l
    //   654: lstore -31
    //   656: iload 6
    //   658: i2l
    //   659: lstore -29
    //   661: iload 28
    //   663: i2l
    //   664: lstore -27
    //   666: iload 6
    //   668: i2l
    //   669: lstore -25
    //   671: iload 29
    //   673: i2l
    //   674: lstore -23
    //   676: iload 7
    //   678: i2l
    //   679: lstore -21
    //   681: iload 12
    //   683: i2l
    //   684: lstore -19
    //   686: iload 32
    //   688: i2l
    //   689: lstore -17
    //   691: iload 13
    //   693: i2l
    //   694: lstore -15
    //   696: iload 7
    //   698: i2l
    //   699: lstore -13
    //   701: iload 14
    //   703: i2l
    //   704: lstore -11
    //   706: iload 32
    //   708: i2l
    //   709: lstore -9
    //   711: iload 15
    //   713: i2l
    //   714: lstore -7
    //   716: iload 7
    //   718: i2l
    //   719: lstore -5
    //   721: iload 16
    //   723: i2l
    //   724: lstore -3
    //   726: iload 32
    //   728: i2l
    //   729: lstore -1
    //   731: iload 25
    //   733: i2l
    //   734: wide
    //   738: iload 7
    //   740: i2l
    //   741: wide
    //   745: iload 26
    //   747: i2l
    //   748: wide
    //   752: iload 32
    //   754: i2l
    //   755: wide
    //   759: iload 27
    //   761: i2l
    //   762: wide
    //   766: iload 7
    //   768: i2l
    //   769: wide
    //   773: iload 28
    //   775: i2l
    //   776: wide
    //   780: iload 32
    //   782: i2l
    //   783: wide
    //   787: iload 29
    //   789: i2l
    //   790: wide
    //   794: iload 8
    //   796: i2l
    //   797: wide
    //   801: iload 12
    //   803: i2l
    //   804: wide
    //   808: iload 8
    //   810: i2l
    //   811: wide
    //   815: iload 13
    //   817: i2l
    //   818: wide
    //   822: iload 8
    //   824: i2l
    //   825: wide
    //   829: iload 14
    //   831: i2l
    //   832: wide
    //   836: iload 8
    //   838: i2l
    //   839: wide
    //   843: iload 15
    //   845: i2l
    //   846: wide
    //   850: iload 8
    //   852: i2l
    //   853: wide
    //   857: iload 24
    //   859: i2l
    //   860: wide
    //   864: iload 8
    //   866: i2l
    //   867: wide
    //   871: iload 25
    //   873: i2l
    //   874: wide
    //   878: iload 8
    //   880: i2l
    //   881: wide
    //   885: iload 26
    //   887: i2l
    //   888: wide
    //   892: iload 8
    //   894: i2l
    //   895: wide
    //   899: iload 27
    //   901: i2l
    //   902: wide
    //   906: iload 8
    //   908: i2l
    //   909: wide
    //   913: iload 28
    //   915: i2l
    //   916: wide
    //   920: iload 8
    //   922: i2l
    //   923: wide
    //   927: iload 29
    //   929: i2l
    //   930: wide
    //   934: iload 9
    //   936: i2l
    //   937: wide
    //   941: iload 12
    //   943: i2l
    //   944: wide
    //   948: iload 33
    //   950: i2l
    //   951: wide
    //   955: iload 13
    //   957: i2l
    //   958: wide
    //   962: iload 9
    //   964: i2l
    //   965: wide
    //   969: iload 14
    //   971: i2l
    //   972: wide
    //   976: iload 33
    //   978: i2l
    //   979: wide
    //   983: iload 23
    //   985: i2l
    //   986: wide
    //   990: iload 9
    //   992: i2l
    //   993: wide
    //   997: iload 24
    //   999: i2l
    //   1000: wide
    //   1004: iload 33
    //   1006: i2l
    //   1007: wide
    //   1011: iload 25
    //   1013: i2l
    //   1014: wide
    //   1018: iload 9
    //   1020: i2l
    //   1021: wide
    //   1025: iload 26
    //   1027: i2l
    //   1028: wide
    //   1032: iload 33
    //   1034: i2l
    //   1035: wide
    //   1039: iload 27
    //   1041: i2l
    //   1042: wide
    //   1046: iload 9
    //   1048: i2l
    //   1049: wide
    //   1053: iload 28
    //   1055: i2l
    //   1056: wide
    //   1060: iload 33
    //   1062: i2l
    //   1063: wide
    //   1067: iload 29
    //   1069: i2l
    //   1070: wide
    //   1074: iload 10
    //   1076: i2l
    //   1077: wide
    //   1081: iload 12
    //   1083: i2l
    //   1084: wide
    //   1088: iload 10
    //   1090: i2l
    //   1091: wide
    //   1095: iload 13
    //   1097: i2l
    //   1098: wide
    //   1102: iload 10
    //   1104: i2l
    //   1105: wide
    //   1109: iload 22
    //   1111: i2l
    //   1112: wide
    //   1116: iload 10
    //   1118: i2l
    //   1119: wide
    //   1123: iload 23
    //   1125: i2l
    //   1126: wide
    //   1130: iload 10
    //   1132: i2l
    //   1133: wide
    //   1137: iload 24
    //   1139: i2l
    //   1140: wide
    //   1144: iload 10
    //   1146: i2l
    //   1147: wide
    //   1151: iload 25
    //   1153: i2l
    //   1154: wide
    //   1158: iload 10
    //   1160: i2l
    //   1161: wide
    //   1165: iload 26
    //   1167: i2l
    //   1168: wide
    //   1172: iload 10
    //   1174: i2l
    //   1175: wide
    //   1179: iload 27
    //   1181: i2l
    //   1182: wide
    //   1186: iload 10
    //   1188: i2l
    //   1189: wide
    //   1193: iload 28
    //   1195: i2l
    //   1196: wide
    //   1200: iload 10
    //   1202: i2l
    //   1203: wide
    //   1207: iload 29
    //   1209: i2l
    //   1210: wide
    //   1214: iload 11
    //   1216: i2l
    //   1217: wide
    //   1221: iload 12
    //   1223: i2l
    //   1224: wide
    //   1228: iload 34
    //   1230: i2l
    //   1231: wide
    //   1235: iload 13
    //   1237: bipush 19
    //   1239: imul
    //   1240: i2l
    //   1241: wide
    //   1245: iload 11
    //   1247: i2l
    //   1248: wide
    //   1252: iload 22
    //   1254: i2l
    //   1255: wide
    //   1259: iload 34
    //   1261: i2l
    //   1262: wide
    //   1266: iload 23
    //   1268: i2l
    //   1269: wide
    //   1273: iload 11
    //   1275: i2l
    //   1276: wide
    //   1280: iload 24
    //   1282: i2l
    //   1283: wide
    //   1287: iload 34
    //   1289: i2l
    //   1290: wide
    //   1294: iload 25
    //   1296: i2l
    //   1297: wide
    //   1301: iload 11
    //   1303: i2l
    //   1304: wide
    //   1308: bipush 10
    //   1310: newarray long
    //   1312: dup
    //   1313: iconst_0
    //   1314: lload 111
    //   1316: lload 113
    //   1318: lmul
    //   1319: lload 35
    //   1321: lload 37
    //   1323: lmul
    //   1324: ladd
    //   1325: lload -109
    //   1327: lload -107
    //   1329: lmul
    //   1330: ladd
    //   1331: lload -73
    //   1333: lload -71
    //   1335: lmul
    //   1336: ladd
    //   1337: lload -37
    //   1339: lload -35
    //   1341: lmul
    //   1342: ladd
    //   1343: lload -1
    //   1345: wide
    //   1349: lmul
    //   1350: ladd
    //   1351: wide
    //   1355: wide
    //   1359: lmul
    //   1360: ladd
    //   1361: wide
    //   1365: wide
    //   1369: lmul
    //   1370: ladd
    //   1371: wide
    //   1375: wide
    //   1379: lmul
    //   1380: ladd
    //   1381: wide
    //   1385: wide
    //   1389: lmul
    //   1390: ladd
    //   1391: lastore
    //   1392: dup
    //   1393: iconst_1
    //   1394: lload -69
    //   1396: lload -67
    //   1398: lmul
    //   1399: lload 39
    //   1401: lload 41
    //   1403: lmul
    //   1404: lload 75
    //   1406: lload 77
    //   1408: lmul
    //   1409: ladd
    //   1410: lload -105
    //   1412: lload -103
    //   1414: lmul
    //   1415: ladd
    //   1416: ladd
    //   1417: lload -33
    //   1419: lload -31
    //   1421: lmul
    //   1422: ladd
    //   1423: wide
    //   1427: wide
    //   1431: lmul
    //   1432: ladd
    //   1433: wide
    //   1437: wide
    //   1441: lmul
    //   1442: ladd
    //   1443: wide
    //   1447: wide
    //   1451: lmul
    //   1452: ladd
    //   1453: wide
    //   1457: wide
    //   1461: lmul
    //   1462: ladd
    //   1463: wide
    //   1467: wide
    //   1471: lmul
    //   1472: ladd
    //   1473: lastore
    //   1474: dup
    //   1475: iconst_2
    //   1476: lload 43
    //   1478: lload 45
    //   1480: lmul
    //   1481: lload 79
    //   1483: lload 81
    //   1485: lmul
    //   1486: ladd
    //   1487: lload 115
    //   1489: lload 117
    //   1491: lmul
    //   1492: ladd
    //   1493: lload -65
    //   1495: lload -63
    //   1497: lmul
    //   1498: ladd
    //   1499: lload -29
    //   1501: lload -27
    //   1503: lmul
    //   1504: ladd
    //   1505: wide
    //   1509: wide
    //   1513: lmul
    //   1514: ladd
    //   1515: wide
    //   1519: wide
    //   1523: lmul
    //   1524: ladd
    //   1525: wide
    //   1529: wide
    //   1533: lmul
    //   1534: ladd
    //   1535: wide
    //   1539: wide
    //   1543: lmul
    //   1544: ladd
    //   1545: wide
    //   1549: wide
    //   1553: lmul
    //   1554: ladd
    //   1555: lastore
    //   1556: dup
    //   1557: iconst_3
    //   1558: wide
    //   1562: wide
    //   1566: lmul
    //   1567: lload 47
    //   1569: lload 49
    //   1571: lmul
    //   1572: lload 83
    //   1574: lload 85
    //   1576: lmul
    //   1577: ladd
    //   1578: lload 119
    //   1580: lload 121
    //   1582: lmul
    //   1583: ladd
    //   1584: lload -101
    //   1586: lload -99
    //   1588: lmul
    //   1589: ladd
    //   1590: lload -25
    //   1592: lload -23
    //   1594: lmul
    //   1595: ladd
    //   1596: ladd
    //   1597: wide
    //   1601: wide
    //   1605: lmul
    //   1606: ladd
    //   1607: wide
    //   1611: wide
    //   1615: lmul
    //   1616: ladd
    //   1617: wide
    //   1621: wide
    //   1625: lmul
    //   1626: ladd
    //   1627: wide
    //   1631: wide
    //   1635: lmul
    //   1636: ladd
    //   1637: lastore
    //   1638: dup
    //   1639: iconst_4
    //   1640: lload 51
    //   1642: lload 53
    //   1644: lmul
    //   1645: lload 87
    //   1647: lload 89
    //   1649: lmul
    //   1650: ladd
    //   1651: lload 123
    //   1653: lload 125
    //   1655: lmul
    //   1656: ladd
    //   1657: lload -97
    //   1659: lload -95
    //   1661: lmul
    //   1662: ladd
    //   1663: lload -61
    //   1665: lload -59
    //   1667: lmul
    //   1668: ladd
    //   1669: wide
    //   1673: wide
    //   1677: lmul
    //   1678: ladd
    //   1679: wide
    //   1683: wide
    //   1687: lmul
    //   1688: ladd
    //   1689: wide
    //   1693: wide
    //   1697: lmul
    //   1698: ladd
    //   1699: wide
    //   1703: wide
    //   1707: lmul
    //   1708: ladd
    //   1709: wide
    //   1713: wide
    //   1717: lmul
    //   1718: ladd
    //   1719: lastore
    //   1720: dup
    //   1721: iconst_5
    //   1722: lload 55
    //   1724: lload 57
    //   1726: lmul
    //   1727: lload 91
    //   1729: lload 93
    //   1731: lmul
    //   1732: ladd
    //   1733: lload 127
    //   1735: lload -127
    //   1737: lmul
    //   1738: ladd
    //   1739: lload -93
    //   1741: lload -91
    //   1743: lmul
    //   1744: ladd
    //   1745: lload -57
    //   1747: lload -55
    //   1749: lmul
    //   1750: ladd
    //   1751: lload -21
    //   1753: lload -19
    //   1755: lmul
    //   1756: ladd
    //   1757: wide
    //   1761: wide
    //   1765: lmul
    //   1766: ladd
    //   1767: wide
    //   1771: wide
    //   1775: lmul
    //   1776: ladd
    //   1777: wide
    //   1781: wide
    //   1785: lmul
    //   1786: ladd
    //   1787: iload 26
    //   1789: i2l
    //   1790: wide
    //   1794: lmul
    //   1795: ladd
    //   1796: lastore
    //   1797: dup
    //   1798: bipush 6
    //   1800: lload 59
    //   1802: lload 61
    //   1804: lmul
    //   1805: lload 95
    //   1807: lload 97
    //   1809: lmul
    //   1810: ladd
    //   1811: lload -125
    //   1813: lload -123
    //   1815: lmul
    //   1816: ladd
    //   1817: lload -89
    //   1819: lload -87
    //   1821: lmul
    //   1822: ladd
    //   1823: lload -53
    //   1825: lload -51
    //   1827: lmul
    //   1828: ladd
    //   1829: lload -17
    //   1831: lload -15
    //   1833: lmul
    //   1834: ladd
    //   1835: wide
    //   1839: wide
    //   1843: lmul
    //   1844: ladd
    //   1845: wide
    //   1849: wide
    //   1853: lmul
    //   1854: ladd
    //   1855: wide
    //   1859: wide
    //   1863: lmul
    //   1864: ladd
    //   1865: iload 34
    //   1867: i2l
    //   1868: iload 27
    //   1870: i2l
    //   1871: lmul
    //   1872: ladd
    //   1873: lastore
    //   1874: dup
    //   1875: bipush 7
    //   1877: lload 63
    //   1879: lload 65
    //   1881: lmul
    //   1882: lload 99
    //   1884: lload 101
    //   1886: lmul
    //   1887: ladd
    //   1888: lload -121
    //   1890: lload -119
    //   1892: lmul
    //   1893: ladd
    //   1894: lload -85
    //   1896: lload -83
    //   1898: lmul
    //   1899: ladd
    //   1900: lload -49
    //   1902: lload -47
    //   1904: lmul
    //   1905: ladd
    //   1906: lload -13
    //   1908: lload -11
    //   1910: lmul
    //   1911: ladd
    //   1912: wide
    //   1916: wide
    //   1920: lmul
    //   1921: ladd
    //   1922: wide
    //   1926: wide
    //   1930: lmul
    //   1931: ladd
    //   1932: wide
    //   1936: wide
    //   1940: lmul
    //   1941: ladd
    //   1942: iload 11
    //   1944: i2l
    //   1945: iload 28
    //   1947: i2l
    //   1948: lmul
    //   1949: ladd
    //   1950: lastore
    //   1951: dup
    //   1952: bipush 8
    //   1954: lload 67
    //   1956: lload 69
    //   1958: lmul
    //   1959: lload 103
    //   1961: lload 105
    //   1963: lmul
    //   1964: ladd
    //   1965: lload -117
    //   1967: lload -115
    //   1969: lmul
    //   1970: ladd
    //   1971: lload -81
    //   1973: lload -79
    //   1975: lmul
    //   1976: ladd
    //   1977: lload -45
    //   1979: lload -43
    //   1981: lmul
    //   1982: ladd
    //   1983: lload -9
    //   1985: lload -7
    //   1987: lmul
    //   1988: ladd
    //   1989: wide
    //   1993: wide
    //   1997: lmul
    //   1998: ladd
    //   1999: wide
    //   2003: wide
    //   2007: lmul
    //   2008: ladd
    //   2009: wide
    //   2013: wide
    //   2017: lmul
    //   2018: ladd
    //   2019: iload 34
    //   2021: i2l
    //   2022: iload 29
    //   2024: i2l
    //   2025: lmul
    //   2026: ladd
    //   2027: lastore
    //   2028: dup
    //   2029: bipush 9
    //   2031: lload 107
    //   2033: lload 109
    //   2035: lmul
    //   2036: lload 71
    //   2038: lload 73
    //   2040: lmul
    //   2041: ladd
    //   2042: lload -113
    //   2044: lload -111
    //   2046: lmul
    //   2047: ladd
    //   2048: lload -75
    //   2050: lload -77
    //   2052: lmul
    //   2053: ladd
    //   2054: lload -41
    //   2056: lload -39
    //   2058: lmul
    //   2059: ladd
    //   2060: lload -3
    //   2062: lload -5
    //   2064: lmul
    //   2065: ladd
    //   2066: wide
    //   2070: wide
    //   2074: lmul
    //   2075: ladd
    //   2076: wide
    //   2080: wide
    //   2084: lmul
    //   2085: ladd
    //   2086: wide
    //   2090: wide
    //   2094: lmul
    //   2095: ladd
    //   2096: wide
    //   2100: wide
    //   2104: lmul
    //   2105: ladd
    //   2106: lastore
    //   2107: areturn
  }
}

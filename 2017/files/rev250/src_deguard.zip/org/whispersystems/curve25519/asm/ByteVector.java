package org.whispersystems.curve25519.asm;

public class ByteVector
{
  public static void a(ClassWriter paramClassWriter, x paramX, e paramE)
  {
    int[] arrayOfInt = new int[10];
    Frame.a(d, d, c);
    k.a(e, d, c);
    SignatureReader.a(f, d, f);
    SignatureReader.a(e, e, e);
    SignatureReader.a(c, d, b);
    Frame.a(arrayOfInt, a, a);
    k.a(d, f, e);
    Frame.a(e, f, e);
    Frame.a(f, arrayOfInt, c);
    k.a(c, arrayOfInt, c);
  }
}

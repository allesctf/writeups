package org.whispersystems.curve25519.asm;

public abstract interface Edge {}

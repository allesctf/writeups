package org.whispersystems.curve25519.asm;

public class b
{
  public static void a(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int i = paramArrayOfInt2[0];
    int j = paramArrayOfInt2[1];
    int k = paramArrayOfInt2[2];
    int m = paramArrayOfInt2[3];
    int n = paramArrayOfInt2[4];
    int i1 = paramArrayOfInt2[5];
    int i2 = paramArrayOfInt2[6];
    int i3 = paramArrayOfInt2[7];
    int i4 = paramArrayOfInt2[8];
    int i5 = paramArrayOfInt2[9];
    long l7 = i;
    long l1 = j * 121666L;
    long l9 = k;
    long l2 = m * 121666L;
    long l11 = n;
    long l3 = i1 * 121666L;
    long l13 = i2;
    long l4 = i3 * 121666L;
    long l15 = i4;
    long l5 = i5 * 121666L;
    long l6 = 16777216L + l5 >> 25;
    l7 = l7 * 121666L + 19L * l6;
    long l8 = 16777216L + l1 >> 25;
    l9 = l9 * 121666L + l8;
    long l10 = 16777216L + l2 >> 25;
    l11 = l11 * 121666L + l10;
    long l12 = 16777216L + l3 >> 25;
    l13 = l13 * 121666L + l12;
    long l14 = 16777216L + l4 >> 25;
    l15 = l15 * 121666L + l14;
    long l16 = 33554432L + l7 >> 26;
    long l17 = 33554432L + l9 >> 26;
    long l18 = 33554432L + l11 >> 26;
    long l19 = 33554432L + l13 >> 26;
    long l20 = 33554432L + l15 >> 26;
    paramArrayOfInt1[0] = ((int)(l7 - (l16 << 26)));
    paramArrayOfInt1[1] = ((int)(l1 - (l8 << 25) + l16));
    paramArrayOfInt1[2] = ((int)(l9 - (l17 << 26)));
    paramArrayOfInt1[3] = ((int)(l2 - (l10 << 25) + l17));
    paramArrayOfInt1[4] = ((int)(l11 - (l18 << 26)));
    paramArrayOfInt1[5] = ((int)(l3 - (l12 << 25) + l18));
    paramArrayOfInt1[6] = ((int)(l13 - (l19 << 26)));
    paramArrayOfInt1[7] = ((int)(l4 - (l14 << 25) + l19));
    paramArrayOfInt1[8] = ((int)(l15 - (l20 << 26)));
    paramArrayOfInt1[9] = ((int)(l5 - (l6 << 25) + l20));
  }
}

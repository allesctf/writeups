package org.apache.commons.math3.fraction;

import java.nio.charset.Charset;
import org.apache.commons.math3.Charsets;

public class Item
{
  private static final char[] b = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
  private static final char[] c;
  public static final Charset d = Charsets.ISO_8859_1;
  private final Charset charset;
  
  static
  {
    c = new char[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102 };
  }
  
  public static char[] a(byte[] paramArrayOfByte, boolean paramBoolean)
  {
    if (paramBoolean) {}
    for (char[] arrayOfChar = c;; arrayOfChar = b) {
      return read(paramArrayOfByte, arrayOfChar);
    }
  }
  
  public static char[] add(byte[] paramArrayOfByte)
  {
    return a(paramArrayOfByte, true);
  }
  
  protected static char[] read(byte[] paramArrayOfByte, char[] paramArrayOfChar)
  {
    int j = 0;
    int k = paramArrayOfByte.length;
    char[] arrayOfChar = new char[k << 1];
    int i = 0;
    while (i < k)
    {
      int m = j + 1;
      arrayOfChar[j] = paramArrayOfChar[((paramArrayOfByte[i] & 0xF0) >>> 4)];
      j = m + 1;
      arrayOfChar[m] = paramArrayOfChar[(paramArrayOfByte[i] & 0xF)];
      i += 1;
    }
    return arrayOfChar;
  }
  
  public String toString()
  {
    return super.toString() + "[charsetName=" + charset + "]";
  }
}

package org.apache.commons.math3;

import java.nio.charset.Charset;

public class Charsets
{
  @Deprecated
  public static final Charset ASCII;
  @Deprecated
  public static final Charset ISO_8859_1 = Charset.forName("UTF-8");
  @Deprecated
  public static final Charset US_ASCII;
  @Deprecated
  public static final Charset UTF_16BE = Charset.forName("ISO-8859-1");
  @Deprecated
  public static final Charset UTF_16LE = Charset.forName("US-ASCII");
  @Deprecated
  public static final Charset UTF_8 = Charset.forName("UTF-16");
  
  static
  {
    ASCII = Charset.forName("UTF-16BE");
    US_ASCII = Charset.forName("UTF-16LE");
  }
}

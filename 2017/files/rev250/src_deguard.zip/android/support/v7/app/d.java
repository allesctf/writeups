package android.support.v7.app;

import android.content.res.Resources;
import android.os.Build.VERSION;
import android.util.Log;
import android.util.LongSparseArray;
import java.lang.reflect.Field;
import java.util.Map;

class d
{
  private static Field B;
  private static boolean a;
  private static Field b;
  private static Class c;
  private static boolean f;
  private static Field h;
  private static boolean i;
  private static boolean w;
  
  private static boolean a(Resources paramResources)
  {
    if (!i) {}
    try
    {
      Field localField1 = Resources.class.getDeclaredField("mResourcesImpl");
      B = localField1;
      localField1 = B;
      localField1.setAccessible(true);
    }
    catch (NoSuchFieldException localNoSuchFieldException1)
    {
      for (;;)
      {
        Log.e("ResourcesFlusher", "Could not retrieve Resources#mResourcesImpl field", localNoSuchFieldException1);
      }
      Field localField2 = B;
      try
      {
        paramResources = localField2.get(paramResources);
        if (paramResources == null) {
          break label173;
        }
        if (!w) {}
        try
        {
          localField2 = paramResources.getClass().getDeclaredField("mDrawableCache");
          h = localField2;
          localField2 = h;
          localField2.setAccessible(true);
        }
        catch (NoSuchFieldException localNoSuchFieldException2)
        {
          for (;;)
          {
            Log.e("ResourcesFlusher", "Could not retrieve ResourcesImpl#mDrawableCache field", localNoSuchFieldException2);
            continue;
            paramResources = null;
          }
        }
        w = true;
        if (h != null) {
          localField2 = h;
        }
      }
      catch (IllegalAccessException paramResources)
      {
        for (;;)
        {
          try
          {
            paramResources = localField2.get(paramResources);
            if ((paramResources == null) || (!a(paramResources))) {
              break;
            }
            return true;
          }
          catch (IllegalAccessException paramResources)
          {
            Log.e("ResourcesFlusher", "Could not retrieve value from ResourcesImpl#mDrawableCache", paramResources);
          }
          paramResources = paramResources;
          Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mResourcesImpl", paramResources);
          paramResources = null;
        }
      }
      return false;
    }
    i = true;
    return B != null;
  }
  
  private static boolean a(Object paramObject)
  {
    if (!a) {}
    try
    {
      Class localClass = Class.forName("android.content.res.ThemedResourceCache");
      c = localClass;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      for (;;)
      {
        Log.e("ResourcesFlusher", "Could not find ThemedResourceCache class", localClassNotFoundException);
      }
      if (f) {
        break label75;
      }
      Object localObject = c;
      try
      {
        localObject = ((Class)localObject).getDeclaredField("mUnthemedEntries");
        b = (Field)localObject;
        localObject = b;
        ((Field)localObject).setAccessible(true);
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        for (;;)
        {
          Log.e("ResourcesFlusher", "Could not retrieve ThemedResourceCache#mUnthemedEntries field", localNoSuchFieldException);
        }
        Field localField = b;
        try
        {
          paramObject = localField.get(paramObject);
          paramObject = (LongSparseArray)paramObject;
        }
        catch (IllegalAccessException paramObject)
        {
          for (;;)
          {
            Log.e("ResourcesFlusher", "Could not retrieve value from ThemedResourceCache#mUnthemedEntries", paramObject);
            paramObject = null;
          }
        }
        if (paramObject == null) {
          break label136;
        }
        paramObject.clear();
        return true;
      }
      f = true;
      if (b != null) {
        break label96;
      }
      return false;
    }
    a = true;
    return c != null;
  }
  
  static boolean b(Resources paramResources)
  {
    int j = Build.VERSION.SDK_INT;
    if (j >= 24) {
      return a(paramResources);
    }
    if (j >= 23) {
      return c(paramResources);
    }
    if (j >= 21) {
      return create(paramResources);
    }
    return false;
  }
  
  private static boolean c(Resources paramResources)
  {
    if (!w) {}
    try
    {
      localField = Resources.class.getDeclaredField("mDrawableCache");
      h = localField;
      localField = h;
      localField.setAccessible(true);
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      for (;;)
      {
        try
        {
          Field localField;
          paramResources = localField.get(paramResources);
          if (paramResources != null) {
            break;
          }
          return false;
        }
        catch (IllegalAccessException paramResources)
        {
          Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mDrawableCache", paramResources);
        }
        localNoSuchFieldException = localNoSuchFieldException;
        Log.e("ResourcesFlusher", "Could not retrieve Resources#mDrawableCache field", localNoSuchFieldException);
        continue;
        paramResources = null;
      }
      if ((paramResources == null) || (!a(paramResources))) {
        break label94;
      }
      return true;
    }
    w = true;
    if (h != null) {
      localField = h;
    }
    label94:
    return false;
  }
  
  private static boolean create(Resources paramResources)
  {
    if (!w) {}
    try
    {
      localField = Resources.class.getDeclaredField("mDrawableCache");
      h = localField;
      localField = h;
      localField.setAccessible(true);
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      for (;;)
      {
        Field localField;
        Log.e("ResourcesFlusher", "Could not retrieve Resources#mDrawableCache field", localNoSuchFieldException);
      }
    }
    w = true;
    if (h != null)
    {
      localField = h;
      try
      {
        paramResources = localField.get(paramResources);
        paramResources = (Map)paramResources;
      }
      catch (IllegalAccessException paramResources)
      {
        for (;;)
        {
          Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mDrawableCache", paramResources);
          paramResources = null;
        }
      }
      if (paramResources != null)
      {
        paramResources.clear();
        return true;
      }
    }
    return false;
  }
}

package android.support.v7.app;

import android.support.v4.view.ViewPropertyAnimatorUpdateListener;
import android.view.View;

class b
  implements ViewPropertyAnimatorUpdateListener
{
  b(WindowDecorActionBar paramWindowDecorActionBar) {}
  
  public void b(View paramView)
  {
    ((View)a.mContainerView.getParent()).invalidate();
  }
}

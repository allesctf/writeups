package android.support.v7.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;

final class MainActivity
{
  private IntentFilter filter;
  private boolean header;
  private BroadcastReceiver receiver;
  private TwilightManager title;
  
  MainActivity(AppCompatDelegateImplV14 paramAppCompatDelegateImplV14, TwilightManager paramTwilightManager)
  {
    title = paramTwilightManager;
    header = paramTwilightManager.isNight();
  }
  
  final int mapNightMode()
  {
    header = title.isNight();
    if (header) {
      return 2;
    }
    return 1;
  }
  
  final void onCreate()
  {
    boolean bool = title.isNight();
    if (bool != header)
    {
      header = bool;
      adapter.applyDayNight();
    }
  }
  
  final void onDestroy()
  {
    if (receiver != null)
    {
      adapter.mContext.unregisterReceiver(receiver);
      receiver = null;
    }
  }
  
  final void onResume()
  {
    onDestroy();
    if (receiver == null) {
      receiver = new i.b.1(this);
    }
    if (filter == null)
    {
      filter = new IntentFilter();
      filter.addAction("android.intent.action.TIME_SET");
      filter.addAction("android.intent.action.TIMEZONE_CHANGED");
      filter.addAction("android.intent.action.TIME_TICK");
    }
    adapter.mContext.registerReceiver(receiver, filter);
  }
}

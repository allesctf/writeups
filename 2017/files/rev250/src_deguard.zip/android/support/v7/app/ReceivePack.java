package android.support.v7.app;

import android.content.Context;
import android.view.Window;
import android.view.Window.Callback;

class ReceivePack
  extends AppCompatDelegateImplV23
{
  ReceivePack(Context paramContext, Window paramWindow, AppCompatCallback paramAppCompatCallback)
  {
    super(paramContext, paramWindow, paramAppCompatCallback);
  }
  
  Window.Callback wrapWindowCallback(Window.Callback paramCallback)
  {
    return new Roster.RosterPushListener(this, paramCallback);
  }
}

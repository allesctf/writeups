package android.support.v7.recyclerview.app;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.support.v4.graphics.ColorUtils;
import android.support.v7.appcompat.R.attr;
import android.support.v7.appcompat.R.styleable;
import android.util.AttributeSet;
import android.util.StateSet;
import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

final class PreferenceInflater
{
  private static int getThemeAttrColor(int paramInt, float paramFloat)
  {
    return ColorUtils.setAlphaComponent(paramInt, Math.round(Color.alpha(paramInt) * paramFloat));
  }
  
  public static ColorStateList inflate(Resources paramResources, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme)
  {
    AttributeSet localAttributeSet = Xml.asAttributeSet(paramXmlPullParser);
    int i;
    do
    {
      i = paramXmlPullParser.next();
    } while ((i != 2) && (i != 1));
    if (i != 2) {
      throw new XmlPullParserException("No start tag found");
    }
    return inflate(paramResources, paramXmlPullParser, localAttributeSet, paramTheme);
  }
  
  private static ColorStateList inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    String str = paramXmlPullParser.getName();
    if (!str.equals("selector")) {
      throw new XmlPullParserException(paramXmlPullParser.getPositionDescription() + ": invalid color state list tag " + str);
    }
    return init(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
  }
  
  private static ColorStateList init(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    int i1 = paramXmlPullParser.getDepth() + 1;
    Object localObject1 = new int[20][];
    int[] arrayOfInt = new int[localObject1.length];
    int i = 0;
    int j;
    int k;
    do
    {
      j = paramXmlPullParser.next();
      if (j == 1) {
        break;
      }
      k = paramXmlPullParser.getDepth();
      if ((k < i1) && (j == 3)) {
        break;
      }
    } while ((j != 2) || (k > i1) || (!paramXmlPullParser.getName().equals("item")));
    Object localObject2 = obtainAttributes(paramResources, paramTheme, paramAttributeSet, R.styleable.ColorStateListItem);
    int i2 = ((TypedArray)localObject2).getColor(R.styleable.ColorStateListItem_android_color, -65281);
    float f = 1.0F;
    label137:
    label162:
    int n;
    int m;
    if (((TypedArray)localObject2).hasValue(R.styleable.ColorStateListItem_android_alpha))
    {
      f = ((TypedArray)localObject2).getFloat(R.styleable.ColorStateListItem_android_alpha, 1.0F);
      ((TypedArray)localObject2).recycle();
      k = 0;
      int i3 = paramAttributeSet.getAttributeCount();
      localObject2 = new int[i3];
      j = 0;
      if (j >= i3) {
        break label272;
      }
      n = paramAttributeSet.getAttributeNameResource(j);
      m = n;
      if ((n == 16843173) || (n == 16843551) || (n == R.attr.alpha)) {
        break label380;
      }
      if (!paramAttributeSet.getAttributeBooleanValue(j, false)) {
        break label264;
      }
      label217:
      localObject2[k] = m;
      k += 1;
    }
    label264:
    label272:
    label380:
    for (;;)
    {
      j += 1;
      break label162;
      if (!((TypedArray)localObject2).hasValue(R.styleable.ColorStateListItem_alpha)) {
        break label137;
      }
      f = ((TypedArray)localObject2).getFloat(R.styleable.ColorStateListItem_alpha, 1.0F);
      break label137;
      m = -n;
      break label217;
      localObject2 = StateSet.trimStateSet((int[])localObject2, k);
      j = getThemeAttrColor(i2, f);
      if ((i != 0) && (localObject2.length == 0)) {}
      arrayOfInt = StringBlock.get(arrayOfInt, i, j);
      localObject1 = StringBlock.read((Object[])localObject1, i, localObject2);
      i += 1;
      localObject1 = (int[][])localObject1;
      break;
      paramResources = new int[i];
      paramXmlPullParser = new int[i][];
      System.arraycopy(arrayOfInt, 0, paramResources, 0, i);
      System.arraycopy(localObject1, 0, paramXmlPullParser, 0, i);
      return new ColorStateList(paramXmlPullParser, paramResources);
    }
  }
  
  private static TypedArray obtainAttributes(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int[] paramArrayOfInt)
  {
    if (paramTheme == null) {
      return paramResources.obtainAttributes(paramAttributeSet, paramArrayOfInt);
    }
    return paramTheme.obtainStyledAttributes(paramAttributeSet, paramArrayOfInt, 0, 0);
  }
}

package android.support.v7.recyclerview.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v4.content.ContextCompat;
import android.support.v7.b.a.b.a;
import android.support.v7.widget.AppCompatDrawableManager;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import java.util.WeakHashMap;

public final class TintManager
{
  private static final ThreadLocal<TypedValue> TL_TYPED_VALUE = new ThreadLocal();
  private static final WeakHashMap<Context, SparseArray<b.a>> d = new WeakHashMap(0);
  private static final Object e = new Object();
  
  private static ColorStateList a(Context paramContext, int paramInt)
  {
    Object localObject = e;
    try
    {
      SparseArray localSparseArray = (SparseArray)d.get(paramContext);
      if ((localSparseArray != null) && (localSparseArray.size() > 0))
      {
        x localX = (x)localSparseArray.get(paramInt);
        if (localX != null)
        {
          if (d.equals(paramContext.getResources().getConfiguration()))
          {
            paramContext = c;
            return paramContext;
          }
          localSparseArray.remove(paramInt);
        }
      }
      return null;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  private static void a(Context paramContext, int paramInt, ColorStateList paramColorStateList)
  {
    Object localObject = e;
    try
    {
      SparseArray localSparseArray2 = (SparseArray)d.get(paramContext);
      SparseArray localSparseArray1 = localSparseArray2;
      if (localSparseArray2 == null)
      {
        localSparseArray1 = new SparseArray();
        d.put(paramContext, localSparseArray1);
      }
      localSparseArray1.append(paramInt, new x(paramColorStateList, paramContext.getResources().getConfiguration()));
      return;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  private static ColorStateList b(Context paramContext, int paramInt)
  {
    if (get(paramContext, paramInt)) {
      return null;
    }
    Resources localResources = paramContext.getResources();
    XmlResourceParser localXmlResourceParser = localResources.getXml(paramInt);
    try
    {
      paramContext = PreferenceInflater.inflate(localResources, localXmlResourceParser, paramContext.getTheme());
      return paramContext;
    }
    catch (Exception paramContext)
    {
      Log.e("AppCompatResources", "Failed to inflate ColorStateList, leaving it to the framework", paramContext);
    }
    return null;
  }
  
  private static boolean get(Context paramContext, int paramInt)
  {
    paramContext = paramContext.getResources();
    TypedValue localTypedValue = getTypedValue();
    paramContext.getValue(paramInt, localTypedValue, true);
    return (type >= 28) && (type <= 31);
  }
  
  public static Drawable getDrawable(Context paramContext, int paramInt)
  {
    return AppCompatDrawableManager.get().getDrawable(paramContext, paramInt);
  }
  
  private static TypedValue getTypedValue()
  {
    TypedValue localTypedValue2 = (TypedValue)TL_TYPED_VALUE.get();
    TypedValue localTypedValue1 = localTypedValue2;
    if (localTypedValue2 == null)
    {
      localTypedValue1 = new TypedValue();
      TL_TYPED_VALUE.set(localTypedValue1);
    }
    return localTypedValue1;
  }
  
  public static ColorStateList onCreateView(Context paramContext, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23) {
      return paramContext.getColorStateList(paramInt);
    }
    ColorStateList localColorStateList2 = a(paramContext, paramInt);
    ColorStateList localColorStateList1 = localColorStateList2;
    if (localColorStateList2 == null)
    {
      localColorStateList1 = b(paramContext, paramInt);
      if (localColorStateList1 != null)
      {
        a(paramContext, paramInt, localColorStateList1);
        return localColorStateList1;
      }
      localColorStateList1 = ContextCompat.getColorStateList(paramContext, paramInt);
    }
    return localColorStateList1;
  }
}

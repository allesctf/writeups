package android.support.v7.recyclerview.app;

import android.content.res.ColorStateList;
import android.content.res.Configuration;

class x
{
  final ColorStateList c;
  final Configuration d;
  
  x(ColorStateList paramColorStateList, Configuration paramConfiguration)
  {
    c = paramColorStateList;
    d = paramConfiguration;
  }
}

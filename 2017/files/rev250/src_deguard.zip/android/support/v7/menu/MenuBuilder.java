package android.support.v7.menu;

import android.view.ViewGroup;

public class MenuBuilder
{
  public static void getItem(ViewGroup paramViewGroup) {}
}

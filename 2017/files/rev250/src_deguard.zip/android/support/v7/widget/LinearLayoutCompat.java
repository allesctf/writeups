package android.support.v7.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R.styleable;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityRecord;

public class LinearLayoutCompat
  extends ViewGroup
{
  private boolean mBaselineAligned = true;
  private int mBaselineAlignedChildIndex = -1;
  private int mBaselineChildTop = 0;
  private Drawable mDivider;
  private int mDividerHeight;
  private int mDividerPadding;
  private int mDividerWidth;
  private int mGravity = 8388659;
  private int[] mMaxAscent;
  private int[] mMaxDescent;
  private int mOrientation;
  private int mShowDividers;
  private int mTotalLength;
  private boolean mUseLargestChild;
  private float mWeightSum;
  
  public LinearLayoutCompat(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    paramContext = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, R.styleable.LinearLayoutCompat, paramInt, 0);
    paramInt = paramContext.getInt(R.styleable.LinearLayoutCompat_android_orientation, -1);
    if (paramInt >= 0) {
      setOrientation(paramInt);
    }
    paramInt = paramContext.getInt(R.styleable.LinearLayoutCompat_android_gravity, -1);
    if (paramInt >= 0) {
      setGravity(paramInt);
    }
    boolean bool = paramContext.getBoolean(R.styleable.LinearLayoutCompat_android_baselineAligned, true);
    if (!bool) {
      setBaselineAligned(bool);
    }
    mWeightSum = paramContext.getFloat(R.styleable.LinearLayoutCompat_android_weightSum, -1.0F);
    mBaselineAlignedChildIndex = paramContext.getInt(R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
    mUseLargestChild = paramContext.getBoolean(R.styleable.LinearLayoutCompat_measureWithLargestChild, false);
    setDividerDrawable(paramContext.getDrawable(R.styleable.LinearLayoutCompat_divider));
    mShowDividers = paramContext.getInt(R.styleable.LinearLayoutCompat_showDividers, 0);
    mDividerPadding = paramContext.getDimensionPixelSize(R.styleable.LinearLayoutCompat_dividerPadding, 0);
    paramContext.recycle();
  }
  
  private void forceUniformHeight(int paramInt1, int paramInt2)
  {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    int i = 0;
    while (i < paramInt1)
    {
      View localView = getVirtualChildAt(i);
      if (localView.getVisibility() != 8)
      {
        ah.a localA = (ah.a)localView.getLayoutParams();
        if (height == -1)
        {
          int k = width;
          width = localView.getMeasuredWidth();
          measureChildWithMargins(localView, paramInt2, 0, j, 0);
          width = k;
        }
      }
      i += 1;
    }
  }
  
  private void forceUniformWidth(int paramInt1, int paramInt2)
  {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    int i = 0;
    while (i < paramInt1)
    {
      View localView = getVirtualChildAt(i);
      if (localView.getVisibility() != 8)
      {
        ah.a localA = (ah.a)localView.getLayoutParams();
        if (width == -1)
        {
          int k = height;
          height = localView.getMeasuredHeight();
          measureChildWithMargins(localView, j, 0, paramInt2, 0);
          height = k;
        }
      }
      i += 1;
    }
  }
  
  private void setChildFrame(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramView.layout(paramInt1, paramInt2, paramInt1 + paramInt3, paramInt2 + paramInt4);
  }
  
  protected ah.a a()
  {
    if (mOrientation == 0) {
      return new ah.a(-2, -2);
    }
    if (mOrientation == 1) {
      return new ah.a(-1, -2);
    }
    return null;
  }
  
  protected ah.a b(ViewGroup.LayoutParams paramLayoutParams)
  {
    return new ah.a(paramLayoutParams);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return paramLayoutParams instanceof ah.a;
  }
  
  void drawDividersHorizontal(Canvas paramCanvas)
  {
    int k = getVirtualChildCount();
    boolean bool = ViewUtils.isLayoutRtl(this);
    int i = 0;
    View localView;
    ah.a localA;
    if (i < k)
    {
      localView = getVirtualChildAt(i);
      if ((localView != null) && (localView.getVisibility() != 8) && (hasDividerBeforeChildAt(i)))
      {
        localA = (ah.a)localView.getLayoutParams();
        if (!bool) {
          break label92;
        }
        j = localView.getRight();
      }
      label92:
      for (int j = rightMargin + j;; j = localView.getLeft() - leftMargin - mDividerWidth)
      {
        drawVerticalDivider(paramCanvas, j);
        i += 1;
        break;
      }
    }
    if (hasDividerBeforeChildAt(k))
    {
      localView = getVirtualChildAt(k - 1);
      if (localView == null) {
        if (bool) {
          i = getPaddingLeft();
        }
      }
      for (;;)
      {
        drawVerticalDivider(paramCanvas, i);
        return;
        i = getWidth() - getPaddingRight() - mDividerWidth;
        continue;
        localA = (ah.a)localView.getLayoutParams();
        if (bool)
        {
          i = localView.getLeft() - leftMargin - mDividerWidth;
        }
        else
        {
          i = localView.getRight();
          i = rightMargin + i;
        }
      }
    }
  }
  
  void drawDividersVertical(Canvas paramCanvas)
  {
    int j = getVirtualChildCount();
    int i = 0;
    View localView;
    ah.a localA;
    while (i < j)
    {
      localView = getVirtualChildAt(i);
      if ((localView != null) && (localView.getVisibility() != 8) && (hasDividerBeforeChildAt(i)))
      {
        localA = (ah.a)localView.getLayoutParams();
        drawHorizontalDivider(paramCanvas, localView.getTop() - topMargin - mDividerHeight);
      }
      i += 1;
    }
    if (hasDividerBeforeChildAt(j))
    {
      localView = getVirtualChildAt(j - 1);
      if (localView == null) {}
      for (i = getHeight() - getPaddingBottom() - mDividerHeight;; i = bottomMargin + i)
      {
        drawHorizontalDivider(paramCanvas, i);
        return;
        localA = (ah.a)localView.getLayoutParams();
        i = localView.getBottom();
      }
    }
  }
  
  void drawHorizontalDivider(Canvas paramCanvas, int paramInt)
  {
    mDivider.setBounds(getPaddingLeft() + mDividerPadding, paramInt, getWidth() - getPaddingRight() - mDividerPadding, mDividerHeight + paramInt);
    mDivider.draw(paramCanvas);
  }
  
  void drawVerticalDivider(Canvas paramCanvas, int paramInt)
  {
    mDivider.setBounds(paramInt, getPaddingTop() + mDividerPadding, mDividerWidth + paramInt, getHeight() - getPaddingBottom() - mDividerPadding);
    mDivider.draw(paramCanvas);
  }
  
  public int getBaseline()
  {
    if (mBaselineAlignedChildIndex < 0) {
      return super.getBaseline();
    }
    if (getChildCount() <= mBaselineAlignedChildIndex) {
      throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
    }
    View localView = getChildAt(mBaselineAlignedChildIndex);
    int k = localView.getBaseline();
    if (k == -1)
    {
      if (mBaselineAlignedChildIndex != 0) {
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      }
    }
    else
    {
      int j = mBaselineChildTop;
      int i = j;
      if (mOrientation == 1)
      {
        int m = mGravity & 0x70;
        i = j;
        if (m != 48) {
          switch (m)
          {
          default: 
            i = j;
            break;
          }
        }
      }
      for (;;)
      {
        return getLayoutParamstopMargin + i + k;
        i = getBottom() - getTop() - getPaddingBottom() - mTotalLength;
        continue;
        i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - mTotalLength) / 2;
      }
    }
    return -1;
  }
  
  public int getBaselineAlignedChildIndex()
  {
    return mBaselineAlignedChildIndex;
  }
  
  int getChildrenSkipCount(View paramView, int paramInt)
  {
    return 0;
  }
  
  public Drawable getDividerDrawable()
  {
    return mDivider;
  }
  
  public int getDividerPadding()
  {
    return mDividerPadding;
  }
  
  public int getDividerWidth()
  {
    return mDividerWidth;
  }
  
  public int getGravity()
  {
    return mGravity;
  }
  
  int getLocationOffset(View paramView)
  {
    return 0;
  }
  
  int getNextLocationOffset(View paramView)
  {
    return 0;
  }
  
  public int getOrientation()
  {
    return mOrientation;
  }
  
  public int getShowDividers()
  {
    return mShowDividers;
  }
  
  View getVirtualChildAt(int paramInt)
  {
    return getChildAt(paramInt);
  }
  
  int getVirtualChildCount()
  {
    return getChildCount();
  }
  
  public float getWeightSum()
  {
    return mWeightSum;
  }
  
  protected boolean hasDividerBeforeChildAt(int paramInt)
  {
    if (paramInt == 0) {
      return (mShowDividers & 0x1) != 0;
    }
    if (paramInt == getChildCount())
    {
      if ((mShowDividers & 0x4) == 0) {
        return false;
      }
    }
    else
    {
      if ((mShowDividers & 0x2) != 0)
      {
        paramInt -= 1;
        while (paramInt >= 0)
        {
          if (getChildAt(paramInt).getVisibility() != 8) {
            break label75;
          }
          paramInt -= 1;
        }
      }
      return false;
    }
    label75:
    return true;
  }
  
  void layoutHorizontal(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    boolean bool1 = ViewUtils.isLayoutRtl(this);
    int k = getPaddingTop();
    int n = paramInt4 - paramInt2;
    int i1 = getPaddingBottom();
    int i2 = getPaddingBottom();
    int i3 = getVirtualChildCount();
    paramInt2 = mGravity;
    int i4 = mGravity;
    boolean bool2 = mBaselineAligned;
    int[] arrayOfInt1 = mMaxAscent;
    int[] arrayOfInt2 = mMaxDescent;
    switch (GravityCompat.getAbsoluteGravity(paramInt2 & 0x800007, ViewCompat.getLayoutDirection(this)))
    {
    default: 
      paramInt1 = getPaddingLeft();
      if (bool1) {
        paramInt4 = -1;
      }
      break;
    }
    for (int i = i3 - 1;; i = 0)
    {
      paramInt2 = 0;
      paramInt3 = paramInt1;
      label130:
      int i5;
      View localView;
      if (paramInt2 < i3)
      {
        i5 = i + paramInt4 * paramInt2;
        localView = getVirtualChildAt(i5);
        if (localView == null) {
          paramInt3 += measureNullChild(i5);
        }
      }
      for (;;)
      {
        paramInt2 += 1;
        break label130;
        paramInt1 = getPaddingLeft() + paramInt3 - paramInt1 - mTotalLength;
        break;
        paramInt1 = getPaddingLeft() + (paramInt3 - paramInt1 - mTotalLength) / 2;
        break;
        if (localView.getVisibility() != 8)
        {
          int i6 = localView.getMeasuredWidth();
          int i7 = localView.getMeasuredHeight();
          ah.a localA = (ah.a)localView.getLayoutParams();
          if ((bool2) && (height != -1)) {}
          for (int j = localView.getBaseline();; j = -1)
          {
            int m = gravity;
            paramInt1 = m;
            if (m < 0) {
              paramInt1 = i4 & 0x70;
            }
            switch (paramInt1 & 0x70)
            {
            default: 
              paramInt1 = k;
              label330:
              if (hasDividerBeforeChildAt(i5)) {
                paramInt3 = mDividerWidth + paramInt3;
              }
              break;
            }
            for (;;)
            {
              paramInt3 += leftMargin;
              setChildFrame(localView, paramInt3 + getLocationOffset(localView), paramInt1, i6, i7);
              paramInt3 += rightMargin + i6 + getNextLocationOffset(localView);
              paramInt2 = getChildrenSkipCount(localView, i5) + paramInt2;
              break;
              m = k + topMargin;
              paramInt1 = m;
              if (j == -1) {
                break label330;
              }
              paramInt1 = m + (arrayOfInt1[1] - j);
              break label330;
              paramInt1 = (n - k - i2 - i7) / 2 + k + topMargin - bottomMargin;
              break label330;
              m = n - i1 - i7 - bottomMargin;
              paramInt1 = m;
              if (j == -1) {
                break label330;
              }
              paramInt1 = localView.getMeasuredHeight();
              paramInt1 = m - (arrayOfInt2[2] - (paramInt1 - j));
              break label330;
              return;
            }
          }
        }
      }
      paramInt4 = 1;
    }
  }
  
  void layoutVertical(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    paramInt1 = mGravity;
    int i1 = mGravity;
    label86:
    View localView;
    switch (paramInt1 & 0x70)
    {
    default: 
      paramInt1 = getPaddingTop();
      paramInt3 = 0;
      paramInt2 = paramInt1;
      paramInt1 = paramInt3;
      if (paramInt1 < n)
      {
        localView = getVirtualChildAt(paramInt1);
        if (localView == null) {
          paramInt2 += measureNullChild(paramInt1);
        }
      }
      break;
    }
    for (;;)
    {
      paramInt1 += 1;
      break label86;
      paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - mTotalLength;
      break;
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - mTotalLength) / 2;
      break;
      if (localView.getVisibility() != 8)
      {
        int i2 = localView.getMeasuredWidth();
        int i3 = localView.getMeasuredHeight();
        ah.a localA = (ah.a)localView.getLayoutParams();
        paramInt4 = gravity;
        paramInt3 = paramInt4;
        if (paramInt4 < 0) {
          paramInt3 = i1 & 0x800007;
        }
        switch (GravityCompat.getAbsoluteGravity(paramInt3, ViewCompat.getLayoutDirection(this)) & 0x7)
        {
        default: 
          paramInt3 = i + leftMargin;
          label264:
          if (hasDividerBeforeChildAt(paramInt1)) {
            paramInt2 = mDividerHeight + paramInt2;
          }
          break;
        }
        for (;;)
        {
          paramInt2 += topMargin;
          setChildFrame(localView, paramInt3, paramInt2 + getLocationOffset(localView), i2, i3);
          paramInt2 += bottomMargin + i3 + getNextLocationOffset(localView);
          paramInt1 = getChildrenSkipCount(localView, paramInt1) + paramInt1;
          break;
          paramInt3 = (j - i - m - i2) / 2 + i + leftMargin - rightMargin;
          break label264;
          paramInt3 = j - k - i2 - rightMargin;
          break label264;
          return;
        }
      }
    }
  }
  
  void measureChildBeforeLayout(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  void measureHorizontal(int paramInt1, int paramInt2)
  {
    mTotalLength = 0;
    int i4 = 0;
    int k = 0;
    int i = 0;
    int n = 0;
    int j = 1;
    float f1 = 0.0F;
    int i10 = getVirtualChildCount();
    int i12 = View.MeasureSpec.getMode(paramInt1);
    int i11 = View.MeasureSpec.getMode(paramInt2);
    int m = 0;
    int i3 = 0;
    if ((mMaxAscent == null) || (mMaxDescent == null))
    {
      mMaxAscent = new int[4];
      mMaxDescent = new int[4];
    }
    Object localObject = mMaxAscent;
    int[] arrayOfInt = mMaxDescent;
    localObject[3] = -1;
    localObject[2] = -1;
    localObject[1] = -1;
    localObject[0] = -1;
    arrayOfInt[3] = -1;
    arrayOfInt[2] = -1;
    arrayOfInt[1] = -1;
    arrayOfInt[0] = -1;
    boolean bool1 = mBaselineAligned;
    boolean bool2 = mUseLargestChild;
    int i7;
    int i1;
    int i2;
    label156:
    View localView;
    if (i12 == 1073741824)
    {
      i7 = 1;
      i1 = Integer.MIN_VALUE;
      i2 = 0;
      if (i2 >= i10) {
        break label861;
      }
      localView = getVirtualChildAt(i2);
      if (localView != null) {
        break label206;
      }
      mTotalLength += measureNullChild(i2);
    }
    for (;;)
    {
      i2 += 1;
      break label156;
      i7 = 0;
      break;
      label206:
      if (localView.getVisibility() != 8) {
        break label232;
      }
      i2 += getChildrenSkipCount(localView, i2);
    }
    label232:
    if (hasDividerBeforeChildAt(i2)) {
      mTotalLength += mDividerWidth;
    }
    ah.a localA = (ah.a)localView.getLayoutParams();
    f1 += weight;
    label322:
    int i5;
    int i6;
    if ((i12 == 1073741824) && (width == 0) && (weight > 0.0F)) {
      if (i7 != 0)
      {
        mTotalLength += leftMargin + rightMargin;
        if (!bool1) {
          break label604;
        }
        i5 = View.MeasureSpec.makeMeasureSpec(0, 0);
        localView.measure(i5, i5);
        i6 = i1;
        i5 = i3;
        label351:
        i1 = 0;
        if ((i11 == 1073741824) || (height != -1)) {
          break label2186;
        }
        m = 1;
        i1 = 1;
      }
    }
    label447:
    label520:
    label604:
    label667:
    label772:
    label814:
    label830:
    label837:
    label861:
    label1559:
    label1578:
    label1619:
    label1645:
    label1816:
    label1822:
    label1829:
    label1835:
    label2176:
    label2186:
    for (;;)
    {
      i3 = topMargin;
      i3 = bottomMargin + i3;
      int i8 = localView.getMeasuredHeight() + i3;
      int i9 = ViewUtils.combineMeasuredStates(k, localView.getMeasuredState());
      if (bool1)
      {
        int i13 = localView.getBaseline();
        if (i13 != -1)
        {
          if (gravity >= 0) {
            break label814;
          }
          k = mGravity;
          k = ((k & 0x70) >> 4 & 0xFFFFFFFE) >> 1;
          localObject[k] = Math.max(localObject[k], i13);
          arrayOfInt[k] = Math.max(arrayOfInt[k], i8 - i13);
        }
      }
      i4 = Math.max(i4, i8);
      if ((j != 0) && (height == -1))
      {
        j = 1;
        if (weight <= 0.0F) {
          break label837;
        }
        if (i1 == 0) {
          break label830;
        }
      }
      for (;;)
      {
        n = Math.max(n, i3);
        i2 += getChildrenSkipCount(localView, i2);
        k = i9;
        i3 = i5;
        i1 = i6;
        break;
        i5 = mTotalLength;
        mTotalLength = Math.max(i5, leftMargin + i5 + rightMargin);
        break label322;
        i5 = 1;
        i6 = i1;
        break label351;
        i6 = Integer.MIN_VALUE;
        i5 = i6;
        if (width == 0)
        {
          i5 = i6;
          if (weight > 0.0F)
          {
            i5 = 0;
            width = -2;
          }
        }
        if (f1 == 0.0F)
        {
          i6 = mTotalLength;
          measureChildBeforeLayout(localView, i2, paramInt1, i6, paramInt2, 0);
          if (i5 != Integer.MIN_VALUE) {
            width = i5;
          }
          i8 = localView.getMeasuredWidth();
          if (i7 == 0) {
            break label772;
          }
        }
        for (mTotalLength += leftMargin + i8 + rightMargin + getNextLocationOffset(localView);; mTotalLength = Math.max(i5, i5 + i8 + leftMargin + rightMargin + getNextLocationOffset(localView)))
        {
          i5 = i3;
          i6 = i1;
          if (!bool2) {
            break;
          }
          i6 = Math.max(i8, i1);
          i5 = i3;
          break;
          i6 = 0;
          break label667;
          i5 = mTotalLength;
        }
        k = gravity;
        break label447;
        j = 0;
        break label520;
        i3 = i8;
      }
      if (i1 != 0) {}
      for (;;)
      {
        i = Math.max(i, i3);
        break;
        i3 = i8;
      }
      if ((mTotalLength > 0) && (hasDividerBeforeChildAt(i10))) {
        mTotalLength += mDividerWidth;
      }
      if ((localObject[1] != -1) || (localObject[0] != -1) || (localObject[2] != -1) || (localObject[3] != -1)) {}
      for (i2 = Math.max(i4, Math.max(localObject[3], Math.max(localObject[0], Math.max(localObject[1], localObject[2]))) + Math.max(arrayOfInt[3], Math.max(arrayOfInt[0], Math.max(arrayOfInt[1], arrayOfInt[2]))));; i2 = i4)
      {
        if ((bool2) && ((i12 == Integer.MIN_VALUE) || (i12 == 0)))
        {
          mTotalLength = 0;
          i4 = 0;
          if (i4 < i10)
          {
            localView = getVirtualChildAt(i4);
            if (localView == null) {
              mTotalLength += measureNullChild(i4);
            }
            for (;;)
            {
              i4 += 1;
              break;
              if (localView.getVisibility() == 8)
              {
                i4 = getChildrenSkipCount(localView, i4) + i4;
              }
              else
              {
                localA = (ah.a)localView.getLayoutParams();
                if (i7 != 0)
                {
                  i5 = mTotalLength;
                  i6 = leftMargin;
                  mTotalLength = (rightMargin + (i6 + i1) + getNextLocationOffset(localView) + i5);
                }
                else
                {
                  i5 = mTotalLength;
                  i6 = leftMargin;
                  mTotalLength = Math.max(i5, rightMargin + (i5 + i1 + i6) + getNextLocationOffset(localView));
                }
              }
            }
          }
        }
        mTotalLength += getPaddingLeft() + getPaddingRight();
        i8 = View.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumWidth()), paramInt1, 0);
        i4 = (0xFFFFFF & i8) - mTotalLength;
        if ((i3 != 0) || ((i4 != 0) && (f1 > 0.0F)))
        {
          if (mWeightSum > 0.0F) {
            f1 = mWeightSum;
          }
          localObject[3] = -1;
          localObject[2] = -1;
          localObject[1] = -1;
          localObject[0] = -1;
          arrayOfInt[3] = -1;
          arrayOfInt[2] = -1;
          arrayOfInt[1] = -1;
          arrayOfInt[0] = -1;
          mTotalLength = 0;
          i2 = 0;
          n = j;
          j = i;
          i = k;
          i1 = i4;
          i3 = -1;
          k = n;
          n = i3;
          if (i2 < i10)
          {
            localView = getVirtualChildAt(i2);
            if (localView == null) {
              break label2176;
            }
            if (localView.getVisibility() != 8) {}
          }
        }
        for (;;)
        {
          i2 += 1;
          break;
          localA = (ah.a)localView.getLayoutParams();
          float f2 = weight;
          if (f2 > 0.0F)
          {
            i4 = (int)(i1 * f2 / f1);
            f1 -= f2;
            i3 = i1 - i4;
            i5 = ViewGroup.getChildMeasureSpec(paramInt2, getPaddingTop() + getPaddingBottom() + topMargin + bottomMargin, height);
            if ((width != 0) || (i12 != 1073741824))
            {
              i4 += localView.getMeasuredWidth();
              i1 = i4;
              if (i4 < 0) {
                i1 = 0;
              }
              localView.measure(View.MeasureSpec.makeMeasureSpec(i1, 1073741824), i5);
              i = View.combineMeasuredStates(i, localView.getMeasuredState() & 0xFF000000);
              i1 = i3;
            }
          }
          for (;;)
          {
            if (i7 != 0)
            {
              mTotalLength += localView.getMeasuredWidth() + leftMargin + rightMargin + getNextLocationOffset(localView);
              if ((i11 == 1073741824) || (height != -1)) {
                break label1816;
              }
              i3 = 1;
              i6 = topMargin + bottomMargin;
              i4 = localView.getMeasuredHeight() + i6;
              i5 = Math.max(n, i4);
              if (i3 == 0) {
                break label1822;
              }
              n = i6;
              i3 = Math.max(j, n);
              if ((k == 0) || (height != -1)) {
                break label1829;
              }
              j = 1;
              if (bool1)
              {
                n = localView.getBaseline();
                if (n != -1) {
                  if (gravity >= 0) {
                    break label1835;
                  }
                }
              }
            }
            for (k = mGravity;; k = gravity)
            {
              k = ((k & 0x70) >> 4 & 0xFFFFFFFE) >> 1;
              localObject[k] = Math.max(localObject[k], n);
              arrayOfInt[k] = Math.max(arrayOfInt[k], i4 - n);
              n = i5;
              k = j;
              j = i3;
              break;
              if (i4 > 0) {}
              for (i1 = i4;; i1 = 0)
              {
                localView.measure(View.MeasureSpec.makeMeasureSpec(i1, 1073741824), i5);
                break;
              }
              i3 = mTotalLength;
              mTotalLength = Math.max(i3, localView.getMeasuredWidth() + i3 + leftMargin + rightMargin + getNextLocationOffset(localView));
              break label1559;
              i3 = 0;
              break label1578;
              n = i4;
              break label1619;
              j = 0;
              break label1645;
            }
            mTotalLength += getPaddingLeft() + getPaddingRight();
            if ((localObject[1] == -1) && (localObject[0] == -1) && (localObject[2] == -1))
            {
              i1 = n;
              if (localObject[3] == -1) {}
            }
            else
            {
              i1 = Math.max(n, Math.max(localObject[3], Math.max(localObject[0], Math.max(localObject[1], localObject[2]))) + Math.max(arrayOfInt[3], Math.max(arrayOfInt[0], Math.max(arrayOfInt[1], arrayOfInt[2]))));
            }
            i2 = j;
            n = i;
            j = i1;
            i = i2;
            i1 = k;
            k = n;
            for (;;)
            {
              if ((i1 == 0) && (i11 != 1073741824)) {}
              for (;;)
              {
                setMeasuredDimension(0xFF000000 & k | i8, View.resolveSizeAndState(Math.max(i + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), paramInt2, k << 16));
                if (m == 0) {
                  return;
                }
                forceUniformHeight(i10, paramInt1);
                return;
                n = Math.max(i, n);
                if ((!bool2) || (i12 == 1073741824)) {
                  break;
                }
                i = 0;
                if (i >= i10) {
                  break;
                }
                localObject = getVirtualChildAt(i);
                if ((localObject == null) || (((View)localObject).getVisibility() == 8)) {}
                for (;;)
                {
                  i += 1;
                  break;
                  if (getLayoutParamsweight > 0.0F) {
                    ((View)localObject).measure(View.MeasureSpec.makeMeasureSpec(i1, 1073741824), View.MeasureSpec.makeMeasureSpec(((View)localObject).getMeasuredHeight(), 1073741824));
                  }
                }
                i = j;
              }
              i = n;
              i1 = j;
              j = i2;
            }
          }
        }
      }
    }
  }
  
  int measureNullChild(int paramInt)
  {
    return 0;
  }
  
  void measureVertical(int paramInt1, int paramInt2)
  {
    mTotalLength = 0;
    int m = 0;
    int j = 0;
    int i = 0;
    int i1 = 0;
    int k = 1;
    float f1 = 0.0F;
    int i9 = getVirtualChildCount();
    int i10 = View.MeasureSpec.getMode(paramInt1);
    int i11 = View.MeasureSpec.getMode(paramInt2);
    int n = 0;
    int i4 = 0;
    int i12 = mBaselineAlignedChildIndex;
    boolean bool = mUseLargestChild;
    int i2 = Integer.MIN_VALUE;
    int i3 = 0;
    View localView;
    int i7;
    label148:
    ah.a localA;
    int i6;
    int i5;
    if (i3 < i9)
    {
      localView = getVirtualChildAt(i3);
      if (localView == null) {
        mTotalLength += measureNullChild(i3);
      }
      for (i7 = j;; i7 = j)
      {
        i3 += 1;
        j = i7;
        break;
        if (localView.getVisibility() != 8) {
          break label148;
        }
        i3 += getChildrenSkipCount(localView, i3);
      }
      if (hasDividerBeforeChildAt(i3)) {
        mTotalLength += mDividerHeight;
      }
      localA = (ah.a)localView.getLayoutParams();
      f1 += weight;
      if ((i11 == 1073741824) && (height == 0) && (weight > 0.0F))
      {
        i4 = mTotalLength;
        mTotalLength = Math.max(i4, topMargin + i4 + bottomMargin);
        i6 = 1;
        i5 = i2;
        if ((i12 >= 0) && (i12 == i3 + 1)) {
          mBaselineChildTop = mTotalLength;
        }
        if ((i3 < i12) && (weight > 0.0F)) {
          throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
        }
      }
      else
      {
        i6 = Integer.MIN_VALUE;
        i5 = i6;
        if (height == 0)
        {
          i5 = i6;
          if (weight > 0.0F)
          {
            i5 = 0;
            height = -2;
          }
        }
        if (f1 == 0.0F) {}
        for (i6 = mTotalLength;; i6 = 0)
        {
          measureChildBeforeLayout(localView, i3, paramInt1, 0, paramInt2, i6);
          if (i5 != Integer.MIN_VALUE) {
            height = i5;
          }
          i7 = localView.getMeasuredHeight();
          i5 = mTotalLength;
          mTotalLength = Math.max(i5, i5 + i7 + topMargin + bottomMargin + getNextLocationOffset(localView));
          i6 = i4;
          i5 = i2;
          if (!bool) {
            break;
          }
          i5 = Math.max(i7, i2);
          i6 = i4;
          break;
        }
      }
      i2 = 0;
      if ((i10 == 1073741824) || (width != -1)) {
        break label1549;
      }
      n = 1;
      i2 = 1;
    }
    label551:
    label613:
    label620:
    label1179:
    label1188:
    label1317:
    label1324:
    label1538:
    label1549:
    for (;;)
    {
      i4 = leftMargin;
      i4 = rightMargin + i4;
      i7 = localView.getMeasuredWidth() + i4;
      m = Math.max(m, i7);
      int i8 = View.combineMeasuredStates(j, localView.getMeasuredState());
      if ((k != 0) && (width == -1))
      {
        j = 1;
        if (weight <= 0.0F) {
          break label620;
        }
        if (i2 == 0) {
          break label613;
        }
      }
      for (;;)
      {
        i1 = Math.max(i1, i4);
        i3 += getChildrenSkipCount(localView, i3);
        i7 = i8;
        k = j;
        i4 = i6;
        i2 = i5;
        break;
        j = 0;
        break label551;
        i4 = i7;
      }
      if (i2 != 0) {}
      for (;;)
      {
        i = Math.max(i, i4);
        break;
        i4 = i7;
      }
      if ((mTotalLength > 0) && (hasDividerBeforeChildAt(i9))) {
        mTotalLength += mDividerHeight;
      }
      if ((bool) && ((i11 == Integer.MIN_VALUE) || (i11 == 0)))
      {
        mTotalLength = 0;
        i3 = 0;
        if (i3 < i9)
        {
          localView = getVirtualChildAt(i3);
          if (localView == null) {
            mTotalLength += measureNullChild(i3);
          }
          for (;;)
          {
            i3 += 1;
            break;
            if (localView.getVisibility() == 8)
            {
              i3 = getChildrenSkipCount(localView, i3) + i3;
            }
            else
            {
              localA = (ah.a)localView.getLayoutParams();
              i5 = mTotalLength;
              i6 = topMargin;
              mTotalLength = Math.max(i5, bottomMargin + (i5 + i2 + i6) + getNextLocationOffset(localView));
            }
          }
        }
      }
      mTotalLength += getPaddingTop() + getPaddingBottom();
      i6 = View.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumHeight()), paramInt2, 0);
      i3 = (0xFFFFFF & i6) - mTotalLength;
      if ((i4 != 0) || ((i3 != 0) && (f1 > 0.0F)))
      {
        if (mWeightSum > 0.0F) {
          f1 = mWeightSum;
        }
        mTotalLength = 0;
        i1 = 0;
        i2 = i3;
        i3 = i1;
        for (;;)
        {
          if (i3 < i9)
          {
            localView = getVirtualChildAt(i3);
            if (localView.getVisibility() == 8)
            {
              i4 = k;
              k = i;
              i1 = j;
              i3 += 1;
              j = i1;
              i = k;
              k = i4;
            }
            else
            {
              localA = (ah.a)localView.getLayoutParams();
              float f2 = weight;
              if (f2 <= 0.0F) {
                break label1538;
              }
              i1 = (int)(i2 * f2 / f1);
              f1 -= f2;
              i2 -= i1;
              i5 = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + leftMargin + rightMargin, width);
              if ((height != 0) || (i11 != 1073741824))
              {
                i4 = i1 + localView.getMeasuredHeight();
                i1 = i4;
                if (i4 < 0) {
                  i1 = 0;
                }
                localView.measure(i5, View.MeasureSpec.makeMeasureSpec(i1, 1073741824));
                i1 = View.combineMeasuredStates(j, localView.getMeasuredState() & 0xFF00);
              }
            }
          }
        }
      }
      for (j = i2;; j = i2)
      {
        i4 = leftMargin + rightMargin;
        i5 = localView.getMeasuredWidth() + i4;
        i2 = Math.max(m, i5);
        if ((i10 != 1073741824) && (width == -1))
        {
          m = 1;
          if (m == 0) {
            break label1317;
          }
          m = i4;
          i4 = Math.max(i, m);
          if ((k == 0) || (width != -1)) {
            break label1324;
          }
        }
        for (i = 1;; i = 0)
        {
          k = mTotalLength;
          m = localView.getMeasuredHeight();
          i5 = topMargin;
          mTotalLength = Math.max(k, bottomMargin + (m + k + i5) + getNextLocationOffset(localView));
          m = i2;
          k = i4;
          i2 = j;
          i4 = i;
          break;
          if (i1 > 0) {}
          for (;;)
          {
            localView.measure(i5, View.MeasureSpec.makeMeasureSpec(i1, 1073741824));
            break;
            i1 = 0;
          }
          m = 0;
          break label1179;
          m = i5;
          break label1188;
        }
        mTotalLength += getPaddingTop() + getPaddingBottom();
        i1 = k;
        for (k = m;; k = m)
        {
          if ((i1 == 0) && (i10 != 1073741824)) {}
          for (;;)
          {
            setMeasuredDimension(View.resolveSizeAndState(Math.max(i + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), paramInt1, j), i6);
            if (n == 0) {
              return;
            }
            forceUniformWidth(i9, paramInt2);
            return;
            i1 = Math.max(i, i1);
            if ((!bool) || (i11 == 1073741824)) {
              break;
            }
            i = 0;
            if (i >= i9) {
              break;
            }
            localView = getVirtualChildAt(i);
            if ((localView == null) || (localView.getVisibility() == 8)) {}
            for (;;)
            {
              i += 1;
              break;
              if (getLayoutParamsweight > 0.0F) {
                localView.measure(View.MeasureSpec.makeMeasureSpec(localView.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(i2, 1073741824));
              }
            }
            i = k;
          }
          i = i1;
          i1 = k;
        }
        i1 = j;
      }
    }
  }
  
  public ah.a onCreateView(AttributeSet paramAttributeSet)
  {
    return new ah.a(getContext(), paramAttributeSet);
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    if (mDivider == null) {
      return;
    }
    if (mOrientation == 1)
    {
      drawDividersVertical(paramCanvas);
      return;
    }
    drawDividersHorizontal(paramCanvas);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
      paramAccessibilityEvent.setClassName(ah.class.getName());
    }
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo)
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
      paramAccessibilityNodeInfo.setClassName(ah.class.getName());
    }
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (mOrientation == 1)
    {
      layoutVertical(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    layoutHorizontal(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    if (mOrientation == 1)
    {
      measureVertical(paramInt1, paramInt2);
      return;
    }
    measureHorizontal(paramInt1, paramInt2);
  }
  
  public void setBaselineAligned(boolean paramBoolean)
  {
    mBaselineAligned = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= getChildCount())) {
      throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
    }
    mBaselineAlignedChildIndex = paramInt;
  }
  
  public void setDividerDrawable(Drawable paramDrawable)
  {
    boolean bool = false;
    if (paramDrawable == mDivider) {
      return;
    }
    mDivider = paramDrawable;
    if (paramDrawable != null) {
      mDividerWidth = paramDrawable.getIntrinsicWidth();
    }
    for (mDividerHeight = paramDrawable.getIntrinsicHeight();; mDividerHeight = 0)
    {
      if (paramDrawable == null) {
        bool = true;
      }
      setWillNotDraw(bool);
      requestLayout();
      return;
      mDividerWidth = 0;
    }
  }
  
  public void setDividerPadding(int paramInt)
  {
    mDividerPadding = paramInt;
  }
  
  public void setGravity(int paramInt)
  {
    if (mGravity != paramInt)
    {
      if ((0x800007 & paramInt) == 0) {
        paramInt = 0x800003 | paramInt;
      }
      for (;;)
      {
        int i = paramInt;
        if ((paramInt & 0x70) == 0) {
          i = paramInt | 0x30;
        }
        mGravity = i;
        requestLayout();
        return;
      }
    }
  }
  
  public void setHorizontalGravity(int paramInt)
  {
    paramInt &= 0x800007;
    if ((mGravity & 0x800007) != paramInt)
    {
      mGravity = (paramInt | mGravity & 0xFF7FFFF8);
      requestLayout();
    }
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean)
  {
    mUseLargestChild = paramBoolean;
  }
  
  public void setOrientation(int paramInt)
  {
    if (mOrientation != paramInt)
    {
      mOrientation = paramInt;
      requestLayout();
    }
  }
  
  public void setShowDividers(int paramInt)
  {
    if (paramInt != mShowDividers) {
      requestLayout();
    }
    mShowDividers = paramInt;
  }
  
  public void setVerticalGravity(int paramInt)
  {
    paramInt &= 0x70;
    if ((mGravity & 0x70) != paramInt)
    {
      mGravity = (paramInt | mGravity & 0xFFFFFF8F);
      requestLayout();
    }
  }
  
  public void setWeightSum(float paramFloat)
  {
    mWeightSum = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState()
  {
    return false;
  }
}

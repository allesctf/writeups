package android.support.v7.widget;

import android.app.SearchableInfo;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.ResultReceiver;
import android.support.v4.e.c;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.view.Item;
import android.support.v4.widget.CursorAdapter;
import android.support.v7.appcompat.R.attr;
import android.support.v7.appcompat.R.dimen;
import android.support.v7.view.CollapsibleActionView;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.KeyEvent.DispatcherState;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

public class SearchView
  extends LinearLayoutCompat
  implements CollapsibleActionView
{
  static final a HIDDEN_METHOD_INVOKER = new a();
  private Rect a;
  private f i;
  private Rect left;
  private Bundle mAppSearchData;
  private boolean mClearingFocus;
  final ImageView mCloseButton;
  private final ImageView mCollapsedIcon;
  private int mCollapsedImeOptions;
  private final CharSequence mDefaultQueryHint;
  private boolean mExpandedInActionView;
  final ImageView mGoButton;
  private boolean mIconified;
  private boolean mIconifiedByDefault;
  private int[] mLocation;
  private int mMaxWidth;
  private b mOnCloseListener;
  private c mOnQueryChangeListener;
  View.OnFocusChangeListener mOnQueryTextFocusChangeListener;
  private View.OnClickListener mOnSearchClickListener;
  private d mOnSuggestionListener;
  private final WeakHashMap<String, Drawable.ConstantState> mOutsideDrawablesCache;
  private int[] mPosition;
  private CharSequence mQueryHint;
  private boolean mQueryRefinement;
  private Runnable mReleaseCursorRunnable;
  final ImageView mSearchButton;
  private final View mSearchEditFrame;
  private final Drawable mSearchHintIcon;
  final SearchAutoComplete mSearchSrcTextView;
  SearchableInfo mSearchable;
  private Runnable mShowImeRunnable;
  private final View mSubmitArea;
  private boolean mSubmitButtonEnabled;
  private final int mSuggestionCommitIconResId;
  private final int mSuggestionRowLayout;
  CursorAdapter mSuggestionsAdapter;
  private final Runnable mUpdateDrawableStateRunnable;
  private CharSequence mUserQuery;
  private final Intent mVoiceAppSearchIntent;
  final ImageView mVoiceButton;
  private boolean mVoiceButtonEnabled;
  private final Intent mVoiceWebSearchIntent;
  
  private Intent createIntent(String paramString1, Uri paramUri, String paramString2, String paramString3, int paramInt, String paramString4)
  {
    paramString1 = new Intent(paramString1);
    paramString1.addFlags(268435456);
    if (paramUri != null) {
      paramString1.setData(paramUri);
    }
    paramString1.putExtra("user_query", mUserQuery);
    if (paramString3 != null) {
      paramString1.putExtra("query", paramString3);
    }
    if (paramString2 != null) {
      paramString1.putExtra("intent_extra_data_key", paramString2);
    }
    if (mAppSearchData != null) {
      paramString1.putExtra("app_data", mAppSearchData);
    }
    if (paramInt != 0)
    {
      paramString1.putExtra("action_key", paramInt);
      paramString1.putExtra("action_msg", paramString4);
    }
    paramString1.setComponent(mSearchable.getSearchActivity());
    return paramString1;
  }
  
  private void dismissSuggestions()
  {
    mSearchSrcTextView.dismissDropDown();
  }
  
  private void draw(View paramView, Rect paramRect)
  {
    paramView.getLocationInWindow(mPosition);
    getLocationInWindow(mLocation);
    int j = mPosition[1] - mLocation[1];
    int k = mPosition[0] - mLocation[0];
    paramRect.set(k, j, paramView.getWidth() + k, paramView.getHeight() + j);
  }
  
  private CharSequence getDecoratedHint(CharSequence paramCharSequence)
  {
    if (mIconifiedByDefault)
    {
      if (mSearchHintIcon == null) {
        return paramCharSequence;
      }
      int j = (int)(mSearchSrcTextView.getTextSize() * 1.25D);
      mSearchHintIcon.setBounds(0, 0, j, j);
      SpannableStringBuilder localSpannableStringBuilder = new SpannableStringBuilder("   ");
      localSpannableStringBuilder.setSpan(new ImageSpan(mSearchHintIcon), 1, 2, 33);
      localSpannableStringBuilder.append(paramCharSequence);
      return localSpannableStringBuilder;
    }
    return paramCharSequence;
  }
  
  private int getPreferredHeight()
  {
    return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_height);
  }
  
  private int getPreferredWidth()
  {
    return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_width);
  }
  
  private boolean hasVoiceSearch()
  {
    if ((mSearchable != null) && (mSearchable.getVoiceSearchEnabled()))
    {
      Intent localIntent = null;
      if (mSearchable.getVoiceSearchLaunchWebSearch()) {
        localIntent = mVoiceWebSearchIntent;
      }
      while ((localIntent != null) && (getContext().getPackageManager().resolveActivity(localIntent, 65536) != null))
      {
        return true;
        if (mSearchable.getVoiceSearchLaunchRecognizer()) {
          localIntent = mVoiceAppSearchIntent;
        }
      }
    }
    return false;
  }
  
  static boolean isLandscapeMode(Context paramContext)
  {
    return getResourcesgetConfigurationorientation == 2;
  }
  
  private boolean isSubmitAreaEnabled()
  {
    return ((mSubmitButtonEnabled) || (mVoiceButtonEnabled)) && (!isIconified());
  }
  
  private void postUpdateFocusedState()
  {
    post(mUpdateDrawableStateRunnable);
  }
  
  private void setQuery(CharSequence paramCharSequence)
  {
    mSearchSrcTextView.setText(paramCharSequence);
    SearchAutoComplete localSearchAutoComplete = mSearchSrcTextView;
    if (TextUtils.isEmpty(paramCharSequence)) {}
    for (int j = 0;; j = paramCharSequence.length())
    {
      localSearchAutoComplete.setSelection(j);
      return;
    }
  }
  
  private void updateCloseButton()
  {
    int n = 1;
    int m = 0;
    int j;
    int k;
    label44:
    label56:
    Drawable localDrawable;
    if (!TextUtils.isEmpty(mSearchSrcTextView.getText()))
    {
      j = 1;
      k = n;
      if (j == 0)
      {
        if ((!mIconifiedByDefault) || (mExpandedInActionView)) {
          break label99;
        }
        k = n;
      }
      localObject = mCloseButton;
      if (k == 0) {
        break label104;
      }
      k = m;
      ((ImageView)localObject).setVisibility(k);
      localDrawable = mCloseButton.getDrawable();
      if (localDrawable == null) {
        return;
      }
      if (j == 0) {
        break label110;
      }
    }
    label99:
    label104:
    label110:
    for (Object localObject = View.ENABLED_STATE_SET;; localObject = View.EMPTY_STATE_SET)
    {
      localDrawable.setState((int[])localObject);
      return;
      j = 0;
      break;
      k = 0;
      break label44;
      k = 8;
      break label56;
    }
  }
  
  private void updateQueryHint()
  {
    CharSequence localCharSequence = getQueryHint();
    Object localObject = localCharSequence;
    SearchAutoComplete localSearchAutoComplete = mSearchSrcTextView;
    if (localCharSequence == null) {
      localObject = "";
    }
    localSearchAutoComplete.setHint(getDecoratedHint((CharSequence)localObject));
  }
  
  private void updateSearchAutoComplete()
  {
    int k = 1;
    mSearchSrcTextView.setThreshold(mSearchable.getSuggestThreshold());
    mSearchSrcTextView.setImeOptions(mSearchable.getImeOptions());
    int m = mSearchable.getInputType();
    int j = m;
    if ((m & 0xF) == 1)
    {
      m &= 0xFFFEFFFF;
      j = m;
      if (mSearchable.getSuggestAuthority() != null) {
        j = m | 0x10000 | 0x80000;
      }
    }
    mSearchSrcTextView.setInputType(j);
    if (mSuggestionsAdapter != null) {
      mSuggestionsAdapter.changeCursor(null);
    }
    if (mSearchable.getSuggestAuthority() != null)
    {
      mSuggestionsAdapter = new SuggestionsAdapter(getContext(), this, mSearchable, mOutsideDrawablesCache);
      mSearchSrcTextView.setAdapter(mSuggestionsAdapter);
      SuggestionsAdapter localSuggestionsAdapter = (SuggestionsAdapter)mSuggestionsAdapter;
      j = k;
      if (mQueryRefinement) {
        j = 2;
      }
      localSuggestionsAdapter.setQueryRefinement(j);
    }
  }
  
  private void updateSubmitArea()
  {
    int k = 8;
    int j = k;
    if (isSubmitAreaEnabled()) {
      if (mGoButton.getVisibility() != 0)
      {
        j = k;
        if (mVoiceButton.getVisibility() != 0) {}
      }
      else
      {
        j = 0;
      }
    }
    mSubmitArea.setVisibility(j);
  }
  
  private void updateSubmitButton(boolean paramBoolean)
  {
    int k = 8;
    int j = k;
    if (mSubmitButtonEnabled)
    {
      j = k;
      if (isSubmitAreaEnabled())
      {
        j = k;
        if (hasFocus()) {
          if (!paramBoolean)
          {
            j = k;
            if (mVoiceButtonEnabled) {}
          }
          else
          {
            j = 0;
          }
        }
      }
    }
    mGoButton.setVisibility(j);
  }
  
  private void updateViewsVisibility(boolean paramBoolean)
  {
    boolean bool2 = true;
    int k = 8;
    mIconified = paramBoolean;
    int j;
    boolean bool1;
    if (paramBoolean)
    {
      j = 0;
      if (TextUtils.isEmpty(mSearchSrcTextView.getText())) {
        break label123;
      }
      bool1 = true;
      label33:
      mSearchButton.setVisibility(j);
      updateSubmitButton(bool1);
      View localView = mSearchEditFrame;
      if (!paramBoolean) {
        break label129;
      }
      j = 8;
      label60:
      localView.setVisibility(j);
      j = k;
      if (mCollapsedIcon.getDrawable() != null)
      {
        if (!mIconifiedByDefault) {
          break label134;
        }
        j = k;
      }
      label87:
      mCollapsedIcon.setVisibility(j);
      updateCloseButton();
      if (bool1) {
        break label139;
      }
    }
    label123:
    label129:
    label134:
    label139:
    for (paramBoolean = bool2;; paramBoolean = false)
    {
      updateVoiceButton(paramBoolean);
      updateSubmitArea();
      return;
      j = 8;
      break;
      bool1 = false;
      break label33;
      j = 0;
      break label60;
      j = 0;
      break label87;
    }
  }
  
  private void updateVoiceButton(boolean paramBoolean)
  {
    int j;
    if ((mVoiceButtonEnabled) && (!isIconified()) && (paramBoolean))
    {
      j = 0;
      mGoButton.setVisibility(8);
    }
    for (;;)
    {
      mVoiceButton.setVisibility(j);
      return;
      j = 8;
    }
  }
  
  public void clearFocus()
  {
    mClearingFocus = true;
    setImeVisibility(false);
    super.clearFocus();
    mSearchSrcTextView.clearFocus();
    mClearingFocus = false;
  }
  
  void forceSuggestionQuery()
  {
    HIDDEN_METHOD_INVOKER.doBeforeTextChanged(mSearchSrcTextView);
    HIDDEN_METHOD_INVOKER.doAfterTextChanged(mSearchSrcTextView);
  }
  
  public int getImeOptions()
  {
    return mSearchSrcTextView.getImeOptions();
  }
  
  public int getInputType()
  {
    return mSearchSrcTextView.getInputType();
  }
  
  public int getMaxWidth()
  {
    return mMaxWidth;
  }
  
  public CharSequence getQuery()
  {
    return mSearchSrcTextView.getText();
  }
  
  public CharSequence getQueryHint()
  {
    if (mQueryHint != null) {
      return mQueryHint;
    }
    if ((mSearchable != null) && (mSearchable.getHintId() != 0)) {
      return getContext().getText(mSearchable.getHintId());
    }
    return mDefaultQueryHint;
  }
  
  int getSuggestionCommitIconResId()
  {
    return mSuggestionCommitIconResId;
  }
  
  int getSuggestionRowLayout()
  {
    return mSuggestionRowLayout;
  }
  
  public CursorAdapter getSuggestionsAdapter()
  {
    return mSuggestionsAdapter;
  }
  
  public boolean isIconified()
  {
    return mIconified;
  }
  
  void launchQuerySearch(int paramInt, String paramString1, String paramString2)
  {
    paramString1 = createIntent("android.intent.action.SEARCH", null, null, paramString2, paramInt, paramString1);
    getContext().startActivity(paramString1);
  }
  
  public void onActionViewCollapsed()
  {
    setQuery("", false);
    clearFocus();
    updateViewsVisibility(true);
    mSearchSrcTextView.setImeOptions(mCollapsedImeOptions);
    mExpandedInActionView = false;
  }
  
  public void onActionViewExpanded()
  {
    if (mExpandedInActionView) {
      return;
    }
    mExpandedInActionView = true;
    mCollapsedImeOptions = mSearchSrcTextView.getImeOptions();
    mSearchSrcTextView.setImeOptions(mCollapsedImeOptions | 0x2000000);
    mSearchSrcTextView.setText("");
    setIconified(false);
  }
  
  void onCloseClicked()
  {
    if (TextUtils.isEmpty(mSearchSrcTextView.getText()))
    {
      if ((mIconifiedByDefault) && ((mOnCloseListener == null) || (!mOnCloseListener.onClose())))
      {
        clearFocus();
        updateViewsVisibility(true);
      }
    }
    else
    {
      mSearchSrcTextView.setText("");
      mSearchSrcTextView.requestFocus();
      setImeVisibility(true);
    }
  }
  
  protected void onDetachedFromWindow()
  {
    removeCallbacks(mUpdateDrawableStateRunnable);
    post(mReleaseCursorRunnable);
    super.onDetachedFromWindow();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramBoolean)
    {
      draw(mSearchSrcTextView, left);
      a.set(left.left, 0, left.right, paramInt4 - paramInt2);
      if (i == null)
      {
        i = new f(a, left, mSearchSrcTextView);
        setTouchDelegate(i);
        return;
      }
      i.draw(a, left);
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    if (isIconified())
    {
      super.onMeasure(paramInt1, paramInt2);
      return;
    }
    int k = View.MeasureSpec.getMode(paramInt1);
    int j = View.MeasureSpec.getSize(paramInt1);
    paramInt1 = j;
    switch (k)
    {
    default: 
      k = View.MeasureSpec.getMode(paramInt2);
      j = View.MeasureSpec.getSize(paramInt2);
      paramInt2 = j;
      switch (k)
      {
      }
      break;
    }
    for (;;)
    {
      super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
      return;
      if (mMaxWidth > 0)
      {
        paramInt1 = Math.min(mMaxWidth, j);
        break;
      }
      paramInt1 = Math.min(getPreferredWidth(), j);
      break;
      if (mMaxWidth <= 0) {
        break;
      }
      paramInt1 = Math.min(mMaxWidth, j);
      break;
      if (mMaxWidth > 0)
      {
        paramInt1 = mMaxWidth;
        break;
      }
      paramInt1 = getPreferredWidth();
      break;
      paramInt2 = Math.min(getPreferredHeight(), j);
      continue;
      paramInt2 = getPreferredHeight();
    }
  }
  
  void onQueryRefine(CharSequence paramCharSequence)
  {
    setQuery(paramCharSequence);
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof e))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    paramParcelable = (e)paramParcelable;
    super.onRestoreInstanceState(paramParcelable.a());
    updateViewsVisibility(isIconified);
    requestLayout();
  }
  
  protected Parcelable onSaveInstanceState()
  {
    e localE = new e(super.onSaveInstanceState());
    isIconified = isIconified();
    return localE;
  }
  
  void onSearchClicked()
  {
    updateViewsVisibility(false);
    mSearchSrcTextView.requestFocus();
    setImeVisibility(true);
    if (mOnSearchClickListener != null) {
      mOnSearchClickListener.onClick(this);
    }
  }
  
  void onSubmitQuery()
  {
    Editable localEditable = mSearchSrcTextView.getText();
    if ((localEditable != null) && (TextUtils.getTrimmedLength(localEditable) > 0) && ((mOnQueryChangeListener == null) || (!mOnQueryChangeListener.onQueryTextSubmit(localEditable.toString()))))
    {
      if (mSearchable != null) {
        launchQuerySearch(0, null, localEditable.toString());
      }
      setImeVisibility(false);
      dismissSuggestions();
    }
  }
  
  void onTextFocusChanged()
  {
    updateViewsVisibility(isIconified());
    postUpdateFocusedState();
    if (mSearchSrcTextView.hasFocus()) {
      forceSuggestionQuery();
    }
  }
  
  public void onWindowFocusChanged(boolean paramBoolean)
  {
    super.onWindowFocusChanged(paramBoolean);
    postUpdateFocusedState();
  }
  
  public boolean requestFocus(int paramInt, Rect paramRect)
  {
    if (mClearingFocus) {
      return false;
    }
    if (isFocusable())
    {
      if (!isIconified())
      {
        boolean bool = mSearchSrcTextView.requestFocus(paramInt, paramRect);
        if (bool) {
          updateViewsVisibility(false);
        }
        return bool;
      }
      return super.requestFocus(paramInt, paramRect);
    }
    return false;
  }
  
  public void setAppSearchData(Bundle paramBundle)
  {
    mAppSearchData = paramBundle;
  }
  
  public void setIconified(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      onCloseClicked();
      return;
    }
    onSearchClicked();
  }
  
  public void setIconifiedByDefault(boolean paramBoolean)
  {
    if (mIconifiedByDefault == paramBoolean) {
      return;
    }
    mIconifiedByDefault = paramBoolean;
    updateViewsVisibility(paramBoolean);
    updateQueryHint();
  }
  
  public void setImeOptions(int paramInt)
  {
    mSearchSrcTextView.setImeOptions(paramInt);
  }
  
  void setImeVisibility(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      post(mShowImeRunnable);
      return;
    }
    removeCallbacks(mShowImeRunnable);
    InputMethodManager localInputMethodManager = (InputMethodManager)getContext().getSystemService("input_method");
    if (localInputMethodManager != null) {
      localInputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
    }
  }
  
  public void setInputType(int paramInt)
  {
    mSearchSrcTextView.setInputType(paramInt);
  }
  
  public void setMaxWidth(int paramInt)
  {
    mMaxWidth = paramInt;
    requestLayout();
  }
  
  public void setOnCloseListener(b paramB)
  {
    mOnCloseListener = paramB;
  }
  
  public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener paramOnFocusChangeListener)
  {
    mOnQueryTextFocusChangeListener = paramOnFocusChangeListener;
  }
  
  public void setOnQueryTextListener(c paramC)
  {
    mOnQueryChangeListener = paramC;
  }
  
  public void setOnSearchClickListener(View.OnClickListener paramOnClickListener)
  {
    mOnSearchClickListener = paramOnClickListener;
  }
  
  public void setOnSuggestionListener(d paramD)
  {
    mOnSuggestionListener = paramD;
  }
  
  public void setQuery(CharSequence paramCharSequence, boolean paramBoolean)
  {
    mSearchSrcTextView.setText(paramCharSequence);
    if (paramCharSequence != null)
    {
      mSearchSrcTextView.setSelection(mSearchSrcTextView.length());
      mUserQuery = paramCharSequence;
    }
    if ((paramBoolean) && (!TextUtils.isEmpty(paramCharSequence))) {
      onSubmitQuery();
    }
  }
  
  public void setQueryHint(CharSequence paramCharSequence)
  {
    mQueryHint = paramCharSequence;
    updateQueryHint();
  }
  
  public void setQueryRefinementEnabled(boolean paramBoolean)
  {
    mQueryRefinement = paramBoolean;
    if ((mSuggestionsAdapter instanceof SuggestionsAdapter))
    {
      SuggestionsAdapter localSuggestionsAdapter = (SuggestionsAdapter)mSuggestionsAdapter;
      if (paramBoolean) {}
      for (int j = 2;; j = 1)
      {
        localSuggestionsAdapter.setQueryRefinement(j);
        return;
      }
    }
  }
  
  public void setSearchableInfo(SearchableInfo paramSearchableInfo)
  {
    mSearchable = paramSearchableInfo;
    if (mSearchable != null)
    {
      updateSearchAutoComplete();
      updateQueryHint();
    }
    mVoiceButtonEnabled = hasVoiceSearch();
    if (mVoiceButtonEnabled) {
      mSearchSrcTextView.setPrivateImeOptions("nm");
    }
    updateViewsVisibility(isIconified());
  }
  
  public void setSubmitButtonEnabled(boolean paramBoolean)
  {
    mSubmitButtonEnabled = paramBoolean;
    updateViewsVisibility(isIconified());
  }
  
  public void setSuggestionsAdapter(CursorAdapter paramCursorAdapter)
  {
    mSuggestionsAdapter = paramCursorAdapter;
    mSearchSrcTextView.setAdapter(mSuggestionsAdapter);
  }
  
  public static class SearchAutoComplete
    extends AppCompatAutoCompleteTextView
  {
    private SearchView mSearchView;
    private int mThreshold = getThreshold();
    
    public SearchAutoComplete(Context paramContext)
    {
      this(paramContext, null);
    }
    
    public SearchAutoComplete(Context paramContext, AttributeSet paramAttributeSet)
    {
      this(paramContext, paramAttributeSet, R.attr.autoCompleteTextViewStyle);
    }
    
    public SearchAutoComplete(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
    {
      super(paramAttributeSet, paramInt);
    }
    
    private int getSearchViewTextMinWidthDp()
    {
      Configuration localConfiguration = getResources().getConfiguration();
      int i = screenWidthDp;
      int j = screenHeightDp;
      if ((i >= 960) && (j >= 720) && (orientation == 2)) {
        return 256;
      }
      if ((i >= 600) || ((i >= 640) && (j >= 480))) {
        return 192;
      }
      return 160;
    }
    
    public boolean enoughToFilter()
    {
      return (mThreshold <= 0) || (super.enoughToFilter());
    }
    
    protected void onFinishInflate()
    {
      super.onFinishInflate();
      DisplayMetrics localDisplayMetrics = getResources().getDisplayMetrics();
      setMinWidth((int)TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), localDisplayMetrics));
    }
    
    protected void onFocusChanged(boolean paramBoolean, int paramInt, Rect paramRect)
    {
      super.onFocusChanged(paramBoolean, paramInt, paramRect);
      mSearchView.onTextFocusChanged();
    }
    
    public boolean onKeyPreIme(int paramInt, KeyEvent paramKeyEvent)
    {
      if (paramInt == 4)
      {
        KeyEvent.DispatcherState localDispatcherState;
        if ((paramKeyEvent.getAction() == 0) && (paramKeyEvent.getRepeatCount() == 0))
        {
          localDispatcherState = getKeyDispatcherState();
          if (localDispatcherState == null) {
            break label96;
          }
          localDispatcherState.startTracking(paramKeyEvent, this);
          return true;
        }
        if (paramKeyEvent.getAction() == 1)
        {
          localDispatcherState = getKeyDispatcherState();
          if (localDispatcherState != null) {
            localDispatcherState.handleUpEvent(paramKeyEvent);
          }
          if ((paramKeyEvent.isTracking()) && (!paramKeyEvent.isCanceled()))
          {
            mSearchView.clearFocus();
            mSearchView.setImeVisibility(false);
            return true;
          }
        }
      }
      return super.onKeyPreIme(paramInt, paramKeyEvent);
      label96:
      return true;
    }
    
    public void onWindowFocusChanged(boolean paramBoolean)
    {
      super.onWindowFocusChanged(paramBoolean);
      if ((paramBoolean) && (mSearchView.hasFocus()) && (getVisibility() == 0))
      {
        ((InputMethodManager)getContext().getSystemService("input_method")).showSoftInput(this, 0);
        if (SearchView.isLandscapeMode(getContext())) {
          SearchView.HIDDEN_METHOD_INVOKER.ensureImeVisible(this, true);
        }
      }
    }
    
    public void performCompletion() {}
    
    protected void replaceText(CharSequence paramCharSequence) {}
    
    void setSearchView(SearchView paramSearchView)
    {
      mSearchView = paramSearchView;
    }
    
    public void setThreshold(int paramInt)
    {
      super.setThreshold(paramInt);
      mThreshold = paramInt;
    }
  }
  
  private static class a
  {
    private Method doAfterTextChanged;
    private Method doBeforeTextChanged;
    private Method ensureImeVisible;
    private Method showSoftInputUnchecked;
    
    a()
    {
      for (;;)
      {
        try
        {
          localObject = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
          doBeforeTextChanged = ((Method)localObject);
          localObject = doBeforeTextChanged;
          ((Method)localObject).setAccessible(true);
        }
        catch (NoSuchMethodException localNoSuchMethodException4)
        {
          Object localObject;
          continue;
        }
        try
        {
          localObject = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
          doAfterTextChanged = ((Method)localObject);
          localObject = doAfterTextChanged;
          ((Method)localObject).setAccessible(true);
        }
        catch (NoSuchMethodException localNoSuchMethodException3) {}
      }
      localObject = Boolean.TYPE;
      try
      {
        localObject = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { localObject });
        ensureImeVisible = ((Method)localObject);
        localObject = ensureImeVisible;
        ((Method)localObject).setAccessible(true);
      }
      catch (NoSuchMethodException localNoSuchMethodException2)
      {
        for (;;) {}
      }
      localObject = Integer.TYPE;
      try
      {
        localObject = InputMethodManager.class.getMethod("showSoftInputUnchecked", new Class[] { localObject, ResultReceiver.class });
        showSoftInputUnchecked = ((Method)localObject);
        localObject = showSoftInputUnchecked;
        ((Method)localObject).setAccessible(true);
        return;
      }
      catch (NoSuchMethodException localNoSuchMethodException1) {}
    }
    
    void doAfterTextChanged(AutoCompleteTextView paramAutoCompleteTextView)
    {
      if (doAfterTextChanged != null)
      {
        Method localMethod = doAfterTextChanged;
        try
        {
          localMethod.invoke(paramAutoCompleteTextView, new Object[0]);
          return;
        }
        catch (Exception paramAutoCompleteTextView) {}
      }
    }
    
    void doBeforeTextChanged(AutoCompleteTextView paramAutoCompleteTextView)
    {
      if (doBeforeTextChanged != null)
      {
        Method localMethod = doBeforeTextChanged;
        try
        {
          localMethod.invoke(paramAutoCompleteTextView, new Object[0]);
          return;
        }
        catch (Exception paramAutoCompleteTextView) {}
      }
    }
    
    void ensureImeVisible(AutoCompleteTextView paramAutoCompleteTextView, boolean paramBoolean)
    {
      if (ensureImeVisible != null)
      {
        Method localMethod = ensureImeVisible;
        try
        {
          localMethod.invoke(paramAutoCompleteTextView, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        }
        catch (Exception paramAutoCompleteTextView) {}
      }
    }
  }
  
  public static abstract interface b
  {
    public abstract boolean onClose();
  }
  
  public static abstract interface c
  {
    public abstract boolean onQueryTextSubmit(String paramString);
  }
  
  public static abstract interface d {}
  
  static class e
    extends Item
  {
    public static final Parcelable.Creator<e> CREATOR = ParcelableCompat.newCreator(new android.support.v4.os.ParcelableCompatCreatorCallbacks()
    {
      public SearchView.e[] getValue(int paramAnonymousInt)
      {
        return new SearchView.e[paramAnonymousInt];
      }
      
      public SearchView.e readFromParcel(Parcel paramAnonymousParcel, ClassLoader paramAnonymousClassLoader)
      {
        return new SearchView.e(paramAnonymousParcel, paramAnonymousClassLoader);
      }
    });
    boolean isIconified;
    
    public e(Parcel paramParcel, ClassLoader paramClassLoader)
    {
      super(paramClassLoader);
      isIconified = ((Boolean)paramParcel.readValue(null)).booleanValue();
    }
    
    e(Parcelable paramParcelable)
    {
      super();
    }
    
    public String toString()
    {
      return "SearchView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " isIconified=" + isIconified + "}";
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeValue(Boolean.valueOf(isIconified));
    }
  }
  
  private static class f
    extends TouchDelegate
  {
    private final View a;
    private final Rect b;
    private final Rect d;
    private boolean e;
    private final Rect f;
    private final int i;
    
    public f(Rect paramRect1, Rect paramRect2, View paramView)
    {
      super(paramView);
      i = ViewConfiguration.get(paramView.getContext()).getScaledTouchSlop();
      d = new Rect();
      f = new Rect();
      b = new Rect();
      draw(paramRect1, paramRect2);
      a = paramView;
    }
    
    public void draw(Rect paramRect1, Rect paramRect2)
    {
      d.set(paramRect1);
      f.set(paramRect1);
      f.inset(-i, -i);
      b.set(paramRect2);
    }
    
    public boolean onTouchEvent(MotionEvent paramMotionEvent)
    {
      int k = 1;
      int m = (int)paramMotionEvent.getX();
      int n = (int)paramMotionEvent.getY();
      boolean bool1;
      int j;
      switch (paramMotionEvent.getAction())
      {
      default: 
        bool1 = false;
        j = k;
        label72:
        if (!bool1) {
          break label246;
        }
        if ((j != 0) && (!b.contains(m, n))) {
          paramMotionEvent.setLocation(a.getWidth() / 2, a.getHeight() / 2);
        }
        break;
      }
      for (;;)
      {
        return a.dispatchTouchEvent(paramMotionEvent);
        if (!d.contains(m, n)) {
          break;
        }
        e = true;
        bool1 = true;
        j = k;
        break label72;
        boolean bool2 = e;
        j = k;
        bool1 = bool2;
        if (!bool2) {
          break label72;
        }
        j = k;
        bool1 = bool2;
        if (f.contains(m, n)) {
          break label72;
        }
        j = 0;
        bool1 = bool2;
        break label72;
        bool1 = e;
        e = false;
        j = k;
        break label72;
        paramMotionEvent.setLocation(m - b.left, n - b.top);
      }
      label246:
      return false;
    }
  }
}

package android.support.v7.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.os.Build.VERSION;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class TintContextWrapper
  extends ContextWrapper
{
  private static final Object LINE_SEPARATOR = new Object();
  private static ArrayList<WeakReference<as>> sCache;
  private final Resources mResources;
  private final Resources.Theme mTheme;
  
  private TintContextWrapper(Context paramContext)
  {
    super(paramContext);
    if (TintManager.get())
    {
      mResources = new TintManager(this, paramContext.getResources());
      mTheme = mResources.newTheme();
      mTheme.setTo(paramContext.getTheme());
      return;
    }
    mResources = new TintResources(this, paramContext.getResources());
    mTheme = null;
  }
  
  private static boolean get(Context paramContext)
  {
    if ((!(paramContext instanceof TintContextWrapper)) && (!(paramContext.getResources() instanceof TintResources)))
    {
      if ((paramContext.getResources() instanceof TintManager)) {
        return false;
      }
      if ((Build.VERSION.SDK_INT < 21) || (TintManager.get())) {
        return true;
      }
    }
    return false;
  }
  
  public static Context wrap(Context paramContext)
  {
    Object localObject2;
    if (get(paramContext)) {
      localObject2 = LINE_SEPARATOR;
    }
    for (;;)
    {
      int i;
      try
      {
        if (sCache == null)
        {
          sCache = new ArrayList();
          paramContext = new TintContextWrapper(paramContext);
          sCache.add(new WeakReference(paramContext));
          return paramContext;
        }
        i = sCache.size() - 1;
        Object localObject1;
        if (i >= 0)
        {
          localObject1 = (WeakReference)sCache.get(i);
          if ((localObject1 == null) || (((WeakReference)localObject1).get() == null)) {
            sCache.remove(i);
          }
        }
        else
        {
          i = sCache.size() - 1;
          if (i < 0) {
            continue;
          }
          localObject1 = (WeakReference)sCache.get(i);
          if (localObject1 != null)
          {
            localObject1 = (TintContextWrapper)((WeakReference)localObject1).get();
            if ((localObject1 == null) || (((ContextWrapper)localObject1).getBaseContext() != paramContext)) {
              break label174;
            }
            return localObject1;
          }
          localObject1 = null;
          continue;
          return paramContext;
        }
      }
      catch (Throwable paramContext)
      {
        throw paramContext;
      }
      i -= 1;
      continue;
      label174:
      i -= 1;
    }
  }
  
  public AssetManager getAssets()
  {
    return mResources.getAssets();
  }
  
  public Resources getResources()
  {
    return mResources;
  }
  
  public Resources.Theme getTheme()
  {
    if (mTheme == null) {
      return super.getTheme();
    }
    return mTheme;
  }
  
  public void setTheme(int paramInt)
  {
    if (mTheme == null)
    {
      super.setTheme(paramInt);
      return;
    }
    mTheme.applyStyle(paramInt, true);
  }
}

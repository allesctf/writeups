package android.support.v7.widget;

import android.support.v7.view.menu.f;
import android.view.MenuItem;

public abstract interface Object
{
  public abstract void a(f paramF, MenuItem paramMenuItem);
  
  public abstract void b(f paramF, MenuItem paramMenuItem);
}

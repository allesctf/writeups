package android.support.v7.widget;

public abstract interface FitWindowsViewGroup
{
  public abstract void setOnFitSystemWindowsListener(af.a paramA);
}

package android.support.v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v4.view.TintableBackgroundView;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R.attr;
import android.support.v7.appcompat.R.layout;
import android.support.v7.appcompat.R.styleable;
import android.support.v7.recyclerview.app.TintManager;
import android.support.v7.view.ContextThemeWrapper;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver;
import android.widget.AbsListView;
import android.widget.AbsSpinner;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

public class AppCompatSpinner
  extends Spinner
  implements TintableBackgroundView
{
  private static final int[] ATTRS_ANDROID_SPINNERMODE = { 16843505 };
  private AppCompatBackgroundHelper mBackgroundTintHelper;
  int mDropDownWidth;
  private ListPopupWindow.ForwardingListener mForwardingListener;
  DropdownPopup mPopup;
  private Context mPopupContext;
  private boolean mPopupSet;
  private SpinnerAdapter mTempAdapter;
  final Rect mTempRect = new Rect();
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, R.attr.spinnerStyle);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    this(paramContext, paramAttributeSet, paramInt1, paramInt2, null);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, Resources.Theme paramTheme)
  {
    super(paramContext, paramAttributeSet, paramInt1);
    TintTypedArray localTintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, R.styleable.Spinner, paramInt1, 0);
    mBackgroundTintHelper = new AppCompatBackgroundHelper(this);
    int j;
    if (paramTheme != null)
    {
      mPopupContext = new ContextThemeWrapper(paramContext, paramTheme);
      if (mPopupContext != null)
      {
        j = paramInt2;
        if (paramInt2 == -1)
        {
          if (Build.VERSION.SDK_INT < 11) {
            break label456;
          }
          paramTheme = ATTRS_ANDROID_SPINNERMODE;
        }
      }
    }
    for (;;)
    {
      try
      {
        localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, paramTheme, paramInt1, 0);
        localObject = localTypedArray;
        paramTheme = (Resources.Theme)localObject;
      }
      catch (Exception localException1)
      {
        TypedArray localTypedArray;
        boolean bool;
        int i;
        Object localObject = null;
        paramTheme = (Resources.Theme)localObject;
        Log.i("AppCompatSpinner", "Could not read android:spinnerMode", localException1);
        j = paramInt2;
        if (localObject == null) {
          continue;
        }
        ((TypedArray)localObject).recycle();
        j = paramInt2;
        continue;
      }
      catch (Throwable paramContext)
      {
        paramTheme = null;
      }
      try
      {
        bool = localTypedArray.hasValue(0);
        i = paramInt2;
        if (bool)
        {
          paramTheme = (Resources.Theme)localObject;
          i = localTypedArray.getInt(0, 0);
        }
        j = i;
        if (localTypedArray != null)
        {
          localTypedArray.recycle();
          j = i;
        }
        if (j == 1)
        {
          paramTheme = new DropdownPopup(mPopupContext, paramAttributeSet, paramInt1);
          localObject = TintTypedArray.obtainStyledAttributes(mPopupContext, paramAttributeSet, R.styleable.Spinner, paramInt1, 0);
          mDropDownWidth = ((TintTypedArray)localObject).getLayoutDimension(R.styleable.Spinner_android_dropDownWidth, -2);
          paramTheme.setBackgroundDrawable(((TintTypedArray)localObject).getDrawable(R.styleable.Spinner_android_popupBackground));
          paramTheme.setPromptText(localTintTypedArray.getString(R.styleable.Spinner_android_prompt));
          ((TintTypedArray)localObject).recycle();
          mPopup = paramTheme;
          mForwardingListener = new ActivityChooserView.3(this, this, paramTheme);
        }
        paramTheme = localTintTypedArray.getTextArray(R.styleable.Spinner_android_entries);
        if (paramTheme != null)
        {
          paramContext = new ArrayAdapter(paramContext, 17367048, paramTheme);
          paramContext.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
          setAdapter(paramContext);
        }
        localTintTypedArray.recycle();
        mPopupSet = true;
        if (mTempAdapter != null)
        {
          setAdapter(mTempAdapter);
          mTempAdapter = null;
        }
        mBackgroundTintHelper.loadFromAttributes(paramAttributeSet, paramInt1);
        return;
      }
      catch (Throwable paramContext)
      {
        for (;;) {}
      }
      catch (Exception localException2)
      {
        continue;
      }
      i = localTintTypedArray.getResourceId(R.styleable.Spinner_popupTheme, 0);
      if (i != 0)
      {
        mPopupContext = new ContextThemeWrapper(paramContext, i);
        break;
      }
      if (Build.VERSION.SDK_INT < 23)
      {
        paramTheme = paramContext;
        mPopupContext = paramTheme;
        break;
      }
      paramTheme = null;
      continue;
      if (paramTheme != null) {
        paramTheme.recycle();
      }
      throw paramContext;
      label456:
      j = 1;
    }
  }
  
  int compatMeasureContentWidth(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable)
  {
    if (paramSpinnerAdapter == null) {
      return 0;
    }
    int i1 = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int i2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i3 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int j = Math.max(0, i - (15 - (i3 - i)));
    Object localObject = null;
    int k = 0;
    i = 0;
    if (j < i3)
    {
      int n = paramSpinnerAdapter.getItemViewType(j);
      int m = n;
      if (n == i) {
        break label212;
      }
      localObject = null;
      i = m;
    }
    label212:
    for (;;)
    {
      View localView = paramSpinnerAdapter.getView(j, (View)localObject, this);
      localObject = localView;
      if (localView.getLayoutParams() == null) {
        localView.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
      }
      localView.measure(i1, i2);
      k = Math.max(k, localView.getMeasuredWidth());
      j += 1;
      break;
      if (paramDrawable != null)
      {
        paramDrawable.getPadding(mTempRect);
        return mTempRect.left + mTempRect.right + k;
      }
      return k;
    }
  }
  
  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    if (mBackgroundTintHelper != null) {
      mBackgroundTintHelper.applySupportBackgroundTint();
    }
  }
  
  public int getDropDownHorizontalOffset()
  {
    if (mPopup != null) {
      return mPopup.getHorizontalOffset();
    }
    if (Build.VERSION.SDK_INT >= 16) {
      return super.getDropDownHorizontalOffset();
    }
    return 0;
  }
  
  public int getDropDownVerticalOffset()
  {
    if (mPopup != null) {
      return mPopup.getVerticalOffset();
    }
    if (Build.VERSION.SDK_INT >= 16) {
      return super.getDropDownVerticalOffset();
    }
    return 0;
  }
  
  public int getDropDownWidth()
  {
    if (mPopup != null) {
      return mDropDownWidth;
    }
    if (Build.VERSION.SDK_INT >= 16) {
      return super.getDropDownWidth();
    }
    return 0;
  }
  
  public Drawable getPopupBackground()
  {
    if (mPopup != null) {
      return mPopup.getBackground();
    }
    if (Build.VERSION.SDK_INT >= 16) {
      return super.getPopupBackground();
    }
    return null;
  }
  
  public Context getPopupContext()
  {
    if (mPopup != null) {
      return mPopupContext;
    }
    if (Build.VERSION.SDK_INT >= 23) {
      return super.getPopupContext();
    }
    return null;
  }
  
  public CharSequence getPrompt()
  {
    if (mPopup != null) {
      return mPopup.getHintText();
    }
    return super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList()
  {
    if (mBackgroundTintHelper != null) {
      return mBackgroundTintHelper.getSupportBackgroundTintList();
    }
    return null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode()
  {
    if (mBackgroundTintHelper != null) {
      return mBackgroundTintHelper.getSupportBackgroundTintMode();
    }
    return null;
  }
  
  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    if ((mPopup != null) && (mPopup.isShowing())) {
      mPopup.dismiss();
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    if ((mPopup != null) && (View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)) {
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), compatMeasureContentWidth(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight());
    }
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if ((mForwardingListener != null) && (mForwardingListener.onTouch(this, paramMotionEvent))) {
      return true;
    }
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick()
  {
    if (mPopup != null)
    {
      if (!mPopup.isShowing()) {
        mPopup.show();
      }
      return true;
    }
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter)
  {
    if (!mPopupSet)
    {
      mTempAdapter = paramSpinnerAdapter;
      return;
    }
    super.setAdapter(paramSpinnerAdapter);
    if (mPopup != null)
    {
      if (mPopupContext == null) {}
      for (Context localContext = getContext();; localContext = mPopupContext)
      {
        mPopup.setAdapter(new SpinnerCompat.DropDownAdapter(paramSpinnerAdapter, localContext.getTheme()));
        return;
      }
    }
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable)
  {
    super.setBackgroundDrawable(paramDrawable);
    if (mBackgroundTintHelper != null) {
      mBackgroundTintHelper.onSetBackgroundDrawable(paramDrawable);
    }
  }
  
  public void setBackgroundResource(int paramInt)
  {
    super.setBackgroundResource(paramInt);
    if (mBackgroundTintHelper != null) {
      mBackgroundTintHelper.onSetBackgroundResource(paramInt);
    }
  }
  
  public void setDropDownHorizontalOffset(int paramInt)
  {
    if (mPopup != null)
    {
      mPopup.setHorizontalOffset(paramInt);
      return;
    }
    if (Build.VERSION.SDK_INT >= 16) {
      super.setDropDownHorizontalOffset(paramInt);
    }
  }
  
  public void setDropDownVerticalOffset(int paramInt)
  {
    if (mPopup != null)
    {
      mPopup.setVerticalOffset(paramInt);
      return;
    }
    if (Build.VERSION.SDK_INT >= 16) {
      super.setDropDownVerticalOffset(paramInt);
    }
  }
  
  public void setDropDownWidth(int paramInt)
  {
    if (mPopup != null)
    {
      mDropDownWidth = paramInt;
      return;
    }
    if (Build.VERSION.SDK_INT >= 16) {
      super.setDropDownWidth(paramInt);
    }
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable)
  {
    if (mPopup != null)
    {
      mPopup.setBackgroundDrawable(paramDrawable);
      return;
    }
    if (Build.VERSION.SDK_INT >= 16) {
      super.setPopupBackgroundDrawable(paramDrawable);
    }
  }
  
  public void setPopupBackgroundResource(int paramInt)
  {
    setPopupBackgroundDrawable(TintManager.getDrawable(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence)
  {
    if (mPopup != null)
    {
      mPopup.setPromptText(paramCharSequence);
      return;
    }
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList)
  {
    if (mBackgroundTintHelper != null) {
      mBackgroundTintHelper.setSupportBackgroundTintList(paramColorStateList);
    }
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode)
  {
    if (mBackgroundTintHelper != null) {
      mBackgroundTintHelper.setSupportBackgroundTintMode(paramMode);
    }
  }
  
  class DropdownPopup
    extends ListPopupWindow
  {
    ListAdapter mAdapter;
    private CharSequence mHintText;
    private final Rect mVisibleRect = new Rect();
    
    public DropdownPopup(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
    {
      super(paramAttributeSet, paramInt);
      setAnchorView(AppCompatSpinner.this);
      setModal(true);
      setPromptPosition(0);
      setOnItemClickListener(new x.b.1(this, AppCompatSpinner.this));
    }
    
    void computeContentWidth()
    {
      Object localObject = getBackground();
      int i;
      int n;
      int i1;
      int i2;
      int k;
      int j;
      if (localObject != null)
      {
        ((Drawable)localObject).getPadding(mTempRect);
        if (ViewUtils.isLayoutRtl(AppCompatSpinner.this))
        {
          i = mTempRect.right;
          n = getPaddingLeft();
          i1 = getPaddingRight();
          i2 = getWidth();
          if (mDropDownWidth != -2) {
            break label243;
          }
          k = compatMeasureContentWidth((SpinnerAdapter)mAdapter, getBackground());
          int m = getContext().getResources().getDisplayMetrics().widthPixels - mTempRect.left - mTempRect.right;
          j = m;
          if (k <= m) {
            break label291;
          }
        }
      }
      for (;;)
      {
        setContentWidth(Math.max(j, i2 - n - i1));
        label168:
        if (ViewUtils.isLayoutRtl(AppCompatSpinner.this)) {
          i = i2 - i1 - getWidth() + i;
        }
        for (;;)
        {
          setHorizontalOffset(i);
          return;
          i = -mTempRect.left;
          break;
          localObject = mTempRect;
          mTempRect.right = 0;
          left = 0;
          i = 0;
          break;
          label243:
          if (mDropDownWidth == -1)
          {
            setContentWidth(i2 - n - i1);
            break label168;
          }
          setContentWidth(mDropDownWidth);
          break label168;
          i += n;
        }
        label291:
        j = k;
      }
    }
    
    public CharSequence getHintText()
    {
      return mHintText;
    }
    
    boolean isVisibleToUser(View paramView)
    {
      return (ViewCompat.isAttachedToWindow(paramView)) && (paramView.getGlobalVisibleRect(mVisibleRect));
    }
    
    public void setAdapter(ListAdapter paramListAdapter)
    {
      super.setAdapter(paramListAdapter);
      mAdapter = paramListAdapter;
    }
    
    public void setPromptText(CharSequence paramCharSequence)
    {
      mHintText = paramCharSequence;
    }
    
    public void show()
    {
      boolean bool = isShowing();
      computeContentWidth();
      setInputMethodMode(2);
      super.show();
      getListView().setChoiceMode(1);
      setSelection(getSelectedItemPosition());
      if (bool) {
        return;
      }
      ViewTreeObserver localViewTreeObserver = getViewTreeObserver();
      if (localViewTreeObserver != null)
      {
        x.b.2 local2 = new x.b.2(this);
        localViewTreeObserver.addOnGlobalLayoutListener(local2);
        setOnDismissListener(new x.b.3(this, local2));
      }
    }
  }
}

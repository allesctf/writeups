package android.support.v7.widget;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build.VERSION;
import android.support.v7.appcompat.R.styleable;
import android.support.v7.recyclerview.app.TintManager;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;

public class AppCompatImageHelper
{
  private final ImageView mView;
  
  public AppCompatImageHelper(ImageView paramImageView)
  {
    mView = paramImageView;
  }
  
  public void loadFromAttributes(AttributeSet paramAttributeSet, int paramInt)
  {
    Object localObject3 = null;
    Object localObject2 = null;
    Object localObject1 = localObject3;
    try
    {
      Drawable localDrawable3 = mView.getDrawable();
      Drawable localDrawable1 = localDrawable3;
      Drawable localDrawable2 = localDrawable1;
      if (localDrawable3 == null)
      {
        localObject1 = localObject3;
        localObject2 = TintTypedArray.obtainStyledAttributes(mView.getContext(), paramAttributeSet, R.styleable.AppCompatImageView, paramInt, 0);
        paramAttributeSet = (AttributeSet)localObject2;
        localObject1 = paramAttributeSet;
        paramInt = ((TintTypedArray)localObject2).getResourceId(R.styleable.AppCompatImageView_srcCompat, -1);
        localObject2 = paramAttributeSet;
        localDrawable2 = localDrawable1;
        if (paramInt != -1)
        {
          localObject1 = paramAttributeSet;
          localDrawable3 = TintManager.getDrawable(mView.getContext(), paramInt);
          localDrawable1 = localDrawable3;
          localObject2 = paramAttributeSet;
          localDrawable2 = localDrawable1;
          if (localDrawable3 != null)
          {
            localObject1 = paramAttributeSet;
            mView.setImageDrawable(localDrawable3);
            localDrawable2 = localDrawable1;
            localObject2 = paramAttributeSet;
          }
        }
      }
      if (localDrawable2 != null)
      {
        localObject1 = localObject2;
        DrawableUtils.fixDrawable(localDrawable2);
      }
      if (localObject2 != null)
      {
        ((TintTypedArray)localObject2).recycle();
        return;
      }
    }
    catch (Throwable paramAttributeSet)
    {
      if (localObject1 != null) {
        ((TintTypedArray)localObject1).recycle();
      }
      throw paramAttributeSet;
    }
  }
  
  boolean loadFromAttributes()
  {
    Drawable localDrawable = mView.getBackground();
    return (Build.VERSION.SDK_INT < 21) || (!(localDrawable instanceof RippleDrawable));
  }
  
  public void setImageResource(int paramInt)
  {
    if (paramInt != 0)
    {
      Drawable localDrawable = TintManager.getDrawable(mView.getContext(), paramInt);
      if (localDrawable != null) {
        DrawableUtils.fixDrawable(localDrawable);
      }
      mView.setImageDrawable(localDrawable);
      return;
    }
    mView.setImageDrawable(null);
  }
}

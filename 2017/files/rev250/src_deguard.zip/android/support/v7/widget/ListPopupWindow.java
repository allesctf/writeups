package android.support.v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Handler;
import android.support.v4.widget.PopupWindowCompat;
import android.support.v7.appcompat.R.attr;
import android.support.v7.appcompat.R.styleable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import java.lang.reflect.Method;

public class ListPopupWindow
  implements android.support.v7.view.menu.ListPopupWindow
{
  private static Method sClipToWindowEnabledMethod;
  private static Method sComputeFitSystemWindowsMethod;
  private static Method sGetMaxAvailableHeightMethod;
  private boolean DEBUG = true;
  private ListAdapter mAdapter;
  private Context mContext;
  private boolean mDropDownAlwaysVisible = false;
  private View mDropDownAnchorView;
  private int mDropDownGravity = 0;
  private int mDropDownHeight = -2;
  private int mDropDownHorizontalOffset;
  ListPopupWindow.DropDownListView mDropDownList;
  private Drawable mDropDownListHighlight;
  private int mDropDownVerticalOffset;
  private boolean mDropDownVerticalOffsetSet;
  private int mDropDownWidth = -2;
  private int mDropDownWindowLayoutType = 1002;
  private boolean mForceIgnoreOutsideTouch = false;
  final Handler mHandler;
  private final ai.a mHideSelector = new ai.a(this);
  private AdapterView.OnItemClickListener mItemClickListener;
  private AdapterView.OnItemSelectedListener mItemSelectedListener;
  int mListItemExpandMaximum = Integer.MAX_VALUE;
  private Rect mMenu;
  private boolean mModal;
  private DataSetObserver mObserver;
  PopupWindow mPopup;
  private int mPromptPosition = 0;
  private View mPromptView;
  final ai.e mRunnable = new ai.e(this);
  private final ai.c mScrollListener = new ai.c(this);
  private Runnable mShowDropDownRunnable;
  private final Rect mTempRect = new Rect();
  private final ai.d mTouchInterceptor = new ai.d(this);
  
  static
  {
    Object localObject = Boolean.TYPE;
    try
    {
      localObject = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { localObject });
      sClipToWindowEnabledMethod = (Method)localObject;
    }
    catch (NoSuchMethodException localNoSuchMethodException1)
    {
      for (;;)
      {
        try
        {
          Class localClass;
          localObject = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, localObject, localClass });
          sGetMaxAvailableHeightMethod = (Method)localObject;
        }
        catch (NoSuchMethodException localNoSuchMethodException2)
        {
          Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
          continue;
        }
        try
        {
          localObject = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
          sComputeFitSystemWindowsMethod = (Method)localObject;
          return;
        }
        catch (NoSuchMethodException localNoSuchMethodException3)
        {
          Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
        }
        localNoSuchMethodException1 = localNoSuchMethodException1;
        Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
      }
    }
    localObject = Integer.TYPE;
    localClass = Boolean.TYPE;
  }
  
  public ListPopupWindow(Context paramContext)
  {
    this(paramContext, null, R.attr.listPopupWindowStyle);
  }
  
  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    mContext = paramContext;
    mHandler = new Handler(paramContext.getMainLooper());
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ListPopupWindow, paramInt1, paramInt2);
    mDropDownHorizontalOffset = localTypedArray.getDimensionPixelOffset(R.styleable.ListPopupWindow_android_dropDownHorizontalOffset, 0);
    mDropDownVerticalOffset = localTypedArray.getDimensionPixelOffset(R.styleable.ListPopupWindow_android_dropDownVerticalOffset, 0);
    if (mDropDownVerticalOffset != 0) {
      mDropDownVerticalOffsetSet = true;
    }
    localTypedArray.recycle();
    if (Build.VERSION.SDK_INT >= 11) {}
    for (mPopup = new AppCompatPopupWindow(paramContext, paramAttributeSet, paramInt1, paramInt2);; mPopup = new AppCompatPopupWindow(paramContext, paramAttributeSet, paramInt1))
    {
      mPopup.setInputMethodMode(1);
      return;
    }
  }
  
  private int buildDropDown()
  {
    boolean bool2 = true;
    Object localObject2;
    boolean bool1;
    Object localObject1;
    View localView;
    LinearLayout.LayoutParams localLayoutParams;
    label260:
    int i;
    int j;
    if (mDropDownList == null)
    {
      localObject2 = mContext;
      mShowDropDownRunnable = new ai.1(this);
      if (!mModal)
      {
        bool1 = true;
        mDropDownList = show((Context)localObject2, bool1);
        if (mDropDownListHighlight != null) {
          mDropDownList.setSelector(mDropDownListHighlight);
        }
        mDropDownList.setAdapter(mAdapter);
        mDropDownList.setOnItemClickListener(mItemClickListener);
        mDropDownList.setFocusable(true);
        mDropDownList.setFocusableInTouchMode(true);
        mDropDownList.setOnItemSelectedListener(new ai.2(this));
        mDropDownList.setOnScrollListener(mScrollListener);
        if (mItemSelectedListener != null) {
          mDropDownList.setOnItemSelectedListener(mItemSelectedListener);
        }
        localObject1 = mDropDownList;
        localView = mPromptView;
        if (localView == null) {
          break label749;
        }
        localObject2 = new LinearLayout((Context)localObject2);
        ((LinearLayout)localObject2).setOrientation(1);
        localLayoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0F);
        switch (mPromptPosition)
        {
        default: 
          Log.e("ListPopupWindow", "Invalid hint position " + mPromptPosition);
          if (mDropDownWidth >= 0)
          {
            i = mDropDownWidth;
            j = Integer.MIN_VALUE;
            label276:
            localView.measure(View.MeasureSpec.makeMeasureSpec(i, j), 0);
            localObject1 = (LinearLayout.LayoutParams)localView.getLayoutParams();
            i = localView.getMeasuredHeight();
            j = topMargin;
            i = bottomMargin + (i + j);
            localObject1 = localObject2;
          }
          break;
        }
      }
    }
    for (;;)
    {
      mPopup.setContentView((View)localObject1);
      for (;;)
      {
        label332:
        localObject1 = mPopup.getBackground();
        int k;
        if (localObject1 != null)
        {
          ((Drawable)localObject1).getPadding(mTempRect);
          k = mTempRect.top + mTempRect.bottom;
          if (mDropDownVerticalOffsetSet) {
            break label741;
          }
          mDropDownVerticalOffset = (-mTempRect.top);
        }
        label391:
        label569:
        label741:
        for (;;)
        {
          if (mPopup.getInputMethodMode() == 2) {}
          int m;
          for (bool1 = bool2;; bool1 = false)
          {
            m = getMaxAvailableHeight(getAnchorView(), mDropDownVerticalOffset, bool1);
            if ((!mDropDownAlwaysVisible) && (mDropDownHeight != -1)) {
              break label569;
            }
            return m + k;
            bool1 = false;
            break;
            ((ViewGroup)localObject2).addView((View)localObject1, localLayoutParams);
            ((ViewGroup)localObject2).addView(localView);
            break label260;
            ((ViewGroup)localObject2).addView(localView);
            ((ViewGroup)localObject2).addView((View)localObject1, localLayoutParams);
            break label260;
            j = 0;
            i = 0;
            break label276;
            localObject1 = (ViewGroup)mPopup.getContentView();
            localObject1 = mPromptView;
            if (localObject1 == null) {
              break label744;
            }
            localObject2 = (LinearLayout.LayoutParams)((View)localObject1).getLayoutParams();
            i = ((View)localObject1).getMeasuredHeight();
            j = topMargin;
            i = bottomMargin + (i + j);
            break label332;
            mTempRect.setEmpty();
            k = 0;
            break label391;
          }
          switch (mDropDownWidth)
          {
          default: 
            j = View.MeasureSpec.makeMeasureSpec(mDropDownWidth, 1073741824);
          }
          for (;;)
          {
            m = mDropDownList.measureHeightOfChildrenCompat(j, 0, -1, m - i, -1);
            j = i;
            if (m > 0) {
              j = i + (mDropDownList.getPaddingTop() + mDropDownList.getPaddingBottom() + k);
            }
            return m + j;
            j = View.MeasureSpec.makeMeasureSpec(mContext.getResources().getDisplayMetrics().widthPixels - (mTempRect.left + mTempRect.right), Integer.MIN_VALUE);
            continue;
            j = View.MeasureSpec.makeMeasureSpec(mContext.getResources().getDisplayMetrics().widthPixels - (mTempRect.left + mTempRect.right), 1073741824);
          }
        }
        label744:
        i = 0;
      }
      label749:
      i = 0;
    }
  }
  
  private int getMaxAvailableHeight(View paramView, int paramInt, boolean paramBoolean)
  {
    if (sGetMaxAvailableHeightMethod != null)
    {
      Object localObject = sGetMaxAvailableHeightMethod;
      PopupWindow localPopupWindow = mPopup;
      try
      {
        localObject = ((Method)localObject).invoke(localPopupWindow, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
        localObject = (Integer)localObject;
        int i = ((Integer)localObject).intValue();
        return i;
      }
      catch (Exception localException)
      {
        Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
      }
    }
    return mPopup.getMaxAvailableHeight(paramView, paramInt);
  }
  
  private void removePromptView()
  {
    if (mPromptView != null)
    {
      ViewParent localViewParent = mPromptView.getParent();
      if ((localViewParent instanceof ViewGroup)) {
        ((ViewGroup)localViewParent).removeView(mPromptView);
      }
    }
  }
  
  private void setPopupClipToScreenEnabled(boolean paramBoolean)
  {
    if (sClipToWindowEnabledMethod != null)
    {
      Method localMethod = sClipToWindowEnabledMethod;
      PopupWindow localPopupWindow = mPopup;
      try
      {
        localMethod.invoke(localPopupWindow, new Object[] { Boolean.valueOf(paramBoolean) });
        return;
      }
      catch (Exception localException)
      {
        Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
      }
    }
  }
  
  public void clearListSelection()
  {
    ListPopupWindow.DropDownListView localDropDownListView = mDropDownList;
    if (localDropDownListView != null)
    {
      localDropDownListView.setListSelectionHidden(true);
      localDropDownListView.requestLayout();
    }
  }
  
  public void dismiss()
  {
    mPopup.dismiss();
    removePromptView();
    mPopup.setContentView(null);
    mDropDownList = null;
    mHandler.removeCallbacks(mRunnable);
  }
  
  public void dismiss(int paramInt)
  {
    mDropDownGravity = paramInt;
  }
  
  public View getAnchorView()
  {
    return mDropDownAnchorView;
  }
  
  public Drawable getBackground()
  {
    return mPopup.getBackground();
  }
  
  public int getHorizontalOffset()
  {
    return mDropDownHorizontalOffset;
  }
  
  public ListView getListView()
  {
    return mDropDownList;
  }
  
  public int getVerticalOffset()
  {
    if (!mDropDownVerticalOffsetSet) {
      return 0;
    }
    return mDropDownVerticalOffset;
  }
  
  public int getWidth()
  {
    return mDropDownWidth;
  }
  
  public boolean isInputMethodNotNeeded()
  {
    return mPopup.getInputMethodMode() == 2;
  }
  
  public boolean isModal()
  {
    return mModal;
  }
  
  public boolean isShowing()
  {
    return mPopup.isShowing();
  }
  
  public void setAdapter(ListAdapter paramListAdapter)
  {
    if (mObserver == null) {
      mObserver = new ai.b(this);
    }
    for (;;)
    {
      mAdapter = paramListAdapter;
      if (mAdapter != null) {
        paramListAdapter.registerDataSetObserver(mObserver);
      }
      if (mDropDownList == null) {
        break;
      }
      mDropDownList.setAdapter(mAdapter);
      return;
      if (mAdapter != null) {
        mAdapter.unregisterDataSetObserver(mObserver);
      }
    }
  }
  
  public void setAnchorView(View paramView)
  {
    mDropDownAnchorView = paramView;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable)
  {
    mPopup.setBackgroundDrawable(paramDrawable);
  }
  
  public void setContentWidth(int paramInt)
  {
    Drawable localDrawable = mPopup.getBackground();
    if (localDrawable != null)
    {
      localDrawable.getPadding(mTempRect);
      mDropDownWidth = (mTempRect.left + mTempRect.right + paramInt);
      return;
    }
    setWidth(paramInt);
  }
  
  public void setHorizontalOffset(int paramInt)
  {
    mDropDownHorizontalOffset = paramInt;
  }
  
  public void setInputMethodMode(int paramInt)
  {
    mPopup.setInputMethodMode(paramInt);
  }
  
  public void setModal(boolean paramBoolean)
  {
    mModal = paramBoolean;
    mPopup.setFocusable(paramBoolean);
  }
  
  public void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener)
  {
    mPopup.setOnDismissListener(paramOnDismissListener);
  }
  
  public void setOnItemClickListener(AdapterView.OnItemClickListener paramOnItemClickListener)
  {
    mItemClickListener = paramOnItemClickListener;
  }
  
  public void setPromptPosition(int paramInt)
  {
    mPromptPosition = paramInt;
  }
  
  public void setSelection(int paramInt)
  {
    ListPopupWindow.DropDownListView localDropDownListView = mDropDownList;
    if ((isShowing()) && (localDropDownListView != null))
    {
      localDropDownListView.setListSelectionHidden(false);
      localDropDownListView.setSelection(paramInt);
      if ((Build.VERSION.SDK_INT >= 11) && (localDropDownListView.getChoiceMode() != 0)) {
        localDropDownListView.setItemChecked(paramInt, true);
      }
    }
  }
  
  public void setVerticalOffset(int paramInt)
  {
    mDropDownVerticalOffset = paramInt;
    mDropDownVerticalOffsetSet = true;
  }
  
  public void setWidth(int paramInt)
  {
    mDropDownWidth = paramInt;
  }
  
  ListPopupWindow.DropDownListView show(Context paramContext, boolean paramBoolean)
  {
    return new ListPopupWindow.DropDownListView(paramContext, paramBoolean);
  }
  
  public void show()
  {
    boolean bool1 = true;
    boolean bool2 = false;
    int m = -1;
    int k = buildDropDown();
    int j = k;
    boolean bool3 = isInputMethodNotNeeded();
    PopupWindowCompat.setWindowLayoutType(mPopup, mDropDownWindowLayoutType);
    int i;
    label66:
    Object localObject1;
    label87:
    label101:
    Object localObject2;
    if (mPopup.isShowing())
    {
      int n;
      int i1;
      if (mDropDownWidth == -1)
      {
        i = -1;
        if (mDropDownHeight != -1) {
          break label268;
        }
        if (!bool3) {
          break label220;
        }
        if (!bool3) {
          break label230;
        }
        localObject1 = mPopup;
        if (mDropDownWidth != -1) {
          break label225;
        }
        k = -1;
        ((PopupWindow)localObject1).setWidth(k);
        mPopup.setHeight(0);
        localObject1 = mPopup;
        bool1 = bool2;
        if (!mForceIgnoreOutsideTouch)
        {
          bool1 = bool2;
          if (!mDropDownAlwaysVisible) {
            bool1 = true;
          }
        }
        ((PopupWindow)localObject1).setOutsideTouchable(bool1);
        localObject1 = mPopup;
        localObject2 = getAnchorView();
        n = mDropDownHorizontalOffset;
        i1 = mDropDownVerticalOffset;
        k = i;
        if (i < 0) {
          k = -1;
        }
        if (j >= 0) {
          break label290;
        }
      }
      label220:
      label225:
      label230:
      label268:
      label290:
      for (i = m;; i = j)
      {
        ((PopupWindow)localObject1).update((View)localObject2, n, i1, k, i);
        return;
        if (mDropDownWidth == -2)
        {
          i = getAnchorView().getWidth();
          break;
        }
        i = mDropDownWidth;
        break;
        j = -1;
        break label66;
        k = 0;
        break label87;
        localObject1 = mPopup;
        if (mDropDownWidth == -1) {}
        for (k = -1;; k = 0)
        {
          ((PopupWindow)localObject1).setWidth(k);
          mPopup.setHeight(-1);
          break;
        }
        if (mDropDownHeight == -2)
        {
          j = k;
          break label101;
        }
        j = mDropDownHeight;
        break label101;
      }
    }
    if (mDropDownWidth == -1) {
      i = -1;
    }
    for (;;)
    {
      label315:
      Rect localRect;
      if (mDropDownHeight == -1)
      {
        j = -1;
        mPopup.setWidth(i);
        mPopup.setHeight(j);
        setPopupClipToScreenEnabled(true);
        localObject1 = mPopup;
        if ((mForceIgnoreOutsideTouch) || (mDropDownAlwaysVisible)) {
          break label531;
        }
        ((PopupWindow)localObject1).setOutsideTouchable(bool1);
        mPopup.setTouchInterceptor(mTouchInterceptor);
        if (sComputeFitSystemWindowsMethod != null)
        {
          localObject1 = sComputeFitSystemWindowsMethod;
          localObject2 = mPopup;
          localRect = mMenu;
        }
      }
      try
      {
        ((Method)localObject1).invoke(localObject2, new Object[] { localRect });
        PopupWindowCompat.showAsDropDown(mPopup, getAnchorView(), mDropDownHorizontalOffset, mDropDownVerticalOffset, mDropDownGravity);
        mDropDownList.setSelection(-1);
        if ((!mModal) || (mDropDownList.isInTouchMode())) {
          clearListSelection();
        }
        if (!mModal)
        {
          mHandler.post(mHideSelector);
          return;
          if (mDropDownWidth == -2)
          {
            i = getAnchorView().getWidth();
          }
          else
          {
            i = mDropDownWidth;
            continue;
            if (mDropDownHeight == -2) {
              break label315;
            }
            j = mDropDownHeight;
            break label315;
            label531:
            bool1 = false;
          }
        }
      }
      catch (Exception localException)
      {
        for (;;)
        {
          Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", localException);
        }
      }
    }
  }
  
  public void show(int paramInt)
  {
    mPopup.setAnimationStyle(paramInt);
  }
  
  public void show(Rect paramRect)
  {
    mMenu = paramRect;
  }
}

package android.support.v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R.id;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;

public class AlertDialogLayout
  extends LinearLayoutCompat
{
  public AlertDialogLayout(Context paramContext)
  {
    super(paramContext);
  }
  
  public AlertDialogLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  private static int a(View paramView)
  {
    int i = ViewCompat.getMinimumHeight(paramView);
    if (i > 0) {
      return i;
    }
    if ((paramView instanceof ViewGroup))
    {
      paramView = (ViewGroup)paramView;
      if (paramView.getChildCount() == 1) {
        return a(paramView.getChildAt(0));
      }
    }
    return 0;
  }
  
  private void forceUniformWidth(int paramInt1, int paramInt2)
  {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    int i = 0;
    while (i < paramInt1)
    {
      View localView = getChildAt(i);
      if (localView.getVisibility() != 8)
      {
        ah.a localA = (ah.a)localView.getLayoutParams();
        if (width == -1)
        {
          int k = height;
          height = localView.getMeasuredHeight();
          measureChildWithMargins(localView, j, 0, paramInt2, 0);
          height = k;
        }
      }
      i += 1;
    }
  }
  
  private boolean onMeasureExactFormat(int paramInt1, int paramInt2)
  {
    Object localObject3 = null;
    Object localObject1 = null;
    int i3 = getChildCount();
    int i = 0;
    Object localObject2 = null;
    if (i < i3)
    {
      View localView1 = getChildAt(i);
      View localView2 = localView1;
      if (localView1.getVisibility() == 8) {}
      for (;;)
      {
        i += 1;
        break;
        j = localView1.getId();
        if (j == R.id.topPanel)
        {
          localObject3 = localView1;
        }
        else if (j == R.id.buttonPanel)
        {
          localObject1 = localView2;
        }
        else
        {
          if ((j != R.id.contentPanel) && (j != R.id.customPanel)) {
            break label118;
          }
          if (localObject2 != null) {
            return false;
          }
          localObject2 = localView1;
        }
      }
      label118:
      return false;
    }
    int i5 = View.MeasureSpec.getMode(paramInt2);
    int i2 = View.MeasureSpec.getSize(paramInt2);
    int i4 = View.MeasureSpec.getMode(paramInt1);
    int k = 0;
    i = getPaddingTop();
    i = getPaddingBottom() + i;
    int j = i;
    if (localObject3 != null)
    {
      localObject3.measure(paramInt1, 0);
      j = i + localObject3.getMeasuredHeight();
      k = View.combineMeasuredStates(0, localObject3.getMeasuredState());
    }
    i = 0;
    int n;
    if (localObject1 != null)
    {
      ((View)localObject1).measure(paramInt1, 0);
      m = a((View)localObject1);
      i = m;
      n = ((View)localObject1).getMeasuredHeight();
      j += m;
      k = View.combineMeasuredStates(k, ((View)localObject1).getMeasuredState());
    }
    for (int m = n - m;; m = 0)
    {
      int i1;
      if (localObject2 != null) {
        if (i5 == 0)
        {
          n = 0;
          localObject2.measure(paramInt1, n);
          i1 = localObject2.getMeasuredHeight();
          j += i1;
          k = View.combineMeasuredStates(k, localObject2.getMeasuredState());
        }
      }
      for (;;)
      {
        i2 -= j;
        if (localObject1 != null)
        {
          int i6 = Math.min(i2, m);
          m = i2;
          n = i;
          if (i6 > 0)
          {
            m = i2 - i6;
            n = i + i6;
          }
          ((View)localObject1).measure(paramInt1, View.MeasureSpec.makeMeasureSpec(n, 1073741824));
          j = ((View)localObject1).getMeasuredHeight() + (j - i);
          k = View.combineMeasuredStates(k, ((View)localObject1).getMeasuredState());
        }
        for (;;)
        {
          if ((localObject2 != null) && (m > 0))
          {
            localObject2.measure(paramInt1, View.MeasureSpec.makeMeasureSpec(m + i1, i5));
            i = j - i1 + localObject2.getMeasuredHeight();
            k = View.combineMeasuredStates(k, localObject2.getMeasuredState());
          }
          for (;;)
          {
            m = 0;
            j = 0;
            for (;;)
            {
              if (j < i3)
              {
                localObject1 = getChildAt(j);
                n = m;
                if (((View)localObject1).getVisibility() != 8) {
                  n = Math.max(m, ((View)localObject1).getMeasuredWidth());
                }
                j += 1;
                m = n;
                continue;
                n = View.MeasureSpec.makeMeasureSpec(Math.max(0, i2 - j), i5);
                break;
              }
            }
            setMeasuredDimension(View.resolveSizeAndState(m + (getPaddingLeft() + getPaddingRight()), paramInt1, k), View.resolveSizeAndState(i, paramInt2, 0));
            if (i4 != 1073741824) {
              forceUniformWidth(i3, paramInt2);
            }
            return true;
            i = j;
          }
          m = i2;
        }
        i1 = 0;
      }
    }
  }
  
  private void setChildFrame(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramView.layout(paramInt1, paramInt2, paramInt1 + paramInt3, paramInt2 + paramInt4);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int j = getPaddingLeft();
    int k = paramInt3 - paramInt1;
    int m = getPaddingRight();
    int n = getPaddingRight();
    paramInt1 = getMeasuredHeight();
    int i1 = getChildCount();
    int i2 = getGravity();
    Object localObject;
    label94:
    label97:
    int i3;
    int i4;
    ah.a localA;
    switch (i2 & 0x70)
    {
    default: 
      paramInt1 = getPaddingTop();
      localObject = getDividerDrawable();
      if (localObject == null)
      {
        paramInt3 = 0;
        paramInt4 = 0;
        if (paramInt4 >= i1) {
          break label376;
        }
        localObject = getChildAt(paramInt4);
        paramInt2 = paramInt1;
        if (localObject != null)
        {
          paramInt2 = paramInt1;
          if (((View)localObject).getVisibility() != 8)
          {
            i3 = ((View)localObject).getMeasuredWidth();
            i4 = ((View)localObject).getMeasuredHeight();
            localA = (ah.a)((View)localObject).getLayoutParams();
            int i = gravity;
            paramInt2 = i;
            if (i < 0) {
              paramInt2 = i2 & 0x800007;
            }
            switch (GravityCompat.getAbsoluteGravity(paramInt2, ViewCompat.getLayoutDirection(this)) & 0x7)
            {
            default: 
              paramInt2 = j + leftMargin;
              label224:
              if (hasDividerBeforeChildAt(paramInt4)) {
                paramInt1 += paramInt3;
              }
              break;
            }
          }
        }
      }
      break;
    }
    for (;;)
    {
      paramInt1 = topMargin + paramInt1;
      setChildFrame((View)localObject, paramInt2, paramInt1, i3, i4);
      paramInt2 = paramInt1 + (bottomMargin + i4);
      paramInt4 += 1;
      paramInt1 = paramInt2;
      break label97;
      paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - paramInt1;
      break;
      paramInt3 = getPaddingTop();
      paramInt1 = (paramInt4 - paramInt2 - paramInt1) / 2 + paramInt3;
      break;
      paramInt3 = ((Drawable)localObject).getIntrinsicHeight();
      break label94;
      paramInt2 = (k - j - n - i3) / 2 + j + leftMargin - rightMargin;
      break label224;
      paramInt2 = k - m - i3 - rightMargin;
      break label224;
      label376:
      return;
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    if (!onMeasureExactFormat(paramInt1, paramInt2)) {
      super.onMeasure(paramInt1, paramInt2);
    }
  }
}

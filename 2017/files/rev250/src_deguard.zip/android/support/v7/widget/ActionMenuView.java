package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.view.menu.MenuBuilder.Callback;
import android.support.v7.view.menu.MenuBuilder.ItemInvoker;
import android.support.v7.view.menu.MenuItemImpl;
import android.support.v7.view.menu.MenuView;
import android.support.v7.view.menu.f;
import android.support.v7.view.menu.l.a;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;

public class ActionMenuView
  extends LinearLayoutCompat
  implements MenuBuilder.ItemInvoker, MenuView
{
  e m;
  private l.a mActionMenuPresenterCallback;
  MenuBuilder.Callback mCallback;
  private boolean mFormatItems;
  private int mFormatItemsWidth;
  private int mGeneratedItemPadding;
  private f mMenu;
  private int mMinCellSize;
  private Context mPopupContext;
  private int mPopupTheme;
  private ActionMenuPresenter mPresenter;
  private boolean mReserveOverflow;
  
  public ActionMenuView(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    setBaselineAligned(false);
    float f = getResourcesgetDisplayMetricsdensity;
    mMinCellSize = ((int)(56.0F * f));
    mGeneratedItemPadding = ((int)(f * 4.0F));
    mPopupContext = paramContext;
    mPopupTheme = 0;
  }
  
  static int measureChildForCells(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    boolean bool2 = false;
    c localC = (c)paramView.getLayoutParams();
    int i = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt3) - paramInt4, View.MeasureSpec.getMode(paramInt3));
    ActionMenuItemView localActionMenuItemView;
    if ((paramView instanceof ActionMenuItemView))
    {
      localActionMenuItemView = (ActionMenuItemView)paramView;
      if ((localActionMenuItemView == null) || (!localActionMenuItemView.hasText())) {
        break label184;
      }
      paramInt4 = 1;
      label57:
      if ((paramInt2 <= 0) || ((paramInt4 != 0) && (paramInt2 < 2))) {
        break label190;
      }
      paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1 * paramInt2, Integer.MIN_VALUE), i);
      int j = paramView.getMeasuredWidth();
      paramInt3 = j / paramInt1;
      paramInt2 = paramInt3;
      if (j % paramInt1 != 0) {
        paramInt2 = paramInt3 + 1;
      }
      paramInt3 = paramInt2;
      if (paramInt4 != 0)
      {
        paramInt3 = paramInt2;
        if (paramInt2 >= 2) {}
      }
    }
    label184:
    label190:
    for (paramInt3 = 2;; paramInt3 = 0)
    {
      boolean bool1 = bool2;
      if (!isOverflowButton)
      {
        bool1 = bool2;
        if (paramInt4 != 0) {
          bool1 = true;
        }
      }
      expandable = bool1;
      cellsUsed = paramInt3;
      paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt3 * paramInt1, 1073741824), i);
      return paramInt3;
      localActionMenuItemView = null;
      break;
      paramInt4 = 0;
      break label57;
    }
  }
  
  private void onMeasureExactFormat(int paramInt1, int paramInt2)
  {
    int i7 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int i6 = View.MeasureSpec.getSize(paramInt2);
    int i = getPaddingLeft();
    int j = getPaddingRight();
    int i3 = getPaddingTop() + getPaddingBottom();
    int i8 = ViewGroup.getChildMeasureSpec(paramInt2, i3, -2);
    int i9 = paramInt1 - (i + j);
    paramInt1 = i9 / mMinCellSize;
    paramInt2 = mMinCellSize;
    if (paramInt1 == 0)
    {
      setMeasuredDimension(i9, 0);
      return;
    }
    int i10 = mMinCellSize + i9 % paramInt2 / paramInt1;
    paramInt2 = 0;
    int n = 0;
    j = 0;
    int i1 = 0;
    i = 0;
    long l1 = 0L;
    int i11 = getChildCount();
    int k = 0;
    Object localObject;
    boolean bool;
    int i2;
    c localC;
    for (;;)
    {
      if (k < i11)
      {
        localObject = getChildAt(k);
        if (((View)localObject).getVisibility() == 8)
        {
          k += 1;
        }
        else
        {
          bool = localObject instanceof ActionMenuItemView;
          i2 = i1 + 1;
          if (bool) {
            ((View)localObject).setPadding(mGeneratedItemPadding, 0, mGeneratedItemPadding, 0);
          }
          localC = (c)((View)localObject).getLayoutParams();
          expanded = false;
          extraPixels = 0;
          cellsUsed = 0;
          expandable = false;
          leftMargin = 0;
          rightMargin = 0;
          if ((bool) && (((ActionMenuItemView)localObject).hasText()))
          {
            bool = true;
            label255:
            preventEdgeOffset = bool;
            if (!isOverflowButton) {
              break label366;
            }
            i1 = 1;
            label273:
            i1 = measureChildForCells((View)localObject, i10, i1, i8, i3);
            n = Math.max(n, i1);
            if (!expandable) {
              break label1145;
            }
            j += 1;
          }
        }
      }
    }
    label366:
    label418:
    label447:
    label462:
    label521:
    label549:
    label683:
    label702:
    label728:
    label739:
    label877:
    label1021:
    label1024:
    label1123:
    label1126:
    label1129:
    label1132:
    label1145:
    for (;;)
    {
      if (isOverflowButton) {
        i = 1;
      }
      for (;;)
      {
        paramInt1 -= i1;
        paramInt2 = Math.max(paramInt2, ((View)localObject).getMeasuredHeight());
        if (i1 == 1)
        {
          l1 = 1 << k | l1;
          i1 = i2;
          break;
          bool = false;
          break label255;
          i1 = paramInt1;
          break label273;
          int i4;
          long l2;
          int i5;
          if ((i != 0) && (i1 == 2))
          {
            i2 = 1;
            k = 0;
            i3 = paramInt1;
            paramInt1 = k;
            if ((j <= 0) || (i3 <= 0)) {
              break label1132;
            }
            i4 = Integer.MAX_VALUE;
            l2 = 0L;
            k = 0;
            i5 = 0;
            if (i5 >= i11) {
              break label521;
            }
            localObject = (c)getChildAt(i5).getLayoutParams();
            if (expandable) {
              break label462;
            }
          }
          for (;;)
          {
            i5 += 1;
            break label418;
            i2 = 0;
            break;
            if (cellsUsed < i4)
            {
              i4 = cellsUsed;
              l2 = 1 << i5;
              k = 1;
            }
            else
            {
              if (cellsUsed != i4) {
                break label1129;
              }
              l2 |= 1 << i5;
              k += 1;
            }
          }
          l1 |= l2;
          if (k > i3) {}
          for (;;)
          {
            if ((i == 0) && (i1 == 1))
            {
              i = 1;
              if ((i3 <= 0) || (l1 == 0L) || ((i3 >= i1 - 1) && (i == 0) && (n <= 1))) {
                break label1021;
              }
              float f3 = Long.bitCount(l1);
              float f2 = f3;
              if (i != 0) {
                break label1123;
              }
              float f1 = f3;
              if ((1L & l1) != 0L)
              {
                f1 = f3;
                if (!getChildAt0getLayoutParamspreventEdgeOffset) {
                  f1 = f3 - 0.5F;
                }
              }
              f2 = f1;
              if ((1 << i11 - 1 & l1) == 0L) {
                break label1123;
              }
              f2 = f1;
              if (getChildAt1getLayoutParamspreventEdgeOffset) {
                break label1123;
              }
              f2 = f1 - 0.5F;
              if (f2 <= 0.0F) {
                break label877;
              }
              i = (int)(i3 * i10 / f2);
              j = 0;
              for (;;)
              {
                k = paramInt1;
                if (j >= i11) {
                  break label1024;
                }
                if ((1 << j & l1) != 0L) {
                  break;
                }
                j += 1;
              }
              paramInt1 = 0;
              if (paramInt1 < i11)
              {
                localObject = getChildAt(paramInt1);
                localC = (c)((View)localObject).getLayoutParams();
                if ((1 << paramInt1 & l2) == 0L)
                {
                  if (cellsUsed != i4 + 1) {
                    break label1126;
                  }
                  l1 |= 1 << paramInt1;
                }
              }
            }
            for (;;)
            {
              paramInt1 += 1;
              break label739;
              if ((i2 != 0) && (preventEdgeOffset) && (i3 == 1)) {
                ((View)localObject).setPadding(mGeneratedItemPadding + i10, 0, mGeneratedItemPadding, 0);
              }
              cellsUsed += 1;
              expanded = true;
              i3 -= 1;
              continue;
              paramInt1 = 1;
              break;
              i = 0;
              break label549;
              i = 0;
              break label702;
              localObject = getChildAt(j);
              localC = (c)((View)localObject).getLayoutParams();
              if ((localObject instanceof ActionMenuItemView))
              {
                extraPixels = i;
                expanded = true;
                if ((j == 0) && (!preventEdgeOffset)) {
                  leftMargin = (-i / 2);
                }
                paramInt1 = 1;
                break label728;
              }
              if (isOverflowButton)
              {
                extraPixels = i;
                expanded = true;
                rightMargin = (-i / 2);
                paramInt1 = 1;
                break label728;
              }
              if (j != 0) {
                leftMargin = (i / 2);
              }
              if (j != i11 - 1) {
                rightMargin = (i / 2);
              }
              break label728;
              k = paramInt1;
              if (k != 0)
              {
                paramInt1 = 0;
                if (paramInt1 < i11)
                {
                  localObject = getChildAt(paramInt1);
                  localC = (c)((View)localObject).getLayoutParams();
                  if (!expanded) {}
                  for (;;)
                  {
                    paramInt1 += 1;
                    break;
                    i = cellsUsed;
                    ((View)localObject).measure(View.MeasureSpec.makeMeasureSpec(extraPixels + i * i10, 1073741824), i8);
                  }
                }
              }
              if (i7 != 1073741824) {}
              for (;;)
              {
                setMeasuredDimension(i9, paramInt2);
                return;
                paramInt2 = i6;
              }
              break label683;
            }
            break label447;
          }
        }
        i1 = i2;
        break;
      }
    }
  }
  
  protected c a(ViewGroup.LayoutParams paramLayoutParams)
  {
    if (paramLayoutParams != null)
    {
      if ((paramLayoutParams instanceof c)) {}
      for (paramLayoutParams = new c((c)paramLayoutParams);; paramLayoutParams = new c(paramLayoutParams))
      {
        localObject = paramLayoutParams;
        if (gravity > 0) {
          break;
        }
        gravity = 16;
        return paramLayoutParams;
      }
    }
    Object localObject = getValue();
    return localObject;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return (paramLayoutParams != null) && ((paramLayoutParams instanceof c));
  }
  
  public void dismissPopupMenus()
  {
    if (mPresenter != null) {
      mPresenter.dismissPopupMenus();
    }
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    return false;
  }
  
  public c generateOverflowButtonLayoutParams()
  {
    c localC = getValue();
    isOverflowButton = true;
    return localC;
  }
  
  public Menu getMenu()
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a6 = a5\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer$LiveA.onUseLocal(UnSSATransformer.java:552)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer$LiveA.onUseLocal(UnSSATransformer.java:1)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.onUse(BaseAnalyze.java:166)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.onUse(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.travel(Cfg.java:331)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.travel(Cfg.java:387)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:90)\n\t... 17 more\n");
  }
  
  public Drawable getOverflowIcon()
  {
    getMenu();
    return mPresenter.getOverflowIcon();
  }
  
  public int getPopupTheme()
  {
    return mPopupTheme;
  }
  
  protected c getValue()
  {
    c localC = new c(-2, -2);
    gravity = 16;
    return localC;
  }
  
  public int getWindowAnimations()
  {
    return 0;
  }
  
  protected boolean hasSupportDividerBeforeChildAt(int paramInt)
  {
    boolean bool2 = false;
    if (paramInt == 0) {
      return false;
    }
    View localView1 = getChildAt(paramInt - 1);
    View localView2 = getChildAt(paramInt);
    boolean bool1 = bool2;
    if (paramInt < getChildCount())
    {
      bool1 = bool2;
      if ((localView1 instanceof a)) {
        bool1 = false | ((a)localView1).needsDividerAfter();
      }
    }
    bool2 = bool1;
    if (paramInt > 0)
    {
      bool2 = bool1;
      if ((localView2 instanceof a)) {
        bool2 = ((a)localView2).needsDividerBefore() | bool1;
      }
    }
    return bool2;
  }
  
  public boolean hideOverflowMenu()
  {
    return (mPresenter != null) && (mPresenter.showOverflowMenu());
  }
  
  public c initialize(AttributeSet paramAttributeSet)
  {
    return new c(getContext(), paramAttributeSet);
  }
  
  public void initialize(f paramF)
  {
    mMenu = paramF;
  }
  
  public boolean invokeItem(MenuItemImpl paramMenuItemImpl)
  {
    return mMenu.a(paramMenuItemImpl, 0);
  }
  
  public boolean isOverflowMenuShowPending()
  {
    return (mPresenter != null) && (mPresenter.isOverflowMenuShowPending());
  }
  
  public boolean isOverflowMenuShowing()
  {
    return (mPresenter != null) && (mPresenter.isOverflowMenuShowing());
  }
  
  public boolean isOverflowReserved()
  {
    return mReserveOverflow;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    if (mPresenter != null)
    {
      mPresenter.updateMenuView(false);
      if (mPresenter.isOverflowMenuShowing())
      {
        mPresenter.hideOverflowMenu();
        mPresenter.showOverflowMenu();
      }
    }
  }
  
  public void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    dismissPopupMenus();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (!mFormatItems)
    {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    int i2 = getChildCount();
    int i1 = (paramInt4 - paramInt2) / 2;
    int i3 = getDividerWidth();
    paramInt4 = 0;
    paramInt2 = paramInt3 - paramInt1 - getPaddingRight() - getPaddingLeft();
    int j = 0;
    paramBoolean = ViewUtils.isLayoutRtl(this);
    int i = 0;
    View localView;
    c localC;
    if (i < i2)
    {
      localView = getChildAt(i);
      if (localView.getVisibility() == 8) {}
      for (;;)
      {
        i += 1;
        break;
        localC = (c)localView.getLayoutParams();
        if (isOverflowButton)
        {
          k = localView.getMeasuredWidth();
          j = k;
          if (hasSupportDividerBeforeChildAt(i)) {
            j = k + i3;
          }
          i4 = localView.getMeasuredHeight();
          if (paramBoolean)
          {
            k = getPaddingLeft();
            k = leftMargin + k;
            n = k + j;
          }
          for (;;)
          {
            int i5 = i1 - i4 / 2;
            localView.layout(k, i5, n, i4 + i5);
            paramInt2 -= j;
            j = 1;
            break;
            n = getWidth() - getPaddingRight() - rightMargin;
            k = n - j;
          }
        }
        int k = localView.getMeasuredWidth();
        int n = leftMargin;
        int i4 = rightMargin;
        if (hasSupportDividerBeforeChildAt(i)) {}
        paramInt2 -= k + n + i4;
        paramInt4 += 1;
      }
    }
    if ((i2 == 1) && (j == 0))
    {
      localView = getChildAt(0);
      paramInt2 = localView.getMeasuredWidth();
      paramInt4 = localView.getMeasuredHeight();
      paramInt1 = (paramInt3 - paramInt1) / 2 - paramInt2 / 2;
      paramInt3 = i1 - paramInt4 / 2;
      localView.layout(paramInt1, paramInt3, paramInt2 + paramInt1, paramInt4 + paramInt3);
      return;
    }
    if (j != 0)
    {
      paramInt1 = 0;
      paramInt1 = paramInt4 - paramInt1;
      if (paramInt1 <= 0) {
        break label458;
      }
      paramInt1 = paramInt2 / paramInt1;
      label382:
      paramInt3 = Math.max(0, paramInt1);
      if (!paramBoolean) {
        break label528;
      }
      paramInt2 = getWidth() - getPaddingRight();
      paramInt1 = 0;
      label405:
      if (paramInt1 >= i2) {
        return;
      }
      localView = getChildAt(paramInt1);
      localC = (c)localView.getLayoutParams();
      if (localView.getVisibility() == 8) {
        break label651;
      }
      if (!isOverflowButton) {
        break label463;
      }
    }
    label458:
    label463:
    label528:
    label651:
    for (;;)
    {
      paramInt1 += 1;
      break label405;
      paramInt1 = 1;
      break;
      paramInt1 = 0;
      break label382;
      paramInt2 -= rightMargin;
      paramInt4 = localView.getMeasuredWidth();
      i = localView.getMeasuredHeight();
      j = i1 - i / 2;
      localView.layout(paramInt2 - paramInt4, j, paramInt2, i + j);
      paramInt2 -= leftMargin + paramInt4 + paramInt3;
      continue;
      paramInt2 = getPaddingLeft();
      paramInt1 = 0;
      if (paramInt1 >= i2) {
        return;
      }
      localView = getChildAt(paramInt1);
      localC = (c)localView.getLayoutParams();
      if (localView.getVisibility() != 8) {
        if (!isOverflowButton) {}
      }
      for (;;)
      {
        paramInt1 += 1;
        break;
        paramInt2 += leftMargin;
        paramInt4 = localView.getMeasuredWidth();
        i = localView.getMeasuredHeight();
        j = i1 - i / 2;
        localView.layout(paramInt2, j, paramInt2 + paramInt4, i + j);
        paramInt2 = rightMargin + paramInt4 + paramInt3 + paramInt2;
      }
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    boolean bool2 = mFormatItems;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {}
    int j;
    for (boolean bool1 = true;; bool1 = false)
    {
      mFormatItems = bool1;
      if (bool2 != mFormatItems) {
        mFormatItemsWidth = 0;
      }
      i = View.MeasureSpec.getSize(paramInt1);
      if ((mFormatItems) && (mMenu != null) && (i != mFormatItemsWidth))
      {
        mFormatItemsWidth = i;
        mMenu.onItemsChanged(true);
      }
      j = getChildCount();
      if ((!mFormatItems) || (j <= 0)) {
        break;
      }
      onMeasureExactFormat(paramInt1, paramInt2);
      return;
    }
    int i = 0;
    while (i < j)
    {
      c localC = (c)getChildAt(i).getLayoutParams();
      rightMargin = 0;
      leftMargin = 0;
      i += 1;
    }
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public f peekMenu()
  {
    return mMenu;
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean)
  {
    mPresenter.setExpandedActionViewsExclusive(paramBoolean);
  }
  
  public void setMenuCallbacks(l.a paramA, MenuBuilder.Callback paramCallback)
  {
    mActionMenuPresenterCallback = paramA;
    mCallback = paramCallback;
  }
  
  public void setOnMenuItemClickListener(e paramE)
  {
    m = paramE;
  }
  
  public void setOverflowIcon(Drawable paramDrawable)
  {
    getMenu();
    mPresenter.setOverflowIcon(paramDrawable);
  }
  
  public void setOverflowReserved(boolean paramBoolean)
  {
    mReserveOverflow = paramBoolean;
  }
  
  public void setPopupTheme(int paramInt)
  {
    if (mPopupTheme != paramInt)
    {
      mPopupTheme = paramInt;
      if (paramInt == 0)
      {
        mPopupContext = getContext();
        return;
      }
      mPopupContext = new ContextThemeWrapper(getContext(), paramInt);
    }
  }
  
  public void setPresenter(ActionMenuPresenter paramActionMenuPresenter)
  {
    mPresenter = paramActionMenuPresenter;
    mPresenter.setMenuView(this);
  }
  
  public boolean showOverflowMenu()
  {
    return (mPresenter != null) && (mPresenter.hideOverflowMenu());
  }
  
  public static abstract interface a
  {
    public abstract boolean needsDividerAfter();
    
    public abstract boolean needsDividerBefore();
  }
  
  private class b
    implements l.a
  {
    b() {}
    
    public void onCloseMenu(f paramF, boolean paramBoolean) {}
    
    public boolean onOpenSubMenu(f paramF)
    {
      return false;
    }
  }
  
  public static class c
    extends ah.a
  {
    @ViewDebug.ExportedProperty
    public int cellsUsed;
    @ViewDebug.ExportedProperty
    public boolean expandable;
    boolean expanded;
    @ViewDebug.ExportedProperty
    public int extraPixels;
    @ViewDebug.ExportedProperty
    public boolean isOverflowButton;
    @ViewDebug.ExportedProperty
    public boolean preventEdgeOffset;
    
    public c(int paramInt1, int paramInt2)
    {
      super(paramInt2);
      isOverflowButton = false;
    }
    
    public c(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
    }
    
    public c(c paramC)
    {
      super();
      isOverflowButton = isOverflowButton;
    }
    
    public c(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
  }
  
  private class d
    implements MenuBuilder.Callback
  {
    d() {}
    
    public boolean onMenuItemSelected(f paramF, MenuItem paramMenuItem)
    {
      return (m != null) && (m.onMenuItemClick(paramMenuItem));
    }
    
    public void onMenuModeChange(f paramF)
    {
      if (mCallback != null) {
        mCallback.onMenuModeChange(paramF);
      }
    }
  }
  
  public static abstract interface e
  {
    public abstract boolean onMenuItemClick(MenuItem paramMenuItem);
  }
}

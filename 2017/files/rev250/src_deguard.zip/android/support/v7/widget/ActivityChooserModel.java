package android.support.v7.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.DataSetObservable;
import android.os.AsyncTask;
import android.text.TextUtils;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ActivityChooserModel
  extends DataSetObservable
{
  static final String LOG_TAG = e.class.getSimpleName();
  private static final Map<String, e> sDataModelRegistry = new HashMap();
  private static final Object sRegistryLock = new Object();
  private final List<e.a> mActivities;
  private OnChooseActivityListener mActivityChoserModelPolicy;
  private ActivitySorter mActivitySorter;
  boolean mCanReadHistoricalData;
  final Context mContext;
  private final List<e.c> mHistoricalRecords;
  private boolean mHistoricalRecordsChanged;
  final String mHistoryFileName;
  private int mHistoryMaxSize;
  private final Object mInstanceLock;
  private Intent mIntent;
  private boolean mReadShareHistoryCalled;
  private boolean mReloadActivities;
  
  private boolean addHisoricalRecord(HistoricalRecord paramHistoricalRecord)
  {
    boolean bool = mHistoricalRecords.add(paramHistoricalRecord);
    if (bool)
    {
      mHistoricalRecordsChanged = true;
      pruneExcessiveHistoricalRecordsIfNeeded();
      persistHistoricalDataIfNeeded();
      sortActivitiesIfNeeded();
      notifyChanged();
    }
    return bool;
  }
  
  private void ensureConsistentState()
  {
    boolean bool1 = loadActivitiesIfNeeded();
    boolean bool2 = readHistoricalDataIfNeeded();
    pruneExcessiveHistoricalRecordsIfNeeded();
    if ((bool1 | bool2))
    {
      sortActivitiesIfNeeded();
      notifyChanged();
    }
  }
  
  private boolean loadActivitiesIfNeeded()
  {
    if ((mReloadActivities) && (mIntent != null))
    {
      mReloadActivities = false;
      mActivities.clear();
      List localList = mContext.getPackageManager().queryIntentActivities(mIntent, 0);
      int j = localList.size();
      int i = 0;
      while (i < j)
      {
        ResolveInfo localResolveInfo = (ResolveInfo)localList.get(i);
        mActivities.add(new ActivityResolveInfo(localResolveInfo));
        i += 1;
      }
      return true;
    }
    return false;
  }
  
  private void persistHistoricalDataIfNeeded()
  {
    if (!mReadShareHistoryCalled) {
      throw new IllegalStateException("No preceding call to #readHistoricalData");
    }
    if (!mHistoricalRecordsChanged) {
      return;
    }
    mHistoricalRecordsChanged = false;
    if (!TextUtils.isEmpty(mHistoryFileName)) {
      new Track.1(this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[] { new ArrayList(mHistoricalRecords), mHistoryFileName });
    }
  }
  
  private void pruneExcessiveHistoricalRecordsIfNeeded()
  {
    int j = mHistoricalRecords.size() - mHistoryMaxSize;
    if (j <= 0) {
      return;
    }
    mHistoricalRecordsChanged = true;
    int i = 0;
    while (i < j)
    {
      HistoricalRecord localHistoricalRecord = (HistoricalRecord)mHistoricalRecords.remove(0);
      i += 1;
    }
  }
  
  private boolean readHistoricalDataIfNeeded()
  {
    if ((mCanReadHistoricalData) && (mHistoricalRecordsChanged) && (!TextUtils.isEmpty(mHistoryFileName)))
    {
      mCanReadHistoricalData = false;
      mReadShareHistoryCalled = true;
      readHistoricalDataImpl();
      return true;
    }
    return false;
  }
  
  /* Error */
  private void readHistoricalDataImpl()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 111	android/support/v7/widget/ActivityChooserModel:mContext	Landroid/content/Context;
    //   4: astore 6
    //   6: aload_0
    //   7: getfield 147	android/support/v7/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
    //   10: astore 7
    //   12: aload 6
    //   14: aload 7
    //   16: invokevirtual 193	android/content/Context:openFileInput	(Ljava/lang/String;)Ljava/io/FileInputStream;
    //   19: astore 6
    //   21: invokestatic 199	android/util/Xml:newPullParser	()Lorg/xmlpull/v1/XmlPullParser;
    //   24: astore 7
    //   26: aload 7
    //   28: aload 6
    //   30: ldc -55
    //   32: invokeinterface 207 3 0
    //   37: iconst_0
    //   38: istore_2
    //   39: iload_2
    //   40: iconst_1
    //   41: if_icmpeq +19 -> 60
    //   44: iload_2
    //   45: iconst_2
    //   46: if_icmpeq +14 -> 60
    //   49: aload 7
    //   51: invokeinterface 210 1 0
    //   56: istore_2
    //   57: goto -18 -> 39
    //   60: ldc -44
    //   62: aload 7
    //   64: invokeinterface 215 1 0
    //   69: invokevirtual 220	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   72: istore_3
    //   73: iload_3
    //   74: ifne +61 -> 135
    //   77: new 185	org/xmlpull/v1/XmlPullParserException
    //   80: dup
    //   81: ldc -34
    //   83: invokespecial 223	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   86: astore 7
    //   88: aload 7
    //   90: athrow
    //   91: astore 7
    //   93: getstatic 55	android/support/v7/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
    //   96: new 225	java/lang/StringBuilder
    //   99: dup
    //   100: invokespecial 226	java/lang/StringBuilder:<init>	()V
    //   103: ldc -28
    //   105: invokevirtual 232	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: aload_0
    //   109: getfield 147	android/support/v7/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
    //   112: invokevirtual 232	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: invokevirtual 235	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   118: aload 7
    //   120: invokestatic 241	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   123: pop
    //   124: aload 6
    //   126: ifnull +232 -> 358
    //   129: aload 6
    //   131: invokevirtual 246	java/io/FileInputStream:close	()V
    //   134: return
    //   135: aload_0
    //   136: getfield 72	android/support/v7/widget/ActivityChooserModel:mHistoricalRecords	Ljava/util/List;
    //   139: astore 8
    //   141: aload 8
    //   143: invokeinterface 109 1 0
    //   148: aload 7
    //   150: invokeinterface 210 1 0
    //   155: istore_2
    //   156: iload_2
    //   157: iconst_1
    //   158: if_icmpne +17 -> 175
    //   161: aload 6
    //   163: ifnull +195 -> 358
    //   166: aload 6
    //   168: invokevirtual 246	java/io/FileInputStream:close	()V
    //   171: return
    //   172: astore 6
    //   174: return
    //   175: iload_2
    //   176: iconst_3
    //   177: if_icmpeq -29 -> 148
    //   180: iload_2
    //   181: iconst_4
    //   182: if_icmpeq -34 -> 148
    //   185: aload 7
    //   187: invokeinterface 215 1 0
    //   192: astore 9
    //   194: ldc -8
    //   196: aload 9
    //   198: invokevirtual 220	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   201: istore_3
    //   202: iload_3
    //   203: ifne +64 -> 267
    //   206: new 185	org/xmlpull/v1/XmlPullParserException
    //   209: dup
    //   210: ldc -6
    //   212: invokespecial 223	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   215: astore 7
    //   217: aload 7
    //   219: athrow
    //   220: astore 7
    //   222: getstatic 55	android/support/v7/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
    //   225: new 225	java/lang/StringBuilder
    //   228: dup
    //   229: invokespecial 226	java/lang/StringBuilder:<init>	()V
    //   232: ldc -28
    //   234: invokevirtual 232	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   237: aload_0
    //   238: getfield 147	android/support/v7/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
    //   241: invokevirtual 232	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   244: invokevirtual 235	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   247: aload 7
    //   249: invokestatic 241	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   252: pop
    //   253: aload 6
    //   255: ifnull +103 -> 358
    //   258: aload 6
    //   260: invokevirtual 246	java/io/FileInputStream:close	()V
    //   263: return
    //   264: astore 6
    //   266: return
    //   267: aload 7
    //   269: aconst_null
    //   270: ldc -4
    //   272: invokeinterface 256 3 0
    //   277: astore 9
    //   279: aload 7
    //   281: aconst_null
    //   282: ldc_w 258
    //   285: invokeinterface 256 3 0
    //   290: invokestatic 264	java/lang/Long:parseLong	(Ljava/lang/String;)J
    //   293: lstore 4
    //   295: aload 7
    //   297: aconst_null
    //   298: ldc_w 266
    //   301: invokeinterface 256 3 0
    //   306: invokestatic 272	java/lang/Float:parseFloat	(Ljava/lang/String;)F
    //   309: fstore_1
    //   310: aload 8
    //   312: new 10	android/support/v7/widget/ActivityChooserModel$HistoricalRecord
    //   315: dup
    //   316: aload 9
    //   318: lload 4
    //   320: fload_1
    //   321: invokespecial 275	android/support/v7/widget/ActivityChooserModel$HistoricalRecord:<init>	(Ljava/lang/String;JF)V
    //   324: invokeinterface 78 2 0
    //   329: pop
    //   330: goto -182 -> 148
    //   333: astore 7
    //   335: aload 6
    //   337: ifnull +8 -> 345
    //   340: aload 6
    //   342: invokevirtual 246	java/io/FileInputStream:close	()V
    //   345: aload 7
    //   347: athrow
    //   348: astore 6
    //   350: return
    //   351: astore 6
    //   353: goto -8 -> 345
    //   356: astore 6
    //   358: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	359	0	this	ActivityChooserModel
    //   309	12	1	f	float
    //   38	145	2	i	int
    //   72	131	3	bool	boolean
    //   293	26	4	l	long
    //   4	163	6	localObject1	Object
    //   172	87	6	localIOException1	java.io.IOException
    //   264	77	6	localIOException2	java.io.IOException
    //   348	1	6	localIOException3	java.io.IOException
    //   351	1	6	localIOException4	java.io.IOException
    //   356	1	6	localFileNotFoundException	java.io.FileNotFoundException
    //   10	79	7	localObject2	Object
    //   91	95	7	localXmlPullParserException1	org.xmlpull.v1.XmlPullParserException
    //   215	3	7	localXmlPullParserException2	org.xmlpull.v1.XmlPullParserException
    //   220	76	7	localIOException5	java.io.IOException
    //   333	13	7	localThrowable	Throwable
    //   139	172	8	localList	List
    //   192	125	9	str	String
    // Exception table:
    //   from	to	target	type
    //   21	37	91	org/xmlpull/v1/XmlPullParserException
    //   49	57	91	org/xmlpull/v1/XmlPullParserException
    //   60	73	91	org/xmlpull/v1/XmlPullParserException
    //   77	88	91	org/xmlpull/v1/XmlPullParserException
    //   88	91	91	org/xmlpull/v1/XmlPullParserException
    //   141	148	91	org/xmlpull/v1/XmlPullParserException
    //   148	156	91	org/xmlpull/v1/XmlPullParserException
    //   185	194	91	org/xmlpull/v1/XmlPullParserException
    //   194	202	91	org/xmlpull/v1/XmlPullParserException
    //   206	217	91	org/xmlpull/v1/XmlPullParserException
    //   217	220	91	org/xmlpull/v1/XmlPullParserException
    //   267	310	91	org/xmlpull/v1/XmlPullParserException
    //   310	330	91	org/xmlpull/v1/XmlPullParserException
    //   166	171	172	java/io/IOException
    //   21	37	220	java/io/IOException
    //   49	57	220	java/io/IOException
    //   60	73	220	java/io/IOException
    //   77	88	220	java/io/IOException
    //   141	148	220	java/io/IOException
    //   148	156	220	java/io/IOException
    //   185	194	220	java/io/IOException
    //   194	202	220	java/io/IOException
    //   206	217	220	java/io/IOException
    //   267	310	220	java/io/IOException
    //   310	330	220	java/io/IOException
    //   258	263	264	java/io/IOException
    //   21	37	333	java/lang/Throwable
    //   49	57	333	java/lang/Throwable
    //   60	73	333	java/lang/Throwable
    //   77	88	333	java/lang/Throwable
    //   88	91	333	java/lang/Throwable
    //   93	124	333	java/lang/Throwable
    //   141	148	333	java/lang/Throwable
    //   148	156	333	java/lang/Throwable
    //   185	194	333	java/lang/Throwable
    //   194	202	333	java/lang/Throwable
    //   206	217	333	java/lang/Throwable
    //   217	220	333	java/lang/Throwable
    //   222	253	333	java/lang/Throwable
    //   267	310	333	java/lang/Throwable
    //   310	330	333	java/lang/Throwable
    //   129	134	348	java/io/IOException
    //   340	345	351	java/io/IOException
    //   12	21	356	java/io/FileNotFoundException
  }
  
  private boolean sortActivitiesIfNeeded()
  {
    if ((mActivitySorter != null) && (mIntent != null) && (!mActivities.isEmpty()) && (!mHistoricalRecords.isEmpty()))
    {
      mActivitySorter.sort(mIntent, mActivities, Collections.unmodifiableList(mHistoricalRecords));
      return true;
    }
    return false;
  }
  
  public Intent chooseActivity(int paramInt)
  {
    Object localObject1 = mInstanceLock;
    try
    {
      if (mIntent == null) {
        return null;
      }
      ensureConsistentState();
      Object localObject2 = (ActivityResolveInfo)mActivities.get(paramInt);
      localObject2 = new ComponentName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name);
      Intent localIntent1 = new Intent(mIntent);
      localIntent1.setComponent((ComponentName)localObject2);
      if (mActivityChoserModelPolicy != null)
      {
        Intent localIntent2 = new Intent(localIntent1);
        if (mActivityChoserModelPolicy.onChooseActivity(this, localIntent2)) {
          return null;
        }
      }
      addHisoricalRecord(new HistoricalRecord((ComponentName)localObject2, System.currentTimeMillis(), 1.0F));
      return localIntent1;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public ResolveInfo getActivity(int paramInt)
  {
    Object localObject = mInstanceLock;
    try
    {
      ensureConsistentState();
      ResolveInfo localResolveInfo = mActivities.get(paramInt)).resolveInfo;
      return localResolveInfo;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public int getActivityIndex(ResolveInfo paramResolveInfo)
  {
    Object localObject = mInstanceLock;
    try
    {
      ensureConsistentState();
      List localList = mActivities;
      int j = localList.size();
      int i = 0;
      while (i < j)
      {
        if (getresolveInfo == paramResolveInfo) {
          return i;
        }
        i += 1;
      }
      return -1;
    }
    catch (Throwable paramResolveInfo)
    {
      throw paramResolveInfo;
    }
  }
  
  public ResolveInfo getDefaultActivity()
  {
    Object localObject = mInstanceLock;
    try
    {
      ensureConsistentState();
      if (!mActivities.isEmpty())
      {
        ResolveInfo localResolveInfo = mActivities.get(0)).resolveInfo;
        return localResolveInfo;
      }
      return null;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public int getHistorySize()
  {
    Object localObject = mInstanceLock;
    try
    {
      ensureConsistentState();
      int i = mActivities.size();
      return i;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  /* Error */
  public void setDefaultActivity(int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 293	android/support/v7/widget/ActivityChooserModel:mInstanceLock	Ljava/lang/Object;
    //   4: astore_3
    //   5: aload_3
    //   6: monitorenter
    //   7: aload_0
    //   8: invokespecial 295	android/support/v7/widget/ActivityChooserModel:ensureConsistentState	()V
    //   11: aload_0
    //   12: getfield 106	android/support/v7/widget/ActivityChooserModel:mActivities	Ljava/util/List;
    //   15: iload_1
    //   16: invokeinterface 131 2 0
    //   21: checkcast 6	android/support/v7/widget/ActivityChooserModel$ActivityResolveInfo
    //   24: astore 4
    //   26: aload_0
    //   27: getfield 106	android/support/v7/widget/ActivityChooserModel:mActivities	Ljava/util/List;
    //   30: iconst_0
    //   31: invokeinterface 131 2 0
    //   36: checkcast 6	android/support/v7/widget/ActivityChooserModel$ActivityResolveInfo
    //   39: astore 5
    //   41: aload 5
    //   43: ifnull +67 -> 110
    //   46: aload 5
    //   48: getfield 354	android/support/v7/widget/ActivityChooserModel$ActivityResolveInfo:weight	F
    //   51: aload 4
    //   53: getfield 354	android/support/v7/widget/ActivityChooserModel$ActivityResolveInfo:weight	F
    //   56: fsub
    //   57: ldc_w 355
    //   60: fadd
    //   61: fstore_2
    //   62: aload_0
    //   63: new 10	android/support/v7/widget/ActivityChooserModel$HistoricalRecord
    //   66: dup
    //   67: new 297	android/content/ComponentName
    //   70: dup
    //   71: aload 4
    //   73: getfield 301	android/support/v7/widget/ActivityChooserModel$ActivityResolveInfo:resolveInfo	Landroid/content/pm/ResolveInfo;
    //   76: getfield 305	android/content/pm/ResolveInfo:activityInfo	Landroid/content/pm/ActivityInfo;
    //   79: getfield 310	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   82: aload 4
    //   84: getfield 301	android/support/v7/widget/ActivityChooserModel$ActivityResolveInfo:resolveInfo	Landroid/content/pm/ResolveInfo;
    //   87: getfield 305	android/content/pm/ResolveInfo:activityInfo	Landroid/content/pm/ActivityInfo;
    //   90: getfield 313	android/content/pm/PackageItemInfo:name	Ljava/lang/String;
    //   93: invokespecial 316	android/content/ComponentName:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   96: invokestatic 337	java/lang/System:currentTimeMillis	()J
    //   99: fload_2
    //   100: invokespecial 340	android/support/v7/widget/ActivityChooserModel$HistoricalRecord:<init>	(Landroid/content/ComponentName;JF)V
    //   103: invokespecial 342	android/support/v7/widget/ActivityChooserModel:addHisoricalRecord	(Landroid/support/v7/widget/ActivityChooserModel$HistoricalRecord;)Z
    //   106: pop
    //   107: aload_3
    //   108: monitorexit
    //   109: return
    //   110: fconst_1
    //   111: fstore_2
    //   112: goto -50 -> 62
    //   115: astore 4
    //   117: aload_3
    //   118: monitorexit
    //   119: aload 4
    //   121: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	122	0	this	ActivityChooserModel
    //   0	122	1	paramInt	int
    //   61	51	2	f	float
    //   4	114	3	localObject	Object
    //   24	59	4	localActivityResolveInfo1	ActivityResolveInfo
    //   115	5	4	localThrowable	Throwable
    //   39	8	5	localActivityResolveInfo2	ActivityResolveInfo
    // Exception table:
    //   from	to	target	type
    //   7	41	115	java/lang/Throwable
    //   46	62	115	java/lang/Throwable
    //   62	109	115	java/lang/Throwable
    //   117	119	115	java/lang/Throwable
  }
  
  public final class ActivityResolveInfo
    implements Comparable<e.a>
  {
    public final ResolveInfo resolveInfo;
    public float weight;
    
    public ActivityResolveInfo(ResolveInfo paramResolveInfo)
    {
      resolveInfo = paramResolveInfo;
    }
    
    public int compareTo(ActivityResolveInfo paramActivityResolveInfo)
    {
      return Float.floatToIntBits(weight) - Float.floatToIntBits(weight);
    }
    
    public boolean equals(Object paramObject)
    {
      if (this == paramObject) {
        return true;
      }
      if (paramObject == null) {
        return false;
      }
      if (getClass() != paramObject.getClass()) {
        return false;
      }
      paramObject = (ActivityResolveInfo)paramObject;
      return Float.floatToIntBits(weight) == Float.floatToIntBits(weight);
    }
    
    public int hashCode()
    {
      return Float.floatToIntBits(weight) + 31;
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("[");
      localStringBuilder.append("resolveInfo:").append(resolveInfo.toString());
      localStringBuilder.append("; weight:").append(new BigDecimal(weight));
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }
  
  public abstract interface ActivitySorter
  {
    public abstract void sort(Intent paramIntent, List paramList1, List paramList2);
  }
  
  public final class HistoricalRecord
  {
    public final long time;
    public final float weight;
    
    public HistoricalRecord(long paramLong, float paramFloat)
    {
      time = paramLong;
      weight = paramFloat;
    }
    
    public HistoricalRecord(long paramLong, float paramFloat)
    {
      this(paramLong, paramFloat);
    }
    
    public boolean equals(Object paramObject)
    {
      if (this == paramObject) {
        return true;
      }
      if (paramObject == null) {
        return false;
      }
      if (getClass() != paramObject.getClass()) {
        return false;
      }
      paramObject = (HistoricalRecord)paramObject;
      if (ActivityChooserModel.this == null)
      {
        if (activity != null) {
          return false;
        }
      }
      else if (!ActivityChooserModel.this.equals(activity)) {
        return false;
      }
      if (time != time) {
        return false;
      }
      return Float.floatToIntBits(weight) == Float.floatToIntBits(weight);
    }
    
    public int hashCode()
    {
      if (ActivityChooserModel.this == null) {}
      for (int i = 0;; i = ActivityChooserModel.this.hashCode()) {
        return ((i + 31) * 31 + (int)(time ^ time >>> 32)) * 31 + Float.floatToIntBits(weight);
      }
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("[");
      localStringBuilder.append("; activity:").append(ActivityChooserModel.this);
      localStringBuilder.append("; time:").append(time);
      localStringBuilder.append("; weight:").append(new BigDecimal(weight));
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }
  
  public abstract interface OnChooseActivityListener
  {
    public abstract boolean onChooseActivity(ActivityChooserModel paramActivityChooserModel, Intent paramIntent);
  }
}

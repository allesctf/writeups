package android.support.v7.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.support.v7.appcompat.R.attr;
import android.util.AttributeSet;
import android.widget.AbsSeekBar;
import android.widget.SeekBar;

public class SwitchCompat
  extends SeekBar
{
  private DrawableWrapper mThumbDrawable = new DrawableWrapper(this);
  
  public SwitchCompat(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, R.attr.seekBarStyle);
  }
  
  public SwitchCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    mThumbDrawable.loadFromAttributes(paramAttributeSet, paramInt);
  }
  
  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    mThumbDrawable.setState();
  }
  
  public void jumpDrawablesToCurrentState()
  {
    super.jumpDrawablesToCurrentState();
    mThumbDrawable.jumpToCurrentState();
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    mThumbDrawable.draw(paramCanvas);
  }
}

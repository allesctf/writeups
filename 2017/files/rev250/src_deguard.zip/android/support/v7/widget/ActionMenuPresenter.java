package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.view.ActionProvider;
import android.support.v4.view.ActionProvider.SubUiVisibilityListener;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R.attr;
import android.support.v7.appcompat.R.layout;
import android.support.v7.menu.MenuBuilder;
import android.support.v7.view.ActionBarPolicy;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.view.menu.ActionMenuItemView.b;
import android.support.v7.view.menu.ListPopupWindow;
import android.support.v7.view.menu.MenuItemImpl;
import android.support.v7.view.menu.MenuView;
import android.support.v7.view.menu.MenuView.ItemView;
import android.support.v7.view.menu.SubMenuBuilder;
import android.support.v7.view.menu.b;
import android.support.v7.view.menu.f;
import android.support.v7.view.menu.i;
import android.support.v7.view.menu.l.a;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.widget.ImageView;
import java.util.ArrayList;

class ActionMenuPresenter
  extends b
  implements ActionProvider.SubUiVisibilityListener
{
  private final SparseBooleanArray mActionButtonGroups = new SparseBooleanArray();
  ActionButtonSubmenu mActionButtonPopup;
  private int mActionItemWidthLimit;
  private boolean mExpandedActionViewsExclusive;
  private int mMaxItems;
  private boolean mMaxItemsSet;
  private int mMinCellSize;
  int mOpenSubMenuId;
  OverflowMenuButton mOverflowButton;
  OverflowPopup mOverflowPopup;
  private Drawable mPendingOverflowIcon;
  private boolean mPendingOverflowIconSet;
  private ActionMenuPopupCallback mPopupCallback;
  final PopupPresenterCallback mPopupPresenterCallback = new PopupPresenterCallback();
  OpenOverflowRunnable mPostedOpenRunnable;
  private boolean mReserveOverflow;
  private boolean mReserveOverflowSet;
  private View mScrapActionButtonView;
  private boolean mStrictWidthLimit;
  private int mWidthLimit;
  private boolean mWidthLimitSet;
  
  public ActionMenuPresenter(Context paramContext)
  {
    super(paramContext, R.layout.abc_action_menu_layout, R.layout.abc_action_menu_item_layout);
  }
  
  private View findViewForItem(MenuItem paramMenuItem)
  {
    ViewGroup localViewGroup = (ViewGroup)mMenuView;
    if (localViewGroup == null) {
      return null;
    }
    int j = localViewGroup.getChildCount();
    int i = 0;
    View localView;
    while (i < j)
    {
      localView = localViewGroup.getChildAt(i);
      if (((localView instanceof MenuView.ItemView)) && (((MenuView.ItemView)localView).getItemData() == paramMenuItem)) {
        break label68;
      }
      i += 1;
    }
    return null;
    label68:
    return localView;
  }
  
  public void a(f paramF, boolean paramBoolean)
  {
    dismissPopupMenus();
    super.a(paramF, paramBoolean);
  }
  
  public void bindItemView(MenuItemImpl paramMenuItemImpl, MenuView.ItemView paramItemView)
  {
    paramItemView.initialize(paramMenuItemImpl, 0);
    paramMenuItemImpl = (ActionMenuView)mMenuView;
    paramItemView = (ActionMenuItemView)paramItemView;
    paramItemView.setItemInvoker(paramMenuItemImpl);
    if (mPopupCallback == null) {
      mPopupCallback = new ActionMenuPopupCallback();
    }
    paramItemView.setPopupCallback(mPopupCallback);
  }
  
  public boolean dismissPopupMenus()
  {
    return hideOverflowMenu() | hideSubMenus();
  }
  
  public boolean filterLeftoverView(ViewGroup paramViewGroup, int paramInt)
  {
    if (paramViewGroup.getChildAt(paramInt) == mOverflowButton) {
      return false;
    }
    return super.filterLeftoverView(paramViewGroup, paramInt);
  }
  
  public boolean flagActionItems()
  {
    ArrayList localArrayList;
    int i1;
    int i;
    int i3;
    int i5;
    ViewGroup localViewGroup;
    int m;
    int n;
    int k;
    int j;
    label60:
    Object localObject1;
    if (mMenu != null)
    {
      localArrayList = mMenu.getVisibleItems();
      i1 = localArrayList.size();
      i = mMaxItems;
      i3 = mActionItemWidthLimit;
      i5 = View.MeasureSpec.makeMeasureSpec(0, 0);
      localViewGroup = (ViewGroup)mMenuView;
      m = 0;
      n = 0;
      k = 0;
      j = 0;
      if (j >= i1) {
        break label146;
      }
      localObject1 = (MenuItemImpl)localArrayList.get(j);
      if (!((MenuItemImpl)localObject1).requiresActionButton()) {
        break label124;
      }
      m += 1;
      label91:
      if ((!mExpandedActionViewsExclusive) || (!((MenuItemImpl)localObject1).isActionViewExpanded())) {
        break label806;
      }
      i = 0;
    }
    label124:
    label146:
    label323:
    label447:
    label512:
    label551:
    label624:
    label636:
    label641:
    label783:
    label786:
    label797:
    label806:
    for (;;)
    {
      j += 1;
      break label60;
      i1 = 0;
      localArrayList = null;
      break;
      if (((MenuItemImpl)localObject1).requestsActionButton())
      {
        n += 1;
        break label91;
      }
      k = 1;
      break label91;
      j = i;
      if (mReserveOverflow) {
        if (k == 0)
        {
          j = i;
          if (m + n <= i) {}
        }
        else
        {
          j = i - 1;
        }
      }
      k = j - m;
      localObject1 = mActionButtonGroups;
      ((SparseBooleanArray)localObject1).clear();
      i = 0;
      if (mStrictWidthLimit)
      {
        i = i3 / mMinCellSize;
        j = mMinCellSize;
        m = mMinCellSize;
      }
      for (int i2 = i3 % j / i + m;; i2 = 0)
      {
        n = 0;
        m = 0;
        j = i;
        i = m;
        m = i3;
        i3 = n;
        MenuItemImpl localMenuItemImpl;
        Object localObject2;
        int i4;
        if (i3 < i1)
        {
          localMenuItemImpl = (MenuItemImpl)localArrayList.get(i3);
          if (localMenuItemImpl.requiresActionButton())
          {
            localObject2 = getItemView(localMenuItemImpl, mScrapActionButtonView, localViewGroup);
            if (mScrapActionButtonView == null) {
              mScrapActionButtonView = ((View)localObject2);
            }
            if (mStrictWidthLimit)
            {
              j -= ActionMenuView.measureChildForCells((View)localObject2, i2, j, i5, 0);
              i4 = ((View)localObject2).getMeasuredWidth();
              n = i4;
              m -= i4;
              if (i != 0) {
                break label797;
              }
              i = n;
            }
          }
        }
        for (;;)
        {
          n = localMenuItemImpl.getGroupId();
          if (n != 0) {
            ((SparseBooleanArray)localObject1).put(n, true);
          }
          localMenuItemImpl.setIsActionButton(true);
          i3 += 1;
          break;
          ((View)localObject2).measure(i5, i5);
          break label323;
          int i6;
          boolean bool;
          int i7;
          if (localMenuItemImpl.requestsActionButton())
          {
            i6 = localMenuItemImpl.getGroupId();
            bool = ((SparseBooleanArray)localObject1).get(i6);
            if (((k > 0) || (bool)) && (m > 0) && ((!mStrictWidthLimit) || (j > 0)))
            {
              i7 = 1;
              if (i7 == 0) {
                break label786;
              }
              localObject2 = getItemView(localMenuItemImpl, mScrapActionButtonView, localViewGroup);
              if (mScrapActionButtonView == null) {
                mScrapActionButtonView = ((View)localObject2);
              }
              if (!mStrictWidthLimit) {
                break label624;
              }
              n = ActionMenuView.measureChildForCells((View)localObject2, i2, j, i5, 0);
              j -= n;
              if (n != 0) {
                break label783;
              }
              i7 = 0;
              n = ((View)localObject2).getMeasuredWidth();
              i4 = m - n;
              m = i;
              if (i == 0) {
                m = n;
              }
              if (!mStrictWidthLimit) {
                break label641;
              }
              if (i4 < 0) {
                break label636;
              }
              i = 1;
              i7 &= i;
              i = j;
              j = m;
              m = i4;
            }
          }
          for (;;)
          {
            if ((i7 != 0) && (i6 != 0))
            {
              ((SparseBooleanArray)localObject1).put(i6, true);
              n = k;
            }
            for (;;)
            {
              k = n;
              if (i7 != 0) {
                k = n - 1;
              }
              localMenuItemImpl.setIsActionButton(i7);
              n = i;
              i = j;
              j = n;
              break;
              int i8 = 0;
              break label447;
              ((View)localObject2).measure(i5, i5);
              break label512;
              i = 0;
              break label551;
              if (i4 + m > 0) {}
              for (i = 1;; i = 0)
              {
                i8 &= i;
                n = m;
                i = j;
                m = i4;
                j = n;
                break;
              }
              if (bool)
              {
                ((SparseBooleanArray)localObject1).put(i6, false);
                i4 = 0;
                for (;;)
                {
                  if (i4 < i3)
                  {
                    localObject2 = (MenuItemImpl)localArrayList.get(i4);
                    n = k;
                    if (((MenuItemImpl)localObject2).getGroupId() == i6)
                    {
                      n = k;
                      if (((MenuItemImpl)localObject2).isActionButton()) {
                        n = k + 1;
                      }
                      ((MenuItemImpl)localObject2).setIsActionButton(false);
                    }
                    i4 += 1;
                    k = n;
                    continue;
                    localMenuItemImpl.setIsActionButton(false);
                    break;
                    return true;
                  }
                }
                n = k;
              }
              else
              {
                n = k;
              }
            }
            break label512;
            n = i;
            i = j;
            j = n;
          }
        }
      }
    }
  }
  
  public View getItemView(MenuItemImpl paramMenuItemImpl, View paramView, ViewGroup paramViewGroup)
  {
    View localView2 = paramMenuItemImpl.getActionView();
    View localView1 = localView2;
    if ((localView2 == null) || (paramMenuItemImpl.hasCollapsibleActionView())) {
      localView1 = super.getItemView(paramMenuItemImpl, paramView, paramViewGroup);
    }
    if (paramMenuItemImpl.isActionViewExpanded()) {}
    for (int i = 8;; i = 0)
    {
      localView1.setVisibility(i);
      paramMenuItemImpl = (ActionMenuView)paramViewGroup;
      paramView = localView1.getLayoutParams();
      if (paramMenuItemImpl.checkLayoutParams(paramView)) {
        break;
      }
      localView1.setLayoutParams(paramMenuItemImpl.a(paramView));
      return localView1;
    }
    return localView1;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup)
  {
    MenuView localMenuView = mMenuView;
    paramViewGroup = super.getMenuView(paramViewGroup);
    if (localMenuView != paramViewGroup) {
      ((ActionMenuView)paramViewGroup).setPresenter(this);
    }
    return paramViewGroup;
  }
  
  public Drawable getOverflowIcon()
  {
    if (mOverflowButton != null) {
      return mOverflowButton.getDrawable();
    }
    if (mPendingOverflowIconSet) {
      return mPendingOverflowIcon;
    }
    return null;
  }
  
  public boolean hideOverflowMenu()
  {
    if ((mPostedOpenRunnable != null) && (mMenuView != null))
    {
      ((View)mMenuView).removeCallbacks(mPostedOpenRunnable);
      mPostedOpenRunnable = null;
      return true;
    }
    OverflowPopup localOverflowPopup = mOverflowPopup;
    if (localOverflowPopup != null)
    {
      localOverflowPopup.dismiss();
      return true;
    }
    return false;
  }
  
  public boolean hideSubMenus()
  {
    if (mActionButtonPopup != null)
    {
      mActionButtonPopup.dismiss();
      return true;
    }
    return false;
  }
  
  public void initForMenu(Context paramContext, f paramF)
  {
    super.initForMenu(paramContext, paramF);
    paramF = paramContext.getResources();
    paramContext = ActionBarPolicy.get(paramContext);
    if (!mReserveOverflowSet) {
      mReserveOverflow = paramContext.showsOverflowMenuButton();
    }
    if (!mWidthLimitSet) {
      mWidthLimit = paramContext.getEmbeddedMenuWidthLimit();
    }
    if (!mMaxItemsSet) {
      mMaxItems = paramContext.init();
    }
    int i = mWidthLimit;
    if (mReserveOverflow)
    {
      if (mOverflowButton == null)
      {
        mOverflowButton = new OverflowMenuButton(mSystemContext);
        if (mPendingOverflowIconSet)
        {
          mOverflowButton.setImageDrawable(mPendingOverflowIcon);
          mPendingOverflowIcon = null;
          mPendingOverflowIconSet = false;
        }
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        mOverflowButton.measure(j, j);
      }
      i -= mOverflowButton.getMeasuredWidth();
    }
    for (;;)
    {
      mActionItemWidthLimit = i;
      mMinCellSize = ((int)(56.0F * getDisplayMetricsdensity));
      mScrapActionButtonView = null;
      return;
      mOverflowButton = null;
    }
  }
  
  public boolean isOverflowMenuShowPending()
  {
    return (mPostedOpenRunnable != null) || (isOverflowMenuShowing());
  }
  
  public boolean isOverflowMenuShowing()
  {
    return (mOverflowPopup != null) && (mOverflowPopup.isShowing());
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    if (!mMaxItemsSet) {
      mMaxItems = ActionBarPolicy.get(mContext).init();
    }
    if (mMenu != null) {
      mMenu.onItemsChanged(true);
    }
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
  {
    if (!paramSubMenuBuilder.hasVisibleItems()) {
      return false;
    }
    for (Object localObject = paramSubMenuBuilder; ((SubMenuBuilder)localObject).getParentMenu() != mMenu; localObject = (SubMenuBuilder)((SubMenuBuilder)localObject).getParentMenu()) {}
    localObject = findViewForItem(((SubMenuBuilder)localObject).getItem());
    if (localObject != null)
    {
      mOpenSubMenuId = paramSubMenuBuilder.getItem().getItemId();
      int j = paramSubMenuBuilder.size();
      int i = 0;
      if (i < j)
      {
        MenuItem localMenuItem = paramSubMenuBuilder.getItem(i);
        if ((!localMenuItem.isVisible()) || (localMenuItem.getIcon() == null)) {}
      }
      for (boolean bool = true;; bool = false)
      {
        mActionButtonPopup = new ActionButtonSubmenu(mContext, paramSubMenuBuilder, (View)localObject);
        mActionButtonPopup.a(bool);
        mActionButtonPopup.show();
        super.onSubMenuSelected(paramSubMenuBuilder);
        return true;
        i += 1;
        break;
      }
    }
    return false;
  }
  
  public void onSubUiVisibilityChanged(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      super.onSubMenuSelected(null);
      return;
    }
    if (mMenu != null) {
      mMenu.close(false);
    }
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean)
  {
    mExpandedActionViewsExclusive = paramBoolean;
  }
  
  public void setMenuView(ActionMenuView paramActionMenuView)
  {
    mMenuView = paramActionMenuView;
    paramActionMenuView.initialize(mMenu);
  }
  
  public void setOverflowIcon(Drawable paramDrawable)
  {
    if (mOverflowButton != null)
    {
      mOverflowButton.setImageDrawable(paramDrawable);
      return;
    }
    mPendingOverflowIconSet = true;
    mPendingOverflowIcon = paramDrawable;
  }
  
  public void setReserveOverflow(boolean paramBoolean)
  {
    mReserveOverflow = paramBoolean;
    mReserveOverflowSet = true;
  }
  
  public boolean shouldIncludeItem(int paramInt, MenuItemImpl paramMenuItemImpl)
  {
    return paramMenuItemImpl.isActionButton();
  }
  
  public boolean showOverflowMenu()
  {
    if ((mReserveOverflow) && (!isOverflowMenuShowing()) && (mMenu != null) && (mMenuView != null) && (mPostedOpenRunnable == null) && (!mMenu.getNonActionItems().isEmpty()))
    {
      mPostedOpenRunnable = new OpenOverflowRunnable(new OverflowPopup(mContext, mMenu, mOverflowButton, true));
      ((View)mMenuView).post(mPostedOpenRunnable);
      super.onSubMenuSelected(null);
      return true;
    }
    return false;
  }
  
  public void updateMenuView(boolean paramBoolean)
  {
    int j = 1;
    int k = 0;
    Object localObject = (ViewGroup)((View)mMenuView).getParent();
    if (localObject != null) {
      MenuBuilder.getItem((ViewGroup)localObject);
    }
    super.updateMenuView(paramBoolean);
    ((View)mMenuView).requestLayout();
    int i;
    if (mMenu != null)
    {
      localObject = mMenu.getActionItems();
      int m = ((ArrayList)localObject).size();
      i = 0;
      while (i < m)
      {
        ActionProvider localActionProvider = ((MenuItemImpl)((ArrayList)localObject).get(i)).getSupportActionProvider();
        if (localActionProvider != null) {
          localActionProvider.setSubUiVisibilityListener(this);
        }
        i += 1;
      }
    }
    if (mMenu != null)
    {
      localObject = mMenu.getNonActionItems();
      i = k;
      if (mReserveOverflow)
      {
        i = k;
        if (localObject != null)
        {
          i = ((ArrayList)localObject).size();
          if (i != 1) {
            break label281;
          }
          if (((MenuItemImpl)((ArrayList)localObject).get(0)).isActionViewExpanded()) {
            break label276;
          }
          i = 1;
        }
      }
      label170:
      if (i == 0) {
        break label295;
      }
      if (mOverflowButton == null) {
        mOverflowButton = new OverflowMenuButton(mSystemContext);
      }
      localObject = (ViewGroup)mOverflowButton.getParent();
      if (localObject != mMenuView)
      {
        if (localObject != null) {
          ((ViewGroup)localObject).removeView(mOverflowButton);
        }
        localObject = (ActionMenuView)mMenuView;
        ((ViewGroup)localObject).addView(mOverflowButton, ((ActionMenuView)localObject).generateOverflowButtonLayoutParams());
      }
    }
    for (;;)
    {
      ((ActionMenuView)mMenuView).setOverflowReserved(mReserveOverflow);
      return;
      localObject = null;
      break;
      label276:
      i = 0;
      break label170;
      label281:
      if (i > 0) {}
      for (i = j;; i = 0) {
        break;
      }
      label295:
      if ((mOverflowButton != null) && (mOverflowButton.getParent() == mMenuView)) {
        ((ViewGroup)mMenuView).removeView(mOverflowButton);
      }
    }
  }
  
  class ActionButtonSubmenu
    extends i
  {
    public ActionButtonSubmenu(Context paramContext, SubMenuBuilder paramSubMenuBuilder, View paramView)
    {
      super(paramSubMenuBuilder, paramView, false, R.attr.actionOverflowMenuStyle);
      if (!((MenuItemImpl)paramSubMenuBuilder.getItem()).isActionButton()) {
        if (mOverflowButton != null) {
          break label59;
        }
      }
      label59:
      for (paramContext = (View)ActionMenuPresenter.getMenuView(ActionMenuPresenter.this);; paramContext = mOverflowButton)
      {
        a(paramContext);
        a(mPopupPresenterCallback);
        return;
      }
    }
    
    protected void onDismiss()
    {
      mActionButtonPopup = null;
      mOpenSubMenuId = 0;
      super.onDismiss();
    }
  }
  
  class ActionMenuPopupCallback
    extends ActionMenuItemView.b
  {
    ActionMenuPopupCallback() {}
    
    public ListPopupWindow getPopup()
    {
      if (mActionButtonPopup != null) {
        return mActionButtonPopup.a();
      }
      return null;
    }
  }
  
  class OpenOverflowRunnable
    implements Runnable
  {
    private ActionMenuPresenter.OverflowPopup mPopup;
    
    public OpenOverflowRunnable(ActionMenuPresenter.OverflowPopup paramOverflowPopup)
    {
      mPopup = paramOverflowPopup;
    }
    
    public void run()
    {
      if (ActionMenuPresenter.access$setMPostedOpenRunnable(ActionMenuPresenter.this) != null) {
        ActionMenuPresenter.access$getMMenu(ActionMenuPresenter.this).changeMenuMode();
      }
      View localView = (View)ActionMenuPresenter.access$getMMenuView(ActionMenuPresenter.this);
      if ((localView != null) && (localView.getWindowToken() != null) && (mPopup.add())) {
        mOverflowPopup = mPopup;
      }
      mPostedOpenRunnable = null;
    }
  }
  
  class OverflowMenuButton
    extends AppCompatImageView
    implements ActionMenuView.a
  {
    private final float[] mTempPts = new float[2];
    
    public OverflowMenuButton(Context paramContext)
    {
      super(null, R.attr.actionOverflowButtonStyle);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      ViewCompat.setText(this, getContentDescription());
      setOnTouchListener(new d.d.1(this, this, ActionMenuPresenter.this));
    }
    
    public boolean needsDividerAfter()
    {
      return false;
    }
    
    public boolean needsDividerBefore()
    {
      return false;
    }
    
    public boolean performClick()
    {
      if (super.performClick()) {
        return true;
      }
      playSoundEffect(0);
      showOverflowMenu();
      return true;
    }
    
    protected boolean setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      boolean bool = super.setFrame(paramInt1, paramInt2, paramInt3, paramInt4);
      Drawable localDrawable1 = getDrawable();
      Drawable localDrawable2 = getBackground();
      if ((localDrawable1 != null) && (localDrawable2 != null))
      {
        int i = getWidth();
        paramInt2 = getHeight();
        paramInt1 = Math.max(i, paramInt2) / 2;
        int j = getPaddingLeft();
        int k = getPaddingRight();
        paramInt3 = getPaddingTop();
        paramInt4 = getPaddingBottom();
        i = (i + (j - k)) / 2;
        paramInt2 = (paramInt2 + (paramInt3 - paramInt4)) / 2;
        DrawableCompat.setHotspotBounds(localDrawable2, i - paramInt1, paramInt2 - paramInt1, i + paramInt1, paramInt2 + paramInt1);
      }
      return bool;
    }
  }
  
  class OverflowPopup
    extends i
  {
    public OverflowPopup(Context paramContext, f paramF, View paramView, boolean paramBoolean)
    {
      super(paramF, paramView, paramBoolean, R.attr.actionOverflowMenuStyle);
      b(8388613);
      a(mPopupPresenterCallback);
    }
    
    protected void onDismiss()
    {
      if (ActionMenuPresenter.access$setMOverflowPopup(ActionMenuPresenter.this) != null) {
        ActionMenuPresenter.access$setMActionButtonPopup(ActionMenuPresenter.this).close();
      }
      mOverflowPopup = null;
      super.onDismiss();
    }
  }
  
  class PopupPresenterCallback
    implements l.a
  {
    PopupPresenterCallback() {}
    
    public void onCloseMenu(f paramF, boolean paramBoolean)
    {
      if ((paramF instanceof SubMenuBuilder)) {
        paramF.getRootMenu().close(false);
      }
      l.a localA = getCallback();
      if (localA != null) {
        localA.onCloseMenu(paramF, paramBoolean);
      }
    }
    
    public boolean onOpenSubMenu(f paramF)
    {
      if (paramF == null) {
        return false;
      }
      mOpenSubMenuId = ((SubMenuBuilder)paramF).getItem().getItemId();
      l.a localA = getCallback();
      if (localA != null) {
        return localA.onOpenSubMenu(paramF);
      }
      return false;
    }
  }
}

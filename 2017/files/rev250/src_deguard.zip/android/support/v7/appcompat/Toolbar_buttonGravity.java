package android.support.v7.appcompat;

public final class Toolbar_buttonGravity {}

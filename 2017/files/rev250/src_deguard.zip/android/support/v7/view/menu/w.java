package android.support.v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.support.v7.appcompat.R.dimen;
import android.support.v7.appcompat.R.layout;
import android.support.v7.widget.Label;
import android.support.v7.widget.ListPopupWindow;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;

final class w
  extends k
  implements MenuPresenter, View.OnKeyListener, AdapterView.OnItemClickListener, PopupWindow.OnDismissListener
{
  private PopupWindow.OnDismissListener a;
  private final ViewTreeObserver.OnGlobalLayoutListener b = new v(this);
  private final Context c;
  private boolean e;
  private final int f;
  private final e.a g;
  private final int h;
  private final f i;
  private final int j;
  private l.a k;
  private View l;
  View mAnchorView;
  private int mContentWidth;
  final Label mPopup;
  private ViewTreeObserver mTreeObserver;
  private int n = 0;
  private boolean r;
  private boolean s;
  private final boolean this$0;
  
  public w(Context paramContext, f paramF, View paramView, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    c = paramContext;
    i = paramF;
    this$0 = paramBoolean;
    g = new e.a(paramF, LayoutInflater.from(paramContext), this$0);
    f = paramInt1;
    h = paramInt2;
    Resources localResources = paramContext.getResources();
    j = Math.max(getDisplayMetricswidthPixels / 2, localResources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
    l = paramView;
    mPopup = new Label(c, null, f, h);
    paramF.addMenuPresenter(this, paramContext);
  }
  
  private boolean a()
  {
    if (isShowing()) {
      return true;
    }
    if ((s) || (l == null)) {
      return false;
    }
    mAnchorView = l;
    mPopup.setOnDismissListener(this);
    mPopup.setOnItemClickListener(this);
    mPopup.setModal(true);
    Object localObject = mAnchorView;
    if (mTreeObserver == null) {}
    for (int m = 1;; m = 0)
    {
      mTreeObserver = ((View)localObject).getViewTreeObserver();
      if (m != 0) {
        mTreeObserver.addOnGlobalLayoutListener(b);
      }
      mPopup.setAnchorView((View)localObject);
      mPopup.dismiss(n);
      if (!r)
      {
        mContentWidth = k.measureContentWidth(g, null, c, j);
        r = true;
      }
      mPopup.setContentWidth(mContentWidth);
      mPopup.setInputMethodMode(2);
      mPopup.show(get());
      mPopup.show();
      localObject = mPopup.getListView();
      ((View)localObject).setOnKeyListener(this);
      if ((e) && (i.a() != null))
      {
        FrameLayout localFrameLayout = (FrameLayout)LayoutInflater.from(c).inflate(R.layout.abc_popup_menu_header_item_layout, (ViewGroup)localObject, false);
        TextView localTextView = (TextView)localFrameLayout.findViewById(16908310);
        if (localTextView != null) {
          localTextView.setText(i.a());
        }
        localFrameLayout.setEnabled(false);
        ((ListView)localObject).addHeaderView(localFrameLayout, null, false);
      }
      mPopup.setAdapter(g);
      mPopup.show();
      return true;
    }
  }
  
  public void a(int paramInt)
  {
    n = paramInt;
  }
  
  public void a(f paramF, boolean paramBoolean)
  {
    if (paramF != i) {
      return;
    }
    dismiss();
    if (k != null) {
      k.onCloseMenu(paramF, paramBoolean);
    }
  }
  
  public void a(View paramView)
  {
    l = paramView;
  }
  
  public void a(PopupWindow.OnDismissListener paramOnDismissListener)
  {
    a = paramOnDismissListener;
  }
  
  public void a(boolean paramBoolean)
  {
    g.a(paramBoolean);
  }
  
  public void dismiss()
  {
    if (isShowing()) {
      mPopup.dismiss();
    }
  }
  
  public void dismiss(int paramInt)
  {
    mPopup.setVerticalOffset(paramInt);
  }
  
  public boolean flagActionItems()
  {
    return false;
  }
  
  public ListView getListView()
  {
    return mPopup.getListView();
  }
  
  public boolean isShowing()
  {
    return (!s) && (mPopup.isShowing());
  }
  
  public void onDismiss()
  {
    s = true;
    i.close();
    if (mTreeObserver != null)
    {
      if (!mTreeObserver.isAlive()) {
        mTreeObserver = mAnchorView.getViewTreeObserver();
      }
      mTreeObserver.removeGlobalOnLayoutListener(b);
      mTreeObserver = null;
    }
    if (a != null) {
      a.onDismiss();
    }
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramKeyEvent.getAction() == 1) && (paramInt == 82))
    {
      dismiss();
      return true;
    }
    return false;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
  {
    if (paramSubMenuBuilder.hasVisibleItems())
    {
      i localI = new i(c, paramSubMenuBuilder, mAnchorView, this$0, f, h);
      localI.a(k);
      localI.a(k.onSubMenuSelected(paramSubMenuBuilder));
      localI.a(a);
      a = null;
      i.close(false);
      if (localI.a(mPopup.getHorizontalOffset(), mPopup.getVerticalOffset()))
      {
        if (k != null) {
          k.onOpenSubMenu(paramSubMenuBuilder);
        }
        return true;
      }
    }
    return false;
  }
  
  public void setCallback(l.a paramA)
  {
    k = paramA;
  }
  
  public void setCallback(boolean paramBoolean)
  {
    e = paramBoolean;
  }
  
  public void setTitle(f paramF) {}
  
  public void show()
  {
    if (!a()) {
      throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
    }
  }
  
  public void show(int paramInt)
  {
    mPopup.setHorizontalOffset(paramInt);
  }
  
  public void updateMenuView(boolean paramBoolean)
  {
    r = false;
    if (g != null) {
      g.notifyDataSetChanged();
    }
  }
}

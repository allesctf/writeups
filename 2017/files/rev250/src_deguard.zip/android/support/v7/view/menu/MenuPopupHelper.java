package android.support.v7.view.menu;

import android.widget.PopupWindow.OnDismissListener;

class MenuPopupHelper
  implements PopupWindow.OnDismissListener
{
  MenuPopupHelper(i paramI) {}
  
  public void onDismiss()
  {
    mMenu.onDismiss();
  }
}

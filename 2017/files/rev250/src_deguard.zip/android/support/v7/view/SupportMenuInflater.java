package android.support.v7.view;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.support.v4.media.routing.SupportMenu;
import android.support.v4.view.ActionProvider;
import android.support.v4.view.h;
import android.support.v7.appcompat.R.styleable;
import android.support.v7.view.menu.MenuItemImpl;
import android.support.v7.view.menu.MenuItemWrapperICS;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.SubMenu;
import android.view.View;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class SupportMenuInflater
  extends MenuInflater
{
  static final Class<?>[] ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE = ACTION_VIEW_CONSTRUCTOR_SIGNATURE;
  static final Class<?>[] ACTION_VIEW_CONSTRUCTOR_SIGNATURE = { Context.class };
  final Object[] mActionProviderConstructorArguments;
  final Object[] mActionViewConstructorArguments;
  Context mContext;
  private Object mRealOwner;
  
  public SupportMenuInflater(Context paramContext)
  {
    super(paramContext);
    mContext = paramContext;
    mActionViewConstructorArguments = new Object[] { paramContext };
    mActionProviderConstructorArguments = mActionViewConstructorArguments;
  }
  
  private Object findRealOwner(Object paramObject)
  {
    if ((paramObject instanceof Activity)) {
      return paramObject;
    }
    Object localObject = paramObject;
    if ((paramObject instanceof ContextWrapper)) {
      localObject = findRealOwner(((ContextWrapper)paramObject).getBaseContext());
    }
    return localObject;
  }
  
  private void parseMenu(XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Menu paramMenu)
  {
    MenuState localMenuState = new MenuState(paramMenu);
    int j = paramXmlPullParser.getEventType();
    int i;
    label49:
    Menu localMenu;
    int k;
    int n;
    if (j == 2)
    {
      paramMenu = paramXmlPullParser.getName();
      if (paramMenu.equals("menu"))
      {
        i = paramXmlPullParser.next();
        localMenu = null;
        k = 0;
        j = 0;
        n = i;
        label62:
        if (j != 0) {
          return;
        }
      }
    }
    int m;
    switch (n)
    {
    default: 
      paramMenu = localMenu;
      m = j;
      i = k;
      break;
    case 2: 
    case 3: 
      for (;;)
      {
        n = paramXmlPullParser.next();
        localMenu = paramMenu;
        j = m;
        k = i;
        break label62;
        throw new RuntimeException("Expecting menu, got " + paramMenu);
        k = paramXmlPullParser.next();
        i = k;
        j = i;
        if (k != 1) {
          break;
        }
        break label49;
        if (k != 0)
        {
          paramMenu = localMenu;
          m = j;
          i = k;
        }
        else
        {
          paramMenu = paramXmlPullParser.getName();
          if (paramMenu.equals("group"))
          {
            localMenuState.readGroup(paramAttributeSet);
            paramMenu = localMenu;
            m = j;
            i = k;
          }
          else if (paramMenu.equals("item"))
          {
            localMenuState.readItem(paramAttributeSet);
            paramMenu = localMenu;
            m = j;
            i = k;
          }
          else if (paramMenu.equals("menu"))
          {
            parseMenu(paramXmlPullParser, paramAttributeSet, localMenuState.addSubMenuItem());
            paramMenu = localMenu;
            m = j;
            i = k;
          }
          else
          {
            i = 1;
            m = j;
            continue;
            String str = paramXmlPullParser.getName();
            if ((k != 0) && (str.equals(localMenu)))
            {
              paramMenu = null;
              i = 0;
              m = j;
            }
            else if (str.equals("group"))
            {
              localMenuState.resetGroup();
              paramMenu = localMenu;
              m = j;
              i = k;
            }
            else if (str.equals("item"))
            {
              paramMenu = localMenu;
              m = j;
              i = k;
              if (!localMenuState.hasAddedItem()) {
                if ((itemActionProvider != null) && (itemActionProvider.hasSubMenu()))
                {
                  localMenuState.addSubMenuItem();
                  paramMenu = localMenu;
                  m = j;
                  i = k;
                }
                else
                {
                  localMenuState.addItem();
                  paramMenu = localMenu;
                  m = j;
                  i = k;
                }
              }
            }
            else
            {
              paramMenu = localMenu;
              m = j;
              i = k;
              if (str.equals("menu"))
              {
                m = 1;
                paramMenu = localMenu;
                i = k;
              }
            }
          }
        }
      }
    }
    throw new RuntimeException("Unexpected end of document");
  }
  
  Object getRealOwner()
  {
    if (mRealOwner == null) {
      mRealOwner = findRealOwner(mContext);
    }
    return mRealOwner;
  }
  
  public void inflate(int paramInt, Menu paramMenu)
  {
    if (!(paramMenu instanceof SupportMenu))
    {
      super.inflate(paramInt, paramMenu);
      return;
    }
    Object localObject1 = null;
    Object localObject2 = null;
    Object localObject3 = null;
    Object localObject4 = mContext;
    try
    {
      localObject4 = ((Context)localObject4).getResources().getLayout(paramInt);
      localObject2 = localObject4;
      localObject3 = localObject2;
      localObject1 = localObject2;
      parseMenu((XmlPullParser)localObject4, Xml.asAttributeSet((XmlPullParser)localObject4), paramMenu);
      if (localObject4 != null)
      {
        ((XmlResourceParser)localObject4).close();
        return;
      }
    }
    catch (XmlPullParserException paramMenu)
    {
      localObject1 = localObject3;
      throw new InflateException("Error inflating menu XML", paramMenu);
    }
    catch (Throwable paramMenu)
    {
      if (localObject1 != null) {
        localObject1.close();
      }
      throw paramMenu;
    }
    catch (IOException paramMenu)
    {
      localObject1 = localObject2;
      throw new InflateException("Error inflating menu XML", paramMenu);
    }
  }
  
  class InflatedOnMenuItemClickListener
    implements MenuItem.OnMenuItemClickListener
  {
    private static final Class<?>[] PARAM_TYPES = { MenuItem.class };
    private Method mMethod;
    
    public InflatedOnMenuItemClickListener(String paramString)
    {
      this$1 = getClass();
      Object localObject = PARAM_TYPES;
      try
      {
        localObject = getMethod(paramString, (Class[])localObject);
        mMethod = ((Method)localObject);
        return;
      }
      catch (Exception localException)
      {
        this$1 = new InflateException("Couldn't resolve menu item onClick handler " + paramString + " in class " + getName());
        initCause(localException);
        throw SupportMenuInflater.this;
      }
    }
    
    public boolean onMenuItemClick(MenuItem paramMenuItem)
    {
      Object localObject1 = mMethod;
      try
      {
        localObject1 = ((Method)localObject1).getReturnType();
        if (localObject1 == Boolean.TYPE)
        {
          localObject1 = mMethod;
          localObject2 = SupportMenuInflater.this;
          paramMenuItem = ((Method)localObject1).invoke(localObject2, new Object[] { paramMenuItem });
          paramMenuItem = (Boolean)paramMenuItem;
          boolean bool = paramMenuItem.booleanValue();
          return bool;
        }
        localObject1 = mMethod;
        Object localObject2 = SupportMenuInflater.this;
        ((Method)localObject1).invoke(localObject2, new Object[] { paramMenuItem });
        return true;
      }
      catch (Exception paramMenuItem)
      {
        throw new RuntimeException(paramMenuItem);
      }
    }
  }
  
  class MenuState
  {
    private CharSequence author;
    private int groupCategory;
    private int groupCheckable;
    private boolean groupEnabled;
    private int groupId;
    private int groupOrder;
    private boolean groupVisible;
    ActionProvider itemActionProvider;
    private String itemActionProviderClassName;
    private String itemActionViewClassName;
    private int itemActionViewLayout;
    private boolean itemAdded;
    private char itemAlphabeticShortcut;
    private int itemCategoryOrder;
    private int itemCheckable;
    private boolean itemChecked;
    private boolean itemEnabled;
    private int itemIconResId;
    private int itemId;
    private String itemListenerMethodName;
    private char itemNumericShortcut;
    private int itemShowAsAction;
    private CharSequence itemTitle;
    private CharSequence itemTitleCondensed;
    private boolean itemVisible;
    private Menu menu;
    private CharSequence title;
    
    public MenuState(Menu paramMenu)
    {
      menu = paramMenu;
      resetGroup();
    }
    
    private char getShortcut(String paramString)
    {
      if (paramString == null) {
        return '\000';
      }
      return paramString.charAt(0);
    }
    
    private Object newInstance(String paramString, Class[] paramArrayOfClass, Object[] paramArrayOfObject)
    {
      Context localContext = mContext;
      try
      {
        paramArrayOfClass = localContext.getClassLoader().loadClass(paramString).getConstructor(paramArrayOfClass);
        paramArrayOfClass.setAccessible(true);
        paramArrayOfClass = paramArrayOfClass.newInstance(paramArrayOfObject);
        return paramArrayOfClass;
      }
      catch (Exception paramArrayOfClass)
      {
        Log.w("SupportMenuInflater", "Cannot instantiate class: " + paramString, paramArrayOfClass);
      }
      return null;
    }
    
    private void setItem(MenuItem paramMenuItem)
    {
      int i = 1;
      Object localObject = paramMenuItem.setChecked(itemChecked).setVisible(itemVisible).setEnabled(itemEnabled);
      if (itemCheckable >= 1) {}
      for (boolean bool = true;; bool = false)
      {
        ((MenuItem)localObject).setCheckable(bool).setTitleCondensed(itemTitleCondensed).setIcon(itemIconResId).setAlphabeticShortcut(itemAlphabeticShortcut).setNumericShortcut(itemNumericShortcut);
        if (itemShowAsAction >= 0) {
          paramMenuItem.setShowAsAction(itemShowAsAction);
        }
        if (itemListenerMethodName == null) {
          break label164;
        }
        if (!mContext.isRestricted()) {
          break;
        }
        throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
      }
      paramMenuItem.setOnMenuItemClickListener(new SupportMenuInflater.InflatedOnMenuItemClickListener(getRealOwner(), itemListenerMethodName));
      label164:
      if ((paramMenuItem instanceof MenuItemImpl)) {
        localObject = (MenuItemImpl)paramMenuItem;
      }
      if (itemCheckable >= 2)
      {
        if ((paramMenuItem instanceof MenuItemImpl)) {
          ((MenuItemImpl)paramMenuItem).setExclusiveCheckable(true);
        }
      }
      else
      {
        if (itemActionViewClassName == null) {
          break label319;
        }
        paramMenuItem.setActionView((View)newInstance(itemActionViewClassName, SupportMenuInflater.ACTION_VIEW_CONSTRUCTOR_SIGNATURE, mActionViewConstructorArguments));
      }
      for (;;)
      {
        if (itemActionViewLayout > 0)
        {
          if (i != 0) {
            break label308;
          }
          paramMenuItem.setActionView(itemActionViewLayout);
        }
        for (;;)
        {
          if (itemActionProvider != null) {
            h.setActionProvider(paramMenuItem, itemActionProvider);
          }
          h.a(paramMenuItem, title);
          h.setShowAsAction(paramMenuItem, author);
          return;
          if (!(paramMenuItem instanceof MenuItemWrapperICS)) {
            break;
          }
          ((MenuItemWrapperICS)paramMenuItem).setExclusiveCheckable(true);
          break;
          label308:
          Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
        }
        label319:
        i = 0;
      }
    }
    
    public void addItem()
    {
      itemAdded = true;
      setItem(menu.add(groupId, itemId, itemCategoryOrder, itemTitle));
    }
    
    public SubMenu addSubMenuItem()
    {
      itemAdded = true;
      SubMenu localSubMenu = menu.addSubMenu(groupId, itemId, itemCategoryOrder, itemTitle);
      setItem(localSubMenu.getItem());
      return localSubMenu;
    }
    
    public boolean hasAddedItem()
    {
      return itemAdded;
    }
    
    public void readGroup(AttributeSet paramAttributeSet)
    {
      paramAttributeSet = mContext.obtainStyledAttributes(paramAttributeSet, R.styleable.MenuGroup);
      groupId = paramAttributeSet.getResourceId(R.styleable.MenuGroup_android_id, 0);
      groupCategory = paramAttributeSet.getInt(R.styleable.MenuGroup_android_menuCategory, 0);
      groupOrder = paramAttributeSet.getInt(R.styleable.MenuGroup_android_orderInCategory, 0);
      groupCheckable = paramAttributeSet.getInt(R.styleable.MenuGroup_android_checkableBehavior, 0);
      groupVisible = paramAttributeSet.getBoolean(R.styleable.MenuGroup_android_visible, true);
      groupEnabled = paramAttributeSet.getBoolean(R.styleable.MenuGroup_android_enabled, true);
      paramAttributeSet.recycle();
    }
    
    public void readItem(AttributeSet paramAttributeSet)
    {
      int j = 1;
      paramAttributeSet = mContext.obtainStyledAttributes(paramAttributeSet, R.styleable.MenuItem);
      itemId = paramAttributeSet.getResourceId(R.styleable.MenuItem_android_id, 0);
      itemCategoryOrder = (paramAttributeSet.getInt(R.styleable.MenuItem_android_menuCategory, groupCategory) & 0xFFFF0000 | paramAttributeSet.getInt(R.styleable.MenuItem_android_orderInCategory, groupOrder) & 0xFFFF);
      itemTitle = paramAttributeSet.getText(R.styleable.MenuItem_android_title);
      itemTitleCondensed = paramAttributeSet.getText(R.styleable.MenuItem_android_titleCondensed);
      itemIconResId = paramAttributeSet.getResourceId(R.styleable.MenuItem_android_icon, 0);
      itemAlphabeticShortcut = getShortcut(paramAttributeSet.getString(R.styleable.MenuItem_android_alphabeticShortcut));
      itemNumericShortcut = getShortcut(paramAttributeSet.getString(R.styleable.MenuItem_android_numericShortcut));
      int i;
      if (paramAttributeSet.hasValue(R.styleable.MenuItem_android_checkable)) {
        if (paramAttributeSet.getBoolean(R.styleable.MenuItem_android_checkable, false))
        {
          i = 1;
          itemCheckable = i;
          label156:
          itemChecked = paramAttributeSet.getBoolean(R.styleable.MenuItem_android_checked, false);
          itemVisible = paramAttributeSet.getBoolean(R.styleable.MenuItem_android_visible, groupVisible);
          itemEnabled = paramAttributeSet.getBoolean(R.styleable.MenuItem_android_enabled, groupEnabled);
          itemShowAsAction = paramAttributeSet.getInt(R.styleable.MenuItem_showAsAction, -1);
          itemListenerMethodName = paramAttributeSet.getString(R.styleable.MenuItem_android_onClick);
          itemActionViewLayout = paramAttributeSet.getResourceId(R.styleable.MenuItem_actionLayout, 0);
          itemActionViewClassName = paramAttributeSet.getString(R.styleable.MenuItem_actionViewClass);
          itemActionProviderClassName = paramAttributeSet.getString(R.styleable.MenuItem_actionProviderClass);
          if (itemActionProviderClassName == null) {
            break label355;
          }
          i = j;
          label264:
          if ((i == 0) || (itemActionViewLayout != 0) || (itemActionViewClassName != null)) {
            break label360;
          }
        }
      }
      for (itemActionProvider = ((ActionProvider)newInstance(itemActionProviderClassName, SupportMenuInflater.ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE, mActionProviderConstructorArguments));; itemActionProvider = null)
      {
        title = paramAttributeSet.getText(R.styleable.MenuItem_contentDescription);
        author = paramAttributeSet.getText(R.styleable.MenuItem_tooltipText);
        paramAttributeSet.recycle();
        itemAdded = false;
        return;
        i = 0;
        break;
        itemCheckable = groupCheckable;
        break label156;
        label355:
        i = 0;
        break label264;
        label360:
        if (i != 0) {
          Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
        }
      }
    }
    
    public void resetGroup()
    {
      groupId = 0;
      groupCategory = 0;
      groupOrder = 0;
      groupCheckable = 0;
      groupVisible = true;
      groupEnabled = true;
    }
  }
}

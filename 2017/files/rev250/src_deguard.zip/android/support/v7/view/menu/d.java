package android.support.v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Handler;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R.dimen;
import android.support.v7.appcompat.R.layout;
import android.support.v7.widget.Label;
import android.support.v7.widget.ListPopupWindow;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

final class d
  extends k
  implements MenuPresenter, View.OnKeyListener, PopupWindow.OnDismissListener
{
  private boolean J;
  private final Context a;
  private final int b;
  private View c;
  private l.a d;
  private int e;
  final Handler f;
  private int flags;
  private boolean g;
  private boolean h;
  boolean i;
  private final int j;
  private final int k;
  private final boolean l;
  private final List<h> m = new LinkedList();
  private final android.support.v7.widget.Object o = new a(this);
  private PopupWindow.OnDismissListener r;
  private int s = 0;
  private int t = 0;
  View this$0;
  private final ViewTreeObserver.OnGlobalLayoutListener v = new ActivityChooserView.2(this);
  final List<e.a> w = new ArrayList();
  private ViewTreeObserver x;
  private int y;
  private boolean z;
  
  public d(Context paramContext, View paramView, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    a = paramContext;
    c = paramView;
    j = paramInt1;
    k = paramInt2;
    l = paramBoolean;
    g = false;
    e = b();
    paramContext = paramContext.getResources();
    b = Math.max(getDisplayMetricswidthPixels / 2, paramContext.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
    f = new Handler();
  }
  
  private Label a()
  {
    Label localLabel = new Label(a, null, j, k);
    localLabel.a(o);
    localLabel.setOnItemClickListener(this);
    localLabel.setOnDismissListener(this);
    localLabel.setAnchorView(c);
    localLabel.dismiss(t);
    localLabel.setModal(true);
    return localLabel;
  }
  
  private MenuItem a(f paramF1, f paramF2)
  {
    int i1 = paramF1.size();
    int n = 0;
    while (n < i1)
    {
      MenuItem localMenuItem = paramF1.getItem(n);
      if ((localMenuItem.hasSubMenu()) && (paramF2 == localMenuItem.getSubMenu())) {
        return localMenuItem;
      }
      n += 1;
    }
    return null;
  }
  
  private View a(h paramH, f paramF)
  {
    int n = 0;
    paramF = a(c, paramF);
    if (paramF == null) {
      return null;
    }
    ListView localListView = paramH.getListView();
    paramH = localListView.getAdapter();
    int i1;
    if ((paramH instanceof HeaderViewListAdapter))
    {
      paramH = (HeaderViewListAdapter)paramH;
      i1 = paramH.getHeadersCount();
      paramH = (e.a)paramH.getWrappedAdapter();
      int i2 = paramH.getCount();
      label62:
      if (n >= i2) {
        break label135;
      }
      if (paramF != paramH.a(n)) {
        break label95;
      }
    }
    for (;;)
    {
      if (n == -1)
      {
        return null;
        paramH = (e.a)paramH;
        i1 = 0;
        break;
        label95:
        n += 1;
        break label62;
      }
      n = n + i1 - localListView.getFirstVisiblePosition();
      if ((n < 0) || (n >= localListView.getChildCount())) {
        return null;
      }
      return localListView.getChildAt(n);
      label135:
      n = -1;
    }
  }
  
  private void a(f paramF)
  {
    Object localObject3 = LayoutInflater.from(a);
    Object localObject1 = new e.a(paramF, (LayoutInflater)localObject3, l);
    int i3;
    Label localLabel;
    Object localObject2;
    label136:
    int n;
    label167:
    int i4;
    if ((!isShowing()) && (g))
    {
      ((e.a)localObject1).a(true);
      i3 = k.measureContentWidth((ListAdapter)localObject1, null, a, b);
      localLabel = a();
      localLabel.setAdapter((ListAdapter)localObject1);
      localLabel.setContentWidth(i3);
      localLabel.dismiss(t);
      if (w.size() <= 0) {
        break label386;
      }
      localObject1 = (h)w.get(w.size() - 1);
      localObject2 = a((h)localObject1, paramF);
      if (localObject2 == null) {
        break label437;
      }
      localLabel.a(false);
      localLabel.init(null);
      int i1 = c(i3);
      if (i1 != 1) {
        break label395;
      }
      n = 1;
      e = i1;
      int[] arrayOfInt = new int[2];
      ((View)localObject2).getLocationInWindow(arrayOfInt);
      i4 = this$0.getHorizontalOffset() + arrayOfInt[0];
      i1 = this$0.getVerticalOffset();
      int i2 = arrayOfInt[1];
      if ((t & 0x5) != 5) {
        break label412;
      }
      if (n == 0) {
        break label400;
      }
      n = i4 + i3;
      label234:
      localLabel.setHorizontalOffset(n);
      localLabel.setVerticalOffset(i2 + i1);
    }
    for (;;)
    {
      localObject2 = new h(localLabel, paramF, e);
      w.add(localObject2);
      localLabel.show();
      if ((localObject1 != null) || (!J) || (paramF.a() == null)) {
        return;
      }
      localObject1 = localLabel.getListView();
      localObject2 = (FrameLayout)((LayoutInflater)localObject3).inflate(R.layout.abc_popup_menu_header_item_layout, (ViewGroup)localObject1, false);
      localObject3 = (TextView)((View)localObject2).findViewById(16908310);
      ((View)localObject2).setEnabled(false);
      ((TextView)localObject3).setText(paramF.a());
      ((ListView)localObject1).addHeaderView((View)localObject2, null, false);
      localLabel.show();
      return;
      if (!isShowing()) {
        break;
      }
      ((e.a)localObject1).a(k.onSubMenuSelected(paramF));
      break;
      label386:
      localObject2 = null;
      localObject1 = null;
      break label136;
      label395:
      n = 0;
      break label167;
      label400:
      n = i4 - ((View)localObject2).getWidth();
      break label234;
      label412:
      if (n != 0)
      {
        n = ((View)localObject2).getWidth() + i4;
        break label234;
      }
      n = i4 - i3;
      break label234;
      label437:
      if (z) {
        localLabel.setHorizontalOffset(flags);
      }
      if (h) {
        localLabel.setVerticalOffset(y);
      }
      localLabel.show(get());
    }
  }
  
  private int b()
  {
    if (ViewCompat.getLayoutDirection(c) == 1) {
      return 0;
    }
    return 1;
  }
  
  private int c(int paramInt)
  {
    ListView localListView = ((h)w.get(w.size() - 1)).getListView();
    int[] arrayOfInt = new int[2];
    localListView.getLocationOnScreen(arrayOfInt);
    Rect localRect = new Rect();
    this$0.getWindowVisibleDisplayFrame(localRect);
    if (e == 1)
    {
      int n = arrayOfInt[0];
      if (localListView.getWidth() + n + paramInt > right) {
        return 0;
      }
      return 1;
    }
    if (arrayOfInt[0] - paramInt < 0) {
      return 1;
    }
    return 0;
  }
  
  private int c(f paramF)
  {
    int n = 0;
    int i1 = w.size();
    while (n < i1)
    {
      if (paramF == w.get(n)).c) {
        return n;
      }
      n += 1;
    }
    return -1;
  }
  
  public void a(int paramInt)
  {
    if (s != paramInt)
    {
      s = paramInt;
      t = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection(c));
    }
  }
  
  public void a(f paramF, boolean paramBoolean)
  {
    int n = c(paramF);
    if (n < 0) {
      return;
    }
    int i1 = n + 1;
    if (i1 < w.size()) {
      w.get(i1)).c.close(false);
    }
    h localH = (h)w.remove(n);
    c.removeMenuPresenter(this);
    if (i)
    {
      this$0.show(null);
      this$0.show(0);
    }
    this$0.dismiss();
    n = w.size();
    if (n > 0) {}
    for (e = w.get(n - 1)).e; n == 0; e = b())
    {
      dismiss();
      if (d != null) {
        d.onCloseMenu(paramF, true);
      }
      if (x != null)
      {
        if (x.isAlive()) {
          x.removeGlobalOnLayoutListener(v);
        }
        x = null;
      }
      r.onDismiss();
      return;
    }
    if (paramBoolean) {
      w.get(0)).c.close(false);
    }
  }
  
  public void a(View paramView)
  {
    if (c != paramView)
    {
      c = paramView;
      t = GravityCompat.getAbsoluteGravity(s, ViewCompat.getLayoutDirection(c));
    }
  }
  
  public void a(PopupWindow.OnDismissListener paramOnDismissListener)
  {
    r = paramOnDismissListener;
  }
  
  public void a(boolean paramBoolean)
  {
    g = paramBoolean;
  }
  
  public void dismiss()
  {
    int n = w.size();
    if (n > 0)
    {
      h[] arrayOfH = (h[])w.toArray(new h[n]);
      n -= 1;
      while (n >= 0)
      {
        h localH = arrayOfH[n];
        if (this$0.isShowing()) {
          this$0.dismiss();
        }
        n -= 1;
      }
    }
  }
  
  public void dismiss(int paramInt)
  {
    h = true;
    y = paramInt;
  }
  
  public boolean flagActionItems()
  {
    return false;
  }
  
  protected boolean g()
  {
    return false;
  }
  
  public ListView getListView()
  {
    if (w.isEmpty()) {
      return null;
    }
    return ((h)w.get(w.size() - 1)).getListView();
  }
  
  public boolean isShowing()
  {
    return (w.size() > 0) && (w.get(0)).this$0.isShowing());
  }
  
  public void onDismiss()
  {
    int i1 = w.size();
    int n = 0;
    h localH;
    if (n < i1)
    {
      localH = (h)w.get(n);
      if (this$0.isShowing()) {}
    }
    for (;;)
    {
      if (localH == null) {
        return;
      }
      c.close(false);
      return;
      n += 1;
      break;
      localH = null;
    }
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramKeyEvent.getAction() == 1) && (paramInt == 82))
    {
      dismiss();
      return true;
    }
    return false;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
  {
    Iterator localIterator = w.iterator();
    while (localIterator.hasNext())
    {
      h localH = (h)localIterator.next();
      if (paramSubMenuBuilder == c)
      {
        localH.getListView().requestFocus();
        return true;
      }
    }
    if (paramSubMenuBuilder.hasVisibleItems())
    {
      setTitle(paramSubMenuBuilder);
      if (d != null) {
        d.onOpenSubMenu(paramSubMenuBuilder);
      }
      return true;
    }
    return false;
  }
  
  public void setCallback(l.a paramA)
  {
    d = paramA;
  }
  
  public void setCallback(boolean paramBoolean)
  {
    J = paramBoolean;
  }
  
  public void setTitle(f paramF)
  {
    paramF.addMenuPresenter(this, a);
    if (isShowing())
    {
      a(paramF);
      return;
    }
    m.add(paramF);
  }
  
  public void show()
  {
    if (isShowing()) {
      return;
    }
    Iterator localIterator = m.iterator();
    while (localIterator.hasNext()) {
      a((f)localIterator.next());
    }
    m.clear();
    this$0 = c;
    if (this$0 != null)
    {
      if (x == null) {}
      for (int n = 1;; n = 0)
      {
        x = this$0.getViewTreeObserver();
        if (n == 0) {
          break;
        }
        x.addOnGlobalLayoutListener(v);
        return;
      }
    }
  }
  
  public void show(int paramInt)
  {
    z = true;
    flags = paramInt;
  }
  
  public void updateMenuView(boolean paramBoolean)
  {
    Iterator localIterator = w.iterator();
    while (localIterator.hasNext()) {
      k.a(((h)localIterator.next()).getListView().getAdapter()).notifyDataSetChanged();
    }
  }
}

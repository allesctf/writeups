package android.support.v7.view.menu;

import android.support.v7.widget.Label;
import android.support.v7.widget.ListPopupWindow;
import android.widget.ListView;

class h
{
  public final f c;
  public final int e;
  public final Label this$0;
  
  public h(Label paramLabel, f paramF, int paramInt)
  {
    this$0 = paramLabel;
    c = paramF;
    e = paramInt;
  }
  
  public ListView getListView()
  {
    return this$0.getListView();
  }
}

package android.support.v7.view.menu;

import android.os.Handler;
import android.os.SystemClock;
import android.view.MenuItem;
import java.util.List;

class a
  implements android.support.v7.widget.Object
{
  a(d paramD) {}
  
  public void a(f paramF, MenuItem paramMenuItem)
  {
    e.f.removeCallbacksAndMessages(null);
    int i = 0;
    int j = e.w.size();
    if (i < j) {
      if (paramF != e.w.get(i)).c) {}
    }
    for (;;)
    {
      if (i == -1)
      {
        return;
        i += 1;
        break;
      }
      i += 1;
      if (i < e.w.size()) {}
      for (h localH = (h)e.w.get(i);; localH = null)
      {
        paramMenuItem = new e.2.1(this, localH, paramMenuItem, paramF);
        long l = SystemClock.uptimeMillis();
        e.f.postAtTime(paramMenuItem, paramF, l + 200L);
        return;
      }
      i = -1;
    }
  }
  
  public void b(f paramF, MenuItem paramMenuItem)
  {
    e.f.removeCallbacksAndMessages(paramF);
  }
}

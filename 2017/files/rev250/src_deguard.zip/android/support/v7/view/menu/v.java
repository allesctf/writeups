package android.support.v7.view.menu;

import android.support.v7.widget.ListPopupWindow;
import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;

class v
  implements ViewTreeObserver.OnGlobalLayoutListener
{
  v(w paramW) {}
  
  public void onGlobalLayout()
  {
    if ((mPopup.isShowing()) && (!mPopup.mPopup.isModal()))
    {
      View localView = mPopup.mAnchorView;
      if ((localView == null) || (!localView.isShown()))
      {
        mPopup.dismiss();
        return;
      }
      mPopup.mPopup.show();
    }
  }
}

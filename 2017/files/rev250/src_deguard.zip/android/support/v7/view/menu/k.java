package android.support.v7.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow.OnDismissListener;

abstract class k
  implements MenuPresenter, ListPopupWindow, AdapterView.OnItemClickListener
{
  private Rect a;
  
  k() {}
  
  protected static e.a a(ListAdapter paramListAdapter)
  {
    if ((paramListAdapter instanceof HeaderViewListAdapter)) {
      return (e.a)((HeaderViewListAdapter)paramListAdapter).getWrappedAdapter();
    }
    return (e.a)paramListAdapter;
  }
  
  protected static int measureContentWidth(ListAdapter paramListAdapter, ViewGroup paramViewGroup, Context paramContext, int paramInt)
  {
    int i1 = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i2 = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i3 = paramListAdapter.getCount();
    int j = 0;
    int m = 0;
    View localView = null;
    int i = 0;
    Object localObject = paramViewGroup;
    paramViewGroup = localView;
    int k;
    if (j < i3)
    {
      int n = paramListAdapter.getItemViewType(j);
      k = m;
      if (n != m)
      {
        k = n;
        paramViewGroup = null;
      }
      if (localObject != null) {
        break label160;
      }
      localObject = new FrameLayout(paramContext);
      label89:
      localView = paramListAdapter.getView(j, paramViewGroup, (ViewGroup)localObject);
      paramViewGroup = localView;
      localView.measure(i1, i2);
      n = localView.getMeasuredWidth();
      m = n;
      if (n >= paramInt) {
        return paramInt;
      }
      if (n <= i) {
        break label163;
      }
      i = m;
    }
    label160:
    label163:
    for (;;)
    {
      j += 1;
      m = k;
      break;
      return i;
      break label89;
    }
  }
  
  protected static boolean onSubMenuSelected(f paramF)
  {
    int j = paramF.size();
    int i = 0;
    while (i < j)
    {
      MenuItem localMenuItem = paramF.getItem(i);
      if ((localMenuItem.isVisible()) && (localMenuItem.getIcon() != null)) {
        return true;
      }
      i += 1;
    }
    return false;
  }
  
  public abstract void a(int paramInt);
  
  public void a(Rect paramRect)
  {
    a = paramRect;
  }
  
  public abstract void a(View paramView);
  
  public abstract void a(PopupWindow.OnDismissListener paramOnDismissListener);
  
  public abstract void a(boolean paramBoolean);
  
  public boolean collapseItemActionView(f paramF, MenuItemImpl paramMenuItemImpl)
  {
    return false;
  }
  
  public abstract void dismiss(int paramInt);
  
  public boolean expandItemActionView(f paramF, MenuItemImpl paramMenuItemImpl)
  {
    return false;
  }
  
  protected boolean g()
  {
    return true;
  }
  
  public Rect get()
  {
    return a;
  }
  
  public void initForMenu(Context paramContext, f paramF) {}
  
  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    paramView = (ListAdapter)paramAdapterView.getAdapter();
    paramAdapterView = ab;
    paramView = (MenuItem)paramView.getItem(paramInt);
    if (g()) {}
    for (paramInt = 0;; paramInt = 4)
    {
      paramAdapterView.performItemAction(paramView, this, paramInt);
      return;
    }
  }
  
  public abstract void setCallback(boolean paramBoolean);
  
  public abstract void setTitle(f paramF);
  
  public abstract void show(int paramInt);
}

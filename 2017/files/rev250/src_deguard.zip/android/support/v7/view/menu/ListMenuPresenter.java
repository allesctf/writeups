package android.support.v7.view.menu;

import android.content.Context;
import android.support.v7.appcompat.R.layout;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.util.ArrayList;

public class ListMenuPresenter
  implements MenuPresenter, AdapterView.OnItemClickListener
{
  MenuAdapter mAdapter;
  private l.a mCallback;
  Context mContext;
  int mExpandedIndex;
  LayoutInflater mInflater;
  int mItemLayoutRes;
  f mMenu;
  ExpandedMenuView mMenuView;
  int mThemeRes;
  
  public ListMenuPresenter(int paramInt1, int paramInt2)
  {
    mItemLayoutRes = paramInt1;
    mThemeRes = paramInt2;
  }
  
  public ListMenuPresenter(Context paramContext, int paramInt)
  {
    this(paramInt, 0);
    mContext = paramContext;
    mInflater = LayoutInflater.from(mContext);
  }
  
  public void a(f paramF, boolean paramBoolean)
  {
    if (mCallback != null) {
      mCallback.onCloseMenu(paramF, paramBoolean);
    }
  }
  
  public boolean collapseItemActionView(f paramF, MenuItemImpl paramMenuItemImpl)
  {
    return false;
  }
  
  public boolean expandItemActionView(f paramF, MenuItemImpl paramMenuItemImpl)
  {
    return false;
  }
  
  public boolean flagActionItems()
  {
    return false;
  }
  
  public ListAdapter getAdapter()
  {
    if (mAdapter == null) {
      mAdapter = new MenuAdapter();
    }
    return mAdapter;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup)
  {
    if (mMenuView == null)
    {
      mMenuView = ((ExpandedMenuView)mInflater.inflate(R.layout.abc_expanded_menu_layout, paramViewGroup, false));
      if (mAdapter == null) {
        mAdapter = new MenuAdapter();
      }
      mMenuView.setAdapter(mAdapter);
      mMenuView.setOnItemClickListener(this);
    }
    return mMenuView;
  }
  
  public void initForMenu(Context paramContext, f paramF)
  {
    if (mThemeRes != 0)
    {
      mContext = new ContextThemeWrapper(paramContext, mThemeRes);
      mInflater = LayoutInflater.from(mContext);
    }
    for (;;)
    {
      mMenu = paramF;
      if (mAdapter == null) {
        break;
      }
      mAdapter.notifyDataSetChanged();
      return;
      if (mContext != null)
      {
        mContext = paramContext;
        if (mInflater == null) {
          mInflater = LayoutInflater.from(mContext);
        }
      }
    }
  }
  
  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    mMenu.performItemAction(mAdapter.getCount(paramInt), this, 0);
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
  {
    if (!paramSubMenuBuilder.hasVisibleItems()) {
      return false;
    }
    new g(paramSubMenuBuilder).a(null);
    if (mCallback != null) {
      mCallback.onOpenSubMenu(paramSubMenuBuilder);
    }
    return true;
  }
  
  public void setCallback(l.a paramA)
  {
    mCallback = paramA;
  }
  
  public void updateMenuView(boolean paramBoolean)
  {
    if (mAdapter != null) {
      mAdapter.notifyDataSetChanged();
    }
  }
  
  class MenuAdapter
    extends BaseAdapter
  {
    private int mExpandedIndex = -1;
    
    public MenuAdapter()
    {
      findExpandedIndex();
    }
    
    void findExpandedIndex()
    {
      MenuItemImpl localMenuItemImpl = mMenu.getExpandedItem();
      if (localMenuItemImpl != null)
      {
        ArrayList localArrayList = mMenu.getNonActionItems();
        int j = localArrayList.size();
        int i = 0;
        while (i < j)
        {
          if ((MenuItemImpl)localArrayList.get(i) == localMenuItemImpl)
          {
            mExpandedIndex = i;
            return;
          }
          i += 1;
        }
      }
      mExpandedIndex = -1;
    }
    
    public int getCount()
    {
      int i = mMenu.getNonActionItems().size() - mExpandedIndex;
      if (mExpandedIndex < 0) {
        return i;
      }
      return i - 1;
    }
    
    public MenuItemImpl getCount(int paramInt)
    {
      ArrayList localArrayList = mMenu.getNonActionItems();
      int i = mExpandedIndex + paramInt;
      paramInt = i;
      if (mExpandedIndex >= 0)
      {
        paramInt = i;
        if (i >= mExpandedIndex) {
          paramInt = i + 1;
        }
      }
      return (MenuItemImpl)localArrayList.get(paramInt);
    }
    
    public long getItemId(int paramInt)
    {
      return paramInt;
    }
    
    public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
    {
      if (paramView == null) {
        paramView = mInflater.inflate(mItemLayoutRes, paramViewGroup, false);
      }
      for (;;)
      {
        ((MenuView.ItemView)paramView).initialize(getCount(paramInt), 0);
        return paramView;
      }
    }
    
    public void notifyDataSetChanged()
    {
      findExpandedIndex();
      super.notifyDataSetChanged();
    }
  }
}

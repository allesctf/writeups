package android.support.v4.os;

import android.os.Parcel;

public abstract interface ParcelableCompatCreatorCallbacks<T>
{
  public abstract Object[] a(int paramInt);
  
  public abstract Object createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader);
}

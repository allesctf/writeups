package android.support.v4.os;

import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class ParcelableCompat
{
  public static Parcelable.Creator newCreator(ParcelableCompatCreatorCallbacks paramParcelableCompatCreatorCallbacks)
  {
    if (Build.VERSION.SDK_INT >= 13) {
      return ParcelableCompatCreatorHoneycombMR2Stub.instantiate(paramParcelableCompatCreatorCallbacks);
    }
    return new CompatCreator();
  }
  
  class CompatCreator<T>
    implements Parcelable.Creator<T>
  {
    public CompatCreator() {}
    
    public Object createFromParcel(Parcel paramParcel)
    {
      return createFromParcel(paramParcel, null);
    }
    
    public Object[] newArray(int paramInt)
    {
      return a(paramInt);
    }
  }
}

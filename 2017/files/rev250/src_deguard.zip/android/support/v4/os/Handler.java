package android.support.v4.os;

import android.os.Build.VERSION;

public class Handler
{
  public static boolean a()
  {
    return Build.VERSION.SDK_INT >= 24;
  }
  
  public static boolean getType()
  {
    return (!"REL".equals(Build.VERSION.CODENAME)) && (("O".equals(Build.VERSION.CODENAME)) || (Build.VERSION.CODENAME.startsWith("OMR")));
  }
}

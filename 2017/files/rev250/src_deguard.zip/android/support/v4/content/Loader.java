package android.support.v4.content;

import android.support.v4.b.b.a;
import android.support.v4.b.b.b;
import android.support.v4.util.DebugUtils;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class Loader<D>
{
  boolean mAbandoned;
  boolean mContentChanged;
  int mId;
  b.b<D> mListener;
  boolean mProcessingChange;
  boolean mReset;
  boolean mStarted;
  b.a<D> mViewTreeObserver;
  
  public String dataToString(Object paramObject)
  {
    StringBuilder localStringBuilder = new StringBuilder(64);
    DebugUtils.buildShortClassTag(paramObject, localStringBuilder);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mId=");
    paramPrintWriter.print(mId);
    paramPrintWriter.print(" mListener=");
    paramPrintWriter.println(mListener);
    if ((mStarted) || (mContentChanged) || (mProcessingChange))
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStarted=");
      paramPrintWriter.print(mStarted);
      paramPrintWriter.print(" mContentChanged=");
      paramPrintWriter.print(mContentChanged);
      paramPrintWriter.print(" mProcessingChange=");
      paramPrintWriter.println(mProcessingChange);
    }
    if ((mAbandoned) || (mReset))
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAbandoned=");
      paramPrintWriter.print(mAbandoned);
      paramPrintWriter.print(" mReset=");
      paramPrintWriter.println(mReset);
    }
  }
  
  protected void onReset() {}
  
  protected void onStartLoading() {}
  
  protected void onStopLoading() {}
  
  public void registerListener(int paramInt, OnLoadCompleteListener paramOnLoadCompleteListener)
  {
    if (mListener != null) {
      throw new IllegalStateException("There is already a listener registered");
    }
    mListener = paramOnLoadCompleteListener;
    mId = paramInt;
  }
  
  public void registerListener(OnLoadCanceledListener paramOnLoadCanceledListener)
  {
    if (mViewTreeObserver != null) {
      throw new IllegalStateException("There is already a listener registered");
    }
    mViewTreeObserver = paramOnLoadCanceledListener;
  }
  
  public void reset()
  {
    onReset();
    mReset = true;
    mStarted = false;
    mAbandoned = false;
    mContentChanged = false;
    mProcessingChange = false;
  }
  
  public final void startLoading()
  {
    mStarted = true;
    mReset = false;
    mAbandoned = false;
    onStartLoading();
  }
  
  public void stopLoading()
  {
    mStarted = false;
    onStopLoading();
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(64);
    DebugUtils.buildShortClassTag(this, localStringBuilder);
    localStringBuilder.append(" id=");
    localStringBuilder.append(mId);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
  
  public void unregisterListener(OnLoadCanceledListener paramOnLoadCanceledListener)
  {
    if (mViewTreeObserver == null) {
      throw new IllegalStateException("No listener register");
    }
    if (mViewTreeObserver != paramOnLoadCanceledListener) {
      throw new IllegalArgumentException("Attempting to unregister the wrong listener");
    }
    mViewTreeObserver = null;
  }
  
  public void unregisterListener(OnLoadCompleteListener paramOnLoadCompleteListener)
  {
    if (mListener == null) {
      throw new IllegalStateException("No listener register");
    }
    if (mListener != paramOnLoadCompleteListener) {
      throw new IllegalArgumentException("Attempting to unregister the wrong listener");
    }
    mListener = null;
  }
  
  public abstract interface OnLoadCanceledListener<D> {}
  
  public abstract interface OnLoadCompleteListener<D> {}
}

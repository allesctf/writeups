package android.support.v4.widget;

import android.animation.TimeInterpolator;
import android.content.res.Resources;
import android.os.SystemClock;
import android.support.v4.view.ViewCompat;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Interpolator;

public abstract class f
  implements View.OnTouchListener
{
  private static final int DEFAULT_ACTIVATION_DELAY = ;
  private int A;
  private final Interpolator a = new AccelerateInterpolator();
  private boolean b;
  private float[] c = { 0.0F, 0.0F };
  private float[] d = { Float.MAX_VALUE, Float.MAX_VALUE };
  private boolean h;
  private float[] j = { 0.0F, 0.0F };
  boolean m;
  private int mActivationDelay;
  private boolean mAlreadyDelayed;
  private Runnable mRunnable;
  final AutoScrollHelper.ClampedScroller mScroller = new AutoScrollHelper.ClampedScroller();
  final View mTarget;
  private float[] n = { Float.MAX_VALUE, Float.MAX_VALUE };
  boolean s;
  private float[] v = { 0.0F, 0.0F };
  boolean x;
  
  public f(View paramView)
  {
    mTarget = paramView;
    paramView = Resources.getSystem().getDisplayMetrics();
    int i = (int)(1575.0F * density + 0.5F);
    int k = (int)(density * 315.0F + 0.5F);
    e(i, i);
    size(k, k);
    a(1);
    close(Float.MAX_VALUE, Float.MAX_VALUE);
    f(0.2F, 0.2F);
    add(1.0F, 1.0F);
    f(DEFAULT_ACTIVATION_DELAY);
    setRampDownDuration(500);
    setRampUpDuration(500);
  }
  
  private float a(float paramFloat1, float paramFloat2)
  {
    if (paramFloat2 == 0.0F) {
      return 0.0F;
    }
    switch (A)
    {
    default: 
      return 0.0F;
    case 0: 
    case 1: 
      if (paramFloat1 < paramFloat2)
      {
        if (paramFloat1 >= 0.0F) {
          return 1.0F - paramFloat1 / paramFloat2;
        }
        if ((x) && (A == 1)) {
          return 1.0F;
        }
      }
      break;
    case 2: 
      if (paramFloat1 < 0.0F) {
        return paramFloat1 / -paramFloat2;
      }
      break;
    }
    return 0.0F;
  }
  
  static float a(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    if (paramFloat1 > paramFloat3) {
      return paramFloat3;
    }
    if (paramFloat1 < paramFloat2) {
      return paramFloat2;
    }
    return paramFloat1;
  }
  
  private float a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    paramFloat1 = a(paramFloat1 * paramFloat2, 0.0F, paramFloat3);
    paramFloat3 = a(paramFloat4, paramFloat1);
    paramFloat1 = a(paramFloat2 - paramFloat4, paramFloat1) - paramFloat3;
    if (paramFloat1 < 0.0F) {}
    for (paramFloat1 = -a.getInterpolation(-paramFloat1);; paramFloat1 = a.getInterpolation(paramFloat1))
    {
      return a(paramFloat1, -1.0F, 1.0F);
      if (paramFloat1 <= 0.0F) {
        break;
      }
    }
    return 0.0F;
  }
  
  static int a(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 > paramInt3) {
      return paramInt3;
    }
    if (paramInt1 < paramInt2) {
      return paramInt2;
    }
    return paramInt1;
  }
  
  private float add(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3)
  {
    paramFloat1 = a(j[paramInt], paramFloat2, n[paramInt], paramFloat1);
    if (paramFloat1 == 0.0F) {
      return 0.0F;
    }
    float f2 = v[paramInt];
    paramFloat2 = c[paramInt];
    float f1 = d[paramInt];
    paramFloat3 = f2 * paramFloat3;
    if (paramFloat1 > 0.0F) {
      return a(paramFloat1 * paramFloat3, paramFloat2, f1);
    }
    return -a(-paramFloat1 * paramFloat3, paramFloat2, f1);
  }
  
  private void d()
  {
    if (s)
    {
      x = false;
      return;
    }
    mScroller.requestStop();
  }
  
  private void startAnimating()
  {
    if (mRunnable == null) {
      mRunnable = new AutoScrollHelper.ScrollAnimationRunnable(this);
    }
    x = true;
    s = true;
    if ((!mAlreadyDelayed) && (mActivationDelay > 0)) {
      ViewCompat.postOnAnimationDelayed(mTarget, mRunnable, mActivationDelay);
    }
    for (;;)
    {
      mAlreadyDelayed = true;
      return;
      mRunnable.run();
    }
  }
  
  public f a(int paramInt)
  {
    A = paramInt;
    return this;
  }
  
  public f a(boolean paramBoolean)
  {
    if ((b) && (!paramBoolean)) {
      d();
    }
    b = paramBoolean;
    return this;
  }
  
  public f add(float paramFloat1, float paramFloat2)
  {
    v[0] = (paramFloat1 / 1000.0F);
    v[1] = (paramFloat2 / 1000.0F);
    return this;
  }
  
  public abstract boolean canTargetScrollHorizontally(int paramInt);
  
  public abstract boolean canTargetScrollVertically(int paramInt);
  
  public f close(float paramFloat1, float paramFloat2)
  {
    n[0] = paramFloat1;
    n[1] = paramFloat2;
    return this;
  }
  
  public f e(float paramFloat1, float paramFloat2)
  {
    d[0] = (paramFloat1 / 1000.0F);
    d[1] = (paramFloat2 / 1000.0F);
    return this;
  }
  
  public f f(float paramFloat1, float paramFloat2)
  {
    j[0] = paramFloat1;
    j[1] = paramFloat2;
    return this;
  }
  
  public f f(int paramInt)
  {
    mActivationDelay = paramInt;
    return this;
  }
  
  void onLongPress()
  {
    long l = SystemClock.uptimeMillis();
    MotionEvent localMotionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
    mTarget.onTouchEvent(localMotionEvent);
    localMotionEvent.recycle();
  }
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    if (!b) {
      return false;
    }
    switch (paramMotionEvent.getActionMasked())
    {
    default: 
      break;
    }
    while ((h) && (x))
    {
      return true;
      m = true;
      mAlreadyDelayed = false;
      float f1 = add(0, paramMotionEvent.getX(), paramView.getWidth(), mTarget.getWidth());
      float f2 = add(1, paramMotionEvent.getY(), paramView.getHeight(), mTarget.getHeight());
      mScroller.setTargetVelocity(f1, f2);
      if ((!x) && (shouldAnimate()))
      {
        startAnimating();
        continue;
        d();
      }
    }
    return false;
  }
  
  public abstract void scrollTargetBy(int paramInt1, int paramInt2);
  
  public f setRampDownDuration(int paramInt)
  {
    mScroller.setRampDownDuration(paramInt);
    return this;
  }
  
  public f setRampUpDuration(int paramInt)
  {
    mScroller.setRampUpDuration(paramInt);
    return this;
  }
  
  boolean shouldAnimate()
  {
    AutoScrollHelper.ClampedScroller localClampedScroller = mScroller;
    int i = localClampedScroller.getVerticalDirection();
    int k = localClampedScroller.getHorizontalDirection();
    return ((i != 0) && (canTargetScrollVertically(i))) || ((k != 0) && (canTargetScrollHorizontally(k)));
  }
  
  public f size(float paramFloat1, float paramFloat2)
  {
    c[0] = (paramFloat1 / 1000.0F);
    c[1] = (paramFloat2 / 1000.0F);
    return this;
  }
}

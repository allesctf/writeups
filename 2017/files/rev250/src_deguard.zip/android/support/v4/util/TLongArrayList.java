package android.support.v4.util;

import android.support.v4.f.h;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public final class TLongArrayList<E>
  implements Collection<E>, Set<E>
{
  private static final int[] EMPTY = new int[0];
  static Object[] b;
  static int c;
  private static final Object[] data = new Object[0];
  static Object[] q;
  static int x;
  h<E, E> _pos;
  int[] buffer;
  final boolean index;
  int length;
  Object[] next;
  
  public TLongArrayList()
  {
    this(0, false);
  }
  
  public TLongArrayList(int paramInt, boolean paramBoolean)
  {
    index = paramBoolean;
    if (paramInt == 0)
    {
      buffer = EMPTY;
      next = data;
    }
    for (;;)
    {
      length = 0;
      return;
      add(paramInt);
    }
  }
  
  private MapCollections add()
  {
    if (_pos == null) {
      _pos = new BigReal(this);
    }
    return _pos;
  }
  
  private void add(int paramInt)
  {
    if (paramInt == 8) {}
    for (;;)
    {
      try
      {
        if (q != null)
        {
          Object[] arrayOfObject1 = q;
          next = arrayOfObject1;
          q = (Object[])arrayOfObject1[0];
          buffer = ((int[])arrayOfObject1[1]);
          arrayOfObject1[1] = null;
          arrayOfObject1[0] = null;
          x -= 1;
          return;
        }
        buffer = new int[paramInt];
        next = new Object[paramInt];
        return;
      }
      catch (Throwable localThrowable1)
      {
        throw localThrowable1;
      }
      if (paramInt == 4) {
        try
        {
          if (b != null)
          {
            Object[] arrayOfObject2 = b;
            next = arrayOfObject2;
            b = (Object[])arrayOfObject2[0];
            buffer = ((int[])arrayOfObject2[1]);
            arrayOfObject2[1] = null;
            arrayOfObject2[0] = null;
            c -= 1;
            return;
          }
        }
        catch (Throwable localThrowable2)
        {
          throw localThrowable2;
        }
      }
    }
  }
  
  private static void add(int[] paramArrayOfInt, Object[] paramArrayOfObject, int paramInt)
  {
    if (paramArrayOfInt.length == 8) {
      try
      {
        if (x < 10)
        {
          paramArrayOfObject[0] = q;
          paramArrayOfObject[1] = paramArrayOfInt;
          paramInt -= 1;
          break label114;
          q = paramArrayOfObject;
          x += 1;
        }
        return;
      }
      catch (Throwable paramArrayOfInt)
      {
        throw paramArrayOfInt;
      }
    }
    if (paramArrayOfInt.length == 4) {}
    for (;;)
    {
      try
      {
        if (c < 10)
        {
          paramArrayOfObject[0] = b;
          paramArrayOfObject[1] = paramArrayOfInt;
          paramInt -= 1;
          break label130;
          b = paramArrayOfObject;
          c += 1;
        }
        return;
      }
      catch (Throwable paramArrayOfInt)
      {
        throw paramArrayOfInt;
      }
      return;
      label114:
      while (paramInt >= 2)
      {
        paramArrayOfObject[paramInt] = null;
        paramInt -= 1;
      }
      break;
      label130:
      while (paramInt >= 2)
      {
        paramArrayOfObject[paramInt] = null;
        paramInt -= 1;
      }
    }
  }
  
  private int indexOf()
  {
    int m = length;
    if (m == 0) {
      return -1;
    }
    int i = ContainerHelpers.binarySearch(buffer, m, 0);
    int k = i;
    if (i >= 0)
    {
      k = i;
      if (next[i] != null)
      {
        int j = i + 1;
        while ((j < m) && (buffer[j] == 0))
        {
          if (next[j] == null) {
            return j;
          }
          j += 1;
        }
        i -= 1;
        while ((i >= 0) && (buffer[i] == 0))
        {
          k = i;
          if (next[i] == null) {
            return k;
          }
          i -= 1;
        }
        return j;
      }
    }
    return k;
  }
  
  private int indexOf(Object paramObject, int paramInt)
  {
    int j = length;
    if (j == 0) {
      return -1;
    }
    int k = ContainerHelpers.binarySearch(buffer, j, paramInt);
    if ((k >= 0) && (!paramObject.equals(next[k])))
    {
      int i = k + 1;
      while ((i < j) && (buffer[i] == paramInt))
      {
        if (paramObject.equals(next[i])) {
          return i;
        }
        i += 1;
      }
      j = k - 1;
      while ((j >= 0) && (buffer[j] == paramInt))
      {
        if (paramObject.equals(next[j])) {
          break label137;
        }
        j -= 1;
      }
      return i;
    }
    return k;
    label137:
    return j;
  }
  
  public boolean add(Object paramObject)
  {
    int j;
    int i;
    if (paramObject == null)
    {
      k = indexOf();
      j = 0;
      if (k >= 0) {
        return false;
      }
    }
    else
    {
      if (index) {}
      for (i = System.identityHashCode(paramObject);; i = paramObject.hashCode())
      {
        k = indexOf(paramObject, i);
        j = i;
        break;
      }
    }
    int k = k;
    if (length >= buffer.length)
    {
      if (length < 8) {
        break label238;
      }
      i = length + (length >> 1);
    }
    for (;;)
    {
      int[] arrayOfInt = buffer;
      Object[] arrayOfObject = next;
      add(i);
      if (buffer.length > 0)
      {
        System.arraycopy(arrayOfInt, 0, buffer, 0, arrayOfInt.length);
        System.arraycopy(arrayOfObject, 0, next, 0, arrayOfObject.length);
      }
      add(arrayOfInt, arrayOfObject, length);
      if (k < length)
      {
        System.arraycopy(buffer, k, buffer, k + 1, length - k);
        System.arraycopy(next, k, next, k + 1, length - k);
      }
      buffer[k] = j;
      next[k] = paramObject;
      length += 1;
      return true;
      label238:
      if (length >= 4) {
        i = 8;
      } else {
        i = 4;
      }
    }
  }
  
  public boolean addAll(Collection paramCollection)
  {
    toArray(length + paramCollection.size());
    boolean bool = false;
    paramCollection = paramCollection.iterator();
    while (paramCollection.hasNext()) {
      bool |= add(paramCollection.next());
    }
    return bool;
  }
  
  public void clear()
  {
    if (length != 0)
    {
      add(buffer, next, length);
      buffer = EMPTY;
      next = data;
      length = 0;
    }
  }
  
  public boolean contains(Object paramObject)
  {
    return indexOf(paramObject) >= 0;
  }
  
  public boolean containsAll(Collection paramCollection)
  {
    paramCollection = paramCollection.iterator();
    while (paramCollection.hasNext()) {
      if (!contains(paramCollection.next())) {
        return false;
      }
    }
    return true;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if ((paramObject instanceof Set))
    {
      paramObject = (Set)paramObject;
      if (size() != paramObject.size()) {
        return false;
      }
      int i = 0;
      try
      {
        int j = length;
        if (i >= j) {
          break label79;
        }
      }
      catch (NullPointerException paramObject)
      {
        try
        {
          boolean bool = paramObject.contains(get(i));
          if (!bool) {
            return false;
          }
          i += 1;
        }
        catch (ClassCastException paramObject) {}
        paramObject = paramObject;
        return false;
      }
    }
    return false;
    label79:
    return true;
  }
  
  public Object get(int paramInt)
  {
    return next[paramInt];
  }
  
  public int hashCode()
  {
    int i = 0;
    int[] arrayOfInt = buffer;
    int k = length;
    int j = 0;
    while (i < k)
    {
      j += arrayOfInt[i];
      i += 1;
    }
    return j;
  }
  
  public int indexOf(Object paramObject)
  {
    if (paramObject == null) {
      return indexOf();
    }
    if (index) {}
    for (int i = System.identityHashCode(paramObject);; i = paramObject.hashCode()) {
      return indexOf(paramObject, i);
    }
  }
  
  public boolean isEmpty()
  {
    return length <= 0;
  }
  
  public Iterator iterator()
  {
    return add().getKeySet().iterator();
  }
  
  public boolean remove(Object paramObject)
  {
    int i = indexOf(paramObject);
    if (i >= 0)
    {
      set(i);
      return true;
    }
    return false;
  }
  
  public boolean removeAll(Collection paramCollection)
  {
    boolean bool = false;
    paramCollection = paramCollection.iterator();
    while (paramCollection.hasNext()) {
      bool |= remove(paramCollection.next());
    }
    return bool;
  }
  
  public boolean retainAll(Collection paramCollection)
  {
    int i = length;
    boolean bool = false;
    i -= 1;
    while (i >= 0)
    {
      if (!paramCollection.contains(next[i]))
      {
        set(i);
        bool = true;
      }
      i -= 1;
    }
    return bool;
  }
  
  public Object set(int paramInt)
  {
    int i = 8;
    Object localObject = next[paramInt];
    if (length <= 1)
    {
      add(buffer, next, length);
      buffer = EMPTY;
      next = data;
      length = 0;
      return localObject;
    }
    if ((buffer.length > 8) && (length < buffer.length / 3))
    {
      if (length > 8) {
        i = length + (length >> 1);
      }
      int[] arrayOfInt = buffer;
      Object[] arrayOfObject = next;
      add(i);
      length -= 1;
      if (paramInt > 0)
      {
        System.arraycopy(arrayOfInt, 0, buffer, 0, paramInt);
        System.arraycopy(arrayOfObject, 0, next, 0, paramInt);
      }
      if (paramInt < length)
      {
        System.arraycopy(arrayOfInt, paramInt + 1, buffer, paramInt, length - paramInt);
        System.arraycopy(arrayOfObject, paramInt + 1, next, paramInt, length - paramInt);
        return localObject;
      }
    }
    else
    {
      length -= 1;
      if (paramInt < length)
      {
        System.arraycopy(buffer, paramInt + 1, buffer, paramInt, length - paramInt);
        System.arraycopy(next, paramInt + 1, next, paramInt, length - paramInt);
      }
      next[length] = null;
    }
    return localObject;
  }
  
  public int size()
  {
    return length;
  }
  
  public void toArray(int paramInt)
  {
    if (buffer.length < paramInt)
    {
      int[] arrayOfInt = buffer;
      Object[] arrayOfObject = next;
      add(paramInt);
      if (length > 0)
      {
        System.arraycopy(arrayOfInt, 0, buffer, 0, length);
        System.arraycopy(arrayOfObject, 0, next, 0, length);
      }
      add(arrayOfInt, arrayOfObject, length);
    }
  }
  
  public Object[] toArray()
  {
    Object[] arrayOfObject = new Object[length];
    System.arraycopy(next, 0, arrayOfObject, 0, length);
    return arrayOfObject;
  }
  
  public Object[] toArray(Object[] paramArrayOfObject)
  {
    if (paramArrayOfObject.length < length) {
      paramArrayOfObject = (Object[])Array.newInstance(paramArrayOfObject.getClass().getComponentType(), length);
    }
    for (;;)
    {
      System.arraycopy(next, 0, paramArrayOfObject, 0, length);
      if (paramArrayOfObject.length <= length) {
        break;
      }
      paramArrayOfObject[length] = null;
      return paramArrayOfObject;
    }
    return paramArrayOfObject;
  }
  
  public String toString()
  {
    if (isEmpty()) {
      return "{}";
    }
    StringBuilder localStringBuilder = new StringBuilder(length * 14);
    localStringBuilder.append('{');
    int i = 0;
    if (i < length)
    {
      if (i > 0) {
        localStringBuilder.append(", ");
      }
      Object localObject = get(i);
      if (localObject != this) {
        localStringBuilder.append(localObject);
      }
      for (;;)
      {
        i += 1;
        break;
        localStringBuilder.append("(this Set)");
      }
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}

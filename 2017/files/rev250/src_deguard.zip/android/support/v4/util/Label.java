package android.support.v4.util;

public class Label<F, S>
{
  public final F b;
  public final S c;
  
  private static boolean equals(Object paramObject1, Object paramObject2)
  {
    return (paramObject1 == paramObject2) || ((paramObject1 != null) && (paramObject1.equals(paramObject2)));
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof Label)) {
      return false;
    }
    paramObject = (Label)paramObject;
    return (equals(b, b)) && (equals(c, c));
  }
  
  public int hashCode()
  {
    int j = 0;
    int i;
    if (b == null)
    {
      i = 0;
      if (c != null) {
        break label33;
      }
    }
    for (;;)
    {
      return i ^ j;
      i = b.hashCode();
      break;
      label33:
      j = c.hashCode();
    }
  }
  
  public String toString()
  {
    return "Pair{" + String.valueOf(b) + " " + String.valueOf(c) + "}";
  }
}

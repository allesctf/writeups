package android.support.v4.util;

public class LongSparseArray<E>
  implements Cloneable
{
  private static final Object DELETED = new Object();
  private boolean mGarbage = false;
  private long[] mKeys;
  private int mSize;
  private Object[] mValues;
  
  public LongSparseArray()
  {
    this(10);
  }
  
  public LongSparseArray(int paramInt)
  {
    if (paramInt == 0) {
      mKeys = ContainerHelpers.EMPTY_LONGS;
    }
    for (mValues = ContainerHelpers.EMPTY_OBJECTS;; mValues = new Object[paramInt])
    {
      mSize = 0;
      return;
      paramInt = ContainerHelpers.idealLongArraySize(paramInt);
      mKeys = new long[paramInt];
    }
  }
  
  private void gc()
  {
    int m = mSize;
    long[] arrayOfLong = mKeys;
    Object[] arrayOfObject = mValues;
    int i = 0;
    int k;
    for (int j = 0; i < m; j = k)
    {
      Object localObject = arrayOfObject[i];
      k = j;
      if (localObject != DELETED)
      {
        if (i != j)
        {
          arrayOfLong[j] = arrayOfLong[i];
          arrayOfObject[j] = localObject;
          arrayOfObject[i] = null;
        }
        k = j + 1;
      }
      i += 1;
    }
    mGarbage = false;
    mSize = j;
  }
  
  /* Error */
  public LongSparseArray append()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 57	java/lang/Object:clone	()Ljava/lang/Object;
    //   4: astore_1
    //   5: aload_1
    //   6: checkcast 2	android/support/v4/util/LongSparseArray
    //   9: astore_1
    //   10: aload_0
    //   11: getfield 37	android/support/v4/util/LongSparseArray:mKeys	[J
    //   14: astore_2
    //   15: aload_2
    //   16: invokevirtual 57	java/lang/Object:clone	()Ljava/lang/Object;
    //   19: astore_2
    //   20: aload_1
    //   21: aload_2
    //   22: checkcast 58	[J
    //   25: putfield 37	android/support/v4/util/LongSparseArray:mKeys	[J
    //   28: aload_0
    //   29: getfield 42	android/support/v4/util/LongSparseArray:mValues	[Ljava/lang/Object;
    //   32: astore_2
    //   33: aload_2
    //   34: invokevirtual 57	java/lang/Object:clone	()Ljava/lang/Object;
    //   37: astore_2
    //   38: aload_1
    //   39: aload_2
    //   40: checkcast 59	[Ljava/lang/Object;
    //   43: putfield 42	android/support/v4/util/LongSparseArray:mValues	[Ljava/lang/Object;
    //   46: aload_1
    //   47: areturn
    //   48: astore_1
    //   49: aconst_null
    //   50: areturn
    //   51: astore_2
    //   52: aload_1
    //   53: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	54	0	this	LongSparseArray
    //   4	43	1	localObject1	Object
    //   48	5	1	localCloneNotSupportedException1	CloneNotSupportedException
    //   14	26	2	localObject2	Object
    //   51	1	2	localCloneNotSupportedException2	CloneNotSupportedException
    // Exception table:
    //   from	to	target	type
    //   0	5	48	java/lang/CloneNotSupportedException
    //   15	20	51	java/lang/CloneNotSupportedException
    //   33	38	51	java/lang/CloneNotSupportedException
  }
  
  public void clear()
  {
    int j = mSize;
    Object[] arrayOfObject = mValues;
    int i = 0;
    while (i < j)
    {
      arrayOfObject[i] = null;
      i += 1;
    }
    mSize = 0;
    mGarbage = false;
  }
  
  public void delete(long paramLong)
  {
    int i = ContainerHelpers.binarySearch(mKeys, mSize, paramLong);
    if ((i >= 0) && (mValues[i] != DELETED))
    {
      mValues[i] = DELETED;
      mGarbage = true;
    }
  }
  
  public Object get(long paramLong)
  {
    return get(paramLong, null);
  }
  
  public Object get(long paramLong, Object paramObject)
  {
    int i = ContainerHelpers.binarySearch(mKeys, mSize, paramLong);
    Object localObject = paramObject;
    if (i >= 0)
    {
      if (mValues[i] == DELETED) {
        return paramObject;
      }
      localObject = mValues[i];
    }
    return localObject;
  }
  
  public long keyAt(int paramInt)
  {
    if (mGarbage) {
      gc();
    }
    return mKeys[paramInt];
  }
  
  public void put(long paramLong, Object paramObject)
  {
    int i = ContainerHelpers.binarySearch(mKeys, mSize, paramLong);
    if (i >= 0)
    {
      mValues[i] = paramObject;
      return;
    }
    int j = i;
    if ((j < mSize) && (mValues[j] == DELETED))
    {
      mKeys[j] = paramLong;
      mValues[j] = paramObject;
      return;
    }
    i = j;
    if (mGarbage)
    {
      i = j;
      if (mSize >= mKeys.length)
      {
        gc();
        i = ContainerHelpers.binarySearch(mKeys, mSize, paramLong);
      }
    }
    if (mSize >= mKeys.length)
    {
      j = ContainerHelpers.idealLongArraySize(mSize + 1);
      long[] arrayOfLong = new long[j];
      Object[] arrayOfObject = new Object[j];
      System.arraycopy(mKeys, 0, arrayOfLong, 0, mKeys.length);
      System.arraycopy(mValues, 0, arrayOfObject, 0, mValues.length);
      mKeys = arrayOfLong;
      mValues = arrayOfObject;
    }
    if (mSize - i != 0)
    {
      System.arraycopy(mKeys, i, mKeys, i + 1, mSize - i);
      System.arraycopy(mValues, i, mValues, i + 1, mSize - i);
    }
    mKeys[i] = paramLong;
    mValues[i] = paramObject;
    mSize += 1;
  }
  
  public int size()
  {
    if (mGarbage) {
      gc();
    }
    return mSize;
  }
  
  public String toString()
  {
    if (size() <= 0) {
      return "{}";
    }
    StringBuilder localStringBuilder = new StringBuilder(mSize * 28);
    localStringBuilder.append('{');
    int i = 0;
    if (i < mSize)
    {
      if (i > 0) {
        localStringBuilder.append(", ");
      }
      localStringBuilder.append(keyAt(i));
      localStringBuilder.append('=');
      Object localObject = valueAt(i);
      if (localObject != this) {
        localStringBuilder.append(localObject);
      }
      for (;;)
      {
        i += 1;
        break;
        localStringBuilder.append("(this Map)");
      }
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
  
  public Object valueAt(int paramInt)
  {
    if (mGarbage) {
      gc();
    }
    return mValues[paramInt];
  }
}

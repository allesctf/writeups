package android.support.v4.util;

public class SimpleArrayMap<K, V>
{
  static int g;
  static int p;
  static Object[] q;
  static Object[] s;
  Object[] mArray;
  int[] mHashes;
  int mSize;
  
  public SimpleArrayMap()
  {
    mHashes = ContainerHelpers.EMPTY_INTS;
    mArray = ContainerHelpers.EMPTY_OBJECTS;
    mSize = 0;
  }
  
  public SimpleArrayMap(int paramInt)
  {
    if (paramInt == 0)
    {
      mHashes = ContainerHelpers.EMPTY_INTS;
      mArray = ContainerHelpers.EMPTY_OBJECTS;
    }
    for (;;)
    {
      mSize = 0;
      return;
      init(paramInt);
    }
  }
  
  private void init(int paramInt)
  {
    if (paramInt == 8) {}
    for (;;)
    {
      try
      {
        if (s != null)
        {
          Object[] arrayOfObject1 = s;
          mArray = arrayOfObject1;
          s = (Object[])arrayOfObject1[0];
          mHashes = ((int[])arrayOfObject1[1]);
          arrayOfObject1[1] = null;
          arrayOfObject1[0] = null;
          p -= 1;
          return;
        }
        mHashes = new int[paramInt];
        mArray = new Object[paramInt << 1];
        return;
      }
      catch (Throwable localThrowable1)
      {
        throw localThrowable1;
      }
      if (paramInt == 4) {
        try
        {
          if (q != null)
          {
            Object[] arrayOfObject2 = q;
            mArray = arrayOfObject2;
            q = (Object[])arrayOfObject2[0];
            mHashes = ((int[])arrayOfObject2[1]);
            arrayOfObject2[1] = null;
            arrayOfObject2[0] = null;
            g -= 1;
            return;
          }
        }
        catch (Throwable localThrowable2)
        {
          throw localThrowable2;
        }
      }
    }
  }
  
  private static void init(int[] paramArrayOfInt, Object[] paramArrayOfObject, int paramInt)
  {
    if (paramArrayOfInt.length == 8) {
      try
      {
        if (p < 10)
        {
          paramArrayOfObject[0] = s;
          paramArrayOfObject[1] = paramArrayOfInt;
          paramInt = (paramInt << 1) - 1;
          break label118;
          s = paramArrayOfObject;
          p += 1;
        }
        return;
      }
      catch (Throwable paramArrayOfInt)
      {
        throw paramArrayOfInt;
      }
    }
    if (paramArrayOfInt.length == 4) {}
    for (;;)
    {
      try
      {
        if (g < 10)
        {
          paramArrayOfObject[0] = q;
          paramArrayOfObject[1] = paramArrayOfInt;
          paramInt = (paramInt << 1) - 1;
          break label134;
          q = paramArrayOfObject;
          g += 1;
        }
        return;
      }
      catch (Throwable paramArrayOfInt)
      {
        throw paramArrayOfInt;
      }
      return;
      label118:
      while (paramInt >= 2)
      {
        paramArrayOfObject[paramInt] = null;
        paramInt -= 1;
      }
      break;
      label134:
      while (paramInt >= 2)
      {
        paramArrayOfObject[paramInt] = null;
        paramInt -= 1;
      }
    }
  }
  
  public void clear()
  {
    if (mSize != 0)
    {
      init(mHashes, mArray, mSize);
      mHashes = ContainerHelpers.EMPTY_INTS;
      mArray = ContainerHelpers.EMPTY_OBJECTS;
      mSize = 0;
    }
  }
  
  public boolean containsKey(Object paramObject)
  {
    return indexOfKey(paramObject) >= 0;
  }
  
  public boolean containsValue(Object paramObject)
  {
    return indexOfValue(paramObject) >= 0;
  }
  
  /* Error */
  public boolean equals(Object paramObject)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: if_acmpne +5 -> 7
    //   5: iconst_1
    //   6: ireturn
    //   7: aload_1
    //   8: instanceof 2
    //   11: ifeq +109 -> 120
    //   14: aload_1
    //   15: checkcast 2	android/support/v4/util/SimpleArrayMap
    //   18: astore_1
    //   19: aload_0
    //   20: invokevirtual 75	android/support/v4/util/SimpleArrayMap:size	()I
    //   23: aload_1
    //   24: invokevirtual 75	android/support/v4/util/SimpleArrayMap:size	()I
    //   27: if_icmpeq +5 -> 32
    //   30: iconst_0
    //   31: ireturn
    //   32: iconst_0
    //   33: istore_2
    //   34: aload_0
    //   35: getfield 33	android/support/v4/util/SimpleArrayMap:mSize	I
    //   38: istore_3
    //   39: iload_2
    //   40: iload_3
    //   41: if_icmpge +198 -> 239
    //   44: aload_0
    //   45: iload_2
    //   46: invokevirtual 79	android/support/v4/util/SimpleArrayMap:get	(I)Ljava/lang/Object;
    //   49: astore 5
    //   51: aload_0
    //   52: iload_2
    //   53: invokevirtual 82	android/support/v4/util/SimpleArrayMap:valueAt	(I)Ljava/lang/Object;
    //   56: astore 6
    //   58: aload_1
    //   59: aload 5
    //   61: invokevirtual 85	android/support/v4/util/SimpleArrayMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   64: astore 7
    //   66: aload 6
    //   68: ifnonnull +23 -> 91
    //   71: aload 7
    //   73: ifnonnull +16 -> 89
    //   76: aload_1
    //   77: aload 5
    //   79: invokevirtual 87	android/support/v4/util/SimpleArrayMap:containsKey	(Ljava/lang/Object;)Z
    //   82: istore 4
    //   84: iload 4
    //   86: ifne +21 -> 107
    //   89: iconst_0
    //   90: ireturn
    //   91: aload 6
    //   93: aload 7
    //   95: invokevirtual 89	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   98: istore 4
    //   100: iload 4
    //   102: ifne +5 -> 107
    //   105: iconst_0
    //   106: ireturn
    //   107: iload_2
    //   108: iconst_1
    //   109: iadd
    //   110: istore_2
    //   111: goto -77 -> 34
    //   114: astore_1
    //   115: iconst_0
    //   116: ireturn
    //   117: astore_1
    //   118: iconst_0
    //   119: ireturn
    //   120: aload_1
    //   121: instanceof 91
    //   124: ifeq +113 -> 237
    //   127: aload_1
    //   128: checkcast 91	java/util/Map
    //   131: astore_1
    //   132: aload_0
    //   133: invokevirtual 75	android/support/v4/util/SimpleArrayMap:size	()I
    //   136: aload_1
    //   137: invokeinterface 92 1 0
    //   142: if_icmpeq +5 -> 147
    //   145: iconst_0
    //   146: ireturn
    //   147: iconst_0
    //   148: istore_2
    //   149: aload_0
    //   150: getfield 33	android/support/v4/util/SimpleArrayMap:mSize	I
    //   153: istore_3
    //   154: iload_2
    //   155: iload_3
    //   156: if_icmpge +83 -> 239
    //   159: aload_0
    //   160: iload_2
    //   161: invokevirtual 79	android/support/v4/util/SimpleArrayMap:get	(I)Ljava/lang/Object;
    //   164: astore 5
    //   166: aload_0
    //   167: iload_2
    //   168: invokevirtual 82	android/support/v4/util/SimpleArrayMap:valueAt	(I)Ljava/lang/Object;
    //   171: astore 6
    //   173: aload_1
    //   174: aload 5
    //   176: invokeinterface 93 2 0
    //   181: astore 7
    //   183: aload 6
    //   185: ifnonnull +25 -> 210
    //   188: aload 7
    //   190: ifnonnull +18 -> 208
    //   193: aload_1
    //   194: aload 5
    //   196: invokeinterface 94 2 0
    //   201: istore 4
    //   203: iload 4
    //   205: ifne +21 -> 226
    //   208: iconst_0
    //   209: ireturn
    //   210: aload 6
    //   212: aload 7
    //   214: invokevirtual 89	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   217: istore 4
    //   219: iload 4
    //   221: ifne +5 -> 226
    //   224: iconst_0
    //   225: ireturn
    //   226: iload_2
    //   227: iconst_1
    //   228: iadd
    //   229: istore_2
    //   230: goto -81 -> 149
    //   233: astore_1
    //   234: iconst_0
    //   235: ireturn
    //   236: astore_1
    //   237: iconst_0
    //   238: ireturn
    //   239: iconst_1
    //   240: ireturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	241	0	this	SimpleArrayMap
    //   0	241	1	paramObject	Object
    //   33	197	2	i	int
    //   38	119	3	j	int
    //   82	138	4	bool	boolean
    //   49	146	5	localObject1	Object
    //   56	155	6	localObject2	Object
    //   64	149	7	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   34	39	114	java/lang/NullPointerException
    //   44	66	114	java/lang/NullPointerException
    //   76	84	114	java/lang/NullPointerException
    //   91	100	114	java/lang/NullPointerException
    //   44	66	117	java/lang/ClassCastException
    //   76	84	117	java/lang/ClassCastException
    //   91	100	117	java/lang/ClassCastException
    //   149	154	233	java/lang/NullPointerException
    //   159	183	233	java/lang/NullPointerException
    //   193	203	233	java/lang/NullPointerException
    //   210	219	233	java/lang/NullPointerException
    //   159	183	236	java/lang/ClassCastException
    //   193	203	236	java/lang/ClassCastException
    //   210	219	236	java/lang/ClassCastException
  }
  
  public Object get(int paramInt)
  {
    return mArray[(paramInt << 1)];
  }
  
  public Object get(Object paramObject)
  {
    int i = indexOfKey(paramObject);
    if (i >= 0) {
      return mArray[((i << 1) + 1)];
    }
    return null;
  }
  
  public int hashCode()
  {
    int[] arrayOfInt = mHashes;
    Object[] arrayOfObject = mArray;
    int n = mSize;
    int i = 1;
    int j = 0;
    int k = 0;
    if (j < n)
    {
      Object localObject = arrayOfObject[i];
      int i1 = arrayOfInt[j];
      if (localObject == null) {}
      for (int m = 0;; m = localObject.hashCode())
      {
        k += (m ^ i1);
        j += 1;
        i += 2;
        break;
      }
    }
    return k;
  }
  
  int indexOf(Object paramObject, int paramInt)
  {
    int j = mSize;
    if (j == 0) {
      return -1;
    }
    int k = ContainerHelpers.binarySearch(mHashes, j, paramInt);
    if ((k >= 0) && (!paramObject.equals(mArray[(k << 1)])))
    {
      int i = k + 1;
      while ((i < j) && (mHashes[i] == paramInt))
      {
        if (paramObject.equals(mArray[(i << 1)])) {
          return i;
        }
        i += 1;
      }
      j = k - 1;
      while ((j >= 0) && (mHashes[j] == paramInt))
      {
        if (paramObject.equals(mArray[(j << 1)])) {
          break label143;
        }
        j -= 1;
      }
      return i;
    }
    return k;
    label143:
    return j;
  }
  
  public int indexOfKey(Object paramObject)
  {
    if (paramObject == null) {
      return indexOfNull();
    }
    return indexOf(paramObject, paramObject.hashCode());
  }
  
  int indexOfNull()
  {
    int m = mSize;
    if (m == 0) {
      return -1;
    }
    int i = ContainerHelpers.binarySearch(mHashes, m, 0);
    int k = i;
    if (i >= 0)
    {
      k = i;
      if (mArray[(i << 1)] != null)
      {
        int j = i + 1;
        while ((j < m) && (mHashes[j] == 0))
        {
          if (mArray[(j << 1)] == null) {
            return j;
          }
          j += 1;
        }
        i -= 1;
        while ((i >= 0) && (mHashes[i] == 0))
        {
          k = i;
          if (mArray[(i << 1)] == null) {
            return k;
          }
          i -= 1;
        }
        return j;
      }
    }
    return k;
  }
  
  int indexOfValue(Object paramObject)
  {
    int i = 1;
    int j = 1;
    int k = mSize * 2;
    Object[] arrayOfObject = mArray;
    if (paramObject == null)
    {
      i = j;
      while (i < k)
      {
        if (arrayOfObject[i] == null) {
          return i >> 1;
        }
        i += 2;
      }
    }
    do
    {
      i += 2;
      if (i >= k) {
        break;
      }
    } while (!paramObject.equals(arrayOfObject[i]));
    return i >> 1;
    return -1;
  }
  
  public boolean isEmpty()
  {
    return mSize <= 0;
  }
  
  public Object put(Object paramObject1, Object paramObject2)
  {
    int k = 8;
    int i;
    int j;
    if (paramObject1 == null)
    {
      i = indexOfNull();
      j = 0;
    }
    while (i >= 0)
    {
      i = (i << 1) + 1;
      paramObject1 = mArray[i];
      mArray[i] = paramObject2;
      return paramObject1;
      i = paramObject1.hashCode();
      j = i;
      i = indexOf(paramObject1, i);
    }
    int m = i;
    if (mSize >= mHashes.length)
    {
      if (mSize < 8) {
        break label266;
      }
      i = mSize + (mSize >> 1);
    }
    for (;;)
    {
      int[] arrayOfInt = mHashes;
      Object[] arrayOfObject = mArray;
      init(i);
      if (mHashes.length > 0)
      {
        System.arraycopy(arrayOfInt, 0, mHashes, 0, arrayOfInt.length);
        System.arraycopy(arrayOfObject, 0, mArray, 0, arrayOfObject.length);
      }
      init(arrayOfInt, arrayOfObject, mSize);
      if (m < mSize)
      {
        System.arraycopy(mHashes, m, mHashes, m + 1, mSize - m);
        System.arraycopy(mArray, m << 1, mArray, m + 1 << 1, mSize - m << 1);
      }
      mHashes[m] = j;
      mArray[(m << 1)] = paramObject1;
      mArray[((m << 1) + 1)] = paramObject2;
      mSize += 1;
      return null;
      label266:
      i = k;
      if (mSize < 4) {
        i = 4;
      }
    }
  }
  
  public void put(int paramInt)
  {
    if (mHashes.length < paramInt)
    {
      int[] arrayOfInt = mHashes;
      Object[] arrayOfObject = mArray;
      init(paramInt);
      if (mSize > 0)
      {
        System.arraycopy(arrayOfInt, 0, mHashes, 0, mSize);
        System.arraycopy(arrayOfObject, 0, mArray, 0, mSize << 1);
      }
      init(arrayOfInt, arrayOfObject, mSize);
    }
  }
  
  public Object remove(Object paramObject)
  {
    int i = indexOfKey(paramObject);
    if (i >= 0) {
      return removeAt(i);
    }
    return null;
  }
  
  public Object removeAt(int paramInt)
  {
    int i = 8;
    Object localObject = mArray[((paramInt << 1) + 1)];
    if (mSize <= 1)
    {
      init(mHashes, mArray, mSize);
      mHashes = ContainerHelpers.EMPTY_INTS;
      mArray = ContainerHelpers.EMPTY_OBJECTS;
      mSize = 0;
      return localObject;
    }
    if ((mHashes.length > 8) && (mSize < mHashes.length / 3))
    {
      if (mSize > 8) {
        i = mSize + (mSize >> 1);
      }
      int[] arrayOfInt = mHashes;
      Object[] arrayOfObject = mArray;
      init(i);
      mSize -= 1;
      if (paramInt > 0)
      {
        System.arraycopy(arrayOfInt, 0, mHashes, 0, paramInt);
        System.arraycopy(arrayOfObject, 0, mArray, 0, paramInt << 1);
      }
      if (paramInt < mSize)
      {
        System.arraycopy(arrayOfInt, paramInt + 1, mHashes, paramInt, mSize - paramInt);
        System.arraycopy(arrayOfObject, paramInt + 1 << 1, mArray, paramInt << 1, mSize - paramInt << 1);
        return localObject;
      }
    }
    else
    {
      mSize -= 1;
      if (paramInt < mSize)
      {
        System.arraycopy(mHashes, paramInt + 1, mHashes, paramInt, mSize - paramInt);
        System.arraycopy(mArray, paramInt + 1 << 1, mArray, paramInt << 1, mSize - paramInt << 1);
      }
      mArray[(mSize << 1)] = null;
      mArray[((mSize << 1) + 1)] = null;
    }
    return localObject;
  }
  
  public Object setValueAt(int paramInt, Object paramObject)
  {
    paramInt = (paramInt << 1) + 1;
    Object localObject = mArray[paramInt];
    mArray[paramInt] = paramObject;
    return localObject;
  }
  
  public int size()
  {
    return mSize;
  }
  
  public String toString()
  {
    if (isEmpty()) {
      return "{}";
    }
    StringBuilder localStringBuilder = new StringBuilder(mSize * 28);
    localStringBuilder.append('{');
    int i = 0;
    if (i < mSize)
    {
      if (i > 0) {
        localStringBuilder.append(", ");
      }
      Object localObject = get(i);
      if (localObject != this)
      {
        localStringBuilder.append(localObject);
        label70:
        localStringBuilder.append('=');
        localObject = valueAt(i);
        if (localObject == this) {
          break label111;
        }
        localStringBuilder.append(localObject);
      }
      for (;;)
      {
        i += 1;
        break;
        localStringBuilder.append("(this Map)");
        break label70;
        label111:
        localStringBuilder.append("(this Map)");
      }
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
  
  public Object valueAt(int paramInt)
  {
    return mArray[((paramInt << 1) + 1)];
  }
}

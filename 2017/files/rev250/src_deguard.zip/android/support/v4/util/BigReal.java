package android.support.v4.util;

import android.support.v4.f.h;
import java.util.Map;

class BigReal
  extends h<E, E>
{
  BigReal(TLongArrayList paramTLongArrayList) {}
  
  protected void add(Object paramObject1, Object paramObject2)
  {
    this$0.add(paramObject1);
  }
  
  protected void colClear()
  {
    this$0.clear();
  }
  
  protected Object colGetEntry(int paramInt1, int paramInt2)
  {
    return this$0.next[paramInt1];
  }
  
  protected Map colGetMap()
  {
    throw new UnsupportedOperationException("not a map");
  }
  
  protected int colGetSize()
  {
    return this$0.length;
  }
  
  protected int colIndexOfKey(Object paramObject)
  {
    return this$0.indexOf(paramObject);
  }
  
  protected int colIndexOfValue(Object paramObject)
  {
    return this$0.indexOf(paramObject);
  }
  
  protected void colRemoveAt(int paramInt)
  {
    this$0.set(paramInt);
  }
  
  protected Object colSetValue(int paramInt, Object paramObject)
  {
    throw new UnsupportedOperationException("not a map");
  }
}

package android.support.v4.view.accessibility;

class ad
  extends e
{
  ad() {}
  
  public void c(Object paramObject, int paramInt)
  {
    AccessibilityRecordCompat.AccessibilityRecordImpl.setMaxScrollY(paramObject, paramInt);
  }
  
  public void d(Object paramObject, int paramInt)
  {
    AccessibilityRecordCompat.AccessibilityRecordImpl.setMaxScrollX(paramObject, paramInt);
  }
}

package android.support.v4.view;

import android.annotation.TargetApi;
import android.view.View;

@TargetApi(26)
class Message
  extends Packet
{
  Message() {}
  
  public void setScrollIndicators(View paramView, CharSequence paramCharSequence)
  {
    paramView.setTooltipText(paramCharSequence);
  }
}

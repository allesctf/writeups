package android.support.v4.view.accessibility;

class f
  implements g
{
  f() {}
  
  public void a(Object paramObject, int paramInt) {}
  
  public void a(Object paramObject, boolean paramBoolean) {}
  
  public void b(Object paramObject, int paramInt) {}
  
  public void c(Object paramObject, int paramInt) {}
  
  public void d(Object paramObject, int paramInt) {}
}

package android.support.v4.view.accessibility;

import android.annotation.TargetApi;

@TargetApi(22)
class Binder
  extends AccessibilityNodeInfoCompat.AccessibilityNodeInfoApi21Impl
{
  Binder() {}
}

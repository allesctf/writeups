package android.support.v4.view.accessibility;

class NewLine
  extends FormatedText
{
  NewLine() {}
}

package android.support.v4.view;

import android.os.Build.VERSION;

public final class GravityCompat
{
  static final GravityCompatImpl IMPL = new GravityCompatImplBase();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 17)
    {
      IMPL = new GravityCompatImplJellybeanMr1();
      return;
    }
  }
  
  public static int getAbsoluteGravity(int paramInt1, int paramInt2)
  {
    return IMPL.getAbsoluteGravity(paramInt1, paramInt2);
  }
  
  abstract interface GravityCompatImpl
  {
    public abstract int getAbsoluteGravity(int paramInt1, int paramInt2);
  }
  
  class GravityCompatImplBase
    implements GravityCompat.GravityCompatImpl
  {
    GravityCompatImplBase() {}
    
    public int getAbsoluteGravity(int paramInt1, int paramInt2)
    {
      return 0xFF7FFFFF & paramInt1;
    }
  }
  
  class GravityCompatImplJellybeanMr1
    implements GravityCompat.GravityCompatImpl
  {
    GravityCompatImplJellybeanMr1() {}
    
    public int getAbsoluteGravity(int paramInt1, int paramInt2)
    {
      return GravityCompatJellybeanMr1.getAbsoluteGravity(paramInt1, paramInt2);
    }
  }
}

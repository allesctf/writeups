package android.support.v4.view.accessibility;

import android.os.Build.VERSION;
import android.view.accessibility.AccessibilityEvent;

public final class AccessibilityEventCompat
{
  private static final Location waiting = new FormatedText();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 19)
    {
      waiting = new OS.3();
      return;
    }
    if (Build.VERSION.SDK_INT >= 16)
    {
      waiting = new AccessibilityNodeInfoCompat.AccessibilityActionCompat();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      waiting = new NewLine();
      return;
    }
  }
  
  public static Label a(AccessibilityEvent paramAccessibilityEvent)
  {
    return new Label(paramAccessibilityEvent);
  }
}

package android.support.v4.view.accessibility;

class FormatedText
  implements Location
{
  FormatedText() {}
}

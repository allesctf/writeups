package android.support.v4.view.accessibility;

class e
  extends f
{
  e() {}
  
  public void a(Object paramObject, int paramInt)
  {
    AccessibilityRecordCompatIcs.setScrollX(paramObject, paramInt);
  }
  
  public void a(Object paramObject, boolean paramBoolean)
  {
    AccessibilityRecordCompatIcs.setScrollable(paramObject, paramBoolean);
  }
  
  public void b(Object paramObject, int paramInt)
  {
    AccessibilityRecordCompatIcs.setScrollY(paramObject, paramInt);
  }
}

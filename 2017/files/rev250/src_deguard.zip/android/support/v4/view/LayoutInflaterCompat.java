package android.support.v4.view;

import android.os.Build.VERSION;
import android.util.Log;
import android.view.LayoutInflater.Factory2;
import java.lang.reflect.Field;

public final class LayoutInflaterCompat
{
  static final LayoutInflater IMPL = new LayoutInflater();
  private static boolean sCheckedField;
  private static Field sLayoutInflaterFactory2Field;
  
  static
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      IMPL = new LayoutInflaterCompatImplV21();
      return;
    }
  }
  
  static void forceSetFactory2(android.view.LayoutInflater paramLayoutInflater, LayoutInflater.Factory2 paramFactory2)
  {
    if (!sCheckedField) {}
    try
    {
      localField = android.view.LayoutInflater.class.getDeclaredField("mFactory2");
      sLayoutInflaterFactory2Field = localField;
      localField = sLayoutInflaterFactory2Field;
      localField.setAccessible(true);
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      for (;;)
      {
        try
        {
          Field localField;
          localField.set(paramLayoutInflater, paramFactory2);
          return;
        }
        catch (IllegalAccessException paramFactory2)
        {
          Log.e("LayoutInflaterCompatHC", "forceSetFactory2 could not set the Factory2 on LayoutInflater " + paramLayoutInflater + "; inflation may have unexpected results.", paramFactory2);
        }
        localNoSuchFieldException = localNoSuchFieldException;
        Log.e("LayoutInflaterCompatHC", "forceSetFactory2 Could not find field 'mFactory2' on class " + android.view.LayoutInflater.class.getName() + "; inflation may have unexpected results.", localNoSuchFieldException);
      }
    }
    sCheckedField = true;
    if (sLayoutInflaterFactory2Field != null) {
      localField = sLayoutInflaterFactory2Field;
    }
  }
  
  public static void setFactory(android.view.LayoutInflater paramLayoutInflater, LayoutInflater.Factory2 paramFactory2)
  {
    IMPL.setFactory(paramLayoutInflater, paramFactory2);
  }
  
  class LayoutInflaterCompatImplV21
    extends LayoutInflater
  {
    LayoutInflaterCompatImplV21() {}
    
    public void setFactory(android.view.LayoutInflater paramLayoutInflater, LayoutInflater.Factory2 paramFactory2)
    {
      paramLayoutInflater.setFactory2(paramFactory2);
    }
  }
}

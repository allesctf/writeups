package android.support.v4.view;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.g.a;
import android.support.v4.os.ParcelableCompat;

public abstract class Item
  implements Parcelable
{
  public static final Parcelable.Creator<a> CREATOR = ParcelableCompat.newCreator(new AppCompatDelegateImplV7.PanelFeatureState.SavedState.1());
  public static final Item g = new Track();
  private final Parcelable a;
  
  private Item()
  {
    a = null;
  }
  
  protected Item(Parcel paramParcel, ClassLoader paramClassLoader)
  {
    paramClassLoader = paramParcel.readParcelable(paramClassLoader);
    paramParcel = paramClassLoader;
    if (paramClassLoader != null) {}
    for (;;)
    {
      a = paramParcel;
      return;
      paramParcel = g;
    }
  }
  
  protected Item(Parcelable paramParcelable)
  {
    if (paramParcelable == null) {
      throw new IllegalArgumentException("superState must not be null");
    }
    if (paramParcelable != g) {}
    for (;;)
    {
      a = paramParcelable;
      return;
      paramParcelable = null;
    }
  }
  
  public final Parcelable a()
  {
    return a;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeParcelable(a, paramInt);
  }
}

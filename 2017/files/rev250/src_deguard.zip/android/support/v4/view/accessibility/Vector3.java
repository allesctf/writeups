package android.support.v4.view.accessibility;

class Vector3
  extends b
{
  Vector3() {}
  
  public Object b(AccessibilityNodeProviderCompat paramAccessibilityNodeProviderCompat)
  {
    return ClassReader.b(new g.b.1(this, paramAccessibilityNodeProviderCompat));
  }
}

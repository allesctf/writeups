package android.support.v4.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Handler;
import android.support.v4.view.accessibility.AccessibilityManagerCompat;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnHoverListener;
import android.view.View.OnLongClickListener;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import android.widget.Toast;

class Snackbar
  implements View.OnHoverListener, View.OnLongClickListener
{
  private final CharSequence mContext;
  private final Runnable mRunnable = new q.a.1(this);
  private Toast mToast;
  private final View this$0;
  
  Snackbar(View paramView, CharSequence paramCharSequence)
  {
    this$0 = paramView;
    mContext = paramCharSequence;
    this$0.setOnLongClickListener(this);
    this$0.setOnHoverListener(this);
  }
  
  private void show()
  {
    if (mToast != null)
    {
      mToast.cancel();
      mToast = null;
    }
    this$0.getHandler().removeCallbacks(mRunnable);
  }
  
  private void show(int paramInt)
  {
    Context localContext = this$0.getContext();
    Object localObject = localContext.getResources();
    int k = getDisplayMetricswidthPixels;
    int j = getDisplayMetricsheightPixels;
    Rect localRect = new Rect();
    this$0.getWindowVisibleDisplayFrame(localRect);
    int i;
    if ((left < 0) && (top < 0))
    {
      i = ((Resources)localObject).getIdentifier("status_bar_height", "dimen", "android");
      if (i > 0)
      {
        i = ((Resources)localObject).getDimensionPixelSize(i);
        localRect.set(0, i, k, j);
      }
    }
    else
    {
      localObject = new int[2];
      this$0.getLocationOnScreen((int[])localObject);
      j = localObject[0] + this$0.getWidth() / 2;
      i = j;
      if (ViewCompat.getLayoutDirection(this$0) == 0) {
        i = k - j;
      }
      j = localObject[1];
      show();
      mToast = Toast.makeText(localContext, mContext, paramInt);
      if (j >= localRect.height() * 0.8D) {
        break label225;
      }
      mToast.setGravity(8388661, i, j + this$0.getHeight() - top);
    }
    for (;;)
    {
      mToast.show();
      return;
      i = 0;
      break;
      label225:
      mToast.setGravity(8388693, i, bottom - j);
    }
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent)
  {
    paramView = (AccessibilityManager)this$0.getContext().getSystemService("accessibility");
    if ((paramView.isEnabled()) && (AccessibilityManagerCompat.isTouchExplorationEnabled(paramView))) {
      return false;
    }
    int i = paramMotionEvent.getAction();
    if (i == 7)
    {
      show();
      this$0.getHandler().postDelayed(mRunnable, ViewConfiguration.getLongPressTimeout());
      return false;
    }
    if (i == 10) {
      show();
    }
    return false;
  }
  
  public boolean onLongClick(View paramView)
  {
    show(0);
    return true;
  }
}

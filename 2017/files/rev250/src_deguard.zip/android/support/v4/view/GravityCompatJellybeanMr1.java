package android.support.v4.view;

import android.view.Gravity;

class GravityCompatJellybeanMr1
{
  public static int getAbsoluteGravity(int paramInt1, int paramInt2)
  {
    return Gravity.getAbsoluteGravity(paramInt1, paramInt2);
  }
}

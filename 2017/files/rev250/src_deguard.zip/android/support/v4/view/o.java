package android.support.v4.view;

import android.annotation.TargetApi;
import android.view.MenuItem;

@TargetApi(26)
class o
  extends e
{
  o() {}
  
  public void a(MenuItem paramMenuItem, CharSequence paramCharSequence)
  {
    paramMenuItem.setContentDescription(paramCharSequence);
  }
  
  public void b(MenuItem paramMenuItem, CharSequence paramCharSequence)
  {
    paramMenuItem.setTooltipText(paramCharSequence);
  }
}

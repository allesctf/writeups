package android.support.v4.view.accessibility;

class Configurator
  extends b
{
  Configurator() {}
  
  public Object b(AccessibilityNodeProviderCompat paramAccessibilityNodeProviderCompat)
  {
    return AccessibilityNodeProviderCompat.AccessibilityNodeProviderImpl.newAccessibilityNodeProviderBridge(new g.c.1(this, paramAccessibilityNodeProviderCompat));
  }
}

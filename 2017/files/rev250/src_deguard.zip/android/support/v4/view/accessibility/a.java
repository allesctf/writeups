package android.support.v4.view.accessibility;

abstract interface a
{
  public abstract Object b(AccessibilityNodeProviderCompat paramAccessibilityNodeProviderCompat);
}

package android.support.v4.view;

import android.view.WindowInsets;

class d
{
  public static int a(Object paramObject)
  {
    return ((WindowInsets)paramObject).getSystemWindowInsetLeft();
  }
  
  public static Object a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return ((WindowInsets)paramObject).replaceSystemWindowInsets(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static int d(Object paramObject)
  {
    return ((WindowInsets)paramObject).getSystemWindowInsetRight();
  }
  
  public static int dispatchChildInsets(Object paramObject)
  {
    return ((WindowInsets)paramObject).getSystemWindowInsetBottom();
  }
  
  public static int getTopInset(Object paramObject)
  {
    return ((WindowInsets)paramObject).getSystemWindowInsetTop();
  }
}

package android.support.v4.view;

import android.annotation.TargetApi;

@TargetApi(24)
class Packet
  extends ViewCompat.MarshmallowViewCompatImpl
{
  Packet() {}
}

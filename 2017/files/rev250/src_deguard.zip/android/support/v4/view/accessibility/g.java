package android.support.v4.view.accessibility;

abstract interface g
{
  public abstract void a(Object paramObject, int paramInt);
  
  public abstract void a(Object paramObject, boolean paramBoolean);
  
  public abstract void b(Object paramObject, int paramInt);
  
  public abstract void c(Object paramObject, int paramInt);
  
  public abstract void d(Object paramObject, int paramInt);
}

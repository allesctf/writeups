package android.support.v4.view;

import android.view.MenuItem;

class e
  implements i
{
  e() {}
  
  public void a(MenuItem paramMenuItem, CharSequence paramCharSequence) {}
  
  public void b(MenuItem paramMenuItem, CharSequence paramCharSequence) {}
}

package android.support.v4.view;

import android.support.v4.media.routing.SupportMenuItem;
import android.support.v4.os.Handler;
import android.util.Log;
import android.view.MenuItem;

public final class h
{
  static final i l = new e();
  
  static
  {
    if (Handler.getType())
    {
      l = new o();
      return;
    }
  }
  
  public static void a(MenuItem paramMenuItem, CharSequence paramCharSequence)
  {
    if ((paramMenuItem instanceof SupportMenuItem))
    {
      ((SupportMenuItem)paramMenuItem).setIcon(paramCharSequence);
      return;
    }
    l.a(paramMenuItem, paramCharSequence);
  }
  
  public static MenuItem setActionProvider(MenuItem paramMenuItem, ActionProvider paramActionProvider)
  {
    if ((paramMenuItem instanceof SupportMenuItem)) {
      return ((SupportMenuItem)paramMenuItem).setSupportActionProvider(paramActionProvider);
    }
    Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
    return paramMenuItem;
  }
  
  public static void setShowAsAction(MenuItem paramMenuItem, CharSequence paramCharSequence)
  {
    if ((paramMenuItem instanceof SupportMenuItem))
    {
      ((SupportMenuItem)paramMenuItem).setShortcut(paramCharSequence);
      return;
    }
    l.b(paramMenuItem, paramCharSequence);
  }
}

package android.support.v4.view.accessibility;

import android.os.Build.VERSION;

public class Label
{
  private static final g d = new f();
  private final Object a;
  
  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      d = new Daemon.17();
      return;
    }
    if (Build.VERSION.SDK_INT >= 15)
    {
      d = new ad();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      d = new e();
      return;
    }
  }
  
  public Label(Object paramObject)
  {
    a = paramObject;
  }
  
  public void a(int paramInt)
  {
    d.d(a, paramInt);
  }
  
  public void b(int paramInt)
  {
    d.c(a, paramInt);
  }
  
  public void b(boolean paramBoolean)
  {
    d.a(a, paramBoolean);
  }
  
  public void c(int paramInt)
  {
    d.b(a, paramInt);
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (paramObject == null) {
      return false;
    }
    if (getClass() != paramObject.getClass()) {
      return false;
    }
    paramObject = (Label)paramObject;
    if (a == null)
    {
      if (a != null) {
        return false;
      }
    }
    else if (!a.equals(a)) {
      return false;
    }
    return true;
  }
  
  public void getCount(int paramInt)
  {
    d.a(a, paramInt);
  }
  
  public int hashCode()
  {
    if (a == null) {
      return 0;
    }
    return a.hashCode();
  }
}

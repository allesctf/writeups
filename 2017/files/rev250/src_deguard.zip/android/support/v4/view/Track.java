package android.support.v4.view;

final class Track
  extends Item
{
  Track()
  {
    super(null);
  }
}

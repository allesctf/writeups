package android.support.v4.view;

import android.view.LayoutInflater.Factory;
import android.view.LayoutInflater.Factory2;

class LayoutInflater
{
  LayoutInflater() {}
  
  public void setFactory(android.view.LayoutInflater paramLayoutInflater, LayoutInflater.Factory2 paramFactory2)
  {
    paramLayoutInflater.setFactory2(paramFactory2);
    LayoutInflater.Factory localFactory = paramLayoutInflater.getFactory();
    if ((localFactory instanceof LayoutInflater.Factory2))
    {
      LayoutInflaterCompat.forceSetFactory2(paramLayoutInflater, (LayoutInflater.Factory2)localFactory);
      return;
    }
    LayoutInflaterCompat.forceSetFactory2(paramLayoutInflater, paramFactory2);
  }
}

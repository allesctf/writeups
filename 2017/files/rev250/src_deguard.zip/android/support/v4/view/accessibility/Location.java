package android.support.v4.view.accessibility;

abstract interface Location {}

package android.support.v4.view;

import android.view.View;
import android.view.ViewPropertyAnimator;

class ViewPropertyAnimatorCompatKK
{
  public static void setUpdateListener(View paramView, ViewPropertyAnimatorUpdateListener paramViewPropertyAnimatorUpdateListener)
  {
    HoneycombMr1AnimatorCompatProvider.HoneycombValueAnimatorCompat.1 local1 = null;
    if (paramViewPropertyAnimatorUpdateListener != null) {
      local1 = new HoneycombMr1AnimatorCompatProvider.HoneycombValueAnimatorCompat.1(paramViewPropertyAnimatorUpdateListener, paramView);
    }
    paramView.animate().setUpdateListener(local1);
  }
}

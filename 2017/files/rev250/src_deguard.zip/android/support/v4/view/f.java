package android.support.v4.view;

import android.os.Build.VERSION;

public class f
{
  private static final ab.d d = new ab.c();
  private final Object a;
  
  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 21)
    {
      d = new ab.b();
      return;
    }
    if (i >= 20)
    {
      d = new ab.a();
      return;
    }
  }
  
  f(Object paramObject)
  {
    a = paramObject;
  }
  
  static Object a(f paramF)
  {
    if (paramF == null) {
      return null;
    }
    return a;
  }
  
  static f f(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    return new f(paramObject);
  }
  
  public int a()
  {
    return d.b(a);
  }
  
  public f a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return d.a(a, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public int b()
  {
    return d.c(a);
  }
  
  public int c()
  {
    return d.a(a);
  }
  
  public int d()
  {
    return d.d(a);
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if ((paramObject == null) || (getClass() != paramObject.getClass())) {
      return false;
    }
    paramObject = (f)paramObject;
    if (a == null)
    {
      if (a != null) {
        return false;
      }
    }
    else {
      return a.equals(a);
    }
    return true;
  }
  
  public int hashCode()
  {
    if (a == null) {
      return 0;
    }
    return a.hashCode();
  }
}

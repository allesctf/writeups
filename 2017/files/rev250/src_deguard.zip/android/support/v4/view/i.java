package android.support.v4.view;

import android.view.MenuItem;

abstract interface i
{
  public abstract void a(MenuItem paramMenuItem, CharSequence paramCharSequence);
  
  public abstract void b(MenuItem paramMenuItem, CharSequence paramCharSequence);
}

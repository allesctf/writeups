package android.support.v4.view.accessibility;

class b
  implements a
{
  b() {}
  
  public Object b(AccessibilityNodeProviderCompat paramAccessibilityNodeProviderCompat)
  {
    return null;
  }
}

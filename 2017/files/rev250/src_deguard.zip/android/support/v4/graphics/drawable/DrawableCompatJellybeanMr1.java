package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;
import android.util.Log;
import java.lang.reflect.Method;

class DrawableCompatJellybeanMr1
  extends DrawableCompat.DrawableImpl
{
  private static Method sSetLayoutDirectionMethod;
  private static boolean sSetLayoutDirectionMethodFetched;
  
  DrawableCompatJellybeanMr1() {}
  
  public boolean setLayoutDirection(Drawable paramDrawable, int paramInt)
  {
    Object localObject;
    if (!sSetLayoutDirectionMethodFetched) {
      localObject = Integer.TYPE;
    }
    try
    {
      localObject = Drawable.class.getDeclaredMethod("setLayoutDirection", new Class[] { localObject });
      sSetLayoutDirectionMethod = (Method)localObject;
      localObject = sSetLayoutDirectionMethod;
      ((Method)localObject).setAccessible(true);
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      for (;;)
      {
        try
        {
          ((Method)localObject).invoke(paramDrawable, new Object[] { Integer.valueOf(paramInt) });
          return true;
        }
        catch (Exception paramDrawable)
        {
          Log.i("DrawableCompatApi17", "Failed to invoke setLayoutDirection(int) via reflection", paramDrawable);
          sSetLayoutDirectionMethod = null;
        }
        localNoSuchMethodException = localNoSuchMethodException;
        Log.i("DrawableCompatApi17", "Failed to retrieve setLayoutDirection(int) method", localNoSuchMethodException);
      }
    }
    sSetLayoutDirectionMethodFetched = true;
    if (sSetLayoutDirectionMethod != null) {
      localObject = sSetLayoutDirectionMethod;
    }
    return false;
  }
}

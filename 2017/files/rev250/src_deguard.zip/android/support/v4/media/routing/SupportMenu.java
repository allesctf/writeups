package android.support.v4.media.routing;

import android.view.Menu;

public abstract interface SupportMenu
  extends Menu
{}

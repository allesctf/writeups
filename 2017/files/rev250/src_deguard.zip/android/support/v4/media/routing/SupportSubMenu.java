package android.support.v4.media.routing;

import android.view.SubMenu;

public abstract interface SupportSubMenu
  extends SupportMenu, SubMenu
{}

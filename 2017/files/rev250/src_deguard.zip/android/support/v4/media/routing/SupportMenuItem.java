package android.support.v4.media.routing;

import android.support.v4.view.ActionProvider;
import android.view.MenuItem;
import android.view.MenuItem.OnActionExpandListener;
import android.view.View;

public abstract interface SupportMenuItem
  extends MenuItem
{
  public abstract boolean collapseActionView();
  
  public abstract boolean expandActionView();
  
  public abstract View getActionView();
  
  public abstract CharSequence getContentDescription();
  
  public abstract ActionProvider getSupportActionProvider();
  
  public abstract CharSequence getTooltipText();
  
  public abstract boolean isActionViewExpanded();
  
  public abstract MenuItem setActionView(int paramInt);
  
  public abstract MenuItem setActionView(View paramView);
  
  public abstract SupportMenuItem setIcon(CharSequence paramCharSequence);
  
  public abstract SupportMenuItem setShortcut(CharSequence paramCharSequence);
  
  public abstract void setShowAsAction(int paramInt);
  
  public abstract MenuItem setShowAsActionFlags(int paramInt);
  
  public abstract SupportMenuItem setSupportActionProvider(ActionProvider paramActionProvider);
  
  public abstract SupportMenuItem setSupportOnActionExpandListener(MenuItem.OnActionExpandListener paramOnActionExpandListener);
}

package android.support.v4.app;

import android.content.Context;
import android.os.Build.VERSION;

public final class AppOpsManagerCompat
{
  private static final AppOpsManagerImpl IMPL = new AppOpsManagerImpl();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 23)
    {
      IMPL = new AppOpsManager23();
      return;
    }
  }
  
  public static int noteProxyOp(Context paramContext, String paramString1, String paramString2)
  {
    return IMPL.noteProxyOp(paramContext, paramString1, paramString2);
  }
  
  public static String permissionToOp(String paramString)
  {
    return IMPL.permissionToOp(paramString);
  }
  
  class AppOpsManager23
    extends AppOpsManagerCompat.AppOpsManagerImpl
  {
    AppOpsManager23() {}
    
    public int noteProxyOp(Context paramContext, String paramString1, String paramString2)
    {
      return AppOpsManagerCompat23.noteProxyOp(paramContext, paramString1, paramString2);
    }
    
    public String permissionToOp(String paramString)
    {
      return AppOpsManagerCompat23.permissionToOp(paramString);
    }
  }
  
  class AppOpsManagerImpl
  {
    AppOpsManagerImpl() {}
    
    public int noteProxyOp(Context paramContext, String paramString1, String paramString2)
    {
      return 1;
    }
    
    public String permissionToOp(String paramString)
    {
      return null;
    }
  }
}

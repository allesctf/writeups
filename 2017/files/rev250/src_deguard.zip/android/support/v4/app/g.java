package android.support.v4.app;

import android.graphics.Rect;
import android.support.v4.util.ArrayMap;
import android.view.View;

final class g
  implements Runnable
{
  g(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean, ArrayMap paramArrayMap, View paramView, Rect paramRect) {}
  
  public void run()
  {
    f.set(i, h, b, d, false);
    if (c != null) {
      Label.setText(c, a);
    }
  }
}

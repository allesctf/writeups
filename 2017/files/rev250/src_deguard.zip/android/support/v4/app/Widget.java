package android.support.v4.app;

import android.view.View;
import java.util.ArrayList;

final class Widget
  implements Runnable
{
  Widget(int paramInt, ArrayList paramArrayList1, ArrayList paramArrayList2, ArrayList paramArrayList3, ArrayList paramArrayList4) {}
  
  public void run()
  {
    int k = 0;
    while (k < j)
    {
      ((View)i.get(k)).setTransitionName((String)b.get(k));
      ((View)a.get(k)).setTransitionName((String)c.get(k));
      k += 1;
    }
  }
}

package android.support.v4.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

public final class TaskStackBuilder
  implements Iterable<Intent>
{
  private static final ad.c IMPL = new ad.c();
  private final ArrayList<Intent> mIntents = new ArrayList();
  private final Context mSourceContext;
  
  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      IMPL = new ad.b();
      return;
    }
  }
  
  private TaskStackBuilder(Context paramContext)
  {
    mSourceContext = paramContext;
  }
  
  public static TaskStackBuilder create(Context paramContext)
  {
    return new TaskStackBuilder(paramContext);
  }
  
  public TaskStackBuilder addNextIntent(Intent paramIntent)
  {
    mIntents.add(paramIntent);
    return this;
  }
  
  public TaskStackBuilder addParentStack(Activity paramActivity)
  {
    Intent localIntent = null;
    if ((paramActivity instanceof ad.a)) {
      localIntent = ((ad.a)paramActivity).getSupportParentActivityIntent();
    }
    if (localIntent == null) {
      localIntent = NavUtils.getParentActivityIntent(paramActivity);
    }
    while (localIntent != null)
    {
      ComponentName localComponentName = localIntent.getComponent();
      paramActivity = localComponentName;
      if (localComponentName == null) {
        paramActivity = localIntent.resolveActivity(mSourceContext.getPackageManager());
      }
      addParentStack(paramActivity);
      addNextIntent(localIntent);
      return this;
    }
    return this;
  }
  
  public TaskStackBuilder addParentStack(ComponentName paramComponentName)
  {
    int i = mIntents.size();
    Object localObject = mSourceContext;
    try
    {
      for (paramComponentName = NavUtils.getParentActivityIntent((Context)localObject, paramComponentName); paramComponentName != null; paramComponentName = NavUtils.getParentActivityIntent((Context)localObject, paramComponentName.getComponent()))
      {
        localObject = mIntents;
        ((ArrayList)localObject).add(i, paramComponentName);
        localObject = mSourceContext;
      }
      return this;
    }
    catch (PackageManager.NameNotFoundException paramComponentName)
    {
      Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
      throw new IllegalArgumentException(paramComponentName);
    }
  }
  
  public Iterator iterator()
  {
    return mIntents.iterator();
  }
  
  public void startActivities()
  {
    startActivities(null);
  }
  
  public void startActivities(Bundle paramBundle)
  {
    if (mIntents.isEmpty()) {
      throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
    }
    Intent[] arrayOfIntent = (Intent[])mIntents.toArray(new Intent[mIntents.size()]);
    arrayOfIntent[0] = new Intent(arrayOfIntent[0]).addFlags(268484608);
    if (!ContextCompat.startActivities(mSourceContext, arrayOfIntent, paramBundle))
    {
      paramBundle = new Intent(arrayOfIntent[(arrayOfIntent.length - 1)]);
      paramBundle.addFlags(268435456);
      mSourceContext.startActivity(paramBundle);
    }
  }
}

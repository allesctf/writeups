package android.support.v4.app;

import java.util.List;
import java.util.Map;

public abstract class i
{
  private static int MAX_IMAGE_SIZE = 1048576;
  
  public void a(List paramList1, List paramList2, List paramList3) {}
  
  public void a(List paramList, Map paramMap) {}
  
  public void setTitle(List paramList1, List paramList2, List paramList3) {}
}

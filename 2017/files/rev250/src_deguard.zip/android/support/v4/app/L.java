package android.support.v4.app;

public abstract interface L
{
  public abstract void d();
}

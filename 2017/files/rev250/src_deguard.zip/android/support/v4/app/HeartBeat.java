package android.support.v4.app;

import android.app.Activity;
import android.support.v4.f.j;
import android.support.v4.util.SimpleArrayMap;

public class HeartBeat
  extends Activity
{
  private j<Class<? extends Object>, Object> mMenus = new SimpleArrayMap();
  
  public HeartBeat() {}
}

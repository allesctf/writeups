package android.support.v4.app;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.support.v4.util.ArrayMap;
import android.support.v4.util.SimpleArrayMap;
import android.support.v4.view.ViewCompat;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;

class f
{
  private static final int[] i = { 0, 3, 0, 1, 5, 4, 7, 6, 9, 8 };
  
  private static m a(m paramM, SparseArray paramSparseArray, int paramInt)
  {
    m localM = paramM;
    if (paramM == null)
    {
      localM = new m();
      paramSparseArray.put(paramInt, localM);
    }
    return localM;
  }
  
  private static ArrayMap a(int paramInt1, ArrayList paramArrayList1, ArrayList paramArrayList2, int paramInt2, int paramInt3)
  {
    ArrayMap localArrayMap = new ArrayMap();
    paramInt3 -= 1;
    if (paramInt3 >= paramInt2)
    {
      Object localObject = (b)paramArrayList1.get(paramInt3);
      if (!((b)localObject).a(paramInt1)) {}
      boolean bool;
      do
      {
        paramInt3 -= 1;
        break;
        bool = ((Boolean)paramArrayList2.get(paramInt3)).booleanValue();
      } while (c == null);
      int k = c.size();
      ArrayList localArrayList;
      label101:
      int j;
      label104:
      String str1;
      String str2;
      if (bool)
      {
        localArrayList = c;
        localObject = j;
        j = 0;
        if (j < k)
        {
          str1 = (String)((ArrayList)localObject).get(j);
          str2 = (String)localArrayList.get(j);
          String str3 = (String)localArrayMap.remove(str2);
          if (str3 == null) {
            break label188;
          }
          localArrayMap.put(str1, str3);
        }
      }
      for (;;)
      {
        j += 1;
        break label104;
        break;
        localArrayList = j;
        localObject = c;
        break label101;
        label188:
        localArrayMap.put(str1, str2);
      }
    }
    return localArrayMap;
  }
  
  private static ArrayMap a(ArrayMap paramArrayMap, Object paramObject, m paramM)
  {
    Object localObject = b;
    View localView = ((Fragment)localObject).length();
    if ((paramArrayMap.isEmpty()) || (paramObject == null) || (localView == null))
    {
      paramArrayMap.clear();
      return null;
    }
    ArrayMap localArrayMap = new ArrayMap();
    Label.a(localArrayMap, localView);
    paramObject = s;
    int j;
    if (i)
    {
      paramM = ((Fragment)localObject).k();
      paramObject = c;
      localArrayMap.add(paramObject);
      if (paramM == null) {
        break label205;
      }
      paramM.a(paramObject, localArrayMap);
      j = paramObject.size() - 1;
      label99:
      if (j < 0) {
        break label211;
      }
      localObject = (String)paramObject.get(j);
      paramM = (View)localArrayMap.get(localObject);
      if (paramM != null) {
        break label166;
      }
      paramM = a(paramArrayMap, (String)localObject);
      if (paramM != null) {
        paramArrayMap.remove(paramM);
      }
    }
    for (;;)
    {
      j -= 1;
      break label99;
      paramM = ((Fragment)localObject).p();
      paramObject = j;
      break;
      label166:
      if (!((String)localObject).equals(ViewCompat.toString(paramM)))
      {
        localObject = a(paramArrayMap, (String)localObject);
        if (localObject != null) {
          paramArrayMap.put(localObject, ViewCompat.toString(paramM));
        }
      }
    }
    label205:
    remove(paramArrayMap, localArrayMap);
    label211:
    return localArrayMap;
  }
  
  private static Object a(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean)
  {
    if ((paramFragment1 == null) || (paramFragment2 == null)) {
      return null;
    }
    if (paramBoolean) {}
    for (paramFragment1 = paramFragment2.visitArray();; paramFragment1 = paramFragment1.add()) {
      return Label.wrapSharedElementTransition(Label.a(paramFragment1));
    }
  }
  
  private static Object a(Fragment paramFragment, boolean paramBoolean)
  {
    if (paramFragment == null) {
      return null;
    }
    if (paramBoolean) {}
    for (paramFragment = paramFragment.onCreateView();; paramFragment = paramFragment.c()) {
      return Label.a(paramFragment);
    }
  }
  
  private static Object a(ViewGroup paramViewGroup, View paramView, ArrayMap paramArrayMap, m paramM, ArrayList paramArrayList1, ArrayList paramArrayList2, Object paramObject1, Object paramObject2)
  {
    Object localObject2 = null;
    Fragment localFragment1 = b;
    Fragment localFragment2 = a;
    if (localFragment1 != null) {
      localFragment1.length().setVisibility(0);
    }
    if (localFragment1 != null)
    {
      if (localFragment2 == null) {
        return null;
      }
      boolean bool = i;
      Object localObject1;
      ArrayMap localArrayMap2;
      ArrayMap localArrayMap1;
      if (paramArrayMap.isEmpty())
      {
        localObject1 = null;
        localArrayMap2 = b(paramArrayMap, localObject1, paramM);
        localArrayMap1 = a(paramArrayMap, localObject1, paramM);
        if (!paramArrayMap.isEmpty()) {
          break label251;
        }
        if (localArrayMap2 != null) {
          localArrayMap2.clear();
        }
        if (localArrayMap1 == null) {
          break label288;
        }
        localArrayMap1.clear();
        paramArrayMap = null;
      }
      for (;;)
      {
        label104:
        if ((paramObject1 == null) && (paramObject2 == null) && (paramArrayMap == null)) {
          break label293;
        }
        a(localFragment1, localFragment2, bool, localArrayMap2, true);
        if (paramArrayMap != null)
        {
          paramArrayList2.add(paramView);
          Label.setSharedElementTargets(paramArrayMap, paramView, paramArrayList1);
          a(paramArrayMap, paramObject2, localArrayMap2, e, c);
          paramArrayList2 = new Rect();
          paramObject2 = b(localArrayMap1, paramM, paramObject1, bool);
          paramM = paramObject2;
          paramView = paramM;
          paramArrayList1 = paramArrayList2;
          if (paramObject2 != null)
          {
            Label.draw(paramObject1, paramArrayList2);
            paramArrayList1 = paramArrayList2;
          }
        }
        for (paramView = paramM;; paramView = localObject2)
        {
          RecyclerView.Adapter.a(paramViewGroup, new g(localFragment1, localFragment2, bool, localArrayMap1, paramView, paramArrayList1));
          return paramArrayMap;
          localObject1 = a(localFragment1, localFragment2, bool);
          break;
          label251:
          a(paramArrayList1, localArrayMap2, paramArrayMap.keySet());
          a(paramArrayList2, localArrayMap1, paramArrayMap.values());
          paramArrayMap = localObject1;
          break label104;
          paramArrayList1 = null;
        }
        label288:
        paramArrayMap = null;
      }
    }
    label293:
    return null;
  }
  
  private static Object a(Object paramObject1, Object paramObject2, Object paramObject3, Fragment paramFragment, boolean paramBoolean)
  {
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (paramObject1 != null)
    {
      bool1 = bool2;
      if (paramObject2 != null)
      {
        bool1 = bool2;
        if (paramFragment != null) {
          if (!paramBoolean) {
            break label50;
          }
        }
      }
    }
    label50:
    for (bool1 = paramFragment.isVisible(); bool1; bool1 = paramFragment.setTitle()) {
      return Label.put(paramObject2, paramObject1, paramObject3);
    }
    return Label.mergeTransitions(paramObject2, paramObject1, paramObject3);
  }
  
  private static String a(ArrayMap paramArrayMap, String paramString)
  {
    int k = paramArrayMap.size();
    int j = 0;
    while (j < k)
    {
      if (paramString.equals(paramArrayMap.valueAt(j))) {
        return (String)paramArrayMap.get(j);
      }
      j += 1;
    }
    return null;
  }
  
  private static ArrayList a(Object paramObject, Fragment paramFragment, ArrayList paramArrayList, View paramView)
  {
    ArrayList localArrayList;
    if (paramObject != null)
    {
      localArrayList = new ArrayList();
      Label.a(localArrayList, paramFragment.length());
      if (paramArrayList != null) {
        localArrayList.removeAll(paramArrayList);
      }
      if (!localArrayList.isEmpty())
      {
        localArrayList.add(paramView);
        Label.addTargets(paramObject, localArrayList);
        return localArrayList;
      }
    }
    else
    {
      return null;
    }
    return localArrayList;
  }
  
  private static void a(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean1, ArrayMap paramArrayMap, boolean paramBoolean2)
  {
    int k = 0;
    ArrayList localArrayList;
    int j;
    if (paramBoolean1)
    {
      paramFragment1 = paramFragment2.p();
      if (paramFragment1 == null) {
        return;
      }
      paramFragment2 = new ArrayList();
      localArrayList = new ArrayList();
      if (paramArrayMap != null) {
        break label87;
      }
      j = 0;
    }
    for (;;)
    {
      if (k >= j) {
        break label96;
      }
      localArrayList.add(paramArrayMap.get(k));
      paramFragment2.add(paramArrayMap.valueAt(k));
      k += 1;
      continue;
      paramFragment1 = paramFragment1.p();
      break;
      label87:
      j = paramArrayMap.size();
    }
    label96:
    if (paramBoolean2)
    {
      paramFragment1.a(localArrayList, paramFragment2, null);
      return;
    }
    paramFragment1.setTitle(localArrayList, paramFragment2, null);
  }
  
  private static void a(FragmentManagerImpl paramFragmentManagerImpl, int paramInt, m paramM, View paramView, ArrayMap paramArrayMap)
  {
    ViewGroup localViewGroup = null;
    if (mContainer.onHasView()) {
      localViewGroup = (ViewGroup)mContainer.onFindViewById(paramInt);
    }
    if (localViewGroup == null) {
      return;
    }
    Object localObject4 = b;
    Object localObject3 = a;
    boolean bool1 = i;
    boolean bool2 = e;
    paramFragmentManagerImpl = new ArrayList();
    ArrayList localArrayList1 = new ArrayList();
    Object localObject1 = a((Fragment)localObject4, bool1);
    Object localObject2 = b((Fragment)localObject3, bool2);
    paramM = a(localViewGroup, paramView, paramArrayMap, paramM, localArrayList1, paramFragmentManagerImpl, localObject1, localObject2);
    if ((localObject1 != null) || (paramM != null) || (localObject2 != null))
    {
      ArrayList localArrayList2 = a(localObject2, (Fragment)localObject3, localArrayList1, paramView);
      paramView = a(localObject1, (Fragment)localObject4, paramFragmentManagerImpl, paramView);
      c(paramView, 4);
      localObject4 = a(localObject1, localObject2, paramM, (Fragment)localObject4, bool1);
      if (localObject4 != null)
      {
        a(localObject2, (Fragment)localObject3, localArrayList2);
        localObject3 = Label.a(paramFragmentManagerImpl);
        Label.b(localObject4, localObject1, paramView, localObject2, localArrayList2, paramM, paramFragmentManagerImpl);
        Label.a(localViewGroup, localObject4);
        Label.a(localViewGroup, localArrayList1, paramFragmentManagerImpl, (ArrayList)localObject3, paramArrayMap);
        c(paramView, 0);
        Label.a(paramM, localArrayList1, paramFragmentManagerImpl);
      }
    }
  }
  
  static void a(FragmentManagerImpl paramFragmentManagerImpl, ArrayList paramArrayList1, ArrayList paramArrayList2, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (mCurState >= 1)
    {
      if (Build.VERSION.SDK_INT < 21) {
        return;
      }
      SparseArray localSparseArray = new SparseArray();
      int j = paramInt1;
      Object localObject;
      if (j < paramInt2)
      {
        localObject = (b)paramArrayList1.get(j);
        if (((Boolean)paramArrayList2.get(j)).booleanValue()) {
          b((b)localObject, localSparseArray, paramBoolean);
        }
        for (;;)
        {
          j += 1;
          break;
          a((b)localObject, localSparseArray, paramBoolean);
        }
      }
      if (localSparseArray.size() != 0)
      {
        localObject = new View(mHost.getContext());
        int k = localSparseArray.size();
        j = 0;
        if (j < k)
        {
          int m = localSparseArray.keyAt(j);
          ArrayMap localArrayMap = a(m, paramArrayList1, paramArrayList2, paramInt1, paramInt2);
          m localM = (m)localSparseArray.valueAt(j);
          if (paramBoolean) {
            a(paramFragmentManagerImpl, m, localM, (View)localObject, localArrayMap);
          }
          for (;;)
          {
            j += 1;
            break;
            b(paramFragmentManagerImpl, m, localM, (View)localObject, localArrayMap);
          }
        }
      }
    }
  }
  
  private static void a(b paramB, e paramE, SparseArray paramSparseArray, boolean paramBoolean1, boolean paramBoolean2)
  {
    Fragment localFragment = a;
    if (localFragment == null) {
      return;
    }
    int n = mContainerId;
    if (n != 0)
    {
      int j;
      int k;
      int m;
      boolean bool;
      Object localObject;
      if (paramBoolean1)
      {
        j = i[b];
        switch (j)
        {
        default: 
          break;
        case 2: 
          j = 0;
          k = 0;
          m = 0;
          bool = false;
          paramE = (m)paramSparseArray.get(n);
          if (bool)
          {
            localObject = a(paramE, paramSparseArray, n);
            paramE = (e)localObject;
            b = localFragment;
            i = paramBoolean1;
            s = paramB;
          }
          break;
        }
      }
      for (;;)
      {
        if ((!paramBoolean2) && (j != 0))
        {
          if ((paramE != null) && (a == localFragment)) {
            a = null;
          }
          localObject = b;
          if ((mState < 1) && (mCurState >= 1) && (!i))
          {
            ((FragmentManagerImpl)localObject).makeActive(localFragment);
            ((FragmentManagerImpl)localObject).moveToState(localFragment, 1, 0, 0, false);
          }
        }
        if ((k != 0) && ((paramE == null) || (a == null)))
        {
          paramSparseArray = a(paramE, paramSparseArray, n);
          paramE = paramSparseArray;
          a = localFragment;
          e = paramBoolean1;
          c = paramB;
        }
        for (;;)
        {
          if ((paramBoolean2) || (m == 0) || (paramE == null) || (b != localFragment)) {
            return;
          }
          b = null;
          return;
          j = b;
          break;
          if (paramBoolean2) {
            if ((mNeedMenuInvalidate) && (!mHidden) && (mAdded)) {
              bool = true;
            }
          }
          for (;;)
          {
            j = 1;
            k = 0;
            m = 0;
            break;
            bool = false;
            continue;
            bool = mHidden;
          }
          if (paramBoolean2) {
            bool = mActive;
          }
          for (;;)
          {
            j = 1;
            k = 0;
            m = 0;
            break;
            if ((!mAdded) && (!mHidden)) {
              bool = true;
            } else {
              bool = false;
            }
          }
          if (paramBoolean2) {
            if ((mNeedMenuInvalidate) && (mAdded) && (mHidden)) {
              k = 1;
            }
          }
          for (;;)
          {
            j = 0;
            m = 1;
            bool = false;
            break;
            k = 0;
            continue;
            if ((mAdded) && (!mHidden)) {
              k = 1;
            } else {
              k = 0;
            }
          }
          if (paramBoolean2) {
            if ((!mAdded) && (mView != null) && (mView.getVisibility() == 0) && (y >= 0.0F)) {
              k = 1;
            }
          }
          for (;;)
          {
            j = 0;
            m = 1;
            bool = false;
            break;
            k = 0;
            continue;
            if ((mAdded) && (!mHidden)) {
              k = 1;
            } else {
              k = 0;
            }
          }
        }
      }
    }
  }
  
  public static void a(b paramB, SparseArray paramSparseArray, boolean paramBoolean)
  {
    int k = a.size();
    int j = 0;
    while (j < k)
    {
      a(paramB, (e)a.get(j), paramSparseArray, false, paramBoolean);
      j += 1;
    }
  }
  
  private static void a(ViewGroup paramViewGroup, Fragment paramFragment, View paramView, ArrayList paramArrayList1, Object paramObject1, ArrayList paramArrayList2, Object paramObject2, ArrayList paramArrayList3)
  {
    RecyclerView.Adapter.a(paramViewGroup, new R.string(paramObject1, paramView, paramFragment, paramArrayList1, paramArrayList2, paramArrayList3, paramObject2));
  }
  
  private static void a(Object paramObject, Fragment paramFragment, ArrayList paramArrayList)
  {
    if ((paramFragment != null) && (paramObject != null) && (mAdded) && (mHidden) && (mNeedMenuInvalidate))
    {
      paramFragment.a(true);
      Label.draw(paramObject, paramFragment.length(), paramArrayList);
      RecyclerView.Adapter.a(mContainer, new AgendaListView.2(paramArrayList));
    }
  }
  
  private static void a(Object paramObject1, Object paramObject2, ArrayMap paramArrayMap, boolean paramBoolean, b paramB)
  {
    if ((c != null) && (!c.isEmpty()))
    {
      if (paramBoolean) {}
      for (paramB = (String)j.get(0);; paramB = (String)c.get(0))
      {
        paramArrayMap = (View)paramArrayMap.get(paramB);
        Label.draw(paramObject1, paramArrayMap);
        if (paramObject2 == null) {
          break;
        }
        Label.draw(paramObject2, paramArrayMap);
        return;
      }
    }
  }
  
  private static void a(ArrayList paramArrayList, ArrayMap paramArrayMap, Collection paramCollection)
  {
    int j = paramArrayMap.size() - 1;
    while (j >= 0)
    {
      View localView = (View)paramArrayMap.valueAt(j);
      if (paramCollection.contains(ViewCompat.toString(localView))) {
        paramArrayList.add(localView);
      }
      j -= 1;
    }
  }
  
  private static ArrayMap b(ArrayMap paramArrayMap, Object paramObject, m paramM)
  {
    if ((paramArrayMap.isEmpty()) || (paramObject == null))
    {
      paramArrayMap.clear();
      return null;
    }
    Object localObject = a;
    ArrayMap localArrayMap = new ArrayMap();
    Label.a(localArrayMap, ((Fragment)localObject).length());
    paramObject = c;
    int j;
    if (e)
    {
      paramM = ((Fragment)localObject).p();
      paramObject = j;
      localArrayMap.add(paramObject);
      if (paramM == null) {
        break label184;
      }
      paramM.a(paramObject, localArrayMap);
      j = paramObject.size() - 1;
      label90:
      if (j < 0) {
        break label194;
      }
      localObject = (String)paramObject.get(j);
      paramM = (View)localArrayMap.get(localObject);
      if (paramM != null) {
        break label147;
      }
      paramArrayMap.remove(localObject);
    }
    for (;;)
    {
      j -= 1;
      break label90;
      paramM = ((Fragment)localObject).k();
      paramObject = c;
      break;
      label147:
      if (!((String)localObject).equals(ViewCompat.toString(paramM)))
      {
        localObject = (String)paramArrayMap.remove(localObject);
        paramArrayMap.put(ViewCompat.toString(paramM), localObject);
      }
    }
    label184:
    paramArrayMap.add(localArrayMap.keySet());
    label194:
    return localArrayMap;
  }
  
  private static View b(ArrayMap paramArrayMap, m paramM, Object paramObject, boolean paramBoolean)
  {
    paramM = s;
    if ((paramObject != null) && (c != null) && (!c.isEmpty()))
    {
      if (paramBoolean) {}
      for (paramM = (String)c.get(0);; paramM = (String)j.get(0)) {
        return (View)paramArrayMap.get(paramM);
      }
    }
    return null;
  }
  
  private static Object b(Fragment paramFragment, boolean paramBoolean)
  {
    if (paramFragment == null) {
      return null;
    }
    if (paramBoolean) {}
    for (paramFragment = paramFragment.a();; paramFragment = paramFragment.b()) {
      return Label.a(paramFragment);
    }
  }
  
  private static Object b(ViewGroup paramViewGroup, View paramView, ArrayMap paramArrayMap, m paramM, ArrayList paramArrayList1, ArrayList paramArrayList2, Object paramObject1, Object paramObject2)
  {
    Fragment localFragment1 = b;
    Fragment localFragment2 = a;
    if ((localFragment1 == null) || (localFragment2 == null)) {
      return null;
    }
    boolean bool = i;
    Object localObject;
    ArrayMap localArrayMap;
    if (paramArrayMap.isEmpty())
    {
      localObject = null;
      localArrayMap = b(paramArrayMap, localObject, paramM);
      if (!paramArrayMap.isEmpty()) {
        break label90;
      }
      localObject = null;
    }
    for (;;)
    {
      if ((paramObject1 != null) || (paramObject2 != null) || (localObject != null)) {
        break label104;
      }
      return null;
      localObject = a(localFragment1, localFragment2, bool);
      break;
      label90:
      paramArrayList1.addAll(localArrayMap.values());
    }
    label104:
    a(localFragment1, localFragment2, bool, localArrayMap, true);
    Rect localRect;
    if (localObject != null)
    {
      localRect = new Rect();
      Label.setSharedElementTargets(localObject, paramView, paramArrayList1);
      a(localObject, paramObject2, localArrayMap, e, c);
      paramObject2 = localRect;
      if (paramObject1 != null) {
        Label.draw(paramObject1, localRect);
      }
    }
    for (paramObject2 = localRect;; paramObject2 = null)
    {
      RecyclerView.Adapter.a(paramViewGroup, new a(paramArrayMap, localObject, paramM, paramArrayList2, paramView, localFragment1, localFragment2, bool, paramArrayList1, paramObject1, paramObject2));
      return localObject;
    }
  }
  
  private static void b(FragmentManagerImpl paramFragmentManagerImpl, int paramInt, m paramM, View paramView, ArrayMap paramArrayMap)
  {
    ViewGroup localViewGroup = null;
    if (mContainer.onHasView()) {
      localViewGroup = (ViewGroup)mContainer.onFindViewById(paramInt);
    }
    if (localViewGroup == null) {
      return;
    }
    Fragment localFragment = b;
    Object localObject3 = a;
    boolean bool1 = i;
    boolean bool2 = e;
    Object localObject1 = a(localFragment, bool1);
    paramFragmentManagerImpl = b((Fragment)localObject3, bool2);
    ArrayList localArrayList2 = new ArrayList();
    ArrayList localArrayList1 = new ArrayList();
    Object localObject2 = b(localViewGroup, paramView, paramArrayMap, paramM, localArrayList2, localArrayList1, localObject1, paramFragmentManagerImpl);
    if ((localObject1 != null) || (localObject2 != null) || (paramFragmentManagerImpl != null))
    {
      localObject3 = a(paramFragmentManagerImpl, (Fragment)localObject3, localArrayList2, paramView);
      if ((localObject3 == null) || (((ArrayList)localObject3).isEmpty())) {
        paramFragmentManagerImpl = null;
      }
      for (;;)
      {
        Label.a(localObject1, paramView);
        paramM = a(localObject1, paramFragmentManagerImpl, localObject2, localFragment, i);
        if (paramM == null) {
          break;
        }
        localArrayList2 = new ArrayList();
        Label.b(paramM, localObject1, localArrayList2, paramFragmentManagerImpl, (ArrayList)localObject3, localObject2, localArrayList1);
        a(localViewGroup, localFragment, paramView, localArrayList1, localObject1, localArrayList2, paramFragmentManagerImpl, (ArrayList)localObject3);
        Label.a(localViewGroup, localArrayList1, paramArrayMap);
        Label.a(localViewGroup, paramM);
        Label.a(localViewGroup, localArrayList1, paramArrayMap);
        return;
      }
    }
  }
  
  public static void b(b paramB, SparseArray paramSparseArray, boolean paramBoolean)
  {
    if (!b.mContainer.onHasView()) {
      return;
    }
    int j = a.size() - 1;
    while (j >= 0)
    {
      a(paramB, (e)a.get(j), paramSparseArray, true, paramBoolean);
      j -= 1;
    }
  }
  
  private static void c(ArrayList paramArrayList, int paramInt)
  {
    if (paramArrayList == null) {
      return;
    }
    int j = paramArrayList.size() - 1;
    while (j >= 0)
    {
      ((View)paramArrayList.get(j)).setVisibility(paramInt);
      j -= 1;
    }
  }
  
  private static void remove(ArrayMap paramArrayMap1, ArrayMap paramArrayMap2)
  {
    int j = paramArrayMap1.size() - 1;
    while (j >= 0)
    {
      if (!paramArrayMap2.containsKey((String)paramArrayMap1.valueAt(j))) {
        paramArrayMap1.removeAt(j);
      }
      j -= 1;
    }
  }
}

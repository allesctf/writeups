package android.support.v4.app;

import java.util.ArrayList;

abstract interface Runnable
{
  public abstract boolean onCreateView(ArrayList paramArrayList1, ArrayList paramArrayList2);
}

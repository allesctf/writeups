package android.support.v4.app;

class m
{
  public Fragment a;
  public Fragment b;
  public b c;
  public boolean e;
  public boolean i;
  public b s;
  
  m() {}
}

package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.a.f;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

final class BackStackState
  implements Parcelable
{
  public static final Parcelable.Creator<f> CREATOR = new AppCompatDelegateImplV7.PanelFeatureState.SavedState.1();
  final int mBreadCrumbShortTitleRes;
  final CharSequence mBreadCrumbShortTitleText;
  final int mBreadCrumbTitleRes;
  final CharSequence mBreadCrumbTitleText;
  final boolean mFromLayout;
  final int mIndex;
  final String mName;
  final int[] mOps;
  final ArrayList<String> mSharedElementSourceNames;
  final ArrayList<String> mSharedElementTargetNames;
  final int mTransition;
  final int mTransitionStyle;
  
  public BackStackState(Parcel paramParcel)
  {
    mOps = paramParcel.createIntArray();
    mTransition = paramParcel.readInt();
    mTransitionStyle = paramParcel.readInt();
    mName = paramParcel.readString();
    mIndex = paramParcel.readInt();
    mBreadCrumbTitleRes = paramParcel.readInt();
    mBreadCrumbTitleText = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    mBreadCrumbShortTitleRes = paramParcel.readInt();
    mBreadCrumbShortTitleText = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    mSharedElementSourceNames = paramParcel.createStringArrayList();
    mSharedElementTargetNames = paramParcel.createStringArrayList();
    if (paramParcel.readInt() != 0) {}
    for (boolean bool = true;; bool = false)
    {
      mFromLayout = bool;
      return;
    }
  }
  
  public BackStackState(b paramB)
  {
    int k = a.size();
    mOps = new int[k * 6];
    if (!l) {
      throw new IllegalStateException("Not on back stack");
    }
    int i = 0;
    int j = 0;
    if (i < k)
    {
      e localE = (e)a.get(i);
      int[] arrayOfInt = mOps;
      int m = j + 1;
      arrayOfInt[j] = b;
      arrayOfInt = mOps;
      int n = m + 1;
      if (a != null) {}
      for (j = a.mIndex;; j = -1)
      {
        arrayOfInt[m] = j;
        arrayOfInt = mOps;
        j = n + 1;
        arrayOfInt[n] = d;
        arrayOfInt = mOps;
        m = j + 1;
        arrayOfInt[j] = exitAnim;
        arrayOfInt = mOps;
        n = m + 1;
        arrayOfInt[m] = enterAnim;
        arrayOfInt = mOps;
        j = n + 1;
        arrayOfInt[n] = i;
        i += 1;
        break;
      }
    }
    mTransition = mTransition;
    mTransitionStyle = mTransitionStyle;
    mName = mName;
    mIndex = mIndex;
    mBreadCrumbTitleRes = mBreadCrumbTitleRes;
    mBreadCrumbTitleText = mBreadCrumbTitleText;
    mBreadCrumbShortTitleRes = mBreadCrumbShortTitleRes;
    mBreadCrumbShortTitleText = mBreadCrumbShortTitleText;
    mSharedElementSourceNames = c;
    mSharedElementTargetNames = j;
    mFromLayout = i;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public b instantiate(FragmentManagerImpl paramFragmentManagerImpl)
  {
    int j = 0;
    b localB = new b(paramFragmentManagerImpl);
    int i = 0;
    if (j < mOps.length)
    {
      e localE = new e();
      int[] arrayOfInt = mOps;
      int k = j + 1;
      b = arrayOfInt[j];
      if (FragmentManagerImpl.DEBUG) {
        Log.v("FragmentManager", "Instantiate " + localB + " op #" + i + " base fragment #" + mOps[k]);
      }
      arrayOfInt = mOps;
      j = k + 1;
      k = arrayOfInt[k];
      if (k >= 0) {}
      for (a = ((Fragment)mActive.get(k));; a = null)
      {
        arrayOfInt = mOps;
        k = j + 1;
        d = arrayOfInt[j];
        arrayOfInt = mOps;
        j = k + 1;
        exitAnim = arrayOfInt[k];
        arrayOfInt = mOps;
        k = j + 1;
        enterAnim = arrayOfInt[j];
        i = mOps[k];
        d = d;
        g = exitAnim;
        mEnterAnim = enterAnim;
        mExitAnim = i;
        localB.a(localE);
        i += 1;
        j = k + 1;
        break;
      }
    }
    mTransition = mTransition;
    mTransitionStyle = mTransitionStyle;
    mName = mName;
    mIndex = mIndex;
    l = true;
    mBreadCrumbTitleRes = mBreadCrumbTitleRes;
    mBreadCrumbTitleText = mBreadCrumbTitleText;
    mBreadCrumbShortTitleRes = mBreadCrumbShortTitleRes;
    mBreadCrumbShortTitleText = mBreadCrumbShortTitleText;
    c = mSharedElementSourceNames;
    j = mSharedElementTargetNames;
    i = mFromLayout;
    localB.bumpBackStackNesting(1);
    return localB;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramInt = 0;
    paramParcel.writeIntArray(mOps);
    paramParcel.writeInt(mTransition);
    paramParcel.writeInt(mTransitionStyle);
    paramParcel.writeString(mName);
    paramParcel.writeInt(mIndex);
    paramParcel.writeInt(mBreadCrumbTitleRes);
    TextUtils.writeToParcel(mBreadCrumbTitleText, paramParcel, 0);
    paramParcel.writeInt(mBreadCrumbShortTitleRes);
    TextUtils.writeToParcel(mBreadCrumbShortTitleText, paramParcel, 0);
    paramParcel.writeStringList(mSharedElementSourceNames);
    paramParcel.writeStringList(mSharedElementTargetNames);
    if (mFromLayout) {
      paramInt = 1;
    }
    paramParcel.writeInt(paramInt);
  }
}

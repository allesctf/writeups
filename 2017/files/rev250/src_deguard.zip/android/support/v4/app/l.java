package android.support.v4.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public abstract class l
{
  public l() {}
  
  public void a(Object paramObject, Fragment paramFragment) {}
  
  public void a(Object paramObject, Fragment paramFragment, Context paramContext) {}
  
  public void a(Object paramObject, Fragment paramFragment, Bundle paramBundle) {}
  
  public void a(Object paramObject, Fragment paramFragment, View paramView, Bundle paramBundle) {}
  
  public void draw(Object paramObject, Fragment paramFragment) {}
  
  public void getId(Object paramObject, Fragment paramFragment) {}
  
  public void getId(Object paramObject, Fragment paramFragment, Context paramContext) {}
  
  public void onRestoreInstanceState(Object paramObject, Fragment paramFragment) {}
  
  public void onSaveInstanceState(Object paramObject, Fragment paramFragment) {}
  
  public void onSaveInstanceState(Object paramObject, Fragment paramFragment, Bundle paramBundle) {}
  
  public void persist(Object paramObject, Fragment paramFragment) {}
  
  public void remove(Object paramObject, Fragment paramFragment) {}
  
  public void remove(Object paramObject, Fragment paramFragment, Bundle paramBundle) {}
}

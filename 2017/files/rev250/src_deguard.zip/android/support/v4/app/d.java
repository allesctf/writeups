package android.support.v4.app;

import android.view.View;

class d
{
  int A;
  View C;
  private Object N = Fragment.c;
  int a;
  i b = null;
  private Object c = Fragment.c;
  private Object d = Fragment.c;
  private Object e = null;
  private Boolean f;
  boolean i;
  Item k;
  i l = null;
  boolean m;
  int n;
  int s;
  private Object t = null;
  private Object v = null;
  private Boolean value;
  
  d() {}
}

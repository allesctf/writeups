package android.support.v4.app;

import android.support.v4.a.i;
import android.support.v4.a.p;
import java.util.List;

public class ArrayList
{
  private final List<p> actionType;
  private final List<i> val$array;
  
  ArrayList(List paramList1, List paramList2)
  {
    val$array = paramList1;
    actionType = paramList2;
  }
  
  List get()
  {
    return val$array;
  }
  
  List getActionType()
  {
    return actionType;
  }
}

package android.support.v4.app;

abstract interface Item
{
  public abstract void a();
  
  public abstract void setTitle();
}

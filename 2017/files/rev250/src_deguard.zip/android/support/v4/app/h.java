package android.support.v4.app;

import java.util.ArrayList;

class h
  implements Item
{
  private final b a;
  private int b;
  private final boolean c;
  
  h(b paramB, boolean paramBoolean)
  {
    c = paramBoolean;
    a = paramB;
  }
  
  public void a()
  {
    b -= 1;
    if (b != 0) {
      return;
    }
    FragmentManagerImpl.popBackStack(a.b);
  }
  
  public void b()
  {
    boolean bool1 = false;
    if (b > 0) {}
    for (int i = 1;; i = 0)
    {
      localFragmentManagerImpl = a.b;
      int k = mAdded.size();
      int j = 0;
      while (j < k)
      {
        localObject = (Fragment)mAdded.get(j);
        ((Fragment)localObject).a(null);
        if ((i != 0) && (((Fragment)localObject).f())) {
          ((Fragment)localObject).execPendingActions();
        }
        j += 1;
      }
    }
    FragmentManagerImpl localFragmentManagerImpl = a.b;
    Object localObject = a;
    boolean bool2 = c;
    if (i == 0) {
      bool1 = true;
    }
    FragmentManagerImpl.a(localFragmentManagerImpl, (b)localObject, bool2, bool1, true);
  }
  
  public void e()
  {
    FragmentManagerImpl.a(a.b, a, c, false, false);
  }
  
  public boolean isCheckable()
  {
    return b == 0;
  }
  
  public void setTitle()
  {
    b += 1;
  }
}

package android.support.v4.app;

import android.os.Build.VERSION;
import android.support.v4.a.e.a;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

final class b
  extends ListPopupWindow.ForwardingListener
  implements Runnable
{
  static final boolean h;
  ArrayList<e.a> a = new ArrayList();
  final FragmentManagerImpl b;
  ArrayList<String> c;
  int d;
  boolean e = true;
  int g;
  boolean i = false;
  ArrayList<String> j;
  boolean l;
  ArrayList<java.lang.Runnable> m;
  int mBreadCrumbShortTitleRes;
  CharSequence mBreadCrumbShortTitleText;
  int mBreadCrumbTitleRes;
  CharSequence mBreadCrumbTitleText;
  boolean mCommitted;
  int mEnterAnim;
  int mExitAnim;
  int mIndex = -1;
  String mName;
  int mTransition;
  int mTransitionStyle;
  
  static
  {
    if (Build.VERSION.SDK_INT >= 21) {}
    for (boolean bool = true;; bool = false)
    {
      h = bool;
      return;
    }
  }
  
  public b(FragmentManagerImpl paramFragmentManagerImpl)
  {
    b = paramFragmentManagerImpl;
  }
  
  private static boolean b(e paramE)
  {
    paramE = a;
    return (paramE != null) && (mAdded) && (mView != null) && (!mDetached) && (!mHidden) && (paramE.f());
  }
  
  Fragment a(ArrayList paramArrayList, Fragment paramFragment)
  {
    int k = 0;
    Fragment localFragment1 = paramFragment;
    e localE;
    int n;
    Fragment localFragment2;
    int i1;
    label241:
    Fragment localFragment3;
    if (k < a.size())
    {
      localE = (e)a.get(k);
      n = k;
      paramFragment = localFragment1;
      switch (b)
      {
      default: 
        n = k;
        paramFragment = localFragment1;
        break;
      case 4: 
      case 5: 
      case 1: 
      case 7: 
      case 3: 
      case 6: 
        for (;;)
        {
          k = n + 1;
          localFragment1 = paramFragment;
          break;
          paramArrayList.add(a);
          n = k;
          paramFragment = localFragment1;
          continue;
          paramArrayList.remove(a);
          n = k;
          paramFragment = localFragment1;
          if (a == localFragment1)
          {
            a.add(k, new e(9, a));
            n = k + 1;
            paramFragment = null;
          }
        }
      case 2: 
        localFragment2 = a;
        int i3 = mContainerId;
        i1 = 0;
        n = paramArrayList.size() - 1;
        paramFragment = localFragment1;
        if (n >= 0)
        {
          localFragment3 = (Fragment)paramArrayList.get(n);
          if (mContainerId != i3) {
            break label476;
          }
          if (localFragment3 == localFragment2) {
            i1 = 1;
          }
        }
        break;
      }
    }
    label476:
    for (;;)
    {
      n -= 1;
      break label241;
      int i2 = k;
      localFragment1 = paramFragment;
      if (localFragment3 == paramFragment)
      {
        a.add(k, new e(9, localFragment3));
        i2 = k + 1;
        localFragment1 = null;
      }
      paramFragment = new e(3, localFragment3);
      d = d;
      enterAnim = enterAnim;
      exitAnim = exitAnim;
      i = i;
      a.add(i2, paramFragment);
      paramArrayList.remove(localFragment3);
      k = i2 + 1;
      paramFragment = localFragment1;
      continue;
      if (i1 != 0)
      {
        a.remove(k);
        k -= 1;
      }
      for (;;)
      {
        n = k;
        break;
        b = 1;
        paramArrayList.add(localFragment2);
      }
      a.add(k, new e(9, localFragment1));
      n = k + 1;
      paramFragment = a;
      break;
      return localFragment1;
    }
  }
  
  public void a()
  {
    if (m != null)
    {
      int n = m.size();
      int k = 0;
      while (k < n)
      {
        ((java.lang.Runnable)m.get(k)).run();
        k += 1;
      }
      m = null;
    }
  }
  
  void a(Item paramItem)
  {
    int k = 0;
    while (k < a.size())
    {
      e localE = (e)a.get(k);
      if (b(localE)) {
        a.a(paramItem);
      }
      k += 1;
    }
  }
  
  void a(e paramE)
  {
    a.add(paramE);
    d = d;
    exitAnim = g;
    enterAnim = mEnterAnim;
    i = mExitAnim;
  }
  
  boolean a(int paramInt)
  {
    int i1 = a.size();
    int k = 0;
    while (k < i1)
    {
      e localE = (e)a.get(k);
      if (a != null) {}
      for (int n = a.mContainerId; (n != 0) && (n == paramInt); n = 0) {
        return true;
      }
      k += 1;
    }
    return false;
  }
  
  boolean a(ArrayList paramArrayList, int paramInt1, int paramInt2)
  {
    if (paramInt2 == paramInt1) {
      return false;
    }
    int i4 = a.size();
    int n = -1;
    int i1 = 0;
    if (i1 < i4)
    {
      Object localObject = (e)a.get(i1);
      int k;
      int i2;
      if (a != null)
      {
        k = a.mContainerId;
        if ((k == 0) || (k == n)) {
          break label200;
        }
        i2 = paramInt1;
      }
      for (;;)
      {
        n = k;
        if (i2 >= paramInt2) {
          break label189;
        }
        localObject = (b)paramArrayList.get(i2);
        int i5 = a.size();
        n = 0;
        for (;;)
        {
          if (n >= i5) {
            break label180;
          }
          e localE = (e)a.get(n);
          if (a != null) {}
          for (int i3 = a.mContainerId;; i3 = 0)
          {
            if (i3 != k) {
              break label171;
            }
            return true;
            k = 0;
            break;
          }
          label171:
          n += 1;
        }
        label180:
        i2 += 1;
      }
    }
    label189:
    label200:
    for (;;)
    {
      i1 += 1;
      break;
      return false;
    }
  }
  
  Fragment b(ArrayList paramArrayList, Fragment paramFragment)
  {
    int k = 0;
    Fragment localFragment = paramFragment;
    if (k < a.size())
    {
      e localE = (e)a.get(k);
      paramFragment = localFragment;
      switch (b)
      {
      default: 
        paramFragment = localFragment;
        break;
      }
      for (;;)
      {
        k += 1;
        localFragment = paramFragment;
        break;
        paramArrayList.remove(a);
        paramFragment = localFragment;
        continue;
        paramArrayList.add(a);
        paramFragment = localFragment;
        continue;
        paramFragment = a;
        continue;
        paramFragment = null;
      }
    }
    return localFragment;
  }
  
  void bumpBackStackNesting(int paramInt)
  {
    if (!l) {
      return;
    }
    if (FragmentManagerImpl.DEBUG) {
      Log.v("FragmentManager", "Bump nesting in " + this + " by " + paramInt);
    }
    int n = a.size();
    int k = 0;
    while (k < n)
    {
      e localE = (e)a.get(k);
      if (a != null)
      {
        Fragment localFragment = a;
        mBackStackNesting += paramInt;
        if (FragmentManagerImpl.DEBUG) {
          Log.v("FragmentManager", "Bump nesting of " + a + " to " + a.mBackStackNesting);
        }
      }
      k += 1;
    }
  }
  
  boolean c()
  {
    int k = 0;
    while (k < a.size())
    {
      if (b((e)a.get(k))) {
        return true;
      }
      k += 1;
    }
    return false;
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    dump(paramString, paramPrintWriter, true);
  }
  
  public void dump(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(mName);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(mIndex);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(mCommitted);
      if (mTransition != 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(mTransition));
        paramPrintWriter.print(" mTransitionStyle=#");
        paramPrintWriter.println(Integer.toHexString(mTransitionStyle));
      }
      if ((d != 0) || (g != 0))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(d));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(g));
      }
      if ((mEnterAnim != 0) || (mExitAnim != 0))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(mEnterAnim));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(mExitAnim));
      }
      if ((mBreadCrumbTitleRes != 0) || (mBreadCrumbTitleText != null))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(mBreadCrumbTitleRes));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(mBreadCrumbTitleText);
      }
      if ((mBreadCrumbShortTitleRes != 0) || (mBreadCrumbShortTitleText != null))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(mBreadCrumbShortTitleRes));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(mBreadCrumbShortTitleText);
      }
    }
    if (!a.isEmpty())
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      new StringBuilder().append(paramString).append("    ").toString();
      int n = a.size();
      int k = 0;
      if (k < n)
      {
        e localE = (e)a.get(k);
        String str;
        switch (b)
        {
        default: 
          str = "cmd=" + b;
        }
        for (;;)
        {
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  Op #");
          paramPrintWriter.print(k);
          paramPrintWriter.print(": ");
          paramPrintWriter.print(str);
          paramPrintWriter.print(" ");
          paramPrintWriter.println(a);
          if (paramBoolean)
          {
            if ((d != 0) || (exitAnim != 0))
            {
              paramPrintWriter.print(paramString);
              paramPrintWriter.print("enterAnim=#");
              paramPrintWriter.print(Integer.toHexString(d));
              paramPrintWriter.print(" exitAnim=#");
              paramPrintWriter.println(Integer.toHexString(exitAnim));
            }
            if ((enterAnim != 0) || (i != 0))
            {
              paramPrintWriter.print(paramString);
              paramPrintWriter.print("popEnterAnim=#");
              paramPrintWriter.print(Integer.toHexString(enterAnim));
              paramPrintWriter.print(" popExitAnim=#");
              paramPrintWriter.println(Integer.toHexString(i));
            }
          }
          k += 1;
          break;
          str = "NULL";
          continue;
          str = "ADD";
          continue;
          str = "REPLACE";
          continue;
          str = "REMOVE";
          continue;
          str = "HIDE";
          continue;
          str = "SHOW";
          continue;
          str = "DETACH";
          continue;
          str = "ATTACH";
          continue;
          str = "SET_PRIMARY_NAV";
          continue;
          str = "UNSET_PRIMARY_NAV";
        }
      }
    }
  }
  
  public String getName()
  {
    return mName;
  }
  
  public boolean onCreateView(ArrayList paramArrayList1, ArrayList paramArrayList2)
  {
    if (FragmentManagerImpl.DEBUG) {
      Log.v("FragmentManager", "Run: " + this);
    }
    paramArrayList1.add(this);
    paramArrayList2.add(Boolean.valueOf(false));
    if (l) {
      b.addBackStackState(this);
    }
    return true;
  }
  
  void run()
  {
    Object localObject = a;
    b localB = this;
    int n = ((ArrayList)localObject).size();
    int k = 0;
    if (k < n)
    {
      localObject = a;
      localObject = (e)((ArrayList)localObject).get(k);
      Fragment localFragment = a;
      if (localFragment != null) {
        localFragment.a(mTransition, mTransitionStyle);
      }
      switch (b)
      {
      default: 
        break;
      case 2: 
        throw new IllegalArgumentException("Unknown cmd: " + b);
      case 1: 
        localFragment.a(d);
        b.addFragment(localFragment, false);
      }
      for (;;)
      {
        if ((!i) && (b != 1) && (localFragment != null)) {
          b.moveToState(localFragment);
        }
        k += 1;
        break;
        localFragment.a(exitAnim);
        b.removeFragment(localFragment);
        continue;
        localFragment.a(exitAnim);
        b.hideFragment(localFragment);
        continue;
        localFragment.a(d);
        b.showFragment(localFragment);
        continue;
        localFragment.a(exitAnim);
        b.detachFragment(localFragment);
        continue;
        localFragment.a(d);
        b.attachFragment(localFragment);
        continue;
        b.remove(localFragment);
        continue;
        b.remove(null);
      }
    }
    if (!i) {
      b.moveToState(b.mCurState, true);
    }
  }
  
  void run(boolean paramBoolean)
  {
    Object localObject = a;
    b localB = this;
    int k = ((ArrayList)localObject).size() - 1;
    if (k >= 0)
    {
      localObject = a;
      localObject = (e)((ArrayList)localObject).get(k);
      Fragment localFragment = a;
      if (localFragment != null) {
        localFragment.a(FragmentManagerImpl.reverseTransit(mTransition), mTransitionStyle);
      }
      switch (b)
      {
      default: 
        break;
      case 2: 
        throw new IllegalArgumentException("Unknown cmd: " + b);
      case 1: 
        localFragment.a(i);
        b.removeFragment(localFragment);
      }
      for (;;)
      {
        if ((!i) && (b != 3) && (localFragment != null)) {
          b.moveToState(localFragment);
        }
        k -= 1;
        break;
        localFragment.a(enterAnim);
        b.addFragment(localFragment, false);
        continue;
        localFragment.a(enterAnim);
        b.showFragment(localFragment);
        continue;
        localFragment.a(i);
        b.hideFragment(localFragment);
        continue;
        localFragment.a(enterAnim);
        b.attachFragment(localFragment);
        continue;
        localFragment.a(i);
        b.detachFragment(localFragment);
        continue;
        b.remove(null);
        continue;
        b.remove(localFragment);
      }
    }
    if ((!i) && (paramBoolean)) {
      b.moveToState(b.mCurState, true);
    }
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append("BackStackEntry{");
    localStringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (mIndex >= 0)
    {
      localStringBuilder.append(" #");
      localStringBuilder.append(mIndex);
    }
    if (mName != null)
    {
      localStringBuilder.append(" ");
      localStringBuilder.append(mName);
    }
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
}

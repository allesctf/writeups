package android.support.v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.support.v4.a.e;
import android.support.v4.a.n.a;
import android.support.v4.a.n.b;
import android.support.v4.a.o.c;
import android.support.v4.a.o.d;
import android.support.v4.util.DebugUtils;
import android.support.v4.util.Label;
import android.support.v4.util.LogWriter;
import android.support.v4.util.TLongArrayList;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater.Factory2;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class FragmentManagerImpl
  extends Object
  implements LayoutInflater.Factory2
{
  static final Interpolator ACCELERATE_CUBIC = new AccelerateInterpolator(1.5F);
  static final Interpolator ACCELERATE_QUINT;
  static boolean DEBUG;
  static final Interpolator DECELERATE_CUBIC;
  static final Interpolator DECELERATE_QUINT;
  static final boolean HONEYCOMB;
  static Field sAnimationListenerField;
  java.util.ArrayList<android.support.v4.a.i> b;
  private CopyOnWriteArrayList<android.support.v4.f.i<n.a, Boolean>> k;
  java.util.ArrayList<o.d> m;
  java.util.ArrayList<android.support.v4.a.i> mActive;
  java.util.ArrayList<e> mActivity;
  java.util.ArrayList<android.support.v4.a.i> mAdded;
  java.util.ArrayList<Integer> mAvailBackStackIndices;
  java.util.ArrayList<Integer> mAvailIndices;
  java.util.ArrayList<e> mBackStack;
  java.util.ArrayList<e> mBackStackIndices;
  FragmentContainer mContainer;
  java.util.ArrayList<android.support.v4.a.i> mCreatedMenus;
  int mCurState = 0;
  boolean mDestroyed;
  java.lang.Runnable mExecCommit = new MonthByWeekFragment.2(this);
  boolean mExecutingActions;
  java.util.ArrayList<Boolean> mHandler;
  boolean mHavePendingDeferredStart;
  FragmentHostCallback mHost;
  Fragment mIndex;
  boolean mNeedMenuInvalidate;
  String mNoTransactionsBecause;
  Fragment mParent;
  java.util.ArrayList<o.c> mPendingActions;
  SparseArray<Parcelable> mStateArray = null;
  Bundle mStateBundle = null;
  boolean mStateSaved;
  java.util.ArrayList<n.b> this$0;
  
  static
  {
    boolean bool = false;
    DEBUG = false;
    if (Build.VERSION.SDK_INT >= 11) {
      bool = true;
    }
    HONEYCOMB = bool;
    sAnimationListenerField = null;
    DECELERATE_QUINT = new DecelerateInterpolator(2.5F);
    DECELERATE_CUBIC = new DecelerateInterpolator(1.5F);
    ACCELERATE_QUINT = new AccelerateInterpolator(2.5F);
  }
  
  FragmentManagerImpl() {}
  
  private int a(java.util.ArrayList paramArrayList1, java.util.ArrayList paramArrayList2, int paramInt1, int paramInt2, TLongArrayList paramTLongArrayList)
  {
    int i = paramInt2 - 1;
    int j = paramInt2;
    b localB;
    int n;
    if (i >= paramInt1)
    {
      localB = (b)paramArrayList1.get(i);
      boolean bool = ((Boolean)paramArrayList2.get(i)).booleanValue();
      if ((localB.c()) && (!localB.a(paramArrayList1, i + 1, paramInt2)))
      {
        n = 1;
        label67:
        if (n == 0) {
          break label191;
        }
        if (m == null) {
          m = new java.util.ArrayList();
        }
        h localH = new h(localB, bool);
        m.add(localH);
        localB.a(localH);
        if (!bool) {
          break label179;
        }
        localB.run();
        label130:
        j -= 1;
        if (i != j)
        {
          paramArrayList1.remove(i);
          paramArrayList1.add(j, localB);
        }
        dump(paramTLongArrayList);
      }
    }
    label179:
    label191:
    for (;;)
    {
      i -= 1;
      break;
      n = 0;
      break label67;
      localB.run(false);
      break label130;
      return j;
    }
  }
  
  private void a()
  {
    if (m != null) {
      while (!m.isEmpty()) {
        ((h)m.remove(0)).b();
      }
    }
  }
  
  private void a(java.util.ArrayList paramArrayList1, java.util.ArrayList paramArrayList2)
  {
    int j;
    int i;
    label12:
    h localH;
    int n;
    if (m == null)
    {
      j = 0;
      i = 0;
      if (i >= j) {
        return;
      }
      localH = (h)m.get(i);
      if ((paramArrayList1 == null) || (h.c(localH))) {
        break label99;
      }
      n = paramArrayList1.indexOf(h.a(localH));
      if ((n == -1) || (!((Boolean)paramArrayList2.get(n)).booleanValue())) {
        break label99;
      }
      localH.e();
    }
    for (;;)
    {
      i += 1;
      break label12;
      j = m.size();
      break;
      label99:
      int i1;
      if (!localH.isCheckable())
      {
        i1 = j;
        n = i;
        if (paramArrayList1 != null)
        {
          i1 = j;
          n = i;
          if (!h.a(localH).a(paramArrayList1, 0, paramArrayList1.size())) {}
        }
      }
      else
      {
        m.remove(i);
        i -= 1;
        j -= 1;
        if ((paramArrayList1 != null) && (!h.c(localH)))
        {
          n = paramArrayList1.indexOf(h.a(localH));
          if ((n != -1) && (((Boolean)paramArrayList2.get(n)).booleanValue()))
          {
            localH.e();
            continue;
          }
        }
        localH.b();
        n = i;
        i1 = j;
      }
      j = i1;
      i = n;
    }
  }
  
  private void checkStateLoss()
  {
    if (mStateSaved) {
      throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
    }
    if (mNoTransactionsBecause != null) {
      throw new IllegalStateException("Can not perform this action inside of " + mNoTransactionsBecause);
    }
  }
  
  private Fragment dump(Fragment paramFragment)
  {
    ViewGroup localViewGroup = mContainer;
    View localView = mView;
    if ((localViewGroup == null) || (localView == null)) {
      return null;
    }
    int i = mAdded.indexOf(paramFragment) - 1;
    while (i >= 0)
    {
      paramFragment = (Fragment)mAdded.get(i);
      if ((mContainer == localViewGroup) && (mView != null)) {
        return paramFragment;
      }
      i -= 1;
    }
    return null;
    return paramFragment;
  }
  
  private void dump()
  {
    if (mActive == null) {}
    for (int i = 0;; i = mActive.size())
    {
      int j = 0;
      while (j < i)
      {
        Fragment localFragment = (Fragment)mActive.get(j);
        if ((localFragment != null) && (localFragment.getView() != null))
        {
          int n = localFragment.getValue();
          java.lang.Object localObject = localFragment.getView();
          localFragment.append(null);
          localObject = ((View)localObject).getAnimation();
          if (localObject != null) {
            ((Animation)localObject).cancel();
          }
          moveToState(localFragment, n, 0, 0, false);
        }
        j += 1;
      }
    }
  }
  
  private void dump(TLongArrayList paramTLongArrayList)
  {
    if (mCurState < 1) {
      return;
    }
    int n = Math.min(mCurState, 4);
    if (mAdded == null) {}
    for (int i = 0;; i = mAdded.size())
    {
      int j = 0;
      while (j < i)
      {
        Fragment localFragment = (Fragment)mAdded.get(j);
        if (mState < n)
        {
          moveToState(localFragment, n, localFragment.get(), localFragment.size(), false);
          if ((mView != null) && (!mHidden) && (mActive)) {
            paramTLongArrayList.add(localFragment);
          }
        }
        j += 1;
      }
    }
  }
  
  private void enqueueAction()
  {
    int j = 1;
    label86:
    label97:
    label100:
    for (;;)
    {
      try
      {
        int i;
        if ((m != null) && (!m.isEmpty()))
        {
          i = 1;
          if ((mPendingActions == null) || (mPendingActions.size() != 1)) {
            break label97;
          }
          break label86;
          mHost.getHandler().removeCallbacks(mExecCommit);
          mHost.getHandler().post(mExecCommit);
        }
        else
        {
          i = 0;
          continue;
        }
        if (i != 0) {
          continue;
        }
      }
      catch (Throwable localThrowable)
      {
        throw localThrowable;
      }
      for (;;)
      {
        if (j == 0) {
          break label100;
        }
        break;
        j = 0;
      }
    }
  }
  
  private void execPendingActions(boolean paramBoolean)
  {
    if (mExecutingActions) {
      throw new IllegalStateException("FragmentManager is already executing transactions");
    }
    if (Looper.myLooper() != mHost.getHandler().getLooper()) {
      throw new IllegalStateException("Must be called from main thread of fragment host");
    }
    if (!paramBoolean) {
      checkStateLoss();
    }
    if (mActivity == null)
    {
      mActivity = new java.util.ArrayList();
      mHandler = new java.util.ArrayList();
    }
    mExecutingActions = true;
    try
    {
      a(null, null);
      mExecutingActions = false;
      return;
    }
    catch (Throwable localThrowable)
    {
      mExecutingActions = false;
      throw localThrowable;
    }
  }
  
  private boolean execPendingActions(java.util.ArrayList paramArrayList1, java.util.ArrayList paramArrayList2)
  {
    try
    {
      if ((mPendingActions == null) || (mPendingActions.size() == 0)) {
        return false;
      }
      int j = mPendingActions.size();
      int i = 0;
      boolean bool = false;
      while (i < j)
      {
        bool |= ((Runnable)mPendingActions.get(i)).onCreateView(paramArrayList1, paramArrayList2);
        i += 1;
      }
      mPendingActions.clear();
      mHost.getHandler().removeCallbacks(mExecCommit);
      return bool;
    }
    catch (Throwable paramArrayList1)
    {
      throw paramArrayList1;
    }
  }
  
  static Animation makeFadeAnimation(Context paramContext, float paramFloat1, float paramFloat2)
  {
    paramContext = new AlphaAnimation(paramFloat1, paramFloat2);
    paramContext.setInterpolator(DECELERATE_CUBIC);
    paramContext.setDuration(220L);
    return paramContext;
  }
  
  static Animation makeOpenCloseAnimation(Context paramContext, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    paramContext = new AnimationSet(false);
    java.lang.Object localObject = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    ((Animation)localObject).setInterpolator(DECELERATE_QUINT);
    ((Animation)localObject).setDuration(220L);
    paramContext.addAnimation((Animation)localObject);
    localObject = new AlphaAnimation(paramFloat3, paramFloat4);
    ((Animation)localObject).setInterpolator(DECELERATE_CUBIC);
    ((Animation)localObject).setDuration(220L);
    paramContext.addAnimation((Animation)localObject);
    return paramContext;
  }
  
  static boolean modifiesAlpha(Animation paramAnimation)
  {
    if ((paramAnimation instanceof AlphaAnimation)) {
      return true;
    }
    if ((paramAnimation instanceof AnimationSet))
    {
      paramAnimation = ((AnimationSet)paramAnimation).getAnimations();
      int i = 0;
      while (i < paramAnimation.size())
      {
        if ((paramAnimation.get(i) instanceof AlphaAnimation)) {
          return true;
        }
        i += 1;
      }
    }
    return false;
  }
  
  private void onActivityResult()
  {
    mExecutingActions = false;
    mHandler.clear();
    mActivity.clear();
  }
  
  private boolean onActivityResult(String paramString, int paramInt1, int paramInt2)
  {
    execPendingActions();
    execPendingActions(true);
    if ((mIndex != null) && (paramInt1 < 0) && (paramString == null))
    {
      Object localObject = mIndex.findFragmentByWho();
      if ((localObject != null) && (localObject.popBackStackImmediate())) {
        return true;
      }
    }
    boolean bool = popBackStackState(mActivity, mHandler, paramString, paramInt1, paramInt2);
    if (bool) {
      mExecutingActions = true;
    }
    try
    {
      write(mActivity, mHandler);
      onActivityResult();
      moveToState();
      return bool;
    }
    catch (Throwable paramString)
    {
      onActivityResult();
      throw paramString;
    }
  }
  
  public static int reverseTransit(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return 0;
    case 4097: 
      return 8194;
    case 8194: 
      return 4097;
    }
    return 4099;
  }
  
  private void run(b paramB, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    java.lang.Object localObject = new java.util.ArrayList(1);
    java.util.ArrayList localArrayList = new java.util.ArrayList(1);
    ((java.util.ArrayList)localObject).add(paramB);
    localArrayList.add(Boolean.valueOf(paramBoolean1));
    write((java.util.ArrayList)localObject, localArrayList, 0, 1);
    if (paramBoolean2) {
      f.a(this, (java.util.ArrayList)localObject, localArrayList, 0, 1, true);
    }
    if (paramBoolean3) {
      moveToState(mCurState, true);
    }
    if (mActive != null)
    {
      int j = mActive.size();
      int i = 0;
      if (i < j)
      {
        localObject = (Fragment)mActive.get(i);
        if ((localObject != null) && (mView != null) && (mActive) && (paramB.a(mContainerId)))
        {
          if ((Build.VERSION.SDK_INT >= 11) && (y > 0.0F)) {
            mView.setAlpha(y);
          }
          if (!paramBoolean3) {
            break label199;
          }
          y = 0.0F;
        }
        for (;;)
        {
          i += 1;
          break;
          label199:
          y = -1.0F;
          mActive = false;
        }
      }
    }
  }
  
  private void run(java.util.ArrayList paramArrayList1, java.util.ArrayList paramArrayList2, int paramInt1, int paramInt2)
  {
    boolean bool = geti;
    int j;
    java.lang.Object localObject;
    label62:
    b localB;
    if (b == null)
    {
      b = new java.util.ArrayList();
      if (mAdded != null) {
        b.addAll(mAdded);
      }
      j = paramInt1;
      localObject = getValue();
      i = 0;
      if (j >= paramInt2) {
        break label165;
      }
      localB = (b)paramArrayList1.get(j);
      if (((Boolean)paramArrayList2.get(j)).booleanValue()) {
        break label143;
      }
      localObject = localB.a(b, (Fragment)localObject);
      label108:
      if ((i == 0) && (!l)) {
        break label159;
      }
    }
    label143:
    label159:
    for (int i = 1;; i = 0)
    {
      j += 1;
      break label62;
      b.clear();
      break;
      localObject = localB.b(b, (Fragment)localObject);
      break label108;
    }
    label165:
    b.clear();
    if (!bool) {
      f.a(this, paramArrayList1, paramArrayList2, paramInt1, paramInt2, false);
    }
    write(paramArrayList1, paramArrayList2, paramInt1, paramInt2);
    if (bool)
    {
      localObject = new TLongArrayList();
      dump((TLongArrayList)localObject);
      j = a(paramArrayList1, paramArrayList2, paramInt1, paramInt2, (TLongArrayList)localObject);
      update((TLongArrayList)localObject);
    }
    for (;;)
    {
      int n = paramInt1;
      if (j != paramInt1)
      {
        n = paramInt1;
        if (bool)
        {
          f.a(this, paramArrayList1, paramArrayList2, paramInt1, j, true);
          moveToState(mCurState, true);
          n = paramInt1;
        }
      }
      while (n < paramInt2)
      {
        localObject = (b)paramArrayList1.get(n);
        if ((((Boolean)paramArrayList2.get(n)).booleanValue()) && (mIndex >= 0))
        {
          freeBackStackIndex(mIndex);
          mIndex = -1;
        }
        ((b)localObject).a();
        n += 1;
      }
      if (i == 0) {
        break;
      }
      mainLoop();
      return;
      j = paramInt2;
    }
  }
  
  private void setHWLayerAnimListenerIfAlpha(View paramView, Animation paramAnimation)
  {
    if (paramView != null)
    {
      if (paramAnimation == null) {
        return;
      }
      if (shouldRunOnHWLayer(paramView, paramAnimation))
      {
        if (sAnimationListenerField == null) {}
        try
        {
          localObject1 = Animation.class.getDeclaredField("mListener");
          sAnimationListenerField = (Field)localObject1;
          localObject1 = sAnimationListenerField;
          ((Field)localObject1).setAccessible(true);
          localObject1 = sAnimationListenerField;
          localObject1 = ((Field)localObject1).get(paramAnimation);
          localObject1 = (Animation.AnimationListener)localObject1;
        }
        catch (NoSuchFieldException localNoSuchFieldException)
        {
          for (;;)
          {
            java.lang.Object localObject1;
            Log.e("FragmentManager", "No field with the name mListener is found in Animation class", localNoSuchFieldException);
            java.lang.Object localObject2 = null;
          }
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
          for (;;)
          {
            Log.e("FragmentManager", "Cannot access Animation's mListener field", localIllegalAccessException);
            java.lang.Object localObject3 = null;
          }
        }
        paramView.setLayerType(2, null);
        paramAnimation.setAnimationListener(new AnimateOnHWLayerIfNeededListener(paramView, paramAnimation, (Animation.AnimationListener)localObject1));
        return;
      }
    }
  }
  
  static boolean shouldRunOnHWLayer(View paramView, Animation paramAnimation)
  {
    return (Build.VERSION.SDK_INT >= 19) && (paramView.getLayerType() == 0) && (ViewCompat.hasOverlappingRendering(paramView)) && (modifiesAlpha(paramAnimation));
  }
  
  private void throwException(RuntimeException paramRuntimeException)
  {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter localPrintWriter = new PrintWriter(new LogWriter("FragmentManager"));
    FragmentHostCallback localFragmentHostCallback;
    if (mHost != null) {
      localFragmentHostCallback = mHost;
    }
    for (;;)
    {
      try
      {
        localFragmentHostCallback.onDump("  ", null, localPrintWriter, new String[0]);
        throw paramRuntimeException;
      }
      catch (Exception localException1)
      {
        Log.e("FragmentManager", "Failed dumping state", localException1);
        continue;
      }
      try
      {
        dump("  ", null, localException1, new String[0]);
      }
      catch (Exception localException2)
      {
        Log.e("FragmentManager", "Failed dumping state", localException2);
      }
    }
  }
  
  public static int transitToStyleIndex(int paramInt, boolean paramBoolean)
  {
    switch (paramInt)
    {
    default: 
      return -1;
    case 4097: 
      if (paramBoolean) {
        return 1;
      }
      return 2;
    case 8194: 
      if (paramBoolean) {
        return 3;
      }
      return 4;
    }
    if (paramBoolean) {
      return 5;
    }
    return 6;
  }
  
  private void update(TLongArrayList paramTLongArrayList)
  {
    int j = paramTLongArrayList.size();
    int i = 0;
    if (i < j)
    {
      Fragment localFragment = (Fragment)paramTLongArrayList.get(i);
      View localView;
      if (!mAdded)
      {
        localView = localFragment.length();
        if (Build.VERSION.SDK_INT >= 11) {
          break label61;
        }
        localFragment.length().setVisibility(4);
      }
      for (;;)
      {
        i += 1;
        break;
        label61:
        y = localView.getAlpha();
        localView.setAlpha(0.0F);
      }
    }
  }
  
  private void write(java.util.ArrayList paramArrayList1, java.util.ArrayList paramArrayList2)
  {
    int i = 0;
    if (paramArrayList1 != null)
    {
      if (paramArrayList1.isEmpty()) {
        return;
      }
      if ((paramArrayList2 == null) || (paramArrayList1.size() != paramArrayList2.size())) {
        throw new IllegalStateException("Internal error with the back stack records");
      }
      a(paramArrayList1, paramArrayList2);
      int i1 = paramArrayList1.size();
      int j = 0;
      if (i < i1)
      {
        if (geti) {
          break label210;
        }
        if (j != i) {
          run(paramArrayList1, paramArrayList2, j, i);
        }
        int n = i + 1;
        j = n;
        if (((Boolean)paramArrayList2.get(i)).booleanValue()) {
          for (;;)
          {
            j = n;
            if (n >= i1) {
              break;
            }
            j = n;
            if (!((Boolean)paramArrayList2.get(n)).booleanValue()) {
              break;
            }
            j = n;
            if (geti) {
              break;
            }
            n += 1;
          }
        }
        run(paramArrayList1, paramArrayList2, i, j);
        i = j - 1;
      }
      label210:
      for (;;)
      {
        i += 1;
        break;
        if (j == i1) {
          return;
        }
        run(paramArrayList1, paramArrayList2, j, i1);
        return;
      }
    }
  }
  
  private static void write(java.util.ArrayList paramArrayList1, java.util.ArrayList paramArrayList2, int paramInt1, int paramInt2)
  {
    if (paramInt1 < paramInt2)
    {
      b localB = (b)paramArrayList1.get(paramInt1);
      boolean bool;
      if (((Boolean)paramArrayList2.get(paramInt1)).booleanValue())
      {
        localB.bumpBackStackNesting(-1);
        if (paramInt1 == paramInt2 - 1)
        {
          bool = true;
          label45:
          localB.run(bool);
        }
      }
      for (;;)
      {
        paramInt1 += 1;
        break;
        bool = false;
        break label45;
        localB.bumpBackStackNesting(1);
        localB.run();
      }
    }
  }
  
  void a(Fragment paramFragment, Context paramContext, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).a(paramFragment, paramContext, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).a(this, paramFragment, paramContext);
      }
    }
  }
  
  void a(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).a(paramFragment, paramBundle, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).onSaveInstanceState(this, paramFragment, paramBundle);
      }
    }
  }
  
  void a(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).a(paramFragment, paramView, paramBundle, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).a(this, paramFragment, paramView, paramBundle);
      }
    }
  }
  
  void a(Fragment paramFragment, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).a(paramFragment, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).onSaveInstanceState(this, paramFragment);
      }
    }
  }
  
  void addBackStackState(b paramB)
  {
    if (mBackStack == null) {
      mBackStack = new java.util.ArrayList();
    }
    mBackStack.add(paramB);
    mainLoop();
  }
  
  void addFragment(Fragment paramFragment)
  {
    moveToState(paramFragment, mCurState, 0, 0, false);
  }
  
  public void addFragment(Fragment paramFragment, boolean paramBoolean)
  {
    if (mAdded == null) {
      mAdded = new java.util.ArrayList();
    }
    if (DEBUG) {
      Log.v("FragmentManager", "add: " + paramFragment);
    }
    makeActive(paramFragment);
    if (!mDetached)
    {
      if (mAdded.contains(paramFragment)) {
        throw new IllegalStateException("Fragment already added: " + paramFragment);
      }
      mAdded.add(paramFragment);
      mAdded = true;
      mRemoving = false;
      if (mView == null) {
        mNeedMenuInvalidate = false;
      }
      if ((mHasMenu) && (mMenuVisible)) {
        mNeedMenuInvalidate = true;
      }
      if (paramBoolean) {
        addFragment(paramFragment);
      }
    }
  }
  
  public void attachController(FragmentHostCallback paramFragmentHostCallback, FragmentContainer paramFragmentContainer, Fragment paramFragment)
  {
    if (mHost != null) {
      throw new IllegalStateException("Already attached");
    }
    mHost = paramFragmentHostCallback;
    mContainer = paramFragmentContainer;
    mParent = paramFragment;
  }
  
  public void attachFragment(Fragment paramFragment)
  {
    if (DEBUG) {
      Log.v("FragmentManager", "attach: " + paramFragment);
    }
    if (mDetached)
    {
      mDetached = false;
      if (!mAdded)
      {
        if (mAdded == null) {
          mAdded = new java.util.ArrayList();
        }
        if (mAdded.contains(paramFragment)) {
          throw new IllegalStateException("Fragment already added: " + paramFragment);
        }
        if (DEBUG) {
          Log.v("FragmentManager", "add from attach: " + paramFragment);
        }
        mAdded.add(paramFragment);
        mAdded = true;
        if ((mHasMenu) && (mMenuVisible)) {
          mNeedMenuInvalidate = true;
        }
      }
    }
  }
  
  void b(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).b(paramFragment, paramBundle, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).a(this, paramFragment, paramBundle);
      }
    }
  }
  
  void b(Fragment paramFragment, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).b(paramFragment, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).a(this, paramFragment);
      }
    }
  }
  
  void d(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).d(paramFragment, paramBundle, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).remove(this, paramFragment, paramBundle);
      }
    }
  }
  
  void d(Fragment paramFragment, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).d(paramFragment, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).remove(this, paramFragment);
      }
    }
  }
  
  public void detachFragment(Fragment paramFragment)
  {
    if (DEBUG) {
      Log.v("FragmentManager", "detach: " + paramFragment);
    }
    if (!mDetached)
    {
      mDetached = true;
      if (mAdded)
      {
        if (mAdded != null)
        {
          if (DEBUG) {
            Log.v("FragmentManager", "remove from detach: " + paramFragment);
          }
          mAdded.remove(paramFragment);
        }
        if ((mHasMenu) && (mMenuVisible)) {
          mNeedMenuInvalidate = true;
        }
        mAdded = false;
      }
    }
  }
  
  public void dispatchActivityCreated()
  {
    mStateSaved = false;
    mExecutingActions = true;
    moveToState(2, false);
    mExecutingActions = false;
  }
  
  public void dispatchConfigurationChanged(Configuration paramConfiguration)
  {
    if (mAdded != null)
    {
      int i = 0;
      while (i < mAdded.size())
      {
        Fragment localFragment = (Fragment)mAdded.get(i);
        if (localFragment != null) {
          localFragment.performConfigurationChanged(paramConfiguration);
        }
        i += 1;
      }
    }
  }
  
  public boolean dispatchContextItemSelected(MenuItem paramMenuItem)
  {
    if (mAdded != null)
    {
      int i = 0;
      while (i < mAdded.size())
      {
        Fragment localFragment = (Fragment)mAdded.get(i);
        if ((localFragment != null) && (localFragment.performContextItemSelected(paramMenuItem))) {
          return true;
        }
        i += 1;
      }
    }
    return false;
  }
  
  public void dispatchCreate()
  {
    mStateSaved = false;
    mExecutingActions = true;
    moveToState(1, false);
    mExecutingActions = false;
  }
  
  public boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater)
  {
    int j = 0;
    java.lang.Object localObject2 = null;
    java.lang.Object localObject1 = null;
    int i;
    if (mAdded != null)
    {
      i = 0;
      for (boolean bool1 = false;; bool1 = bool2)
      {
        localObject2 = localObject1;
        bool2 = bool1;
        if (i >= mAdded.size()) {
          break;
        }
        Fragment localFragment = (Fragment)mAdded.get(i);
        localObject2 = localObject1;
        bool2 = bool1;
        if (localFragment != null)
        {
          localObject2 = localObject1;
          bool2 = bool1;
          if (localFragment.performCreateOptionsMenu(paramMenu, paramMenuInflater))
          {
            bool2 = true;
            localObject2 = localObject1;
            if (localObject1 == null) {
              localObject2 = new java.util.ArrayList();
            }
            ((java.util.ArrayList)localObject2).add(localFragment);
          }
        }
        i += 1;
        localObject1 = localObject2;
      }
    }
    boolean bool2 = false;
    if (mCreatedMenus != null)
    {
      i = j;
      while (i < mCreatedMenus.size())
      {
        paramMenu = (Fragment)mCreatedMenus.get(i);
        if ((localObject2 == null) || (!((java.util.ArrayList)localObject2).contains(paramMenu))) {
          paramMenu.onDestroyOptionsMenu();
        }
        i += 1;
      }
    }
    mCreatedMenus = ((java.util.ArrayList)localObject2);
    return bool2;
  }
  
  public void dispatchDestroy()
  {
    mDestroyed = true;
    execPendingActions();
    mExecutingActions = true;
    moveToState(0, false);
    mExecutingActions = false;
    mHost = null;
    mContainer = null;
    mParent = null;
  }
  
  public void dispatchDestroyView()
  {
    mExecutingActions = true;
    moveToState(1, false);
    mExecutingActions = false;
  }
  
  public boolean dispatchOptionsItemSelected(MenuItem paramMenuItem)
  {
    if (mAdded != null)
    {
      int i = 0;
      while (i < mAdded.size())
      {
        Fragment localFragment = (Fragment)mAdded.get(i);
        if ((localFragment != null) && (localFragment.performOptionsItemSelected(paramMenuItem))) {
          return true;
        }
        i += 1;
      }
    }
    return false;
  }
  
  public void dispatchPause()
  {
    mExecutingActions = true;
    moveToState(4, false);
    mExecutingActions = false;
  }
  
  public boolean dispatchPrepareOptionsMenu(Menu paramMenu)
  {
    boolean bool1;
    if (mAdded != null)
    {
      int i = 0;
      boolean bool2;
      for (bool1 = false; i < mAdded.size(); bool1 = bool2)
      {
        Fragment localFragment = (Fragment)mAdded.get(i);
        bool2 = bool1;
        if (localFragment != null)
        {
          bool2 = bool1;
          if (localFragment.performPrepareOptionsMenu(paramMenu)) {
            bool2 = true;
          }
        }
        i += 1;
      }
    }
    return false;
    return bool1;
  }
  
  public void dispatchReallyStop()
  {
    mExecutingActions = true;
    moveToState(2, false);
    mExecutingActions = false;
  }
  
  public void dispatchResume()
  {
    mStateSaved = false;
    mExecutingActions = true;
    moveToState(5, false);
    mExecutingActions = false;
  }
  
  public void dispatchStart()
  {
    mStateSaved = false;
    mExecutingActions = true;
    moveToState(4, false);
    mExecutingActions = false;
  }
  
  public void dispatchStop()
  {
    mStateSaved = true;
    mExecutingActions = true;
    moveToState(3, false);
    mExecutingActions = false;
  }
  
  void draw(Fragment paramFragment, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).draw(paramFragment, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).draw(this, paramFragment);
      }
    }
  }
  
  public void dump(Menu paramMenu)
  {
    if (mAdded != null)
    {
      int i = 0;
      while (i < mAdded.size())
      {
        Fragment localFragment = (Fragment)mAdded.get(i);
        if (localFragment != null) {
          localFragment.dump(paramMenu);
        }
        i += 1;
      }
    }
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    int j = 0;
    String str = paramString + "    ";
    int n;
    int i;
    java.lang.Object localObject;
    if (mActive != null)
    {
      n = mActive.size();
      if (n > 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("Active Fragments in ");
        paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
        paramPrintWriter.println(":");
        i = 0;
        while (i < n)
        {
          localObject = (Fragment)mActive.get(i);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(localObject);
          if (localObject != null) {
            ((Fragment)localObject).dump(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
          }
          i += 1;
        }
      }
    }
    if (mAdded != null)
    {
      n = mAdded.size();
      if (n > 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Added Fragments:");
        i = 0;
        while (i < n)
        {
          localObject = (Fragment)mAdded.get(i);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(((Fragment)localObject).toString());
          i += 1;
        }
      }
    }
    if (mCreatedMenus != null)
    {
      n = mCreatedMenus.size();
      if (n > 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Fragments Created Menus:");
        i = 0;
        while (i < n)
        {
          localObject = (Fragment)mCreatedMenus.get(i);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(((Fragment)localObject).toString());
          i += 1;
        }
      }
    }
    if (mBackStack != null)
    {
      n = mBackStack.size();
      if (n > 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Back Stack:");
        i = 0;
        while (i < n)
        {
          localObject = (b)mBackStack.get(i);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(((b)localObject).toString());
          ((b)localObject).dump(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
          i += 1;
        }
      }
    }
    try
    {
      if (mBackStackIndices != null)
      {
        n = mBackStackIndices.size();
        if (n > 0)
        {
          paramPrintWriter.print(paramString);
          paramPrintWriter.println("Back Stack Indices:");
          i = 0;
          while (i < n)
          {
            paramFileDescriptor = (b)mBackStackIndices.get(i);
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("  #");
            paramPrintWriter.print(i);
            paramPrintWriter.print(": ");
            paramPrintWriter.println(paramFileDescriptor);
            i += 1;
          }
        }
      }
      if ((mAvailBackStackIndices != null) && (mAvailBackStackIndices.size() > 0))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mAvailBackStackIndices: ");
        paramPrintWriter.println(Arrays.toString(mAvailBackStackIndices.toArray()));
      }
      if (mPendingActions != null)
      {
        n = mPendingActions.size();
        if (n > 0)
        {
          paramPrintWriter.print(paramString);
          paramPrintWriter.println("Pending Actions:");
          i = j;
          while (i < n)
          {
            paramFileDescriptor = (Runnable)mPendingActions.get(i);
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("  #");
            paramPrintWriter.print(i);
            paramPrintWriter.print(": ");
            paramPrintWriter.println(paramFileDescriptor);
            i += 1;
          }
        }
      }
      paramPrintWriter.print(paramString);
    }
    catch (Throwable paramString)
    {
      throw paramString;
    }
    paramPrintWriter.println("FragmentManager misc state:");
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("  mHost=");
    paramPrintWriter.println(mHost);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("  mContainer=");
    paramPrintWriter.println(mContainer);
    if (mParent != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mParent=");
      paramPrintWriter.println(mParent);
    }
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("  mCurState=");
    paramPrintWriter.print(mCurState);
    paramPrintWriter.print(" mStateSaved=");
    paramPrintWriter.print(mStateSaved);
    paramPrintWriter.print(" mDestroyed=");
    paramPrintWriter.println(mDestroyed);
    if (mNeedMenuInvalidate)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mNeedMenuInvalidate=");
      paramPrintWriter.println(mNeedMenuInvalidate);
    }
    if (mNoTransactionsBecause != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mNoTransactionsBecause=");
      paramPrintWriter.println(mNoTransactionsBecause);
    }
    if ((mAvailIndices != null) && (mAvailIndices.size() > 0))
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mAvailIndices: ");
      paramPrintWriter.println(Arrays.toString(mAvailIndices.toArray()));
    }
  }
  
  public void dump(boolean paramBoolean)
  {
    if (mAdded == null) {
      return;
    }
    int i = mAdded.size() - 1;
    while (i >= 0)
    {
      Fragment localFragment = (Fragment)mAdded.get(i);
      if (localFragment != null) {
        localFragment.dump(paramBoolean);
      }
      i -= 1;
    }
  }
  
  public boolean execPendingActions()
  {
    execPendingActions(true);
    boolean bool = false;
    while (execPendingActions(mActivity, mHandler))
    {
      mExecutingActions = true;
      try
      {
        write(mActivity, mHandler);
        onActivityResult();
        bool = true;
      }
      catch (Throwable localThrowable)
      {
        onActivityResult();
        throw localThrowable;
      }
    }
    moveToState();
    return bool;
  }
  
  void execute(Fragment paramFragment, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).execute(paramFragment, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).persist(this, paramFragment);
      }
    }
  }
  
  void f(Fragment paramFragment, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).f(paramFragment, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).onRestoreInstanceState(this, paramFragment);
      }
    }
  }
  
  public Fragment findFragmentById(int paramInt)
  {
    int i;
    Fragment localFragment;
    if (mAdded != null)
    {
      i = mAdded.size() - 1;
      while (i >= 0)
      {
        localFragment = (Fragment)mAdded.get(i);
        if ((localFragment != null) && (mFragmentId == paramInt)) {
          return localFragment;
        }
        i -= 1;
      }
    }
    if (mActive != null)
    {
      i = mActive.size() - 1;
      while (i >= 0)
      {
        localFragment = (Fragment)mActive.get(i);
        if ((localFragment != null) && (mFragmentId == paramInt)) {
          return localFragment;
        }
        i -= 1;
      }
    }
    return null;
    return localFragment;
  }
  
  public Fragment findFragmentByTag(String paramString)
  {
    int i;
    Fragment localFragment;
    if ((mAdded != null) && (paramString != null))
    {
      i = mAdded.size() - 1;
      while (i >= 0)
      {
        localFragment = (Fragment)mAdded.get(i);
        if ((localFragment != null) && (paramString.equals(mTag))) {
          return localFragment;
        }
        i -= 1;
      }
    }
    if ((mActive != null) && (paramString != null))
    {
      i = mActive.size() - 1;
      while (i >= 0)
      {
        localFragment = (Fragment)mActive.get(i);
        if ((localFragment != null) && (paramString.equals(mTag))) {
          return localFragment;
        }
        i -= 1;
      }
    }
    return null;
    return localFragment;
  }
  
  public Fragment findFragmentByWho(String paramString)
  {
    if ((mActive != null) && (paramString != null))
    {
      int i = mActive.size() - 1;
      while (i >= 0)
      {
        Fragment localFragment = (Fragment)mActive.get(i);
        if (localFragment != null)
        {
          localFragment = localFragment.findFragmentByWho(paramString);
          if (localFragment != null) {
            return localFragment;
          }
        }
        i -= 1;
      }
    }
    return null;
  }
  
  public void freeBackStackIndex(int paramInt)
  {
    try
    {
      mBackStackIndices.set(paramInt, null);
      if (mAvailBackStackIndices == null) {
        mAvailBackStackIndices = new java.util.ArrayList();
      }
      if (DEBUG) {
        Log.v("FragmentManager", "Freeing back stack index " + paramInt);
      }
      mAvailBackStackIndices.add(Integer.valueOf(paramInt));
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public Fragment getFragment(Bundle paramBundle, String paramString)
  {
    int i = paramBundle.getInt(paramString, -1);
    if (i == -1) {
      return null;
    }
    if (i >= mActive.size()) {
      throwException(new IllegalStateException("Fragment no longer exists for key " + paramString + ": index " + i));
    }
    paramBundle = (Fragment)mActive.get(i);
    if (paramBundle == null) {
      throwException(new IllegalStateException("Fragment no longer exists for key " + paramString + ": index " + i));
    }
    return paramBundle;
  }
  
  LayoutInflater.Factory2 getLayoutInflaterFactory()
  {
    return this;
  }
  
  public Fragment getValue()
  {
    return mIndex;
  }
  
  public void hideFragment(Fragment paramFragment)
  {
    boolean bool = true;
    if (DEBUG) {
      Log.v("FragmentManager", "hide: " + paramFragment);
    }
    if (!mHidden)
    {
      mHidden = true;
      if (!mNeedMenuInvalidate) {}
      for (;;)
      {
        mNeedMenuInvalidate = bool;
        return;
        bool = false;
      }
    }
  }
  
  Animation loadAnimation(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2)
  {
    Animation localAnimation = paramFragment.onCreateAnimation(paramInt1, paramBoolean, paramFragment.get());
    if (localAnimation != null) {
      return localAnimation;
    }
    if (paramFragment.get() != 0)
    {
      paramFragment = AnimationUtils.loadAnimation(mHost.getContext(), paramFragment.get());
      if (paramFragment != null) {}
    }
    else
    {
      if (paramInt1 == 0) {
        return null;
      }
      paramInt1 = transitToStyleIndex(paramInt1, paramBoolean);
      if (paramInt1 < 0) {
        return null;
      }
      switch (paramInt1)
      {
      default: 
        paramInt1 = paramInt2;
        if (paramInt2 == 0)
        {
          paramInt1 = paramInt2;
          if (mHost.onHasWindowAnimations()) {
            paramInt1 = mHost.onGetWindowAnimations();
          }
        }
        if (paramInt1 == 0) {
          return null;
        }
        break;
      case 1: 
        return makeOpenCloseAnimation(mHost.getContext(), 1.125F, 1.0F, 0.0F, 1.0F);
      case 2: 
        return makeOpenCloseAnimation(mHost.getContext(), 1.0F, 0.975F, 1.0F, 0.0F);
      case 3: 
        return makeOpenCloseAnimation(mHost.getContext(), 0.975F, 1.0F, 0.0F, 1.0F);
      case 4: 
        return makeOpenCloseAnimation(mHost.getContext(), 1.0F, 1.075F, 1.0F, 0.0F);
      case 5: 
        return makeFadeAnimation(mHost.getContext(), 0.0F, 1.0F);
      case 6: 
        return makeFadeAnimation(mHost.getContext(), 1.0F, 0.0F);
      }
      return null;
    }
    return paramFragment;
  }
  
  void mainLoop()
  {
    if (this$0 != null)
    {
      int i = 0;
      while (i < this$0.size())
      {
        ((L)this$0.get(i)).d();
        i += 1;
      }
    }
  }
  
  void makeActive(Fragment paramFragment)
  {
    if (mIndex >= 0) {
      return;
    }
    if ((mAvailIndices == null) || (mAvailIndices.size() <= 0))
    {
      if (mActive == null) {
        mActive = new java.util.ArrayList();
      }
      paramFragment.setIndex(mActive.size(), mParent);
      mActive.add(paramFragment);
    }
    while (DEBUG)
    {
      Log.v("FragmentManager", "Allocated fragment index " + paramFragment);
      return;
      paramFragment.setIndex(((Integer)mAvailIndices.remove(mAvailIndices.size() - 1)).intValue(), mParent);
      mActive.set(mIndex, paramFragment);
    }
  }
  
  void makeInactive(Fragment paramFragment)
  {
    if (mIndex < 0) {
      return;
    }
    if (DEBUG) {
      Log.v("FragmentManager", "Freeing fragment index " + paramFragment);
    }
    mActive.set(mIndex, null);
    if (mAvailIndices == null) {
      mAvailIndices = new java.util.ArrayList();
    }
    mAvailIndices.add(Integer.valueOf(mIndex));
    mHost.inactivateFragment(mWho);
    paramFragment.initState();
  }
  
  void moveToState()
  {
    if (mHavePendingDeferredStart)
    {
      int i = 0;
      boolean bool2;
      for (boolean bool1 = false; i < mActive.size(); bool1 = bool2)
      {
        Fragment localFragment = (Fragment)mActive.get(i);
        bool2 = bool1;
        if (localFragment != null)
        {
          bool2 = bool1;
          if (mLoaderManager != null) {
            bool2 = bool1 | mLoaderManager.hasRunningLoaders();
          }
        }
        i += 1;
      }
      if (!bool1)
      {
        mHavePendingDeferredStart = false;
        startPendingDeferredFragments();
      }
    }
  }
  
  void moveToState(int paramInt, boolean paramBoolean)
  {
    if ((mHost == null) && (paramInt != 0)) {
      throw new IllegalStateException("No activity");
    }
    if ((!paramBoolean) && (paramInt == mCurState)) {
      return;
    }
    mCurState = paramInt;
    if (mActive != null)
    {
      int i1;
      int n;
      Fragment localFragment;
      if (mAdded != null)
      {
        i1 = mAdded.size();
        n = 0;
        int i = 0;
        paramInt = i;
        if (n >= i1) {
          break label127;
        }
        localFragment = (Fragment)mAdded.get(n);
        moveToState(localFragment);
        if (mLoaderManager == null) {
          break label270;
        }
        i = mLoaderManager.hasRunningLoaders() | i;
      }
      label127:
      label267:
      label270:
      for (;;)
      {
        n += 1;
        break;
        paramInt = 0;
        i1 = mActive.size();
        n = 0;
        int j = paramInt;
        paramInt = n;
        boolean bool;
        if (paramInt < i1)
        {
          localFragment = (Fragment)mActive.get(paramInt);
          if ((localFragment == null) || ((!mRemoving) && (!mDetached)) || (mActive)) {
            break label267;
          }
          moveToState(localFragment);
          if (mLoaderManager == null) {
            break label267;
          }
          bool = mLoaderManager.hasRunningLoaders() | j;
        }
        for (;;)
        {
          paramInt += 1;
          break;
          if (!bool) {
            startPendingDeferredFragments();
          }
          if ((!mNeedMenuInvalidate) || (mHost == null) || (mCurState != 5)) {
            return;
          }
          mHost.onSupportInvalidateOptionsMenu();
          mNeedMenuInvalidate = false;
          return;
        }
      }
    }
  }
  
  void moveToState(Fragment paramFragment)
  {
    if (paramFragment == null) {
      return;
    }
    int j = mCurState;
    int i = j;
    java.lang.Object localObject;
    if (mRemoving)
    {
      if (paramFragment.isInBackStack()) {
        i = Math.min(j, 1);
      }
    }
    else
    {
      moveToState(paramFragment, i, paramFragment.size(), paramFragment.onCreate(), false);
      if (mView != null)
      {
        localObject = dump(paramFragment);
        if (localObject != null)
        {
          localObject = mView;
          ViewGroup localViewGroup = mContainer;
          i = localViewGroup.indexOfChild((View)localObject);
          j = localViewGroup.indexOfChild(mView);
          if (j < i)
          {
            localViewGroup.removeViewAt(j);
            localViewGroup.addView(mView, i);
          }
        }
        if ((mActive) && (mContainer != null))
        {
          if (Build.VERSION.SDK_INT >= 11) {
            break label220;
          }
          mView.setVisibility(0);
        }
      }
    }
    for (;;)
    {
      y = 0.0F;
      mActive = false;
      localObject = loadAnimation(paramFragment, paramFragment.size(), true, paramFragment.onCreate());
      if (localObject != null)
      {
        setHWLayerAnimListenerIfAlpha(mView, (Animation)localObject);
        mView.startAnimation((Animation)localObject);
      }
      if (!mNeedMenuInvalidate) {
        return;
      }
      onCreate(paramFragment);
      return;
      i = Math.min(j, 0);
      break;
      label220:
      if (y > 0.0F) {
        mView.setAlpha(y);
      }
    }
  }
  
  void moveToState(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    boolean bool = true;
    int i;
    if (mAdded)
    {
      i = paramInt1;
      if (!mDetached) {}
    }
    else
    {
      i = paramInt1;
      if (paramInt1 > 1) {
        i = 1;
      }
    }
    int j = i;
    if (mRemoving)
    {
      j = i;
      if (i > mState) {
        j = mState;
      }
    }
    paramInt1 = j;
    if (mDeferStart)
    {
      paramInt1 = j;
      if (mState < 4)
      {
        paramInt1 = j;
        if (j > 3) {
          paramInt1 = 3;
        }
      }
    }
    label578:
    label663:
    label701:
    ViewGroup localViewGroup;
    if (mState <= paramInt1)
    {
      if ((mFromLayout) && (!mInLayout)) {
        return;
      }
      if (paramFragment.getView() != null)
      {
        paramFragment.append(null);
        moveToState(paramFragment, paramFragment.getValue(), 0, 0, true);
      }
      paramInt2 = paramInt1;
      i = paramInt1;
      j = paramInt1;
      paramInt3 = paramInt1;
      switch (mState)
      {
      default: 
        i = paramInt1;
        if (mState == i) {
          return;
        }
        Log.w("FragmentManager", "moveToState: Fragment state for " + paramFragment + " not updated inline; " + "expected state " + i + " found " + mState);
        mState = i;
        return;
      case 0: 
        paramInt2 = paramInt1;
        if (paramInt1 > 0)
        {
          if (DEBUG) {
            Log.v("FragmentManager", "moveto CREATED: " + paramFragment);
          }
          paramInt2 = paramInt1;
          if (mSavedFragmentState != null)
          {
            mSavedFragmentState.setClassLoader(mHost.getContext().getClassLoader());
            mSavedViewState = mSavedFragmentState.getSparseParcelableArray("android:view_state");
            mTarget = getFragment(mSavedFragmentState, "android:target_state");
            if (mTarget != null) {
              mTargetRequestCode = mSavedFragmentState.getInt("android:target_req_state", 0);
            }
            mUserVisibleHint = mSavedFragmentState.getBoolean("android:user_visible_hint", true);
            paramInt2 = paramInt1;
            if (!mUserVisibleHint)
            {
              mDeferStart = true;
              paramInt2 = paramInt1;
              if (paramInt1 > 3) {
                paramInt2 = 3;
              }
            }
          }
          mHost = mHost;
          mParentFragment = mParent;
          if (mParent != null) {}
          for (localObject1 = mParent.mChildFragmentManager;; localObject1 = mHost.getFragmentManagerImpl())
          {
            mFragmentManager = ((FragmentManagerImpl)localObject1);
            if (mTarget == null) {
              break label578;
            }
            if (mActive.contains(mTarget)) {
              break;
            }
            throw new IllegalStateException("Fragment " + paramFragment + " declared target fragment " + mTarget + " that does not belong to this FragmentManager!");
          }
          if (mTarget.mState < 1) {
            moveToState(mTarget, 1, 0, 0, true);
          }
          a(paramFragment, mHost.getContext(), false);
          mCalled = false;
          paramFragment.onAttach(mHost.getContext());
          if (!mCalled) {
            throw new SuperNotCalledException("Fragment " + paramFragment + " did not call through to super.onAttach()");
          }
          if (mParentFragment != null) {
            break label1249;
          }
          mHost.onStartActivityFromFragment(paramFragment);
          toString(paramFragment, mHost.getContext(), false);
          if (mRetaining) {
            break label1260;
          }
          paramFragment.performCreate(mSavedFragmentState);
          d(paramFragment, mSavedFragmentState, false);
          mRetaining = false;
        }
      case 1: 
        onCreateView(paramFragment);
        i = paramInt2;
        if (paramInt2 > 1)
        {
          if (DEBUG) {
            Log.v("FragmentManager", "moveto ACTIVITY_CREATED: " + paramFragment);
          }
          if (!mFromLayout)
          {
            if (mContainerId == 0) {
              break label1910;
            }
            if (mContainerId == -1) {
              throwException(new IllegalArgumentException("Cannot create fragment " + paramFragment + " for a container view with no id"));
            }
            localViewGroup = (ViewGroup)mContainer.onFindViewById(mContainerId);
            localObject1 = localViewGroup;
            if (localViewGroup == null)
            {
              localObject1 = localViewGroup;
              if (mRestored) {}
            }
          }
        }
        break;
      }
      try
      {
        localObject1 = paramFragment.getResources();
        paramInt1 = mContainerId;
        localObject1 = ((Resources)localObject1).getResourceName(paramInt1);
      }
      catch (Resources.NotFoundException localNotFoundException)
      {
        for (;;)
        {
          localObject2 = "unknown";
          continue;
          paramBoolean = false;
          continue;
          mInnerView = null;
        }
      }
      throwException(new IllegalArgumentException("No view found for id 0x" + Integer.toHexString(mContainerId) + " (" + (String)localObject1 + ") for fragment " + paramFragment));
    }
    label1249:
    label1260:
    java.lang.Object localObject2;
    label1373:
    label1789:
    label1883:
    label1904:
    label1910:
    for (java.lang.Object localObject1 = localViewGroup;; localObject2 = null)
    {
      mContainer = ((ViewGroup)localObject1);
      mView = paramFragment.performCreateView(paramFragment.getLayoutInflater(mSavedFragmentState), (ViewGroup)localObject1, mSavedFragmentState);
      if (mView != null)
      {
        mInnerView = mView;
        mView.setSaveFromParentEnabled(false);
        if (localObject1 != null) {
          ((ViewGroup)localObject1).addView(mView);
        }
        if (mHidden) {
          mView.setVisibility(8);
        }
        paramFragment.onViewCreated(mView, mSavedFragmentState);
        a(paramFragment, mView, mSavedFragmentState, false);
        if ((mView.getVisibility() == 0) && (mContainer != null))
        {
          paramBoolean = bool;
          mActive = paramBoolean;
          paramFragment.performActivityCreated(mSavedFragmentState);
          b(paramFragment, mSavedFragmentState, false);
          if (mView != null) {
            paramFragment.restoreViewState(mSavedFragmentState);
          }
          mSavedFragmentState = null;
          i = paramInt2;
          j = i;
          if (i > 2)
          {
            mState = 3;
            j = i;
          }
          paramInt3 = j;
          if (j > 3)
          {
            if (DEBUG) {
              Log.v("FragmentManager", "moveto STARTED: " + paramFragment);
            }
            paramFragment.performStart();
            b(paramFragment, false);
            paramInt3 = j;
          }
          i = paramInt3;
          if (paramInt3 <= 4) {
            break;
          }
          if (DEBUG) {
            Log.v("FragmentManager", "moveto RESUMED: " + paramFragment);
          }
          paramFragment.performResume();
          execute(paramFragment, false);
          mSavedFragmentState = null;
          mSavedViewState = null;
          i = paramInt3;
          break;
          mParentFragment.onPause(paramFragment);
          break label663;
          paramFragment.onCreate(mSavedFragmentState);
          mState = 1;
          break label701;
        }
      }
      i = paramInt1;
      if (mState <= paramInt1) {
        break;
      }
      switch (mState)
      {
      default: 
        i = paramInt1;
        break;
      case 1: 
      case 5: 
      case 4: 
      case 3: 
      case 2: 
        do
        {
          i = paramInt1;
          if (paramInt1 >= 1) {
            break;
          }
          if ((mDestroyed) && (paramFragment.getView() != null))
          {
            localObject2 = paramFragment.getView();
            paramFragment.append(null);
            ((View)localObject2).clearAnimation();
          }
          if (paramFragment.getView() == null) {
            break label1789;
          }
          paramFragment.onDetach(paramInt1);
          i = 1;
          break;
          if (paramInt1 < 5)
          {
            if (DEBUG) {
              Log.v("FragmentManager", "movefrom RESUMED: " + paramFragment);
            }
            paramFragment.performPause();
            a(paramFragment, false);
          }
          if (paramInt1 < 4)
          {
            if (DEBUG) {
              Log.v("FragmentManager", "movefrom STARTED: " + paramFragment);
            }
            paramFragment.performStop();
            toString(paramFragment, false);
          }
          if (paramInt1 < 3)
          {
            if (DEBUG) {
              Log.v("FragmentManager", "movefrom STOPPED: " + paramFragment);
            }
            paramFragment.performReallyStop();
          }
        } while (paramInt1 >= 2);
        if (DEBUG) {
          Log.v("FragmentManager", "movefrom ACTIVITY_CREATED: " + paramFragment);
        }
        if ((mView != null) && (mHost.onShouldSaveFragmentState(paramFragment)) && (mSavedViewState == null)) {
          saveFragmentViewState(paramFragment);
        }
        paramFragment.performDestroyView();
        d(paramFragment, false);
        if ((mView != null) && (mContainer != null)) {
          if ((mCurState <= 0) || (mDestroyed) || (mView.getVisibility() != 0) || (y < 0.0F)) {
            break label1904;
          }
        }
        for (localObject2 = loadAnimation(paramFragment, paramInt2, false, paramInt3);; localObject2 = null)
        {
          y = 0.0F;
          if (localObject2 != null)
          {
            paramFragment.append(mView);
            paramFragment.onDetach(paramInt1);
            ((Animation)localObject2).setAnimationListener(new FragmentManagerImpl.5(this, mView, (Animation)localObject2, paramFragment));
            mView.startAnimation((Animation)localObject2);
          }
          mContainer.removeView(mView);
          mContainer = null;
          mView = null;
          mInnerView = null;
          mInLayout = false;
          break label1373;
          if (DEBUG) {
            Log.v("FragmentManager", "movefrom CREATED: " + paramFragment);
          }
          if (!mRetaining)
          {
            paramFragment.performDestroy();
            draw(paramFragment, false);
          }
          for (;;)
          {
            paramFragment.moveToState();
            f(paramFragment, false);
            i = paramInt1;
            if (paramBoolean) {
              break;
            }
            if (mRetaining) {
              break label1883;
            }
            makeInactive(paramFragment);
            i = paramInt1;
            break;
            mState = 0;
          }
          mHost = null;
          mParentFragment = null;
          mFragmentManager = null;
          i = paramInt1;
          break;
        }
      }
    }
  }
  
  public void moveToState(boolean paramBoolean)
  {
    if (mAdded == null) {
      return;
    }
    int i = mAdded.size() - 1;
    while (i >= 0)
    {
      Fragment localFragment = (Fragment)mAdded.get(i);
      if (localFragment != null) {
        localFragment.moveToState(paramBoolean);
      }
      i -= 1;
    }
  }
  
  boolean moveToState(int paramInt)
  {
    return mCurState >= paramInt;
  }
  
  public void noteStateNotSaved()
  {
    mStateSaved = false;
  }
  
  void onCreate(Fragment paramFragment)
  {
    boolean bool;
    if (mView != null)
    {
      i = paramFragment.size();
      if (mHidden) {
        break label150;
      }
      bool = true;
      Animation localAnimation = loadAnimation(paramFragment, i, bool, paramFragment.onCreate());
      if (localAnimation != null)
      {
        setHWLayerAnimListenerIfAlpha(mView, localAnimation);
        mView.startAnimation(localAnimation);
        setHWLayerAnimListenerIfAlpha(mView, localAnimation);
        localAnimation.start();
      }
      if ((!mHidden) || (paramFragment.getIcon())) {
        break label155;
      }
    }
    label150:
    label155:
    for (int i = 8;; i = 0)
    {
      mView.setVisibility(i);
      if (paramFragment.getIcon()) {
        paramFragment.a(false);
      }
      if ((mAdded) && (mHasMenu) && (mMenuVisible)) {
        mNeedMenuInvalidate = true;
      }
      mNeedMenuInvalidate = false;
      paramFragment.setHasOptionsMenu(mHidden);
      return;
      bool = false;
      break;
    }
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    if (!"fragment".equals(paramString)) {
      return null;
    }
    String str1 = paramAttributeSet.getAttributeValue(null, "class");
    paramString = paramContext.obtainStyledAttributes(paramAttributeSet, FragmentTag.Fragment);
    if (str1 == null) {
      str1 = paramString.getString(0);
    }
    for (;;)
    {
      int n = paramString.getResourceId(1, -1);
      String str2 = paramString.getString(2);
      paramString.recycle();
      if (!Fragment.isSupportFragmentClass(mHost.getContext(), str1)) {
        return null;
      }
      if (paramView != null) {}
      for (int i = paramView.getId(); (i == -1) && (n == -1) && (str2 == null); i = 0) {
        throw new IllegalArgumentException(paramAttributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + str1);
      }
      int j;
      if (n != -1)
      {
        paramString = findFragmentById(n);
        paramView = paramString;
        if (paramString == null)
        {
          paramView = paramString;
          if (str2 != null) {
            paramView = findFragmentByTag(str2);
          }
        }
        paramString = paramView;
        if (paramView == null)
        {
          paramString = paramView;
          if (i != -1) {
            paramString = findFragmentById(i);
          }
        }
        if (DEBUG) {
          Log.v("FragmentManager", "onCreateView: id=0x" + Integer.toHexString(n) + " fname=" + str1 + " existing=" + paramString);
        }
        if (paramString != null) {
          break label434;
        }
        paramString = mContainer.instantiate(paramContext, str1, null);
        mFromLayout = true;
        if (n == 0) {
          break label427;
        }
        j = n;
        label297:
        mFragmentId = j;
        mContainerId = i;
        mTag = str2;
        mInLayout = true;
        mFragmentManager = this;
        mHost = mHost;
        paramString.onInflate(mHost.getContext(), paramAttributeSet, mSavedFragmentState);
        addFragment(paramString, true);
        label356:
        if ((mCurState >= 1) || (!mFromLayout)) {
          break label559;
        }
        moveToState(paramString, 1, 0, 0, false);
      }
      for (;;)
      {
        if (mView != null) {
          break label567;
        }
        throw new IllegalStateException("Fragment " + str1 + " did not create a view.");
        paramString = null;
        break;
        label427:
        j = i;
        break label297;
        label434:
        if (mInLayout) {
          throw new IllegalArgumentException(paramAttributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(n) + ", tag " + str2 + ", or parent id 0x" + Integer.toHexString(i) + " with another fragment for " + str1);
        }
        mInLayout = true;
        mHost = mHost;
        if (!mRetaining) {
          paramString.onInflate(mHost.getContext(), paramAttributeSet, mSavedFragmentState);
        }
        break label356;
        label559:
        addFragment(paramString);
      }
      label567:
      if (n != 0) {
        mView.setId(n);
      }
      if (mView.getTag() == null) {
        mView.setTag(str2);
      }
      return mView;
    }
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  void onCreateView(Fragment paramFragment)
  {
    if ((mFromLayout) && (!mResumed))
    {
      mView = paramFragment.performCreateView(paramFragment.getLayoutInflater(mSavedFragmentState), null, mSavedFragmentState);
      if (mView != null)
      {
        mInnerView = mView;
        mView.setSaveFromParentEnabled(false);
        if (mHidden) {
          mView.setVisibility(8);
        }
        paramFragment.onViewCreated(mView, mSavedFragmentState);
        a(paramFragment, mView, mSavedFragmentState, false);
        return;
      }
      mInnerView = null;
    }
  }
  
  public void performPendingDeferredStart(Fragment paramFragment)
  {
    if (mDeferStart)
    {
      if (mExecutingActions)
      {
        mHavePendingDeferredStart = true;
        return;
      }
      mDeferStart = false;
      moveToState(paramFragment, mCurState, 0, 0, false);
    }
  }
  
  public boolean performPendingDeferredStart()
  {
    return mStateSaved;
  }
  
  public boolean popBackStackImmediate()
  {
    checkStateLoss();
    return onActivityResult(null, -1, 0);
  }
  
  boolean popBackStackState(java.util.ArrayList paramArrayList1, java.util.ArrayList paramArrayList2, String paramString, int paramInt1, int paramInt2)
  {
    if (mBackStack == null) {
      return false;
    }
    if ((paramString == null) && (paramInt1 < 0) && ((paramInt2 & 0x1) == 0))
    {
      paramInt1 = mBackStack.size() - 1;
      if (paramInt1 < 0) {
        return false;
      }
      paramArrayList1.add(mBackStack.remove(paramInt1));
      paramArrayList2.add(Boolean.valueOf(true));
    }
    for (;;)
    {
      return true;
      int i = -1;
      if ((paramString != null) || (paramInt1 >= 0))
      {
        int j = mBackStack.size() - 1;
        b localB;
        for (;;)
        {
          if (j >= 0)
          {
            localB = (b)mBackStack.get(j);
            if ((paramString == null) || (!paramString.equals(localB.getName()))) {
              break label133;
            }
          }
          label133:
          while ((paramInt1 >= 0) && (paramInt1 == mIndex))
          {
            if (j >= 0) {
              break;
            }
            return false;
          }
          j -= 1;
        }
        i = j;
        if ((paramInt2 & 0x1) != 0)
        {
          paramInt2 = j - 1;
          for (;;)
          {
            i = paramInt2;
            if (paramInt2 < 0) {
              break;
            }
            localB = (b)mBackStack.get(paramInt2);
            if ((paramString == null) || (!paramString.equals(localB.getName())))
            {
              i = paramInt2;
              if (paramInt1 < 0) {
                break;
              }
              i = paramInt2;
              if (paramInt1 != mIndex) {
                break;
              }
            }
            paramInt2 -= 1;
          }
        }
      }
      if (i == mBackStack.size() - 1) {
        return false;
      }
      paramInt1 = mBackStack.size() - 1;
      while (paramInt1 > i)
      {
        paramArrayList1.add(mBackStack.remove(paramInt1));
        paramArrayList2.add(Boolean.valueOf(true));
        paramInt1 -= 1;
      }
    }
  }
  
  public void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment)
  {
    if (mIndex < 0) {
      throwException(new IllegalStateException("Fragment " + paramFragment + " is not currently in the FragmentManager"));
    }
    paramBundle.putInt(paramString, mIndex);
  }
  
  public void remove(Fragment paramFragment)
  {
    if ((paramFragment != null) && ((paramFragment.getId() != this) || (mIndex >= mActive.size()) || (mActive.get(mIndex) != paramFragment))) {
      throw new IllegalArgumentException("Fragment " + paramFragment + " is not an active fragment of FragmentManager " + this);
    }
    mIndex = paramFragment;
  }
  
  public void removeFragment(Fragment paramFragment)
  {
    if (DEBUG) {
      Log.v("FragmentManager", "remove: " + paramFragment + " nesting=" + mBackStackNesting);
    }
    if (!paramFragment.isInBackStack()) {}
    for (int i = 1; (!mDetached) || (i != 0); i = 0)
    {
      if (mAdded != null) {
        mAdded.remove(paramFragment);
      }
      if ((mHasMenu) && (mMenuVisible)) {
        mNeedMenuInvalidate = true;
      }
      mAdded = false;
      mRemoving = true;
      return;
    }
  }
  
  public void restoreAllState()
  {
    if (mAdded != null)
    {
      int i = 0;
      while (i < mAdded.size())
      {
        Fragment localFragment = (Fragment)mAdded.get(i);
        if (localFragment != null) {
          localFragment.dump();
        }
        i += 1;
      }
    }
  }
  
  void restoreAllState(Parcelable paramParcelable, ArrayList paramArrayList)
  {
    if (paramParcelable == null) {
      return;
    }
    FragmentManagerState localFragmentManagerState = (FragmentManagerState)paramParcelable;
    if (mActive != null)
    {
      java.lang.Object localObject1;
      int i;
      int j;
      java.lang.Object localObject2;
      if (paramArrayList != null)
      {
        localObject1 = paramArrayList.get();
        paramParcelable = paramArrayList.getActionType();
        if (localObject1 != null) {}
        for (i = ((List)localObject1).size();; i = 0)
        {
          j = 0;
          while (j < i)
          {
            localObject2 = (Fragment)((List)localObject1).get(j);
            if (DEBUG) {
              Log.v("FragmentManager", "restoreAllState: re-attaching retained " + localObject2);
            }
            FragmentState localFragmentState = mActive[mIndex];
            mInstance = ((Fragment)localObject2);
            mSavedViewState = null;
            mBackStackNesting = 0;
            mInLayout = false;
            mAdded = false;
            mTarget = null;
            if (mSavedFragmentState != null)
            {
              mSavedFragmentState.setClassLoader(mHost.getContext().getClassLoader());
              mSavedViewState = mSavedFragmentState.getSparseParcelableArray("android:view_state");
              mSavedFragmentState = mSavedFragmentState;
            }
            j += 1;
          }
        }
      }
      for (;;)
      {
        mActive = new java.util.ArrayList(mActive.length);
        if (mAvailIndices != null) {
          mAvailIndices.clear();
        }
        i = 0;
        if (i < mActive.length)
        {
          localObject2 = mActive[i];
          if (localObject2 != null) {
            if ((paramParcelable == null) || (i >= paramParcelable.size())) {
              break label996;
            }
          }
        }
        label489:
        label560:
        label608:
        label996:
        for (localObject1 = (ArrayList)paramParcelable.get(i);; localObject1 = null)
        {
          localObject1 = ((FragmentState)localObject2).instantiate(mHost, mContainer, mParent, (ArrayList)localObject1);
          if (DEBUG) {
            Log.v("FragmentManager", "restoreAllState: active #" + i + ": " + localObject1);
          }
          mActive.add(localObject1);
          mInstance = null;
          for (;;)
          {
            i += 1;
            break;
            mActive.add(null);
            if (mAvailIndices == null) {
              mAvailIndices = new java.util.ArrayList();
            }
            if (DEBUG) {
              Log.v("FragmentManager", "restoreAllState: avail #" + i);
            }
            mAvailIndices.add(Integer.valueOf(i));
          }
          if (paramArrayList != null)
          {
            paramParcelable = paramArrayList.get();
            if (paramParcelable != null)
            {
              i = paramParcelable.size();
              j = 0;
              if (j >= i) {
                break label608;
              }
              paramArrayList = (Fragment)paramParcelable.get(j);
              if (mTargetIndex >= 0) {
                if (mTargetIndex >= mActive.size()) {
                  break label560;
                }
              }
            }
            for (mTarget = ((Fragment)mActive.get(mTargetIndex));; mTarget = null)
            {
              j += 1;
              break label489;
              i = 0;
              break;
              Log.w("FragmentManager", "Re-attaching retained fragment " + paramArrayList + " target no longer exists: " + mTargetIndex);
            }
          }
          if (mAdded != null)
          {
            mAdded = new java.util.ArrayList(mAdded.length);
            i = 0;
            while (i < mAdded.length)
            {
              paramParcelable = (Fragment)mActive.get(mAdded[i]);
              if (paramParcelable == null) {
                throwException(new IllegalStateException("No instantiated fragment for index #" + mAdded[i]));
              }
              mAdded = true;
              if (DEBUG) {
                Log.v("FragmentManager", "restoreAllState: added #" + i + ": " + paramParcelable);
              }
              if (mAdded.contains(paramParcelable)) {
                throw new IllegalStateException("Already added!");
              }
              mAdded.add(paramParcelable);
              i += 1;
            }
          }
          mAdded = null;
          if (mBackStack != null)
          {
            mBackStack = new java.util.ArrayList(mBackStack.length);
            i = 0;
            while (i < mBackStack.length)
            {
              paramParcelable = mBackStack[i].instantiate(this);
              if (DEBUG)
              {
                Log.v("FragmentManager", "restoreAllState: back stack #" + i + " (index " + mIndex + "): " + paramParcelable);
                paramArrayList = new PrintWriter(new LogWriter("FragmentManager"));
                paramParcelable.dump("  ", paramArrayList, false);
                paramArrayList.close();
              }
              mBackStack.add(paramParcelable);
              if (mIndex >= 0) {
                setBackStackIndex(mIndex, paramParcelable);
              }
              i += 1;
            }
          }
          mBackStack = null;
          if (mIndex < 0) {
            return;
          }
          mIndex = ((Fragment)mActive.get(mIndex));
          return;
        }
        paramParcelable = null;
      }
    }
  }
  
  ArrayList retainNonConfig()
  {
    int i;
    java.lang.Object localObject1;
    java.lang.Object localObject2;
    java.lang.Object localObject4;
    java.lang.Object localObject3;
    java.lang.Object localObject5;
    int j;
    if (mActive != null)
    {
      i = 0;
      localObject1 = null;
      localObject2 = null;
      localObject4 = localObject2;
      localObject3 = localObject1;
      if (i >= mActive.size()) {
        break label300;
      }
      Fragment localFragment = (Fragment)mActive.get(i);
      localObject4 = localObject2;
      localObject5 = localObject1;
      if (localFragment != null)
      {
        localObject3 = localObject2;
        if (mRetainInstance)
        {
          localObject4 = localObject2;
          if (localObject2 == null) {
            localObject4 = new java.util.ArrayList();
          }
          ((java.util.ArrayList)localObject4).add(localFragment);
          mRetaining = true;
          if (mTarget == null) {
            break label227;
          }
        }
        label227:
        for (j = mTarget.mIndex;; j = -1)
        {
          mTargetIndex = j;
          localObject3 = localObject4;
          if (DEBUG)
          {
            Log.v("FragmentManager", "retainNonConfig: keeping retained " + localFragment);
            localObject3 = localObject4;
          }
          if (mChildFragmentManager == null) {
            break label324;
          }
          localObject4 = mChildFragmentManager.retainNonConfig();
          if (localObject4 == null) {
            break label324;
          }
          localObject2 = localObject1;
          if (localObject1 != null) {
            break;
          }
          localObject1 = new java.util.ArrayList();
          j = 0;
          for (;;)
          {
            localObject2 = localObject1;
            if (j >= i) {
              break;
            }
            ((java.util.ArrayList)localObject1).add(null);
            j += 1;
          }
        }
        localObject2.add(localObject4);
        j = 1;
        localObject1 = localObject2;
      }
    }
    for (;;)
    {
      localObject4 = localObject3;
      localObject5 = localObject1;
      if (localObject1 != null)
      {
        localObject4 = localObject3;
        localObject5 = localObject1;
        if (j == 0)
        {
          ((java.util.ArrayList)localObject1).add(null);
          localObject5 = localObject1;
          localObject4 = localObject3;
        }
      }
      i += 1;
      localObject2 = localObject4;
      localObject1 = localObject5;
      break;
      localObject3 = null;
      localObject4 = null;
      label300:
      if ((localObject4 == null) && (localObject3 == null)) {
        return null;
      }
      return new ArrayList((List)localObject4, localObject3);
      label324:
      j = 0;
    }
  }
  
  Parcelable saveAllState()
  {
    java.lang.Object localObject3 = null;
    a();
    dump();
    execPendingActions();
    if (HONEYCOMB) {
      mStateSaved = true;
    }
    if (mActive != null)
    {
      if (mActive.size() <= 0) {
        return null;
      }
      int n = mActive.size();
      FragmentState[] arrayOfFragmentState = new FragmentState[n];
      int i = 0;
      int j = 0;
      java.lang.Object localObject1;
      java.lang.Object localObject2;
      if (i < n)
      {
        localObject1 = (Fragment)mActive.get(i);
        if (localObject1 == null) {
          break label749;
        }
        if (mIndex < 0) {
          throwException(new IllegalStateException("Failure saving state: active " + localObject1 + " has cleared index: " + mIndex));
        }
        localObject2 = new FragmentState((Fragment)localObject1);
        arrayOfFragmentState[i] = localObject2;
        if ((mState > 0) && (mSavedFragmentState == null))
        {
          mSavedFragmentState = saveFragmentBasicState((Fragment)localObject1);
          if (mTarget != null)
          {
            if (mTarget.mIndex < 0) {
              throwException(new IllegalStateException("Failure saving state: " + localObject1 + " has target not in fragment manager: " + mTarget));
            }
            if (mSavedFragmentState == null) {
              mSavedFragmentState = new Bundle();
            }
            putFragment(mSavedFragmentState, "android:target_state", mTarget);
            if (mTargetRequestCode != 0) {
              mSavedFragmentState.putInt("android:target_req_state", mTargetRequestCode);
            }
          }
          label311:
          if (DEBUG) {
            Log.v("FragmentManager", "Saved state of " + localObject1 + ": " + mSavedFragmentState);
          }
          j = 1;
        }
      }
      label749:
      for (;;)
      {
        i += 1;
        break;
        mSavedFragmentState = mSavedFragmentState;
        break label311;
        if (j == 0)
        {
          if (!DEBUG) {
            break label752;
          }
          Log.v("FragmentManager", "saveAllState: no fragments!");
          return null;
        }
        if (mAdded != null)
        {
          j = mAdded.size();
          if (j > 0)
          {
            localObject2 = new int[j];
            i = 0;
            for (;;)
            {
              localObject1 = localObject2;
              if (i >= j) {
                break;
              }
              localObject2[i] = mAdded.get(i)).mIndex;
              if (localObject2[i] < 0) {
                throwException(new IllegalStateException("Failure saving state: active " + mAdded.get(i) + " has cleared index: " + localObject2[i]));
              }
              if (DEBUG) {
                Log.v("FragmentManager", "saveAllState: adding fragment #" + i + ": " + mAdded.get(i));
              }
              i += 1;
            }
          }
        }
        localObject1 = null;
        localObject2 = localObject3;
        if (mBackStack != null)
        {
          j = mBackStack.size();
          localObject2 = localObject3;
          if (j > 0)
          {
            localObject3 = new BackStackState[j];
            i = 0;
            for (;;)
            {
              localObject2 = localObject3;
              if (i >= j) {
                break;
              }
              localObject3[i] = new BackStackState((b)mBackStack.get(i));
              if (DEBUG) {
                Log.v("FragmentManager", "saveAllState: adding back stack #" + i + ": " + mBackStack.get(i));
              }
              i += 1;
            }
          }
        }
        localObject3 = new FragmentManagerState();
        mActive = arrayOfFragmentState;
        mAdded = ((int[])localObject1);
        mBackStack = ((BackStackState[])localObject2);
        if (mIndex != null) {
          mIndex = mIndex.mIndex;
        }
        return localObject3;
      }
    }
    label752:
    return null;
  }
  
  Bundle saveFragmentBasicState(Fragment paramFragment)
  {
    if (mStateBundle == null) {
      mStateBundle = new Bundle();
    }
    paramFragment.performSaveInstanceState(mStateBundle);
    a(paramFragment, mStateBundle, false);
    java.lang.Object localObject1;
    if (!mStateBundle.isEmpty())
    {
      localObject1 = mStateBundle;
      mStateBundle = null;
    }
    java.lang.Object localObject2;
    for (;;)
    {
      if (mView != null) {
        saveFragmentViewState(paramFragment);
      }
      localObject2 = localObject1;
      if (mSavedViewState != null)
      {
        localObject2 = localObject1;
        if (localObject1 == null) {
          localObject2 = new Bundle();
        }
        ((Bundle)localObject2).putSparseParcelableArray("android:view_state", mSavedViewState);
      }
      if (mUserVisibleHint) {
        break;
      }
      localObject1 = localObject2;
      if (localObject2 == null) {
        localObject1 = new Bundle();
      }
      ((Bundle)localObject1).putBoolean("android:user_visible_hint", mUserVisibleHint);
      return localObject1;
      localObject1 = null;
    }
    return localObject2;
  }
  
  void saveFragmentViewState(Fragment paramFragment)
  {
    if (mInnerView == null) {
      return;
    }
    if (mStateArray == null) {
      mStateArray = new SparseArray();
    }
    for (;;)
    {
      mInnerView.saveHierarchyState(mStateArray);
      if (mStateArray.size() <= 0) {
        break;
      }
      mSavedViewState = mStateArray;
      mStateArray = null;
      return;
      mStateArray.clear();
    }
  }
  
  /* Error */
  public void setBackStackIndex(int paramInt, b paramB)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 818	android/support/v4/app/FragmentManagerImpl:mBackStackIndices	Ljava/util/ArrayList;
    //   6: ifnonnull +14 -> 20
    //   9: aload_0
    //   10: new 123	java/util/ArrayList
    //   13: dup
    //   14: invokespecial 144	java/util/ArrayList:<init>	()V
    //   17: putfield 818	android/support/v4/app/FragmentManagerImpl:mBackStackIndices	Ljava/util/ArrayList;
    //   20: aload_0
    //   21: getfield 818	android/support/v4/app/FragmentManagerImpl:mBackStackIndices	Ljava/util/ArrayList;
    //   24: invokevirtual 197	java/util/ArrayList:size	()I
    //   27: istore 4
    //   29: iload 4
    //   31: istore_3
    //   32: iload_1
    //   33: iload 4
    //   35: if_icmpge +59 -> 94
    //   38: getstatic 77	android/support/v4/app/FragmentManagerImpl:DEBUG	Z
    //   41: ifeq +40 -> 81
    //   44: ldc_w 521
    //   47: new 214	java/lang/StringBuilder
    //   50: dup
    //   51: invokespecial 215	java/lang/StringBuilder:<init>	()V
    //   54: ldc_w 1538
    //   57: invokevirtual 221	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: iload_1
    //   61: invokevirtual 901	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   64: ldc_w 1540
    //   67: invokevirtual 221	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   70: aload_2
    //   71: invokevirtual 663	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   74: invokevirtual 225	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   77: invokestatic 666	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   80: pop
    //   81: aload_0
    //   82: getfield 818	android/support/v4/app/FragmentManagerImpl:mBackStackIndices	Ljava/util/ArrayList;
    //   85: iload_1
    //   86: aload_2
    //   87: invokevirtual 896	java/util/ArrayList:set	(ILjava/lang/Object;)Ljava/lang/Object;
    //   90: pop
    //   91: aload_0
    //   92: monitorexit
    //   93: return
    //   94: iload_3
    //   95: iload_1
    //   96: if_icmpge +82 -> 178
    //   99: aload_0
    //   100: getfield 818	android/support/v4/app/FragmentManagerImpl:mBackStackIndices	Ljava/util/ArrayList;
    //   103: aconst_null
    //   104: invokevirtual 151	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   107: pop
    //   108: aload_0
    //   109: getfield 822	android/support/v4/app/FragmentManagerImpl:mAvailBackStackIndices	Ljava/util/ArrayList;
    //   112: ifnonnull +14 -> 126
    //   115: aload_0
    //   116: new 123	java/util/ArrayList
    //   119: dup
    //   120: invokespecial 144	java/util/ArrayList:<init>	()V
    //   123: putfield 822	android/support/v4/app/FragmentManagerImpl:mAvailBackStackIndices	Ljava/util/ArrayList;
    //   126: getstatic 77	android/support/v4/app/FragmentManagerImpl:DEBUG	Z
    //   129: ifeq +30 -> 159
    //   132: ldc_w 521
    //   135: new 214	java/lang/StringBuilder
    //   138: dup
    //   139: invokespecial 215	java/lang/StringBuilder:<init>	()V
    //   142: ldc_w 1542
    //   145: invokevirtual 221	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: iload_3
    //   149: invokevirtual 901	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   152: invokevirtual 225	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   155: invokestatic 666	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   158: pop
    //   159: aload_0
    //   160: getfield 822	android/support/v4/app/FragmentManagerImpl:mAvailBackStackIndices	Ljava/util/ArrayList;
    //   163: iload_3
    //   164: invokestatic 904	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   167: invokevirtual 151	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   170: pop
    //   171: iload_3
    //   172: iconst_1
    //   173: iadd
    //   174: istore_3
    //   175: goto -81 -> 94
    //   178: getstatic 77	android/support/v4/app/FragmentManagerImpl:DEBUG	Z
    //   181: ifeq +40 -> 221
    //   184: ldc_w 521
    //   187: new 214	java/lang/StringBuilder
    //   190: dup
    //   191: invokespecial 215	java/lang/StringBuilder:<init>	()V
    //   194: ldc_w 1544
    //   197: invokevirtual 221	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   200: iload_1
    //   201: invokevirtual 901	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   204: ldc_w 1546
    //   207: invokevirtual 221	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   210: aload_2
    //   211: invokevirtual 663	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   214: invokevirtual 225	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   217: invokestatic 666	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   220: pop
    //   221: aload_0
    //   222: getfield 818	android/support/v4/app/FragmentManagerImpl:mBackStackIndices	Ljava/util/ArrayList;
    //   225: aload_2
    //   226: invokevirtual 151	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   229: pop
    //   230: goto -139 -> 91
    //   233: astore_2
    //   234: aload_0
    //   235: monitorexit
    //   236: aload_2
    //   237: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	238	0	this	FragmentManagerImpl
    //   0	238	1	paramInt	int
    //   0	238	2	paramB	b
    //   31	144	3	i	int
    //   27	9	4	j	int
    // Exception table:
    //   from	to	target	type
    //   2	20	233	java/lang/Throwable
    //   20	29	233	java/lang/Throwable
    //   38	81	233	java/lang/Throwable
    //   81	91	233	java/lang/Throwable
    //   91	93	233	java/lang/Throwable
    //   99	126	233	java/lang/Throwable
    //   126	159	233	java/lang/Throwable
    //   159	171	233	java/lang/Throwable
    //   178	221	233	java/lang/Throwable
    //   221	230	233	java/lang/Throwable
    //   234	236	233	java/lang/Throwable
  }
  
  public void showFragment(Fragment paramFragment)
  {
    boolean bool = false;
    if (DEBUG) {
      Log.v("FragmentManager", "show: " + paramFragment);
    }
    if (mHidden)
    {
      mHidden = false;
      if (!mNeedMenuInvalidate) {
        bool = true;
      }
      mNeedMenuInvalidate = bool;
    }
  }
  
  void startPendingDeferredFragments()
  {
    if (mActive == null) {
      return;
    }
    int i = 0;
    while (i < mActive.size())
    {
      Fragment localFragment = (Fragment)mActive.get(i);
      if (localFragment != null) {
        performPendingDeferredStart(localFragment);
      }
      i += 1;
    }
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append("FragmentManager{");
    localStringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    localStringBuilder.append(" in ");
    if (mParent != null) {
      DebugUtils.buildShortClassTag(mParent, localStringBuilder);
    }
    for (;;)
    {
      localStringBuilder.append("}}");
      return localStringBuilder.toString();
      DebugUtils.buildShortClassTag(mHost, localStringBuilder);
    }
  }
  
  void toString(Fragment paramFragment, Context paramContext, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).toString(paramFragment, paramContext, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).getId(this, paramFragment, paramContext);
      }
    }
  }
  
  void toString(Fragment paramFragment, boolean paramBoolean)
  {
    if (mParent != null)
    {
      localObject = mParent.getId();
      if ((localObject instanceof FragmentManagerImpl)) {
        ((FragmentManagerImpl)localObject).toString(paramFragment, true);
      }
    }
    if (k == null) {
      return;
    }
    java.lang.Object localObject = k.iterator();
    while (((Iterator)localObject).hasNext())
    {
      Label localLabel = (Label)((Iterator)localObject).next();
      if ((!paramBoolean) || (((Boolean)c).booleanValue())) {
        ((l)b).getId(this, paramFragment);
      }
    }
  }
  
  class AnimateOnHWLayerIfNeededListener
    implements Animation.AnimationListener
  {
    private Animation.AnimationListener mOrignalListener;
    private boolean mShouldRunOnHWLayer;
    
    public AnimateOnHWLayerIfNeededListener(Animation paramAnimation)
    {
      if (FragmentManagerImpl.this != null) {
        if (paramAnimation == null) {
          return;
        }
      }
    }
    
    public AnimateOnHWLayerIfNeededListener(Animation paramAnimation, Animation.AnimationListener paramAnimationListener)
    {
      if (FragmentManagerImpl.this != null)
      {
        if (paramAnimation == null) {
          return;
        }
        mOrignalListener = paramAnimationListener;
        mShouldRunOnHWLayer = true;
      }
    }
    
    public void onAnimationEnd(Animation paramAnimation)
    {
      if ((FragmentManagerImpl.this != null) && (mShouldRunOnHWLayer))
      {
        if ((!ViewCompat.isAttachedToWindow(FragmentManagerImpl.this)) && (!android.support.v4.os.Handler.a())) {
          break label64;
        }
        post(new o.a.1(this));
      }
      while (mOrignalListener != null)
      {
        mOrignalListener.onAnimationEnd(paramAnimation);
        return;
        label64:
        setLayerType(0, null);
      }
    }
    
    public void onAnimationRepeat(Animation paramAnimation)
    {
      if (mOrignalListener != null) {
        mOrignalListener.onAnimationRepeat(paramAnimation);
      }
    }
    
    public void onAnimationStart(Animation paramAnimation)
    {
      if (mOrignalListener != null) {
        mOrignalListener.onAnimationStart(paramAnimation);
      }
    }
  }
  
  class FragmentTag
  {
    public static final int[] Fragment = { 16842755, 16842960, 16842961 };
  }
}

package android.support.v4.app;

import android.graphics.Rect;
import android.support.v4.util.ArrayMap;
import android.view.View;
import java.util.ArrayList;

final class a
  implements Runnable
{
  a(ArrayMap paramArrayMap, Object paramObject1, m paramM, ArrayList paramArrayList1, View paramView, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean, ArrayList paramArrayList2, Object paramObject2, Rect paramRect) {}
  
  public void run()
  {
    Object localObject = f.add(j, k, a);
    if (localObject != null)
    {
      r.addAll(((ArrayMap)localObject).values());
      r.add(g);
    }
    f.set(h, i, e, (ArrayMap)localObject, false);
    if (k != null)
    {
      Label.a(k, b, r);
      localObject = f.a((ArrayMap)localObject, a, d, e);
      if (localObject != null) {
        Label.setText((View)localObject, c);
      }
    }
  }
}

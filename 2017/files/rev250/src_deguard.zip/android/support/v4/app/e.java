package android.support.v4.app;

final class e
{
  Fragment a;
  int b;
  int d;
  int enterAnim;
  int exitAnim;
  int i;
  
  e() {}
  
  e(int paramInt, Fragment paramFragment)
  {
    b = paramInt;
    a = paramFragment;
  }
}

package android.support.v4.app;

import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class Object
{
  public Object() {}
  
  public abstract void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract boolean popBackStackImmediate();
}

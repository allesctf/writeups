package android.support.constraint;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.support.constraint.asm.asm.AnchorPosition;
import android.support.constraint.asm.asm.ClassWriter;
import android.support.constraint.asm.asm.c;
import android.support.constraint.asm.asm.f;
import android.support.constraint.asm.asm.h;
import android.support.constraint.asm.asm.i;
import android.support.constraint.asm.asm.m;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import java.util.ArrayList;

public class ConstraintLayout
  extends ViewGroup
{
  private Plot a = null;
  ClassWriter b = new ClassWriter();
  private boolean c = true;
  private int e = 2;
  private int f = 0;
  private int g = Integer.MAX_VALUE;
  private int h = 0;
  private int j = Integer.MAX_VALUE;
  SparseArray<View> v = new SparseArray();
  private final ArrayList<android.support.constraint.a.a.b> x = new ArrayList(100);
  
  public ConstraintLayout(Context paramContext)
  {
    super(paramContext);
    a(null);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    a(paramAttributeSet);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    a(paramAttributeSet);
  }
  
  private final h a(int paramInt)
  {
    if (paramInt == 0) {
      return b;
    }
    View localView = (View)v.get(paramInt);
    if (localView == this) {
      return b;
    }
    if (localView == null) {
      return null;
    }
    return getLayoutParamsa;
  }
  
  private final h a(View paramView)
  {
    if (paramView == this) {
      return b;
    }
    if (paramView == null) {
      return null;
    }
    return getLayoutParamsa;
  }
  
  private void a()
  {
    if (a != null) {
      a.a(this);
    }
    int i10 = getChildCount();
    b.close();
    int i5 = 0;
    Object localObject2;
    Object localObject1;
    a localA;
    label212:
    int n;
    int i1;
    int i2;
    int i3;
    int m;
    int i4;
    float f1;
    int i8;
    int i9;
    int i6;
    int i7;
    float f2;
    int i;
    int k;
    if (i5 < i10)
    {
      localObject2 = getChildAt(i5);
      localObject1 = a((View)localObject2);
      if (localObject1 == null) {}
      do
      {
        for (;;)
        {
          i5 += 1;
          break;
          localA = (a)((View)localObject2).getLayoutParams();
          ((h)localObject1).init();
          ((h)localObject1).putShort(((View)localObject2).getVisibility());
          ((h)localObject1).a(localObject2);
          b.c((h)localObject1);
          if ((!bottomMargin) || (!height)) {
            x.add(localObject1);
          }
          if (!p) {
            break label212;
          }
          localObject1 = (m)localObject1;
          if (y != -1) {
            ((m)localObject1).add(y);
          }
          if (type != -1) {
            ((m)localObject1).getIcon(type);
          }
          if (width != -1.0F) {
            ((m)localObject1).d(width);
          }
        }
      } while ((g == -1) && (f == -1) && (e == -1) && (q == -1) && (B == -1) && (A == -1) && (j == -1) && (k == -1) && (i == -1) && (d == -1) && (x == -1) && (width != -1) && (height != -1));
      n = g;
      i1 = f;
      i2 = e;
      i3 = q;
      m = b;
      i4 = l;
      f1 = Q;
      if (Build.VERSION.SDK_INT >= 17) {
        break label1528;
      }
      m = h;
      n = H;
      i8 = V;
      i9 = C;
      i6 = c;
      i7 = u;
      f2 = z;
      i = m;
      k = n;
      if (m == -1)
      {
        i = m;
        k = n;
        if (n == -1)
        {
          if (n == -1) {
            break label1178;
          }
          i = n;
          k = n;
        }
      }
      label478:
      m = i6;
      f1 = f2;
      n = i;
      i1 = k;
      i2 = i8;
      i3 = i9;
      i4 = i7;
      if (i8 != -1) {
        break label1528;
      }
      m = i6;
      f1 = f2;
      n = i;
      i1 = k;
      i2 = i8;
      i3 = i9;
      i4 = i7;
      if (i9 != -1) {
        break label1528;
      }
      if (w != -1)
      {
        i2 = w;
        i4 = i7;
        i3 = i9;
        f1 = f2;
        m = i6;
      }
    }
    for (;;)
    {
      label570:
      if (i != -1)
      {
        localObject2 = a(i);
        if (localObject2 != null) {
          ((h)localObject1).a(f.c, (h)localObject2, f.c, leftMargin, m);
        }
        label607:
        if (i2 == -1) {
          break label1307;
        }
        localObject2 = a(i2);
        if (localObject2 != null) {
          ((h)localObject1).a(f.i, (h)localObject2, f.c, rightMargin, i4);
        }
        label646:
        if (B == -1) {
          break label1349;
        }
        localObject2 = a(B);
        if (localObject2 != null) {
          ((h)localObject1).a(f.a, (h)localObject2, f.a, topMargin, t);
        }
        label694:
        if (j == -1) {
          break label1400;
        }
        localObject2 = a(j);
        if (localObject2 != null) {
          ((h)localObject1).a(f.b, (h)localObject2, f.a, bottomMargin, F);
        }
        label742:
        if (i != -1)
        {
          Object localObject3 = (View)v.get(i);
          localObject2 = a(i);
          if ((localObject2 != null) && (localObject3 != null) && ((((View)localObject3).getLayoutParams() instanceof a)))
          {
            localObject3 = (a)((View)localObject3).getLayoutParams();
            gravity = true;
            gravity = true;
            ((h)localObject1).a(f.r).a(((h)localObject2).a(f.r), 0, -1, AnchorPosition.c, 0, true);
            ((h)localObject1).a(f.a).a();
            ((h)localObject1).a(f.b).a();
          }
        }
        if ((f1 >= 0.0F) && (f1 != 0.5F)) {
          ((h)localObject1).a(f1);
        }
        if ((P >= 0.0F) && (P != 0.5F)) {
          ((h)localObject1).b(P);
        }
        if ((isInEditMode()) && ((d != -1) || (x != -1))) {
          ((h)localObject1).h(d, x);
        }
        if (height) {
          break label1468;
        }
        if (width != -1) {
          break label1451;
        }
        ((h)localObject1).b(c.d);
        aci = leftMargin;
        aii = rightMargin;
        label1020:
        if (bottomMargin) {
          break label1506;
        }
        if (height != -1) {
          break label1489;
        }
        ((h)localObject1).a(c.d);
        aai = topMargin;
        abi = bottomMargin;
      }
      for (;;)
      {
        if (s != null) {
          ((h)localObject1).b(s);
        }
        ((h)localObject1).c(top);
        ((h)localObject1).append(bottom);
        ((h)localObject1).setIcon(length);
        ((h)localObject1).getItem(next);
        ((h)localObject1).a(left, v, r);
        ((h)localObject1).b(size, L, N);
        break;
        label1178:
        i = m;
        k = n;
        if (o == -1) {
          break label478;
        }
        k = o;
        i = m;
        break label478;
        m = i6;
        f1 = f2;
        n = i;
        i1 = k;
        i2 = i8;
        i3 = i9;
        i4 = i7;
        if (m == -1) {
          break label1528;
        }
        i3 = m;
        m = i6;
        f1 = f2;
        i2 = i8;
        i4 = i7;
        break label570;
        if (k == -1) {
          break label607;
        }
        localObject2 = a(k);
        if (localObject2 == null) {
          break label607;
        }
        ((h)localObject1).a(f.c, (h)localObject2, f.i, leftMargin, m);
        break label607;
        label1307:
        if (i3 == -1) {
          break label646;
        }
        localObject2 = a(i3);
        if (localObject2 == null) {
          break label646;
        }
        ((h)localObject1).a(f.i, (h)localObject2, f.i, rightMargin, i4);
        break label646;
        label1349:
        if (A == -1) {
          break label694;
        }
        localObject2 = a(A);
        if (localObject2 == null) {
          break label694;
        }
        ((h)localObject1).a(f.a, (h)localObject2, f.b, topMargin, t);
        break label694;
        label1400:
        if (k == -1) {
          break label742;
        }
        localObject2 = a(k);
        if (localObject2 == null) {
          break label742;
        }
        ((h)localObject1).a(f.b, (h)localObject2, f.b, bottomMargin, F);
        break label742;
        label1451:
        ((h)localObject1).b(c.c);
        ((h)localObject1).c(0);
        break label1020;
        label1468:
        ((h)localObject1).b(c.a);
        ((h)localObject1).c(width);
        break label1020;
        label1489:
        ((h)localObject1).a(c.c);
        ((h)localObject1).e(0);
        continue;
        label1506:
        ((h)localObject1).a(c.a);
        ((h)localObject1).e(height);
      }
      return;
      label1528:
      i = n;
      k = i1;
    }
  }
  
  private void a(int paramInt1, int paramInt2)
  {
    int i2 = View.MeasureSpec.getMode(paramInt1);
    int k = View.MeasureSpec.getSize(paramInt1);
    paramInt1 = k;
    int m = View.MeasureSpec.getMode(paramInt2);
    int i = View.MeasureSpec.getSize(paramInt2);
    paramInt2 = i;
    int n = getPaddingTop();
    int i1 = getPaddingBottom();
    int i3 = getPaddingLeft();
    int i4 = getPaddingRight();
    c localC1 = c.a;
    c localC2 = c.a;
    getLayoutParams();
    switch (i2)
    {
    default: 
      paramInt1 = 0;
      switch (m)
      {
      default: 
        paramInt2 = 0;
      }
      break;
    }
    for (;;)
    {
      b.setEnabled(0);
      b.g(0);
      b.b(localC1);
      b.c(paramInt1);
      b.a(localC2);
      b.e(paramInt2);
      b.setEnabled(f - getPaddingLeft() - getPaddingRight());
      b.g(h - getPaddingTop() - getPaddingBottom());
      return;
      localC1 = c.b;
      break;
      localC1 = c.b;
      paramInt1 = 0;
      break;
      paramInt1 = Math.min(g, k) - (i3 + i4);
      break;
      localC2 = c.b;
      continue;
      localC2 = c.b;
      paramInt2 = 0;
      continue;
      paramInt2 = Math.min(j, i) - (n + i1);
    }
  }
  
  private void a(AttributeSet paramAttributeSet)
  {
    b.a(this);
    v.put(getId(), this);
    a = null;
    if (paramAttributeSet != null)
    {
      paramAttributeSet = getContext().obtainStyledAttributes(paramAttributeSet, Mixed.1.ConstraintLayout_Layout);
      int k = paramAttributeSet.getIndexCount();
      int i = 0;
      if (i < k)
      {
        int m = paramAttributeSet.getIndex(i);
        if (m == Mixed.1.ConstraintLayout_Layout_android_minWidth) {
          f = paramAttributeSet.getDimensionPixelOffset(m, f);
        }
        for (;;)
        {
          i += 1;
          break;
          if (m == Mixed.1.ConstraintLayout_Layout_android_minHeight)
          {
            h = paramAttributeSet.getDimensionPixelOffset(m, h);
          }
          else if (m == Mixed.1.ConstraintLayout_Layout_android_maxWidth)
          {
            g = paramAttributeSet.getDimensionPixelOffset(m, g);
          }
          else if (m == Mixed.1.ConstraintLayout_Layout_android_maxHeight)
          {
            j = paramAttributeSet.getDimensionPixelOffset(m, j);
          }
          else if (m == Mixed.1.ConstraintLayout_Layout_layout_optimizationLevel)
          {
            e = paramAttributeSet.getInt(m, e);
          }
          else if (m == Mixed.1.ConstraintLayout_Layout_constraintSet)
          {
            m = paramAttributeSet.getResourceId(m, 0);
            a = new Plot();
            a.a(getContext(), m);
          }
        }
      }
      paramAttributeSet.recycle();
    }
    b.put(e);
  }
  
  private void b()
  {
    int m = 0;
    int n = getChildCount();
    int i = 0;
    for (;;)
    {
      int k = m;
      if (i < n)
      {
        if (getChildAt(i).isLayoutRequested()) {
          k = 1;
        }
      }
      else
      {
        if (k == 0) {
          break;
        }
        x.clear();
        a();
        return;
      }
      i += 1;
    }
  }
  
  private void measureHorizontal(int paramInt1, int paramInt2)
  {
    int i4 = getPaddingTop() + getPaddingBottom();
    int i5 = getPaddingLeft() + getPaddingRight();
    int i6 = getChildCount();
    int m = 0;
    View localView;
    a localA;
    h localH;
    int n;
    int k;
    int i;
    label174:
    int i1;
    int i3;
    int i2;
    if (m < i6)
    {
      localView = getChildAt(m);
      if (localView.getVisibility() == 8) {}
      do
      {
        m += 1;
        break;
        localA = (a)localView.getLayoutParams();
        localH = a;
      } while (p);
      n = width;
      k = height;
      if ((height) || (bottomMargin) || ((!height) && (left == 1)) || (width == -1) || ((!bottomMargin) && ((size == 1) || (height == -1))))
      {
        i = 1;
        i1 = 0;
        i3 = 0;
        i2 = 0;
        if (i == 0) {
          break label365;
        }
        if ((n != 0) && (n != -1)) {
          break label332;
        }
        i = 1;
        n = ViewGroup.getChildMeasureSpec(paramInt1, i5, -2);
        label210:
        if ((k != 0) && (k != -1)) {
          break label347;
        }
        i1 = ViewGroup.getChildMeasureSpec(paramInt2, i4, -2);
        k = 1;
        label234:
        localView.measure(n, i1);
        n = localView.getMeasuredWidth();
        i2 = localView.getMeasuredHeight();
        i1 = i;
        i = i2;
      }
    }
    for (;;)
    {
      localH.c(n);
      localH.e(i);
      if (i1 != 0) {
        localH.d(n);
      }
      if (k != 0) {
        localH.update(i);
      }
      if (!gravity) {
        break;
      }
      i = localView.getBaseline();
      if (i == -1) {
        break;
      }
      localH.measure(i);
      break;
      i = 0;
      break label174;
      label332:
      n = ViewGroup.getChildMeasureSpec(paramInt1, i5, n);
      i = 0;
      break label210;
      label347:
      i1 = ViewGroup.getChildMeasureSpec(paramInt2, i4, k);
      k = i2;
      break label234;
      return;
      label365:
      i = k;
      k = i3;
    }
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams)
  {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (Build.VERSION.SDK_INT < 14) {
      onViewAdded(paramView);
    }
  }
  
  public a applyFont(AttributeSet paramAttributeSet)
  {
    return new a(getContext(), paramAttributeSet);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return paramLayoutParams instanceof a;
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return new a(paramLayoutParams);
  }
  
  public int getMaxHeight()
  {
    return j;
  }
  
  public int getMaxWidth()
  {
    return g;
  }
  
  public int getMinHeight()
  {
    return h;
  }
  
  public int getMinWidth()
  {
    return f;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramInt2 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt1 = 0;
    if (paramInt1 < paramInt2)
    {
      View localView = getChildAt(paramInt1);
      Object localObject = (a)localView.getLayoutParams();
      if ((localView.getVisibility() == 8) && (!p) && (!paramBoolean)) {}
      for (;;)
      {
        paramInt1 += 1;
        break;
        localObject = a;
        paramInt3 = ((h)localObject).e();
        paramInt4 = ((h)localObject).length();
        localView.layout(paramInt3, paramInt4, ((h)localObject).getValue() + paramInt3, ((h)localObject).get() + paramInt4);
      }
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int k = getPaddingLeft();
    int n = getPaddingTop();
    b.b(k);
    b.a(n);
    a(paramInt1, paramInt2);
    if (c)
    {
      c = false;
      b();
    }
    measureHorizontal(paramInt1, paramInt2);
    if (getChildCount() > 0) {
      visitFrame();
    }
    int m = 0;
    int i = 0;
    int i4 = x.size();
    int i5 = n + getPaddingBottom();
    int i6 = k + getPaddingRight();
    int i1;
    label141:
    label144:
    h localH;
    label188:
    label194:
    View localView;
    a localA;
    label258:
    int i3;
    if (i4 > 0)
    {
      k = 0;
      int i2;
      if (b.i() == c.b)
      {
        n = 1;
        if (b.getIcon() != c.b) {
          break label188;
        }
        i1 = 1;
        i2 = 0;
        if (i2 >= i4) {
          break label572;
        }
        localH = (h)x.get(i2);
        if (!(localH instanceof m)) {
          break label194;
        }
      }
      do
      {
        i2 += 1;
        break label144;
        n = 0;
        break;
        i1 = 0;
        break label141;
        localView = (View)localH.getView();
      } while ((localView == null) || (localView.getVisibility() == 8));
      localA = (a)localView.getLayoutParams();
      if (width == -2)
      {
        m = ViewGroup.getChildMeasureSpec(paramInt1, i6, width);
        if (height != -2) {
          break label556;
        }
        i3 = ViewGroup.getChildMeasureSpec(paramInt2, i5, height);
        label281:
        localView.measure(m, i3);
        m = localView.getMeasuredWidth();
        i3 = localView.getMeasuredHeight();
        if (m == localH.getValue()) {
          break label722;
        }
        localH.c(m);
        if ((n != 0) && (localH.d() > b.getValue()))
        {
          k = localH.d();
          m = localH.a(f.i).b();
          b.c(Math.max(f, k + m));
        }
        k = 1;
      }
    }
    label556:
    label572:
    label722:
    for (;;)
    {
      m = k;
      if (i3 != localH.get())
      {
        localH.e(i3);
        if ((i1 != 0) && (localH.setTitle() > b.get()))
        {
          k = localH.setTitle();
          m = localH.a(f.b).b();
          b.e(Math.max(h, k + m));
        }
        m = 1;
      }
      k = m;
      if (gravity)
      {
        i3 = localView.getBaseline();
        k = m;
        if (i3 != -1)
        {
          k = m;
          if (i3 != localH.isVisible())
          {
            localH.measure(i3);
            k = 1;
          }
        }
      }
      if (Build.VERSION.SDK_INT >= 11)
      {
        i = View.combineMeasuredStates(i, localView.getMeasuredState());
        break;
        m = View.MeasureSpec.makeMeasureSpec(localH.getValue(), 1073741824);
        break label258;
        i3 = View.MeasureSpec.makeMeasureSpec(localH.get(), 1073741824);
        break label281;
        m = i;
        if (k != 0)
        {
          visitFrame();
          m = i;
        }
        i = b.getValue() + i6;
        k = b.get() + i5;
        if (Build.VERSION.SDK_INT >= 11)
        {
          paramInt1 = View.resolveSizeAndState(i, paramInt1, m);
          paramInt2 = View.resolveSizeAndState(k, paramInt2, m << 16);
          paramInt1 = Math.min(g, paramInt1);
          i = Math.min(j, paramInt2);
          paramInt2 = paramInt1 & 0xFFFFFF;
          i &= 0xFFFFFF;
          paramInt1 = paramInt2;
          if (b.put()) {
            paramInt1 = paramInt2 | 0x1000000;
          }
          paramInt2 = i;
          if (b.getPaddingBottom()) {
            paramInt2 = i | 0x1000000;
          }
          setMeasuredDimension(paramInt1, paramInt2);
          return;
        }
        setMeasuredDimension(i, k);
        return;
      }
      break;
    }
  }
  
  public void onViewAdded(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 14) {
      super.onViewAdded(paramView);
    }
    Object localObject = a(paramView);
    if (((paramView instanceof ViewStubCompat)) && (!(localObject instanceof m)))
    {
      localObject = (a)paramView.getLayoutParams();
      a = new m();
      p = true;
      ((m)a).setTitle(color);
      localObject = a;
    }
    v.put(paramView.getId(), paramView);
    c = true;
  }
  
  public void onViewRemoved(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 14) {
      super.onViewRemoved(paramView);
    }
    v.remove(paramView.getId());
    b.b(a(paramView));
    c = true;
  }
  
  protected a putShort()
  {
    return new a(-2, -2);
  }
  
  public void removeView(View paramView)
  {
    super.removeView(paramView);
    if (Build.VERSION.SDK_INT < 14) {
      onViewRemoved(paramView);
    }
  }
  
  public void requestLayout()
  {
    super.requestLayout();
    c = true;
  }
  
  public void setConstraintSet(Plot paramPlot)
  {
    a = paramPlot;
  }
  
  public void setId(int paramInt)
  {
    v.remove(getId());
    super.setId(paramInt);
    v.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt)
  {
    if (paramInt == j) {
      return;
    }
    j = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt)
  {
    if (paramInt == g) {
      return;
    }
    g = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt)
  {
    if (paramInt == h) {
      return;
    }
    h = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt)
  {
    if (paramInt == f) {
      return;
    }
    f = paramInt;
    requestLayout();
  }
  
  public void setOptimizationLevel(int paramInt)
  {
    b.put(paramInt);
  }
  
  protected void visitFrame()
  {
    b.a();
  }
  
  public static class a
    extends ViewGroup.MarginLayoutParams
  {
    public int A = -1;
    public int B = -1;
    public int C = -1;
    public int F = -1;
    public int H = -1;
    public int L = 0;
    public int N = 0;
    public float P = 0.5F;
    float Q = 0.5F;
    public int V = -1;
    h a = new h();
    int b = -1;
    public float bottom = 0.0F;
    boolean bottomMargin = true;
    public int c = -1;
    public int color = -1;
    public int d = -1;
    int e = -1;
    int f = -1;
    int g = -1;
    boolean gravity = false;
    public int h = -1;
    boolean height = true;
    public int i = -1;
    int index = 1;
    public int j = -1;
    public int k = -1;
    int l = -1;
    public int left = 0;
    public int length = 0;
    public int m = -1;
    public int max = -1;
    public int min = -1;
    public int n = -1;
    public int next = 0;
    public int o = -1;
    boolean p = false;
    int q = -1;
    public int r = 0;
    public String s = null;
    public int size = 0;
    public int t = -1;
    public float top = 0.0F;
    public int type = -1;
    public int u = -1;
    public int v = 0;
    float value = 0.0F;
    public int w = -1;
    public float width = -1.0F;
    public int x = -1;
    public int y = -1;
    public float z = 0.5F;
    
    public a(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }
    
    public a(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, Mixed.1.ConstraintLayout_Layout);
      int i3 = paramContext.getIndexCount();
      int i1 = 0;
      if (i1 < i3)
      {
        int i2 = paramContext.getIndex(i1);
        if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf)
        {
          h = paramContext.getResourceId(i2, h);
          if (h == -1) {
            h = paramContext.getInt(i2, -1);
          }
        }
        for (;;)
        {
          i1 += 1;
          break;
          if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintLeft_toRightOf)
          {
            H = paramContext.getResourceId(i2, H);
            if (H == -1) {
              H = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintRight_toLeftOf)
          {
            V = paramContext.getResourceId(i2, V);
            if (V == -1) {
              V = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintRight_toRightOf)
          {
            C = paramContext.getResourceId(i2, C);
            if (C == -1) {
              C = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintTop_toTopOf)
          {
            B = paramContext.getResourceId(i2, B);
            if (B == -1) {
              B = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintTop_toBottomOf)
          {
            A = paramContext.getResourceId(i2, A);
            if (A == -1) {
              A = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintBottom_toTopOf)
          {
            j = paramContext.getResourceId(i2, j);
            if (j == -1) {
              j = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf)
          {
            k = paramContext.getResourceId(i2, k);
            if (k == -1) {
              k = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf)
          {
            i = paramContext.getResourceId(i2, i);
            if (i == -1) {
              i = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_editor_absoluteX)
          {
            d = paramContext.getDimensionPixelOffset(i2, d);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_editor_absoluteY)
          {
            x = paramContext.getDimensionPixelOffset(i2, x);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintGuide_begin)
          {
            y = paramContext.getDimensionPixelOffset(i2, y);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintGuide_end)
          {
            type = paramContext.getDimensionPixelOffset(i2, type);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintGuide_percent)
          {
            width = paramContext.getFloat(i2, width);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_android_orientation)
          {
            color = paramContext.getInt(i2, color);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintStart_toEndOf)
          {
            o = paramContext.getResourceId(i2, o);
            if (o == -1) {
              o = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintStart_toStartOf)
          {
            n = paramContext.getResourceId(i2, n);
            if (n == -1) {
              n = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintEnd_toStartOf)
          {
            w = paramContext.getResourceId(i2, w);
            if (w == -1) {
              w = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintEnd_toEndOf)
          {
            m = paramContext.getResourceId(i2, m);
            if (m == -1) {
              m = paramContext.getInt(i2, -1);
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_goneMarginLeft)
          {
            c = paramContext.getDimensionPixelSize(i2, c);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_goneMarginTop)
          {
            t = paramContext.getDimensionPixelSize(i2, t);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_goneMarginRight)
          {
            u = paramContext.getDimensionPixelSize(i2, u);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_goneMarginBottom)
          {
            F = paramContext.getDimensionPixelSize(i2, F);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_goneMarginStart)
          {
            max = paramContext.getDimensionPixelSize(i2, max);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_goneMarginEnd)
          {
            min = paramContext.getDimensionPixelSize(i2, min);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintHorizontal_bias)
          {
            z = paramContext.getFloat(i2, z);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintVertical_bias)
          {
            P = paramContext.getFloat(i2, P);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintDimensionRatio)
          {
            s = paramContext.getString(i2);
            value = NaN.0F;
            index = -1;
            if (s != null)
            {
              int i4 = s.length();
              i2 = s.indexOf(',');
              if ((i2 > 0) && (i2 < i4 - 1))
              {
                paramAttributeSet = s.substring(0, i2);
                if (paramAttributeSet.equalsIgnoreCase("W"))
                {
                  index = 0;
                  label1334:
                  i2 += 1;
                }
              }
              float f2;
              for (;;)
              {
                int i5 = s.indexOf(':');
                if ((i5 < 0) || (i5 >= i4 - 1)) {
                  break label1502;
                }
                paramAttributeSet = s.substring(i2, i5);
                String str = s.substring(i5 + 1);
                if ((paramAttributeSet.length() <= 0) || (str.length() <= 0)) {
                  break;
                }
                try
                {
                  f1 = Float.parseFloat(paramAttributeSet);
                  f2 = Float.parseFloat(str);
                  if ((f1 <= 0.0F) || (f2 <= 0.0F)) {
                    break;
                  }
                  if (index != 1) {
                    break label1484;
                  }
                  f1 = f2 / f1;
                  f1 = Math.abs(f1);
                  value = f1;
                }
                catch (NumberFormatException paramAttributeSet) {}
                break;
                if (!paramAttributeSet.equalsIgnoreCase("H")) {
                  break label1334;
                }
                index = 1;
                break label1334;
                i2 = 0;
              }
              label1484:
              f1 /= f2;
              float f1 = Math.abs(f1);
              value = f1;
              continue;
              label1502:
              paramAttributeSet = s.substring(i2);
              if (paramAttributeSet.length() > 0) {
                try
                {
                  f1 = Float.parseFloat(paramAttributeSet);
                  value = f1;
                }
                catch (NumberFormatException paramAttributeSet) {}
              }
            }
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintHorizontal_weight)
          {
            top = paramContext.getFloat(i2, 0.0F);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintVertical_weight)
          {
            bottom = paramContext.getFloat(i2, 0.0F);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle)
          {
            length = paramContext.getInt(i2, 0);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintVertical_chainStyle)
          {
            next = paramContext.getInt(i2, 0);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintWidth_default)
          {
            left = paramContext.getInt(i2, 0);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintHeight_default)
          {
            size = paramContext.getInt(i2, 0);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintWidth_min)
          {
            v = paramContext.getDimensionPixelSize(i2, v);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintWidth_max)
          {
            r = paramContext.getDimensionPixelSize(i2, r);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintHeight_min)
          {
            L = paramContext.getDimensionPixelSize(i2, L);
          }
          else if (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintHeight_max)
          {
            N = paramContext.getDimensionPixelSize(i2, N);
          }
          else if ((i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintLeft_creator) || (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintTop_creator) || (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintRight_creator) || (i2 == Mixed.1.ConstraintLayout_Layout_layout_constraintBottom_creator) || (i2 != Mixed.1.ConstraintLayout_Layout_layout_constraintBaseline_creator)) {}
        }
      }
      paramContext.recycle();
      a();
    }
    
    public a(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public void a()
    {
      p = false;
      height = true;
      bottomMargin = true;
      if ((width == 0) || (width == -1)) {
        height = false;
      }
      if ((height == 0) || (height == -1)) {
        bottomMargin = false;
      }
      if ((width != -1.0F) || (y != -1) || (type != -1))
      {
        p = true;
        height = true;
        bottomMargin = true;
        if (!(a instanceof m)) {
          a = new m();
        }
        ((m)a).setTitle(color);
      }
    }
    
    public int getLayoutDirection()
    {
      throw new Error("Unresolved compilation error: Method <android.support.constraint.ConstraintLayout$a: int getLayoutDirection()> does not exist!");
    }
    
    public void resolveLayoutDirection(int paramInt)
    {
      int i1 = 1;
      super.resolveLayoutDirection(paramInt);
      e = -1;
      q = -1;
      g = -1;
      f = -1;
      b = -1;
      l = -1;
      b = c;
      l = u;
      Q = z;
      if (1 == getLayoutDirection())
      {
        paramInt = i1;
        if (paramInt == 0) {
          break label254;
        }
        if (o == -1) {
          break label235;
        }
        e = o;
        label91:
        if (w != -1) {
          f = w;
        }
        if (m != -1) {
          g = m;
        }
        if (max != -1) {
          l = max;
        }
        if (min != -1) {
          b = min;
        }
        Q = (1.0F - z);
        label165:
        if ((w == -1) && (m == -1))
        {
          if (V == -1) {
            break label353;
          }
          e = V;
        }
      }
      for (;;)
      {
        if ((n == -1) && (o == -1))
        {
          if (h != -1)
          {
            g = h;
            return;
            paramInt = 0;
            break;
            label235:
            if (n == -1) {
              break label91;
            }
            q = n;
            break label91;
            label254:
            if (o != -1) {
              f = o;
            }
            if (n != -1) {
              g = n;
            }
            if (w != -1) {
              e = w;
            }
            if (m != -1) {
              q = m;
            }
            if (max != -1) {
              b = max;
            }
            if (min == -1) {
              break label165;
            }
            l = min;
            break label165;
            label353:
            if (C == -1) {
              continue;
            }
            q = C;
            continue;
          }
          if (H != -1) {
            f = H;
          }
        }
      }
    }
    
    public void setMarginEnd(int paramInt)
    {
      throw new Error("Unresolved compilation error: Method <android.support.constraint.ConstraintLayout$a: void setMarginEnd(int)> does not exist!");
    }
    
    public void setMarginStart(int paramInt)
    {
      throw new Error("Unresolved compilation error: Method <android.support.constraint.ConstraintLayout$a: void setMarginStart(int)> does not exist!");
    }
  }
}

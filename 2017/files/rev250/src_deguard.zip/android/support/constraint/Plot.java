package android.support.constraint;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class Plot
{
  private static final int[] i = { 0, 4, 8 };
  private static SparseIntArray screenDim = new SparseIntArray();
  private HashMap<Integer, a.a> c = new HashMap();
  
  static
  {
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintLeft_toLeftOf, 25);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintLeft_toRightOf, 26);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintRight_toLeftOf, 29);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintRight_toRightOf, 30);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintTop_toTopOf, 36);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintTop_toBottomOf, 35);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintBottom_toTopOf, 4);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintBottom_toBottomOf, 3);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintBaseline_toBaselineOf, 1);
    screenDim.append(Mixed.1.ConstraintSet_layout_editor_absoluteX, 6);
    screenDim.append(Mixed.1.ConstraintSet_layout_editor_absoluteY, 7);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintGuide_begin, 17);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintGuide_end, 18);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintGuide_percent, 19);
    screenDim.append(Mixed.1.ConstraintSet_android_orientation, 27);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintStart_toEndOf, 32);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintStart_toStartOf, 33);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintEnd_toStartOf, 10);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintEnd_toEndOf, 9);
    screenDim.append(Mixed.1.ConstraintSet_layout_goneMarginLeft, 13);
    screenDim.append(Mixed.1.ConstraintSet_layout_goneMarginTop, 16);
    screenDim.append(Mixed.1.ConstraintSet_layout_goneMarginRight, 14);
    screenDim.append(Mixed.1.ConstraintSet_layout_goneMarginBottom, 11);
    screenDim.append(Mixed.1.ConstraintSet_layout_goneMarginStart, 15);
    screenDim.append(Mixed.1.ConstraintSet_layout_goneMarginEnd, 12);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintVertical_weight, 40);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintHorizontal_weight, 39);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintHorizontal_chainStyle, 41);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintVertical_chainStyle, 42);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintHorizontal_bias, 20);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintVertical_bias, 37);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintDimensionRatio, 5);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintLeft_creator, 60);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintTop_creator, 60);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintRight_creator, 60);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintBottom_creator, 60);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintBaseline_creator, 60);
    screenDim.append(Mixed.1.ConstraintSet_android_layout_marginLeft, 24);
    screenDim.append(Mixed.1.ConstraintSet_android_layout_marginRight, 28);
    screenDim.append(Mixed.1.ConstraintSet_android_layout_marginStart, 31);
    screenDim.append(Mixed.1.ConstraintSet_android_layout_marginEnd, 8);
    screenDim.append(Mixed.1.ConstraintSet_android_layout_marginTop, 34);
    screenDim.append(Mixed.1.ConstraintSet_android_layout_marginBottom, 2);
    screenDim.append(Mixed.1.ConstraintSet_android_layout_width, 23);
    screenDim.append(Mixed.1.ConstraintSet_android_layout_height, 21);
    screenDim.append(Mixed.1.ConstraintSet_android_visibility, 22);
    screenDim.append(Mixed.1.ConstraintSet_android_alpha, 43);
    screenDim.append(Mixed.1.ConstraintSet_android_elevation, 44);
    screenDim.append(Mixed.1.ConstraintSet_android_rotationX, 45);
    screenDim.append(Mixed.1.ConstraintSet_android_rotationY, 46);
    screenDim.append(Mixed.1.ConstraintSet_android_scaleX, 47);
    screenDim.append(Mixed.1.ConstraintSet_android_scaleY, 48);
    screenDim.append(Mixed.1.ConstraintSet_android_transformPivotX, 49);
    screenDim.append(Mixed.1.ConstraintSet_android_transformPivotY, 50);
    screenDim.append(Mixed.1.ConstraintSet_android_translationX, 51);
    screenDim.append(Mixed.1.ConstraintSet_android_translationY, 52);
    screenDim.append(Mixed.1.ConstraintSet_android_translationZ, 53);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintWidth_default, 54);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintHeight_default, 55);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintWidth_max, 56);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintHeight_max, 57);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintWidth_min, 58);
    screenDim.append(Mixed.1.ConstraintSet_layout_constraintHeight_min, 59);
    screenDim.append(Mixed.1.ConstraintSet_android_id, 38);
  }
  
  public Plot() {}
  
  private R.id a(Context paramContext, AttributeSet paramAttributeSet)
  {
    R.id localId = new R.id(null);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, Mixed.1.ConstraintSet);
    onDraw(localId, paramContext);
    paramContext.recycle();
    return localId;
  }
  
  private void onDraw(R.id paramId, TypedArray paramTypedArray)
  {
    int k = paramTypedArray.getIndexCount();
    int j = 0;
    if (j < k)
    {
      int m = paramTypedArray.getIndex(j);
      switch (screenDim.get(m))
      {
      default: 
        break;
      case 54: 
      case 55: 
      case 56: 
      case 57: 
      case 58: 
      case 59: 
        Log.w("ConstraintSet", "Unknown attribute 0x" + Integer.toHexString(m) + "   " + screenDim.get(m));
      }
      for (;;)
      {
        j += 1;
        break;
        d = valueOf(paramTypedArray, m, d);
        continue;
        e = valueOf(paramTypedArray, m, e);
        continue;
        b = valueOf(paramTypedArray, m, b);
        continue;
        color = valueOf(paramTypedArray, m, color);
        continue;
        points = valueOf(paramTypedArray, m, points);
        continue;
        path = valueOf(paramTypedArray, m, path);
        continue;
        count = valueOf(paramTypedArray, m, count);
        continue;
        text = valueOf(paramTypedArray, m, text);
        continue;
        size = valueOf(paramTypedArray, m, size);
        continue;
        p = paramTypedArray.getDimensionPixelOffset(m, p);
        continue;
        t = paramTypedArray.getDimensionPixelOffset(m, t);
        continue;
        x = paramTypedArray.getDimensionPixelOffset(m, x);
        continue;
        h = paramTypedArray.getDimensionPixelOffset(m, h);
        continue;
        paint = paramTypedArray.getFloat(m, paint);
        continue;
        y = paramTypedArray.getInt(m, y);
        continue;
        value = valueOf(paramTypedArray, m, value);
        continue;
        position = valueOf(paramTypedArray, m, position);
        continue;
        length = valueOf(paramTypedArray, m, length);
        continue;
        count = valueOf(paramTypedArray, m, data);
        continue;
        radius = paramTypedArray.getDimensionPixelSize(m, radius);
        continue;
        u = paramTypedArray.getDimensionPixelSize(m, u);
        continue;
        v = paramTypedArray.getDimensionPixelSize(m, v);
        continue;
        mOffset = paramTypedArray.getDimensionPixelSize(m, mOffset);
        continue;
        mPaint = paramTypedArray.getDimensionPixelSize(m, mPaint);
        continue;
        mRadius = paramTypedArray.getDimensionPixelSize(m, mRadius);
        continue;
        w = paramTypedArray.getFloat(m, w);
        continue;
        index = paramTypedArray.getFloat(m, index);
        continue;
        height = paramTypedArray.getDimensionPixelSize(m, height);
        continue;
        pos = paramTypedArray.getDimensionPixelSize(m, pos);
        continue;
        n = paramTypedArray.getDimensionPixelSize(m, n);
        continue;
        min = paramTypedArray.getDimensionPixelSize(m, min);
        continue;
        max = paramTypedArray.getDimensionPixelSize(m, max);
        continue;
        flags = paramTypedArray.getDimensionPixelSize(m, flags);
        continue;
        id = paramTypedArray.getLayoutDimension(m, id);
        continue;
        type = paramTypedArray.getLayoutDimension(m, type);
        continue;
        a = paramTypedArray.getInt(m, a);
        a = i[a];
        continue;
        k = paramTypedArray.getFloat(m, k);
        continue;
        o = true;
        j = paramTypedArray.getFloat(m, j);
        continue;
        l = paramTypedArray.getFloat(m, l);
        continue;
        m = paramTypedArray.getFloat(m, m);
        continue;
        i = paramTypedArray.getFloat(m, i);
        continue;
        r = paramTypedArray.getFloat(m, r);
        continue;
        right = paramTypedArray.getFloat(m, right);
        continue;
        top = paramTypedArray.getFloat(m, top);
        continue;
        bottom = paramTypedArray.getFloat(m, bottom);
        continue;
        width = paramTypedArray.getFloat(m, width);
        continue;
        left = paramTypedArray.getFloat(m, left);
        continue;
        mTextSize = paramTypedArray.getFloat(m, mTextSize);
        continue;
        mText = paramTypedArray.getFloat(m, mText);
        continue;
        mMax = paramTypedArray.getInt(m, mMax);
        continue;
        mProgress = paramTypedArray.getInt(m, mProgress);
        continue;
        f = paramTypedArray.getResourceId(m, f);
        continue;
        s = paramTypedArray.getString(m);
        continue;
        Log.w("ConstraintSet", "unused attribute 0x" + Integer.toHexString(m) + "   " + screenDim.get(m));
      }
    }
  }
  
  private static int valueOf(TypedArray paramTypedArray, int paramInt1, int paramInt2)
  {
    paramInt2 = paramTypedArray.getResourceId(paramInt1, paramInt2);
    if (paramInt2 == -1) {
      return paramTypedArray.getInt(paramInt1, -1);
    }
    return paramInt2;
  }
  
  public void a(Context paramContext, int paramInt)
  {
    XmlResourceParser localXmlResourceParser = paramContext.getResources().getXml(paramInt);
    for (;;)
    {
      try
      {
        paramInt = localXmlResourceParser.getEventType();
        if (paramInt == 1) {
          return;
        }
        switch (paramInt)
        {
        }
      }
      catch (XmlPullParserException paramContext)
      {
        paramContext.printStackTrace();
        return;
        Object localObject = localXmlResourceParser.getName();
        R.id localId = a(paramContext, Xml.asAttributeSet(localXmlResourceParser));
        boolean bool = ((String)localObject).equalsIgnoreCase("Guideline");
        if (!bool) {
          continue;
        }
        c = true;
        localObject = c;
        paramInt = f;
        ((HashMap)localObject).put(Integer.valueOf(paramInt), localId);
        continue;
      }
      catch (IOException paramContext)
      {
        ((IOException)paramContext).printStackTrace();
      }
      paramInt = localXmlResourceParser.next();
      continue;
      localXmlResourceParser.getName();
    }
  }
  
  void a(ConstraintLayout paramConstraintLayout)
  {
    int k = paramConstraintLayout.getChildCount();
    Object localObject1 = new HashSet(c.keySet());
    int j = 0;
    Object localObject2;
    Object localObject3;
    Object localObject4;
    while (j < k)
    {
      localObject2 = paramConstraintLayout.getChildAt(j);
      int m = ((View)localObject2).getId();
      if (c.containsKey(Integer.valueOf(m)))
      {
        ((HashSet)localObject1).remove(Integer.valueOf(m));
        localObject3 = (R.id)c.get(Integer.valueOf(m));
        localObject4 = (ConstraintLayout.a)((View)localObject2).getLayoutParams();
        ((R.id)localObject3).init((ConstraintLayout.a)localObject4);
        ((View)localObject2).setLayoutParams((ViewGroup.LayoutParams)localObject4);
        ((View)localObject2).setVisibility(a);
        if (Build.VERSION.SDK_INT >= 17)
        {
          ((View)localObject2).setAlpha(k);
          ((View)localObject2).setRotationX(l);
          ((View)localObject2).setRotationY(m);
          ((View)localObject2).setScaleX(i);
          ((View)localObject2).setScaleY(r);
          ((View)localObject2).setPivotX(right);
          ((View)localObject2).setPivotY(top);
          ((View)localObject2).setTranslationX(bottom);
          ((View)localObject2).setTranslationY(width);
          if (Build.VERSION.SDK_INT >= 21)
          {
            ((View)localObject2).setTranslationZ(left);
            if (o) {
              ((View)localObject2).setElevation(j);
            }
          }
        }
      }
      j += 1;
    }
    localObject1 = ((HashSet)localObject1).iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject4 = (Integer)((Iterator)localObject1).next();
      localObject2 = (R.id)c.get(localObject4);
      if (c)
      {
        localObject3 = new ViewStubCompat(paramConstraintLayout.getContext());
        ((View)localObject3).setId(((Integer)localObject4).intValue());
        localObject4 = paramConstraintLayout.putShort();
        ((R.id)localObject2).init((ConstraintLayout.a)localObject4);
        paramConstraintLayout.addView((View)localObject3, (ViewGroup.LayoutParams)localObject4);
      }
    }
  }
}

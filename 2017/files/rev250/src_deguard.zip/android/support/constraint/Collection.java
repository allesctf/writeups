package android.support.constraint;

public final class Collection {}

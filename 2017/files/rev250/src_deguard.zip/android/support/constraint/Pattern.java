package android.support.constraint;

class Pattern {}

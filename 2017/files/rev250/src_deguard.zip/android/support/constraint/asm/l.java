package android.support.constraint.asm;

abstract interface l<T>
{
  public abstract Object a();
  
  public abstract void a(Object[] paramArrayOfObject, int paramInt);
  
  public abstract boolean a(Object paramObject);
}

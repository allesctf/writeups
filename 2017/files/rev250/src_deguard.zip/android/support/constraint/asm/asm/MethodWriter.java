package android.support.constraint.asm.asm;

class MethodWriter
{
  private i b;
  private AnchorPosition c;
  private int g;
  private int j;
  private i l;
  
  public MethodWriter(i paramI)
  {
    b = paramI;
    l = paramI.size();
    j = paramI.b();
    c = paramI.e();
    g = paramI.l();
  }
  
  public void a(h paramH)
  {
    b = paramH.a(b.q());
    if (b != null)
    {
      l = b.size();
      j = b.b();
      c = b.e();
      g = b.l();
      return;
    }
    l = null;
    j = 0;
    c = AnchorPosition.c;
    g = 0;
  }
  
  public void b(h paramH)
  {
    paramH.a(b.q()).a(l, j, c, g);
  }
}

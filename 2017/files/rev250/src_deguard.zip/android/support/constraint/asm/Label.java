package android.support.constraint.asm;

import java.util.Arrays;

public class Label
{
  private static int line = 1;
  public float a;
  c b;
  public int c = -1;
  float[] e = new float[6];
  int f = 0;
  Item[] g = new Item[8];
  private String h;
  int i = -1;
  public int k = 0;
  
  public Label(c paramC)
  {
    b = paramC;
  }
  
  void a()
  {
    int j = 0;
    while (j < 6)
    {
      e[j] = 0.0F;
      j += 1;
    }
  }
  
  void a(Item paramItem)
  {
    int m = 0;
    int j = 0;
    while (j < f)
    {
      if (g[j] == paramItem)
      {
        while (m < f - j - 1)
        {
          g[(j + m)] = g[(j + m + 1)];
          m += 1;
        }
        f -= 1;
        return;
      }
      j += 1;
    }
  }
  
  public void a(c paramC)
  {
    b = paramC;
  }
  
  public void b()
  {
    h = null;
    b = c.b;
    k = 0;
    c = -1;
    i = -1;
    a = 0.0F;
    f = 0;
  }
  
  void b(Item paramItem)
  {
    int j = 0;
    while (j < f)
    {
      if (g[j] == paramItem) {
        return;
      }
      j += 1;
    }
    if (f >= g.length) {
      g = ((Item[])Arrays.copyOf(g, g.length * 2));
    }
    g[f] = paramItem;
    f += 1;
  }
  
  String normalize()
  {
    String str = this + "[";
    int j = 0;
    if (j < e.length)
    {
      str = str + e[j];
      if (j < e.length - 1) {}
      for (str = str + ", ";; str = str + "] ")
      {
        j += 1;
        break;
      }
    }
    return str;
  }
  
  public String toString()
  {
    return "" + h;
  }
}

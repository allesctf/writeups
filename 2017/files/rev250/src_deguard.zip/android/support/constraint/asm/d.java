package android.support.constraint.asm;

import android.support.constraint.a.g;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class d
{
  private static int b = 1000;
  private int a = 0;
  int c = 1;
  private Item[] e = new Item[n];
  private h g = new h();
  final f i;
  private Item[] j = null;
  private boolean[] k = new boolean[n];
  private int l = n;
  private HashMap<String, g> m = null;
  private int n = 32;
  private Label[] q = new Label[b];
  private int r = n;
  private int s = 0;
  int x = 0;
  
  public d()
  {
    j();
    i = new f();
  }
  
  private int a(h paramH)
  {
    int i1 = 0;
    while (i1 < c)
    {
      k[i1] = false;
      i1 += 1;
    }
    int i2 = 0;
    int i3 = 0;
    i1 = 0;
    int i6;
    Label localLabel;
    if (i1 == 0)
    {
      i6 = i3 + 1;
      localLabel = paramH.a();
      i3 = i2;
      if (localLabel == null) {
        break label376;
      }
      if (k[c] != 0) {
        localLabel = null;
      }
    }
    for (;;)
    {
      if (localLabel != null)
      {
        int i4 = -1;
        float f1 = Float.MAX_VALUE;
        i3 = 0;
        label94:
        Item localItem;
        if (i3 < a)
        {
          localItem = j[i3];
          float f2;
          int i5;
          if (c.b == c.c)
          {
            f2 = f1;
            i5 = i4;
          }
          for (;;)
          {
            i3 += 1;
            i4 = i5;
            f1 = f2;
            break label94;
            k[c] = true;
            i2 += 1;
            i3 = i2;
            if (i2 < c) {
              break label376;
            }
            i1 = 1;
            break;
            i5 = i4;
            f2 = f1;
            if (localItem.b(localLabel))
            {
              float f3 = b.b(localLabel);
              i5 = i4;
              f2 = f1;
              if (f3 < 0.0F)
              {
                f3 = -a / f3;
                i5 = i4;
                f2 = f1;
                if (f3 < f1)
                {
                  i5 = i3;
                  f2 = f3;
                }
              }
            }
          }
        }
        if (i4 > -1)
        {
          localItem = j[i4];
          c.i = -1;
          localItem.a(localLabel);
          c.i = i4;
          i3 = 0;
          while (i3 < a)
          {
            j[i3].a(localItem);
            i3 += 1;
          }
          paramH.a(this);
        }
      }
      for (;;)
      {
        try
        {
          b(paramH);
          i3 = i6;
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
          continue;
        }
        i1 = 1;
        continue;
        i1 = 1;
      }
      return i3;
      label376:
      i2 = i3;
    }
  }
  
  public static Item a(d paramD, Label paramLabel1, Label paramLabel2, int paramInt1, float paramFloat, Label paramLabel3, Label paramLabel4, int paramInt2, boolean paramBoolean)
  {
    Item localItem = paramD.a();
    localItem.a(paramLabel1, paramLabel2, paramInt1, paramFloat, paramLabel3, paramLabel4, paramInt2);
    if (paramBoolean)
    {
      paramLabel1 = paramD.d();
      paramD = paramD.d();
      k = 4;
      k = 4;
      localItem.a(paramLabel1, paramD);
    }
    return localItem;
  }
  
  public static Item a(d paramD, Label paramLabel1, Label paramLabel2, int paramInt, boolean paramBoolean)
  {
    Label localLabel = paramD.c();
    Item localItem = paramD.a();
    localItem.b(paramLabel1, paramLabel2, localLabel, paramInt);
    if (paramBoolean) {
      paramD.a(localItem, (int)(b.b(localLabel) * -1.0F));
    }
    return localItem;
  }
  
  public static Item a(d paramD, Label paramLabel1, Label paramLabel2, Label paramLabel3, float paramFloat, boolean paramBoolean)
  {
    Item localItem = paramD.a();
    if (paramBoolean) {
      paramD.c(localItem);
    }
    return localItem.a(paramLabel1, paramLabel2, paramLabel3, paramFloat);
  }
  
  private Label a(c paramC)
  {
    Object localObject = (Label)i.c.a();
    if (localObject == null) {}
    for (paramC = new Label(paramC);; paramC = (c)localObject)
    {
      if (s >= b)
      {
        b *= 2;
        q = ((Label[])Arrays.copyOf(q, b));
      }
      localObject = q;
      int i1 = s;
      s = (i1 + 1);
      localObject[i1] = paramC;
      return paramC;
      ((Label)localObject).b();
      ((Label)localObject).a(paramC);
    }
  }
  
  private void a(Item paramItem, int paramInt)
  {
    paramItem.setTitle(d(), paramInt);
  }
  
  private int b(h paramH)
  {
    int i1 = 0;
    if (i1 < a)
    {
      if (j[i1].c.b == c.c) {}
      while (j[i1].a >= 0.0F)
      {
        i1 += 1;
        break;
      }
    }
    int i2;
    for (i1 = 1;; i1 = 0)
    {
      int i7;
      int i9;
      float f1;
      int i3;
      int i4;
      label99:
      Item localItem;
      int i8;
      int i6;
      int i5;
      float f2;
      if (i1 != 0)
      {
        i7 = 0;
        i1 = 0;
        i2 = i1;
        if (i7 != 0) {
          break label413;
        }
        i9 = i1 + 1;
        f1 = Float.MAX_VALUE;
        i1 = 0;
        i2 = -1;
        i3 = -1;
        i4 = 0;
        if (i4 < a)
        {
          localItem = j[i4];
          if (c.b == c.c)
          {
            i8 = i3;
            i6 = i2;
            i5 = i1;
            f2 = f1;
          }
        }
      }
      for (;;)
      {
        i4 += 1;
        f1 = f2;
        i1 = i5;
        i2 = i6;
        i3 = i8;
        break label99;
        f2 = f1;
        i5 = i1;
        i6 = i2;
        i8 = i3;
        if (a < 0.0F)
        {
          i5 = 1;
          label195:
          if (i5 < c)
          {
            Label localLabel = i.b[i5];
            float f3 = b.b(localLabel);
            if (f3 <= 0.0F) {}
            for (;;)
            {
              i5 += 1;
              break label195;
              i6 = 0;
              label247:
              if (i6 < 6)
              {
                f2 = e[i6] / f3;
                if (((f2 < f1) && (i6 == i1)) || (i6 > i1))
                {
                  i3 = i5;
                  i2 = i4;
                  i1 = i6;
                  f1 = f2;
                }
                for (;;)
                {
                  i6 += 1;
                  break label247;
                  if (i2 != -1)
                  {
                    localItem = j[i2];
                    c.i = -1;
                    localItem.a(i.b[i3]);
                    c.i = i2;
                    i1 = 0;
                    while (i1 < a)
                    {
                      j[i1].a(localItem);
                      i1 += 1;
                    }
                    paramH.a(this);
                  }
                  for (;;)
                  {
                    i1 = i9;
                    break;
                    i7 = 1;
                  }
                  i2 = 0;
                  label413:
                  i1 = 0;
                  if (i1 >= a) {
                    break label500;
                  }
                  if (j[i1].c.b == c.c) {}
                  while (j[i1].a >= 0.0F)
                  {
                    i1 += 1;
                    break;
                  }
                  return i2;
                }
              }
            }
          }
          f2 = f1;
          i5 = i1;
          i6 = i2;
          i8 = i3;
        }
      }
    }
    label500:
    return i2;
  }
  
  public static Item b(d paramD, Label paramLabel1, Label paramLabel2, int paramInt, boolean paramBoolean)
  {
    Label localLabel = paramD.c();
    Item localItem = paramD.a();
    localItem.a(paramLabel1, paramLabel2, localLabel, paramInt);
    if (paramBoolean) {
      paramD.a(localItem, (int)(b.b(localLabel) * -1.0F));
    }
    return localItem;
  }
  
  private void b(Item paramItem)
  {
    if (a > 0)
    {
      b.a(paramItem, j);
      if (b.i == 0) {
        e = true;
      }
    }
  }
  
  public static Item c(d paramD, Label paramLabel1, Label paramLabel2, int paramInt, boolean paramBoolean)
  {
    Item localItem = paramD.a();
    localItem.a(paramLabel1, paramLabel2, paramInt);
    if (paramBoolean) {
      paramD.a(localItem, 1);
    }
    return localItem;
  }
  
  private void c(Item paramItem)
  {
    paramItem.a(d(), d());
  }
  
  private void g()
  {
    n *= 2;
    j = ((Item[])Arrays.copyOf(j, n));
    i.b = ((Label[])Arrays.copyOf(i.b, n));
    k = new boolean[n];
    l = n;
    r = n;
    g.j.clear();
  }
  
  private void j()
  {
    int i1 = 0;
    while (i1 < j.length)
    {
      Item localItem = j[i1];
      if (localItem != null) {
        i.n.a(localItem);
      }
      j[i1] = null;
      i1 += 1;
    }
  }
  
  private void visitMaxs()
  {
    int i1 = 0;
    while (i1 < a)
    {
      Item localItem = j[i1];
      c.a = a;
      i1 += 1;
    }
  }
  
  public Item a()
  {
    Item localItem = (Item)i.n.a();
    if (localItem == null) {
      return new Item(i);
    }
    localItem.d();
    return localItem;
  }
  
  public Item a(Label paramLabel1, Label paramLabel2, int paramInt1, int paramInt2)
  {
    Item localItem = a();
    localItem.a(paramLabel1, paramLabel2, paramInt1);
    paramLabel1 = d();
    paramLabel2 = d();
    k = paramInt2;
    k = paramInt2;
    localItem.a(paramLabel1, paramLabel2);
    a(localItem);
    return localItem;
  }
  
  public Label a(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    if (c + 1 >= l) {
      g();
    }
    Label localLabel1;
    if ((paramObject instanceof android.support.constraint.asm.asm.i))
    {
      Label localLabel2 = ((android.support.constraint.asm.asm.i)paramObject).m();
      localLabel1 = localLabel2;
      if (localLabel2 == null)
      {
        ((android.support.constraint.asm.asm.i)paramObject).a(i);
        localLabel1 = ((android.support.constraint.asm.asm.i)paramObject).m();
      }
      if ((c == -1) || (c > x) || (i.b[c] == null))
      {
        if (c != -1) {
          localLabel1.b();
        }
        x += 1;
        c += 1;
        c = x;
        b = c.c;
        i.b[x] = localLabel1;
        return localLabel1;
      }
    }
    else
    {
      return null;
    }
    return localLabel1;
  }
  
  public void a(Item paramItem)
  {
    int i3 = 0;
    if (paramItem == null) {
      return;
    }
    if ((a + 1 >= r) || (c + 1 >= l)) {
      g();
    }
    if (!e)
    {
      b(paramItem);
      paramItem.clear();
      paramItem.setTitle();
      if (!paramItem.c()) {}
    }
    else
    {
      if (j[a] != null) {
        i.n.a(j[a]);
      }
      if (!e) {
        paramItem.b();
      }
      j[a] = paramItem;
      c.i = a;
      a += 1;
      int i4 = c.f;
      if (i4 > 0)
      {
        while (e.length < i4) {
          e = new Item[e.length * 2];
        }
        Item[] arrayOfItem = e;
        int i1 = 0;
        int i2;
        for (;;)
        {
          i2 = i3;
          if (i1 >= i4) {
            break;
          }
          arrayOfItem[i1] = c.g[i1];
          i1 += 1;
        }
        if (i2 < i4)
        {
          Item localItem = arrayOfItem[i2];
          if (localItem == paramItem) {}
          for (;;)
          {
            i2 += 1;
            break;
            b.a(localItem, paramItem);
            localItem.b();
          }
        }
      }
    }
  }
  
  public void a(Label paramLabel, int paramInt)
  {
    int i1 = i;
    if (i != -1)
    {
      localItem = j[i1];
      if (e)
      {
        a = paramInt;
        return;
      }
      localItem = a();
      localItem.a(paramLabel, paramInt);
      a(localItem);
      return;
    }
    Item localItem = a();
    localItem.b(paramLabel, paramInt);
    a(localItem);
  }
  
  public void a(Label paramLabel1, Label paramLabel2, int paramInt1, float paramFloat, Label paramLabel3, Label paramLabel4, int paramInt2, int paramInt3)
  {
    Item localItem = a();
    localItem.a(paramLabel1, paramLabel2, paramInt1, paramFloat, paramLabel3, paramLabel4, paramInt2);
    paramLabel1 = d();
    paramLabel2 = d();
    k = paramInt3;
    k = paramInt3;
    localItem.a(paramLabel1, paramLabel2);
    a(localItem);
  }
  
  public int b(Object paramObject)
  {
    paramObject = ((android.support.constraint.asm.asm.i)paramObject).m();
    if (paramObject != null) {
      return (int)(a + 0.5F);
    }
    return 0;
  }
  
  Item b(int paramInt)
  {
    return j[paramInt];
  }
  
  public void b()
  {
    int i1 = 0;
    while (i1 < i.b.length)
    {
      Label localLabel = i.b[i1];
      if (localLabel != null) {
        localLabel.b();
      }
      i1 += 1;
    }
    i.c.a(q, s);
    s = 0;
    Arrays.fill(i.b, null);
    if (m != null) {
      m.clear();
    }
    x = 0;
    g.j.clear();
    c = 1;
    i1 = 0;
    while (i1 < a)
    {
      j[i1].i = false;
      i1 += 1;
    }
    j();
    a = 0;
  }
  
  public void b(Label paramLabel1, Label paramLabel2, int paramInt1, int paramInt2)
  {
    Item localItem = a();
    Label localLabel = c();
    k = paramInt2;
    localItem.b(paramLabel1, paramLabel2, localLabel, paramInt1);
    a(localItem);
  }
  
  public Label c()
  {
    if (c + 1 >= l) {
      g();
    }
    Label localLabel = a(c.a);
    x += 1;
    c += 1;
    c = x;
    i.b[x] = localLabel;
    return localLabel;
  }
  
  public void c(Label paramLabel1, Label paramLabel2, int paramInt1, int paramInt2)
  {
    Item localItem = a();
    Label localLabel = c();
    k = paramInt2;
    localItem.a(paramLabel1, paramLabel2, localLabel, paramInt1);
    a(localItem);
  }
  
  void c(h paramH)
  {
    paramH.a(this);
    b(paramH);
    a(paramH);
    visitMaxs();
  }
  
  public Label d()
  {
    if (c + 1 >= l) {
      g();
    }
    Label localLabel = a(c.f);
    x += 1;
    c += 1;
    c = x;
    i.b[x] = localLabel;
    return localLabel;
  }
  
  public void e()
  {
    c(g);
  }
  
  public f f()
  {
    return i;
  }
}

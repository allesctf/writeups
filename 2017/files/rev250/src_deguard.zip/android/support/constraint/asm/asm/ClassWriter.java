package android.support.constraint.asm.asm;

import android.support.constraint.asm.Item;
import android.support.constraint.asm.Label;
import android.support.constraint.asm.d;
import java.util.ArrayList;
import java.util.Arrays;

public class ClassWriter
  extends b
{
  static boolean K = true;
  protected d a = new d();
  private h[] b = new h[4];
  private int c = 2;
  private h[] d = new h[4];
  protected d e = null;
  private h[] f = new h[4];
  private boolean[] g = new boolean[3];
  private boolean h = false;
  int i;
  private e k;
  private boolean l = false;
  int p;
  private h[] r = new h[4];
  int s;
  int u;
  private int v = 0;
  private int w = 0;
  int x;
  int y;
  
  public ClassWriter() {}
  
  private int a(d paramD, h[] paramArrayOfH, h paramH, int paramInt, boolean[] paramArrayOfBoolean)
  {
    paramArrayOfBoolean[0] = true;
    paramArrayOfBoolean[1] = false;
    paramArrayOfH[0] = null;
    paramArrayOfH[2] = null;
    paramArrayOfH[1] = null;
    paramArrayOfH[3] = null;
    if (paramInt == 0) {
      if ((b.b == null) || (b.b.c == this)) {
        break label1067;
      }
    }
    label127:
    label150:
    label443:
    label628:
    label651:
    label944:
    label1033:
    label1053:
    label1067:
    for (boolean bool1 = false;; bool1 = true)
    {
      type = null;
      Object localObject2 = null;
      if (paramH.ordinal() != 8) {
        localObject2 = paramH;
      }
      Object localObject3 = null;
      int j = 0;
      h localH = paramH;
      Object localObject1 = localObject2;
      Object localObject5;
      Object localObject4;
      if (i.b != null)
      {
        type = null;
        if (localH.ordinal() != 8)
        {
          if (localObject1 != null) {
            break label1053;
          }
          localObject1 = localH;
          if ((localObject2 != null) && (localObject2 != localH)) {
            type = localH;
          }
          localObject2 = localH;
          paramInt = j;
          if (localH.ordinal() != 8)
          {
            paramInt = j;
            if (c == c.c)
            {
              if (j == c.c) {
                paramArrayOfBoolean[0] = false;
              }
              paramInt = j;
              if (y <= 0.0F)
              {
                paramArrayOfBoolean[0] = false;
                if (j + 1 >= d.length) {
                  d = ((h[])Arrays.copyOf(d, d.length * 2));
                }
                d[j] = localH;
                paramInt = j + 1;
              }
            }
          }
          if (i.b.c.b.b != null) {
            break label443;
          }
          j = paramInt;
          localObject5 = localObject1;
          localObject4 = localObject2;
        }
      }
      for (;;)
      {
        boolean bool2 = bool1;
        if (i.b != null)
        {
          bool2 = bool1;
          if (i.b.c != this) {
            bool2 = false;
          }
        }
        if ((b.b == null) || (i.b == null)) {
          paramArrayOfBoolean[1] = true;
        }
        header = bool2;
        type = null;
        paramArrayOfH[0] = paramH;
        paramArrayOfH[2] = localObject5;
        paramArrayOfH[1] = localObject3;
        paramArrayOfH[3] = localObject4;
        return j;
        paramD.a(b.a, b.b.a, 0, 5);
        paramD.a(i.a, b.a, 0, 5);
        break label150;
        localObject4 = localObject2;
        localObject5 = localObject1;
        j = paramInt;
        if (i.b.c.b.b.c == localH)
        {
          localObject4 = localObject2;
          localObject5 = localObject1;
          j = paramInt;
          if (i.b.c != localH)
          {
            localH = i.b.c;
            localObject3 = localH;
            j = paramInt;
            break;
            if ((a.b != null) && (a.b.c != this)) {}
            for (bool1 = false;; bool1 = true)
            {
              items = null;
              localObject2 = null;
              if (paramH.ordinal() != 8) {
                localObject2 = paramH;
              }
              localObject3 = null;
              j = 0;
              localH = paramH;
              localObject1 = localObject2;
              if (r.b != null)
              {
                items = null;
                if (localH.ordinal() != 8)
                {
                  if (localObject1 != null) {
                    break label1033;
                  }
                  localObject1 = localH;
                  if ((localObject2 != null) && (localObject2 != localH)) {
                    items = localH;
                  }
                  localObject2 = localH;
                  paramInt = j;
                  if (localH.ordinal() != 8)
                  {
                    paramInt = j;
                    if (j == c.c)
                    {
                      if (c == c.c) {
                        paramArrayOfBoolean[0] = false;
                      }
                      paramInt = j;
                      if (y <= 0.0F)
                      {
                        paramArrayOfBoolean[0] = false;
                        if (j + 1 >= d.length) {
                          d = ((h[])Arrays.copyOf(d, d.length * 2));
                        }
                        d[j] = localH;
                        paramInt = j + 1;
                      }
                    }
                  }
                  if (r.b.c.a.b != null) {
                    break label944;
                  }
                  j = paramInt;
                  localObject5 = localObject1;
                  localObject4 = localObject2;
                }
              }
              for (;;)
              {
                bool2 = bool1;
                if (r.b != null)
                {
                  bool2 = bool1;
                  if (r.b.c != this) {
                    bool2 = false;
                  }
                }
                if ((a.b == null) || (r.b == null)) {
                  paramArrayOfBoolean[1] = true;
                }
                length = bool2;
                items = null;
                paramArrayOfH[0] = paramH;
                paramArrayOfH[2] = localObject5;
                paramArrayOfH[1] = localObject3;
                paramArrayOfH[3] = localObject4;
                return j;
                paramD.a(a.a, a.b.a, 0, 5);
                paramD.a(r.a, a.a, 0, 5);
                break label651;
                localObject4 = localObject2;
                localObject5 = localObject1;
                j = paramInt;
                if (r.b.c.a.b.c == localH)
                {
                  localObject4 = localObject2;
                  localObject5 = localObject1;
                  j = paramInt;
                  if (r.b.c != localH)
                  {
                    localH = r.b.c;
                    localObject3 = localH;
                    j = paramInt;
                    break;
                    break label628;
                    localObject4 = localObject2;
                    localObject5 = localObject1;
                  }
                }
              }
            }
            break label127;
            localObject4 = localObject2;
            localObject5 = localObject1;
          }
        }
      }
    }
  }
  
  private void a(h paramH)
  {
    int j = 0;
    while (j < v)
    {
      if (f[j] == paramH) {
        return;
      }
      j += 1;
    }
    if (v + 1 >= f.length) {
      f = ((h[])Arrays.copyOf(f, f.length * 2));
    }
    f[v] = paramH;
    v += 1;
  }
  
  private void a(d paramD)
  {
    int m = 0;
    h localH;
    int i3;
    Object localObject2;
    int j;
    Object localObject1;
    label139:
    label149:
    int n;
    label161:
    int i1;
    label243:
    label249:
    label255:
    Label localLabel;
    Object localObject3;
    Object localObject5;
    Object localObject4;
    if (m < w)
    {
      localH = r[m];
      i3 = a(paramD, b, r[m], 0, g);
      localObject2 = b[2];
      if (localObject2 == null) {}
      for (;;)
      {
        m += 1;
        break;
        if (g[1] == 0) {
          break label139;
        }
        j = localH.e();
        while (localObject2 != null)
        {
          paramD.a(b.a, j);
          localObject1 = type;
          j += b.b() + ((h)localObject2).getValue() + i.b();
          localObject2 = localObject1;
        }
      }
      if (width == 0)
      {
        j = 1;
        if (width != 2) {
          break label243;
        }
        n = 1;
        if (c != c.b) {
          break label249;
        }
      }
      for (i1 = 1;; i1 = 0)
      {
        if (((c != 2) && (c != 8)) || (g[0] == 0) || (!header) || (n != 0) || (i1 != 0) || (width != 0)) {
          break label255;
        }
        l.b(this, paramD, i3, localH);
        break;
        j = 0;
        break label149;
        n = 0;
        break label161;
      }
      if ((i3 == 0) || (n != 0))
      {
        localLabel = null;
        i1 = 0;
        localObject1 = null;
        localObject3 = localObject2;
        if (localObject3 != null)
        {
          localObject5 = type;
          if (localObject5 != null) {
            break label2438;
          }
          localObject4 = b;
          i1 = 1;
          localLabel = localObject4[1];
        }
      }
    }
    label472:
    label709:
    label796:
    label825:
    label854:
    label942:
    label948:
    label954:
    label1016:
    label1101:
    label1105:
    label1747:
    label2018:
    label2414:
    label2421:
    label2428:
    label2435:
    label2438:
    for (;;)
    {
      int i2;
      if (n != 0)
      {
        localObject4 = b;
        i2 = ((i)localObject4).b();
        if (localObject1 == null) {
          break label2435;
        }
        i2 += i.b();
      }
      for (;;)
      {
        i3 = 1;
        if (localObject2 != localObject3) {
          i3 = 3;
        }
        paramD.b(a, b.a, i2, i3);
        localObject1 = localObject5;
        if (c == c.c)
        {
          localObject1 = i;
          if (t != 1) {
            break label472;
          }
          i2 = Math.max(e, ((h)localObject3).getValue());
          paramD.a(a, a, i2, 3);
          localObject1 = localObject5;
        }
        for (;;)
        {
          if (i1 != 0) {
            localObject1 = null;
          }
          localObject4 = localObject1;
          localObject1 = localObject3;
          localObject3 = localObject4;
          break;
          paramD.b(a, b.a, i, 3);
          paramD.c(a, a, e, 3);
          localObject1 = localObject5;
          continue;
          if ((j == 0) && (i1 != 0) && (localObject1 != null))
          {
            if (i.b == null)
            {
              paramD.a(i.a, ((h)localObject3).k());
              localObject1 = localObject5;
            }
            else
            {
              i2 = i.b();
              paramD.a(i.a, i.b.a, -i2, 5);
              localObject1 = localObject5;
            }
          }
          else
          {
            if ((j != 0) || (i1 != 0) || (localObject1 != null)) {
              break label709;
            }
            if (b.b == null)
            {
              paramD.a(b.a, ((h)localObject3).e());
              localObject1 = localObject5;
            }
            else
            {
              i2 = b.b();
              paramD.a(b.a, b.b.a, i2, 5);
              localObject1 = localObject5;
            }
          }
        }
        Object localObject6 = b;
        i localI = i;
        i2 = ((i)localObject6).b();
        i3 = localI.b();
        paramD.b(a, b.a, i2, 1);
        paramD.c(a, b.a, -i3, 1);
        if (b != null)
        {
          localObject4 = b.a;
          if (localObject1 == null)
          {
            if (b.b == null) {
              break label942;
            }
            localObject4 = b.b.a;
          }
          if (localObject5 != null) {
            break label2428;
          }
          if (i.b == null) {
            break label948;
          }
          localObject1 = i.b.c;
        }
        for (;;)
        {
          if (localObject1 != null)
          {
            localObject5 = b.a;
            if (i1 != 0) {
              if (i.b == null) {
                break label954;
              }
            }
          }
          for (localObject5 = i.b.a;; localObject5 = null)
          {
            if ((localObject4 != null) && (localObject5 != null)) {
              paramD.a(a, (Label)localObject4, i2, 0.5F, (Label)localObject5, a, i3, 4);
            }
            break;
            localObject4 = null;
            break label796;
            localObject4 = null;
            break label825;
            localObject1 = null;
            break label854;
          }
          if (n == 0) {
            break;
          }
          localObject3 = b;
          localObject4 = i;
          j = ((i)localObject3).b();
          n = ((i)localObject4).b();
          if (b.b != null)
          {
            localObject1 = b.b.a;
            if (i.b == null) {
              break label1101;
            }
          }
          for (localObject2 = i.b.a;; localObject2 = null)
          {
            if ((localObject1 == null) || (localObject2 == null)) {
              break label1105;
            }
            paramD.c(a, (Label)localObject2, -n, 1);
            paramD.a(a, (Label)localObject1, j, C, (Label)localObject2, a, n, 4);
            break;
            localObject1 = null;
            break label1016;
          }
          break;
          float f1 = 0.0F;
          localObject1 = null;
          if (localObject2 != null)
          {
            if (c != c.c)
            {
              n = b.b();
              j = n;
              if (localObject1 != null) {
                j = n + i.b();
              }
              n = 3;
              if (b.b.c.c == c.c) {
                n = 2;
              }
              paramD.b(b.a, b.b.a, j, n);
              i1 = i.b();
              n = i1;
              j = n;
              if (i.b.c.b.b != null)
              {
                j = n;
                if (i.b.c.b.b.c == localObject2) {
                  j = i1 + i.b.c.b.b();
                }
              }
              n = 3;
              if (i.b.c.c == c.c) {
                n = 2;
              }
              paramD.c(i.a, i.b.a, -j, n);
            }
            for (;;)
            {
              localObject1 = localObject2;
              localObject2 = type;
              break;
              f1 += right;
              j = 0;
              if (i.b != null)
              {
                n = i.b();
                j = n;
                if (localObject2 != b[3]) {
                  j = n + i.b.c.b.b();
                }
              }
              paramD.b(i.a, b.a, 0, 1);
              paramD.c(i.a, i.b.a, -j, 1);
            }
          }
          if (i3 == 1)
          {
            localObject2 = d[0];
            n = b.b();
            j = n;
            if (b.b != null) {
              j = n + b.b.b();
            }
            i1 = i.b();
            n = i1;
            if (i.b != null) {
              n = i1 + i.b.b();
            }
            localObject1 = i.b.a;
            if (localObject2 == b[3]) {
              localObject1 = b[1].i.b.a;
            }
            if (t == 1)
            {
              paramD.b(b.a, b.b.a, j, 1);
              paramD.c(i.a, (Label)localObject1, -n, 1);
              paramD.a(i.a, b.a, localH.getValue(), 2);
              break;
            }
            paramD.a(b.a, b.b.a, j, 1);
            paramD.a(i.a, (Label)localObject1, -n, 1);
            break;
          }
          j = 0;
          if (j < i3 - 1)
          {
            localObject3 = d[j];
            localObject4 = d[(j + 1)];
            localObject5 = b.a;
            localLabel = i.a;
            localObject6 = b.a;
            localObject1 = i.a;
            if (localObject4 == b[3]) {
              localObject1 = b[1].i.a;
            }
            i2 = b.b();
            n = i2;
            i1 = n;
            if (b.b != null)
            {
              i1 = n;
              if (b.b.c.i.b != null)
              {
                i1 = n;
                if (b.b.c.i.b.c == localObject3) {
                  i1 = i2 + b.b.c.i.b();
                }
              }
            }
            paramD.b((Label)localObject5, b.b.a, i1, 2);
            i1 = i.b();
            if ((i.b == null) || (type == null)) {
              break label2421;
            }
            if (type.b.b == null) {
              break label2414;
            }
            n = type.b.b();
            n += i1;
          }
          for (;;)
          {
            paramD.c(localLabel, i.b.a, -n, 2);
            if (j + 1 == i3 - 1)
            {
              i2 = b.b();
              n = i2;
              i1 = n;
              if (b.b != null)
              {
                i1 = n;
                if (b.b.c.i.b != null)
                {
                  i1 = n;
                  if (b.b.c.i.b.c == localObject4) {
                    i1 = i2 + b.b.c.i.b();
                  }
                }
              }
              paramD.b((Label)localObject6, b.b.a, i1, 2);
              localObject2 = i;
              if (localObject4 == b[3]) {
                localObject2 = b[1].i;
              }
              i2 = ((i)localObject2).b();
              n = i2;
              i1 = n;
              if (b != null)
              {
                i1 = n;
                if (b.c.b.b != null)
                {
                  i1 = n;
                  if (b.c.b.b.c == localObject4) {
                    i1 = i2 + b.c.b.b();
                  }
                }
              }
              paramD.c((Label)localObject1, b.a, -i1, 2);
            }
            if (g > 0) {
              paramD.c(localLabel, (Label)localObject5, g, 2);
            }
            localObject2 = paramD.a();
            ((Item)localObject2).a(right, f1, right, (Label)localObject5, b.b(), localLabel, i.b(), (Label)localObject6, b.b(), (Label)localObject1, i.b());
            paramD.a((Item)localObject2);
            j += 1;
            break label1747;
            break;
            n = 0;
            break label2018;
            return;
            n = i1;
          }
          localObject1 = localObject5;
        }
      }
    }
  }
  
  private boolean b(d paramD)
  {
    int i5 = a.size();
    int j = 0;
    h localH;
    int m;
    int n;
    label94:
    int i2;
    int i1;
    for (;;)
    {
      if (j < i5)
      {
        localH = (h)a.get(j);
        k = -1;
        h = -1;
        if ((c == c.c) || (j == c.c))
        {
          k = 1;
          h = 1;
        }
        j += 1;
        continue;
        if ((j == 0) && (m == 0))
        {
          n = 1;
          i2 = j;
          i1 = n;
          n = m;
        }
      }
    }
    for (;;)
    {
      int i3;
      label116:
      label162:
      label187:
      int i4;
      if (i1 == 0)
      {
        i3 = 0;
        m = 0;
        j = 0;
        if (i3 < i5)
        {
          localH = (h)a.get(i3);
          if (k == -1)
          {
            if (c != c.b) {
              break label229;
            }
            k = 1;
          }
          if (h == -1)
          {
            if (this.j != c.b) {
              break label239;
            }
            h = 1;
          }
          i4 = j;
          if (h == -1) {
            i4 = j + 1;
          }
          if (k != -1) {
            break label372;
          }
          m += 1;
        }
      }
      label229:
      label239:
      label362:
      label372:
      for (;;)
      {
        i3 += 1;
        j = i4;
        break label116;
        break;
        l.b(this, paramD, localH);
        break label162;
        l.a(this, paramD, localH);
        break label187;
        if ((i2 == j) && (n == m))
        {
          n = 1;
          break label94;
          j = 0;
          m = 0;
          i1 = 0;
          if (j < i5)
          {
            paramD = (h)a.get(j);
            if (k != 1)
            {
              n = i1;
              if (k != -1) {}
            }
            else
            {
              n = i1 + 1;
            }
            if ((h != 1) && (h != -1)) {
              break label362;
            }
            m += 1;
          }
          for (;;)
          {
            j += 1;
            i1 = n;
            break;
            return (i1 == 0) && (m == 0);
          }
        }
        n = i1;
        break label94;
      }
      n = 0;
      i2 = 0;
      i1 = 0;
    }
  }
  
  private void draw(d paramD)
  {
    int m = 0;
    h localH;
    int i3;
    Object localObject2;
    int j;
    Object localObject1;
    label139:
    int n;
    label150:
    int i1;
    label162:
    label243:
    label249:
    label254:
    Label localLabel;
    int i2;
    Object localObject3;
    Object localObject5;
    Object localObject4;
    if (m < v)
    {
      localH = f[m];
      i3 = a(paramD, b, f[m], 1, g);
      localObject2 = b[2];
      if (localObject2 == null) {}
      for (;;)
      {
        m += 1;
        break;
        if (g[1] == 0) {
          break label139;
        }
        j = localH.length();
        while (localObject2 != null)
        {
          paramD.a(a.a, j);
          localObject1 = items;
          j += a.b() + ((h)localObject2).get() + r.b();
          localObject2 = localObject1;
        }
      }
      if (mHeight == 0)
      {
        n = 1;
        if (mHeight != 2) {
          break label243;
        }
        i1 = 1;
        if (this.j != c.b) {
          break label249;
        }
      }
      for (j = 1;; j = 0)
      {
        if (((c != 2) && (c != 8)) || (g[0] == 0) || (!length) || (i1 != 0) || (j != 0) || (mHeight != 0)) {
          break label254;
        }
        l.a(this, paramD, i3, localH);
        break;
        n = 0;
        break label150;
        i1 = 0;
        break label162;
      }
      if ((i3 == 0) || (i1 != 0))
      {
        localLabel = null;
        i2 = 0;
        localObject1 = null;
        localObject3 = localObject2;
        if (localObject3 != null)
        {
          localObject5 = items;
          if (localObject5 != null) {
            break label2513;
          }
          localObject4 = b;
          i2 = 1;
          localLabel = localObject4[1];
        }
      }
    }
    label395:
    label555:
    label790:
    label875:
    label904:
    label933:
    label1020:
    label1026:
    label1032:
    label1094:
    label1179:
    label1183:
    label1825:
    label2096:
    label2492:
    label2499:
    label2506:
    label2513:
    for (;;)
    {
      int i4;
      if (i1 != 0)
      {
        localObject6 = a;
        i3 = ((i)localObject6).b();
        j = i3;
        if (localObject1 != null) {
          j = i3 + r.b();
        }
        i3 = 1;
        if (localObject2 != localObject3) {
          i3 = 3;
        }
        localObject1 = null;
        localObject4 = null;
        if (b != null)
        {
          localObject1 = a;
          localObject4 = b.a;
          i4 = j;
          if ((localObject1 != null) && (localObject4 != null)) {
            paramD.b((Label)localObject1, (Label)localObject4, i4, i3);
          }
          localObject1 = localObject5;
          if (j == c.c)
          {
            localObject1 = r;
            if (left != 1) {
              break label555;
            }
            j = Math.max(offset, ((h)localObject3).get());
            paramD.a(a, a, j, 3);
            localObject1 = localObject5;
          }
        }
      }
      for (;;)
      {
        if (i2 != 0) {
          localObject1 = null;
        }
        localObject4 = localObject1;
        localObject1 = localObject3;
        localObject3 = localObject4;
        break;
        i4 = j;
        if (d.b == null) {
          break label395;
        }
        localObject1 = d.a;
        localObject4 = d.b.a;
        i4 = j - ((i)localObject6).b();
        break label395;
        paramD.b(a, b.a, i, 3);
        paramD.c(a, a, offset, 3);
        localObject1 = localObject5;
        continue;
        if ((n == 0) && (i2 != 0) && (localObject1 != null))
        {
          if (r.b == null)
          {
            paramD.a(r.a, ((h)localObject3).getItem());
            localObject1 = localObject5;
          }
          else
          {
            j = r.b();
            paramD.a(r.a, r.b.a, -j, 5);
            localObject1 = localObject5;
          }
        }
        else
        {
          if ((n != 0) || (i2 != 0) || (localObject1 != null)) {
            break label790;
          }
          if (a.b == null)
          {
            paramD.a(a.a, ((h)localObject3).length());
            localObject1 = localObject5;
          }
          else
          {
            j = a.b();
            paramD.a(a.a, a.b.a, j, 5);
            localObject1 = localObject5;
          }
        }
      }
      Object localObject6 = a;
      i localI = r;
      j = ((i)localObject6).b();
      i3 = localI.b();
      paramD.b(a, b.a, j, 1);
      paramD.c(a, b.a, -i3, 1);
      if (b != null)
      {
        localObject4 = b.a;
        if (localObject1 == null)
        {
          if (a.b == null) {
            break label1020;
          }
          localObject4 = a.b.a;
        }
        if (localObject5 != null) {
          break label2506;
        }
        if (r.b == null) {
          break label1026;
        }
        localObject1 = r.b.c;
      }
      for (;;)
      {
        if (localObject1 != null)
        {
          localObject5 = a.a;
          if (i2 != 0) {
            if (r.b == null) {
              break label1032;
            }
          }
        }
        for (localObject5 = r.b.a;; localObject5 = null)
        {
          if ((localObject4 != null) && (localObject5 != null)) {
            paramD.a(a, (Label)localObject4, j, 0.5F, (Label)localObject5, a, i3, 4);
          }
          break;
          localObject4 = null;
          break label875;
          localObject4 = null;
          break label904;
          localObject1 = null;
          break label933;
        }
        if (i1 == 0) {
          break;
        }
        localObject3 = a;
        localObject4 = r;
        j = ((i)localObject3).b();
        n = ((i)localObject4).b();
        if (a.b != null)
        {
          localObject1 = a.b.a;
          if (r.b == null) {
            break label1179;
          }
        }
        for (localObject2 = r.b.a;; localObject2 = null)
        {
          if ((localObject1 == null) || (localObject2 == null)) {
            break label1183;
          }
          paramD.c(a, (Label)localObject2, -n, 1);
          paramD.a(a, (Label)localObject1, j, f, (Label)localObject2, a, n, 4);
          break;
          localObject1 = null;
          break label1094;
        }
        break;
        float f1 = 0.0F;
        localObject1 = null;
        if (localObject2 != null)
        {
          if (j != c.c)
          {
            n = a.b();
            j = n;
            if (localObject1 != null) {
              j = n + r.b();
            }
            n = 3;
            if (a.b.c.j == c.c) {
              n = 2;
            }
            paramD.b(a.a, a.b.a, j, n);
            i1 = r.b();
            n = i1;
            j = n;
            if (r.b.c.a.b != null)
            {
              j = n;
              if (r.b.c.a.b.c == localObject2) {
                j = i1 + r.b.c.a.b();
              }
            }
            n = 3;
            if (r.b.c.j == c.c) {
              n = 2;
            }
            paramD.c(r.a, r.b.a, -j, n);
          }
          for (;;)
          {
            localObject1 = localObject2;
            localObject2 = items;
            break;
            f1 += height;
            j = 0;
            if (r.b != null)
            {
              n = r.b();
              j = n;
              if (localObject2 != b[3]) {
                j = n + r.b.c.a.b();
              }
            }
            paramD.b(r.a, a.a, 0, 1);
            paramD.c(r.a, r.b.a, -j, 1);
          }
        }
        if (i3 == 1)
        {
          localObject2 = d[0];
          n = a.b();
          j = n;
          if (a.b != null) {
            j = n + a.b.b();
          }
          i1 = r.b();
          n = i1;
          if (r.b != null) {
            n = i1 + r.b.b();
          }
          localObject1 = r.b.a;
          if (localObject2 == b[3]) {
            localObject1 = b[1].r.b.a;
          }
          if (left == 1)
          {
            paramD.b(a.a, a.b.a, j, 1);
            paramD.c(r.a, (Label)localObject1, -n, 1);
            paramD.a(r.a, a.a, localH.get(), 2);
            break;
          }
          paramD.a(a.a, a.b.a, j, 1);
          paramD.a(r.a, (Label)localObject1, -n, 1);
          break;
        }
        j = 0;
        if (j < i3 - 1)
        {
          localObject3 = d[j];
          localObject4 = d[(j + 1)];
          localObject5 = a.a;
          localLabel = r.a;
          localObject6 = a.a;
          localObject1 = r.a;
          if (localObject4 == b[3]) {
            localObject1 = b[1].r.a;
          }
          i2 = a.b();
          n = i2;
          i1 = n;
          if (a.b != null)
          {
            i1 = n;
            if (a.b.c.r.b != null)
            {
              i1 = n;
              if (a.b.c.r.b.c == localObject3) {
                i1 = i2 + a.b.c.r.b();
              }
            }
          }
          paramD.b((Label)localObject5, a.b.a, i1, 2);
          i1 = r.b();
          if ((r.b == null) || (items == null)) {
            break label2499;
          }
          if (items.a.b == null) {
            break label2492;
          }
          n = items.a.b();
          n += i1;
        }
        for (;;)
        {
          paramD.c(localLabel, r.b.a, -n, 2);
          if (j + 1 == i3 - 1)
          {
            i2 = a.b();
            n = i2;
            i1 = n;
            if (a.b != null)
            {
              i1 = n;
              if (a.b.c.r.b != null)
              {
                i1 = n;
                if (a.b.c.r.b.c == localObject4) {
                  i1 = i2 + a.b.c.r.b();
                }
              }
            }
            paramD.b((Label)localObject6, a.b.a, i1, 2);
            localObject2 = r;
            if (localObject4 == b[3]) {
              localObject2 = b[1].r;
            }
            i2 = ((i)localObject2).b();
            n = i2;
            i1 = n;
            if (b != null)
            {
              i1 = n;
              if (b.c.a.b != null)
              {
                i1 = n;
                if (b.c.a.b.c == localObject4) {
                  i1 = i2 + b.c.a.b();
                }
              }
            }
            paramD.c((Label)localObject1, b.a, -i1, 2);
          }
          if (size > 0) {
            paramD.c(localLabel, (Label)localObject5, size, 2);
          }
          localObject2 = paramD.a();
          ((Item)localObject2).a(height, f1, height, (Label)localObject5, a.b(), localLabel, r.b(), (Label)localObject6, a.b(), (Label)localObject1, r.b());
          paramD.a((Item)localObject2);
          j += 1;
          break label1825;
          break;
          n = 0;
          break label2096;
          return;
          n = i1;
        }
        localObject1 = localObject5;
      }
    }
  }
  
  private void init(h paramH)
  {
    int j = 0;
    while (j < w)
    {
      if (r[j] == paramH) {
        return;
      }
      j += 1;
    }
    if (w + 1 >= r.length) {
      r = ((h[])Arrays.copyOf(r, r.length * 2));
    }
    r[w] = paramH;
    w += 1;
  }
  
  private void visitAttribute()
  {
    w = 0;
    v = 0;
  }
  
  public void a()
  {
    int i2 = w;
    int i3 = s;
    int i4 = Math.max(0, getValue());
    int i5 = Math.max(0, get());
    l = false;
    h = false;
    c localC1;
    c localC2;
    if (v != null)
    {
      if (k == null) {
        k = new e(this);
      }
      k.b(this);
      b(i);
      a(u);
      c();
      a(a.f());
      i8 = 0;
      localC1 = this.j;
      localC2 = c;
      i9 = i8;
      if (c != 2) {
        break label425;
      }
      if (this.j != c.b)
      {
        i9 = i8;
        if (c != c.b) {
          break label425;
        }
      }
      a(a, g);
      i9 = g[0];
      i8 = i9;
      if (i4 > 0)
      {
        i8 = i9;
        if (i5 > 0) {
          if (x <= i4)
          {
            i8 = i9;
            if (y <= i5) {}
          }
          else
          {
            i8 = 0;
          }
        }
      }
      i9 = i8;
      if (i8 == 0) {
        break label425;
      }
      if (c == c.b)
      {
        c = c.a;
        if ((i4 <= 0) || (i4 >= x)) {
          break label388;
        }
        l = true;
        c(i4);
      }
      label272:
      i9 = i8;
      if (this.j != c.b) {
        break label425;
      }
      this.j = c.a;
      if ((i5 <= 0) || (i5 >= y)) {
        break label406;
      }
      h = true;
      e(i5);
    }
    int i6;
    Object localObject;
    for (;;)
    {
      visitAttribute();
      i6 = a.size();
      j = 0;
      while (j < i6)
      {
        localObject = (h)a.get(j);
        if ((localObject instanceof b)) {
          ((b)localObject).a();
        }
        j += 1;
      }
      w = 0;
      s = 0;
      break;
      label388:
      c(Math.max(u, x));
      break label272;
      label406:
      e(Math.max(l, y));
      i9 = i8;
      label425:
      i8 = i9;
    }
    int j = 0;
    int i9 = 1;
    int i1;
    int i10;
    int i11;
    int m;
    if (i9 != 0)
    {
      i1 = j + 1;
      localObject = a;
      i10 = i9;
      try
      {
        ((d)localObject).b();
        localObject = a;
        i10 = i9;
        i11 = c((d)localObject, Integer.MAX_VALUE);
        i9 = i11;
        i10 = i9;
        if (i11 != 0)
        {
          localObject = a;
          i10 = i9;
          ((d)localObject).e();
          i10 = i9;
        }
      }
      catch (Exception localException)
      {
        int n;
        for (;;)
        {
          localException.printStackTrace();
        }
        b(a, Integer.MAX_VALUE);
        j = 0;
        while (j < i6)
        {
          h localH = (h)a.get(j);
          if ((c == c.c) && (localH.getValue() < localH.getGroupId()))
          {
            g[2] = true;
            break;
          }
          if ((j == c.c) && (localH.get() < localH.h()))
          {
            g[2] = true;
            break;
          }
          j += 1;
        }
        m = Math.max(u, n);
        j = Math.max(l, j);
        if (localC2 != c.b) {
          break label1214;
        }
      }
      if (i10 != 0)
      {
        a(a, Integer.MAX_VALUE, g);
        if ((i1 >= 8) || (g[2] == 0)) {
          break label1224;
        }
        n = 0;
        j = 0;
        m = 0;
        while (m < i6)
        {
          localObject = (h)a.get(m);
          n = Math.max(n, w + ((h)localObject).getValue());
          int i7 = s;
          j = Math.max(j, ((h)localObject).get() + i7);
          m += 1;
        }
      }
      if (getValue() >= m) {
        break label1214;
      }
      c(m);
      c = c.b;
      i10 = 1;
      i11 = 1;
      label788:
      i9 = i10;
      i8 = i11;
      if (localC1 == c.b)
      {
        i9 = i10;
        i8 = i11;
        if (get() < j)
        {
          e(j);
          this.j = c.b;
          i9 = 1;
        }
      }
    }
    for (int i8 = 1;; i8 = i10)
    {
      j = Math.max(u, getValue());
      i10 = i8;
      if (j > getValue())
      {
        c(j);
        c = c.a;
        i9 = 1;
        i10 = 1;
      }
      j = Math.max(l, get());
      i8 = i9;
      if (j > get())
      {
        e(j);
        this.j = c.a;
        i8 = 1;
        i10 = 1;
      }
      i11 = i8;
      i9 = i10;
      if (i8 == 0)
      {
        int i13 = i8;
        int i12 = i10;
        if (c == c.b)
        {
          i13 = i8;
          i12 = i10;
          if (i4 > 0)
          {
            i13 = i8;
            i12 = i10;
            if (getValue() > i4)
            {
              l = true;
              i13 = 1;
              c = c.a;
              c(i4);
              i12 = 1;
            }
          }
        }
        i11 = i13;
        i9 = i12;
        if (this.j == c.b)
        {
          i11 = i13;
          i9 = i12;
          if (i5 > 0)
          {
            i11 = i13;
            i9 = i12;
            if (get() > i5)
            {
              h = true;
              i11 = 1;
              this.j = c.a;
              e(i5);
              i9 = 1;
            }
          }
        }
      }
      i8 = i11;
      j = i1;
      break;
      if (v != null)
      {
        j = Math.max(u, getValue());
        m = Math.max(l, get());
        k.a(this);
        c(j + i + s);
        e(u + m + p);
      }
      for (;;)
      {
        if (i8 != 0)
        {
          c = localC2;
          this.j = localC1;
        }
        a(a.f());
        if (this != onCreateView()) {
          break;
        }
        write();
        return;
        w = i2;
        s = i3;
      }
      label1214:
      i11 = 0;
      i10 = i8;
      break label788;
      label1224:
      i10 = 0;
      i9 = i8;
    }
  }
  
  void a(h paramH, int paramInt)
  {
    if (paramInt == 0)
    {
      while ((b.b != null) && (b.b.c.i.b != null) && (b.b.c.i.b == b) && (b.b.c != paramH)) {
        paramH = b.b.c;
      }
      init(paramH);
      return;
    }
    if (paramInt == 1)
    {
      while ((a.b != null) && (a.b.c.r.b != null) && (a.b.c.r.b == a) && (a.b.c != paramH)) {
        paramH = a.b.c;
      }
      a(paramH);
    }
  }
  
  public void a(h paramH, boolean[] paramArrayOfBoolean)
  {
    Object localObject = null;
    boolean bool2 = false;
    int n = 0;
    if ((c == c.c) && (j == c.c) && (y > 0.0F))
    {
      paramArrayOfBoolean[0] = false;
      return;
    }
    int j = paramH.b();
    int m = j;
    if ((c == c.c) && (j != c.c) && (y > 0.0F))
    {
      paramArrayOfBoolean[0] = false;
      return;
    }
    top = true;
    if ((paramH instanceof m))
    {
      paramArrayOfBoolean = (m)paramH;
      if (paramArrayOfBoolean.getItemId() != 1) {
        break label914;
      }
      if (paramArrayOfBoolean.g() != -1)
      {
        j = paramArrayOfBoolean.g();
        m = n;
      }
    }
    for (;;)
    {
      int i1 = m;
      for (;;)
      {
        n = j;
        m = i1;
        if (paramH.ordinal() == 8)
        {
          n = j - x;
          m = i1 - x;
        }
        bottom = n;
        q = m;
        return;
        if (paramArrayOfBoolean.a() == -1) {
          break label905;
        }
        j = 0;
        m = paramArrayOfBoolean.a();
        break;
        if ((i.equals()) || (b.equals())) {
          break label233;
        }
        m = paramH.l();
        i1 = j;
        j = m + j;
      }
      label233:
      if ((i.b != null) && (b.b != null) && ((i.b == b.b) || ((i.b.c == b.b.c) && (i.b.c != v))))
      {
        paramArrayOfBoolean[0] = false;
        return;
      }
      h localH2;
      h localH1;
      if (i.b != null)
      {
        localH2 = i.b.c;
        n = i.b() + j;
        i1 = n;
        localH1 = localH2;
        if (!localH2.equals())
        {
          i1 = n;
          localH1 = localH2;
          if (!top)
          {
            a(localH2, paramArrayOfBoolean);
            localH1 = localH2;
          }
        }
      }
      for (i1 = n;; i1 = j)
      {
        if (b.b != null)
        {
          localH2 = b.b.c;
          j += b.b();
          localObject = localH2;
          m = j;
          if (!localH2.equals())
          {
            localObject = localH2;
            m = j;
            if (!top)
            {
              a(localH2, paramArrayOfBoolean);
              m = j;
              localObject = localH2;
            }
          }
        }
        n = i1;
        label528:
        boolean bool1;
        if (i.b != null)
        {
          n = i1;
          if (!localH1.equals())
          {
            if (i.b.d != f.i) {
              break label780;
            }
            j = i1 + (q - localH1.b());
            if ((!z) && ((b.b == null) || (i.b == null) || (c == c.c))) {
              break label811;
            }
            bool1 = true;
            label572:
            z = bool1;
            n = j;
            if (z)
            {
              if (b.b != null) {
                break label817;
              }
              label599:
              n = j + (j - q);
            }
          }
        }
        label610:
        j = m;
        i1 = n;
        if (b.b == null) {
          break;
        }
        j = m;
        i1 = n;
        if (localObject.equals()) {
          break;
        }
        int i2;
        if (b.b.q() == f.c)
        {
          i2 = m + (bottom - localObject.b());
          label674:
          if (!J)
          {
            bool1 = bool2;
            if (b.b != null)
            {
              bool1 = bool2;
              if (i.b != null)
              {
                bool1 = bool2;
                if (c == c.c) {}
              }
            }
          }
          else
          {
            bool1 = true;
          }
          J = bool1;
          j = i2;
          i1 = n;
          if (!J) {
            break;
          }
          if (i.b != null) {
            break label871;
          }
        }
        for (;;)
        {
          j = i2 + (i2 - bottom);
          i1 = n;
          break;
          label780:
          j = i1;
          if (i.b.q() != f.c) {
            break label528;
          }
          j = i1 + q;
          break label528;
          label811:
          bool1 = false;
          break label572;
          label817:
          n = j;
          if (b.b.c == paramH) {
            break label610;
          }
          break label599;
          i2 = m;
          if (b.b.q() != f.i) {
            break label674;
          }
          i2 = m + bottom;
          break label674;
          label871:
          j = i2;
          i1 = n;
          if (i.b.c == paramH) {
            break;
          }
        }
        localH1 = null;
      }
      label905:
      j = 0;
      m = n;
      continue;
      label914:
      n = j;
      m = j;
      j = n;
    }
  }
  
  public void a(d paramD, int paramInt, boolean[] paramArrayOfBoolean)
  {
    paramArrayOfBoolean[2] = false;
    b(paramD, paramInt);
    int m = a.size();
    int j = 0;
    while (j < m)
    {
      h localH = (h)a.get(j);
      localH.b(paramD, paramInt);
      if ((c == c.c) && (localH.getValue() < localH.getGroupId())) {
        paramArrayOfBoolean[2] = true;
      }
      if ((j == c.c) && (localH.get() < localH.h())) {
        paramArrayOfBoolean[2] = true;
      }
      j += 1;
    }
  }
  
  public void a(ArrayList paramArrayList, boolean[] paramArrayOfBoolean)
  {
    int i3 = 0;
    int i6 = 0;
    int i5 = 0;
    int i4 = 0;
    int i2 = 0;
    int i1 = 0;
    int i7 = paramArrayList.size();
    paramArrayOfBoolean[0] = true;
    int n = 0;
    if (n < i7)
    {
      h localH = (h)paramArrayList.get(n);
      if (localH.equals()) {}
      for (;;)
      {
        n += 1;
        break;
        if (!top) {
          a(localH, paramArrayOfBoolean);
        }
        if (!E) {
          b(localH, paramArrayOfBoolean);
        }
        if (paramArrayOfBoolean[0] == 0) {
          return;
        }
        j = bottom + q - localH.getValue();
        int m = D + B - localH.get();
        if (c == c.d) {
          j = localH.getValue() + b.i + i.i;
        }
        if (j == c.d) {
          m = localH.get() + a.i + r.i;
        }
        if (localH.ordinal() == 8)
        {
          j = 0;
          m = 0;
        }
        i6 = Math.max(i6, bottom);
        i5 = Math.max(i5, q);
        i4 = Math.max(i4, B);
        i3 = Math.max(i3, D);
        i2 = Math.max(i2, j);
        i1 = Math.max(i1, m);
      }
    }
    int j = Math.max(i6, i5);
    x = Math.max(u, Math.max(j, i2));
    j = Math.max(i3, i4);
    y = Math.max(l, Math.max(j, i1));
    j = 0;
    while (j < i7)
    {
      paramArrayOfBoolean = (h)paramArrayList.get(j);
      top = false;
      E = false;
      J = false;
      z = false;
      I = false;
      o = false;
      j += 1;
    }
  }
  
  public void b(h paramH, boolean[] paramArrayOfBoolean)
  {
    Object localObject2 = null;
    boolean bool2 = false;
    int n = 0;
    if ((j == c.c) && (c != c.c) && (y > 0.0F))
    {
      paramArrayOfBoolean[0] = false;
      return;
    }
    int j = paramH.size();
    int m = j;
    E = true;
    if ((paramH instanceof m))
    {
      paramArrayOfBoolean = (m)paramH;
      if (paramArrayOfBoolean.getItemId() != 0) {
        break label1082;
      }
      if (paramArrayOfBoolean.g() != -1)
      {
        j = 0;
        m = paramArrayOfBoolean.g();
      }
    }
    for (;;)
    {
      int i1 = m;
      for (;;)
      {
        n = j;
        m = i1;
        if (paramH.ordinal() == 8)
        {
          m = i1 - m;
          n = j - m;
        }
        D = m;
        B = n;
        return;
        if (paramArrayOfBoolean.a() == -1) {
          break label1073;
        }
        j = paramArrayOfBoolean.a();
        m = n;
        break;
        if ((d.b != null) || (a.b != null) || (r.b != null)) {
          break label205;
        }
        i1 = j + paramH.getString();
        j = m;
      }
      label205:
      if ((r.b != null) && (a.b != null) && ((r.b == a.b) || ((r.b.c == a.b.c) && (r.b.c != v))))
      {
        paramArrayOfBoolean[0] = false;
        return;
      }
      Object localObject1;
      if (d.equals())
      {
        localObject1 = d.b.c();
        if (!E) {
          b((h)localObject1, paramArrayOfBoolean);
        }
        n = Math.max(D - m + j, j);
        m = n;
        i1 = Math.max(B - m + j, j);
        j = i1;
        if (paramH.ordinal() == 8)
        {
          m = n - m;
          j = i1 - m;
        }
        D = m;
        B = j;
        return;
      }
      h localH2;
      h localH1;
      if (a.equals())
      {
        localH2 = a.b.c();
        localH1 = localH2;
        n = a.b() + j;
        i1 = n;
        localObject1 = localH1;
        if (!localH2.equals())
        {
          i1 = n;
          localObject1 = localH1;
          if (!E)
          {
            b(localH2, paramArrayOfBoolean);
            localObject1 = localH1;
          }
        }
      }
      for (i1 = n;; i1 = j)
      {
        if (r.equals())
        {
          localH2 = r.b.c();
          localH1 = localH2;
          j += r.b();
          localObject2 = localH1;
          m = j;
          if (!localH2.equals())
          {
            localObject2 = localH1;
            m = j;
            if (!E)
            {
              b(localH2, paramArrayOfBoolean);
              m = j;
              localObject2 = localH1;
            }
          }
        }
        n = i1;
        label628:
        boolean bool1;
        if (a.b != null)
        {
          n = i1;
          if (!((h)localObject1).equals())
          {
            if (a.b.q() != f.a) {
              break label948;
            }
            j = i1 + (D - ((h)localObject1).size());
            if ((!I) && ((a.b == null) || (a.b.c == paramH) || (r.b == null) || (r.b.c == paramH) || (j == c.c))) {
              break label979;
            }
            bool1 = true;
            label702:
            I = bool1;
            n = j;
            if (I)
            {
              if (r.b != null) {
                break label985;
              }
              label729:
              n = j + (j - D);
            }
          }
        }
        label740:
        j = m;
        i1 = n;
        if (r.b == null) {
          break;
        }
        j = m;
        i1 = n;
        if (localObject2.equals()) {
          break;
        }
        int i2;
        if (r.b.q() == f.b)
        {
          i2 = m + (B - localObject2.size());
          label804:
          if (!o)
          {
            bool1 = bool2;
            if (a.b != null)
            {
              bool1 = bool2;
              if (a.b.c != paramH)
              {
                bool1 = bool2;
                if (r.b != null)
                {
                  bool1 = bool2;
                  if (r.b.c != paramH)
                  {
                    bool1 = bool2;
                    if (j == c.c) {}
                  }
                }
              }
            }
          }
          else
          {
            bool1 = true;
          }
          o = bool1;
          j = i2;
          i1 = n;
          if (!o) {
            break;
          }
          if (a.b != null) {
            break label1039;
          }
        }
        for (;;)
        {
          j = i2 + (i2 - B);
          i1 = n;
          break;
          label948:
          j = i1;
          if (a.b.q() != f.b) {
            break label628;
          }
          j = i1 + D;
          break label628;
          label979:
          bool1 = false;
          break label702;
          label985:
          n = j;
          if (r.b.c == paramH) {
            break label740;
          }
          break label729;
          i2 = m;
          if (r.b.q() != f.a) {
            break label804;
          }
          i2 = m + B;
          break label804;
          label1039:
          j = i2;
          i1 = n;
          if (a.b.c == paramH) {
            break;
          }
        }
        localObject1 = null;
      }
      label1073:
      j = 0;
      m = n;
      continue;
      label1082:
      n = j;
      m = j;
      j = n;
    }
  }
  
  public boolean c(d paramD, int paramInt)
  {
    a(paramD, paramInt);
    int n = a.size();
    if ((c == 2) || (c == 4))
    {
      if (!b(paramD)) {
        break label214;
      }
      return false;
    }
    label214:
    for (int j = 1;; j = 0)
    {
      int m = 0;
      if (m < n)
      {
        h localH = (h)a.get(m);
        if ((localH instanceof ClassWriter))
        {
          c localC1 = c;
          c localC2 = j;
          if (localC1 == c.b) {
            localH.b(c.a);
          }
          if (localC2 == c.b) {
            localH.a(c.a);
          }
          localH.a(paramD, paramInt);
          if (localC1 == c.b) {
            localH.b(localC1);
          }
          if (localC2 == c.b) {
            localH.a(localC2);
          }
        }
        for (;;)
        {
          m += 1;
          break;
          if (j != 0) {
            l.d(this, paramD, localH);
          }
          localH.a(paramD, paramInt);
        }
      }
      if (w > 0) {
        a(paramD);
      }
      if (v > 0) {
        draw(paramD);
      }
      return true;
    }
  }
  
  public boolean exists()
  {
    return false;
  }
  
  public boolean getPaddingBottom()
  {
    return h;
  }
  
  public void init()
  {
    a.b();
    i = 0;
    s = 0;
    u = 0;
    p = 0;
    super.init();
  }
  
  public void put(int paramInt)
  {
    c = paramInt;
  }
  
  public boolean put()
  {
    return l;
  }
}

package android.support.constraint.asm.asm;

import android.support.constraint.asm.Label;
import android.support.constraint.asm.c;
import java.util.HashSet;

public class i
{
  Label a;
  i b;
  final h c;
  final f d;
  private AnchorPosition g = AnchorPosition.a;
  int h = -1;
  public int i = 0;
  int j = Integer.MAX_VALUE;
  private TextOrientationType k = TextOrientationType.b;
  private int m = 0;
  
  public i(h paramH, f paramF)
  {
    c = paramH;
    d = paramF;
  }
  
  private String a(HashSet paramHashSet)
  {
    if (paramHashSet.add(this))
    {
      StringBuilder localStringBuilder = new StringBuilder().append(c.getTitle()).append(":").append(d.toString());
      if (b != null) {}
      for (paramHashSet = " connected to " + b.a(paramHashSet);; paramHashSet = "") {
        return paramHashSet;
      }
    }
    return "<-";
  }
  
  public void a()
  {
    b = null;
    i = 0;
    h = -1;
    g = AnchorPosition.c;
    m = 0;
    k = TextOrientationType.b;
  }
  
  public void a(TextOrientationType paramTextOrientationType)
  {
    k = paramTextOrientationType;
  }
  
  public void a(android.support.constraint.asm.f paramF)
  {
    if (a == null)
    {
      a = new Label(c.c);
      return;
    }
    a.b();
  }
  
  public boolean a(i paramI)
  {
    if (paramI == null) {
      return false;
    }
    f localF = paramI.q();
    if (localF == d)
    {
      if ((d != f.g) && ((d != f.r) || ((paramI.c().n()) && (c().n())))) {
        return true;
      }
    }
    else
    {
      boolean bool2;
      switch (Type.d[d.ordinal()])
      {
      default: 
        return false;
      case 1: 
        return (localF != f.r) && (localF != f.d) && (localF != f.e);
      case 2: 
      case 3: 
        if ((localF == f.c) || (localF == f.i)) {}
        for (bool1 = true;; bool1 = false)
        {
          bool2 = bool1;
          if (!(paramI.c() instanceof m)) {
            break;
          }
          if ((!bool1) && (localF != f.d)) {
            break label257;
          }
          return true;
        }
      }
      if ((localF == f.a) || (localF == f.b)) {}
      for (boolean bool1 = true;; bool1 = false)
      {
        bool2 = bool1;
        if (!(paramI.c() instanceof m)) {
          break;
        }
        if ((!bool1) && (localF != f.e)) {
          break label257;
        }
        return true;
      }
      return bool2;
    }
    label257:
    return false;
  }
  
  public boolean a(i paramI, int paramInt1, int paramInt2, AnchorPosition paramAnchorPosition, int paramInt3, boolean paramBoolean)
  {
    if (paramI == null)
    {
      b = null;
      i = 0;
      h = -1;
      g = AnchorPosition.a;
      m = 2;
      return true;
    }
    if ((!paramBoolean) && (!a(paramI))) {
      return false;
    }
    b = paramI;
    if (paramInt1 > 0) {}
    for (i = paramInt1;; i = 0)
    {
      h = paramInt2;
      g = paramAnchorPosition;
      m = paramInt3;
      return true;
    }
  }
  
  public boolean a(i paramI, int paramInt1, AnchorPosition paramAnchorPosition, int paramInt2)
  {
    return a(paramI, paramInt1, -1, paramAnchorPosition, paramInt2, false);
  }
  
  public int b()
  {
    if (c.ordinal() == 8) {
      return 0;
    }
    if ((h > -1) && (b != null) && (b.c.ordinal() == 8)) {
      return h;
    }
    return i;
  }
  
  public h c()
  {
    return c;
  }
  
  public AnchorPosition e()
  {
    return g;
  }
  
  public boolean equals()
  {
    return b != null;
  }
  
  public TextOrientationType i()
  {
    return k;
  }
  
  public int l()
  {
    return m;
  }
  
  public Label m()
  {
    return a;
  }
  
  public f q()
  {
    return d;
  }
  
  public i size()
  {
    return b;
  }
  
  public String toString()
  {
    Object localObject = new HashSet();
    StringBuilder localStringBuilder = new StringBuilder().append(c.getTitle()).append(":").append(d.toString());
    if (b != null) {}
    for (localObject = " connected to " + b.a((HashSet)localObject);; localObject = "") {
      return (String)localObject;
    }
  }
}

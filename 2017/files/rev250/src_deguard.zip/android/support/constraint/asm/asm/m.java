package android.support.constraint.asm.asm;

import android.support.constraint.asm.d;
import java.util.ArrayList;

public class m
  extends h
{
  private i a = a;
  private int b = 0;
  private boolean c = false;
  private int e = 0;
  protected int k = -1;
  protected float m = -1.0F;
  protected int n = -1;
  private ByteVector r = new ByteVector();
  private int s = 8;
  
  public m()
  {
    n.clear();
    n.add(a);
  }
  
  public int a()
  {
    return k;
  }
  
  public i a(f paramF)
  {
    switch (XYGraphWidget.a.a[paramF.ordinal()])
    {
    default: 
      break;
    }
    do
    {
      do
      {
        return null;
      } while (e != 1);
      return a;
    } while (e != 0);
    return a;
  }
  
  public void a(d paramD, int paramInt)
  {
    ClassWriter localClassWriter = (ClassWriter)next();
    if (localClassWriter == null) {
      return;
    }
    i localI1 = localClassWriter.a(f.c);
    i localI2 = localClassWriter.a(f.i);
    if (e == 0)
    {
      localI1 = localClassWriter.a(f.a);
      localI2 = localClassWriter.a(f.b);
    }
    for (;;)
    {
      if (n != -1)
      {
        paramD.a(d.c(paramD, paramD.a(a), paramD.a(localI1), n, false));
        return;
      }
      if (k != -1)
      {
        paramD.a(d.c(paramD, paramD.a(a), paramD.a(localI2), -k, false));
        return;
      }
      if (m == -1.0F) {
        break;
      }
      paramD.a(d.a(paramD, paramD.a(a), paramD.a(localI1), paramD.a(localI2), m, c));
      return;
    }
  }
  
  public void add(int paramInt)
  {
    if (paramInt > -1)
    {
      m = -1.0F;
      n = paramInt;
      k = -1;
    }
  }
  
  public void b(d paramD, int paramInt)
  {
    if (next() == null) {
      return;
    }
    paramInt = paramD.b(a);
    if (e == 1)
    {
      b(paramInt);
      a(0);
      e(next().get());
      c(0);
      return;
    }
    b(0);
    a(paramInt);
    c(next().getValue());
    e(0);
  }
  
  public void d(float paramFloat)
  {
    if (paramFloat > -1.0F)
    {
      m = paramFloat;
      n = -1;
      k = -1;
    }
  }
  
  public int g()
  {
    return n;
  }
  
  public void getIcon(int paramInt)
  {
    if (paramInt > -1)
    {
      m = -1.0F;
      n = -1;
      k = paramInt;
    }
  }
  
  public int getItemId()
  {
    return e;
  }
  
  public ArrayList j()
  {
    return n;
  }
  
  public float m()
  {
    return m;
  }
  
  public void setTitle(int paramInt)
  {
    if (e == paramInt) {
      return;
    }
    e = paramInt;
    n.clear();
    if (e == 1) {}
    for (a = b;; a = a)
    {
      n.add(a);
      return;
    }
  }
}

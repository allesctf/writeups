package android.support.constraint.asm.asm;

import android.support.constraint.a.a.g.a;
import java.util.ArrayList;

public class e
{
  private int a;
  private int b;
  private int d;
  private int i;
  private ArrayList<g.a> j = new ArrayList();
  
  public e(h paramH)
  {
    i = paramH.l();
    b = paramH.getString();
    d = paramH.getValue();
    a = paramH.get();
    paramH = paramH.j();
    int m = paramH.size();
    int k = 0;
    while (k < m)
    {
      i localI = (i)paramH.get(k);
      j.add(new MethodWriter(localI));
      k += 1;
    }
  }
  
  public void a(h paramH)
  {
    paramH.b(i);
    paramH.a(b);
    paramH.c(d);
    paramH.e(a);
    int m = j.size();
    int k = 0;
    while (k < m)
    {
      ((MethodWriter)j.get(k)).b(paramH);
      k += 1;
    }
  }
  
  public void b(h paramH)
  {
    i = paramH.l();
    b = paramH.getString();
    d = paramH.getValue();
    a = paramH.get();
    int m = j.size();
    int k = 0;
    while (k < m)
    {
      ((MethodWriter)j.get(k)).a(paramH);
      k += 1;
    }
  }
}

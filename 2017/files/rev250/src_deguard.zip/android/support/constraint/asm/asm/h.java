package android.support.constraint.asm.asm;

import android.support.constraint.a.a.a;
import android.support.constraint.asm.Item;
import android.support.constraint.asm.Label;
import android.support.constraint.asm.d;
import java.util.ArrayList;

public class h
{
  public static float FILL = 0.5F;
  int A = 0;
  int B;
  float C = FILL;
  int D;
  boolean E;
  private int F = 0;
  private int G = 0;
  i H = new i(this, f.d);
  boolean I;
  boolean J;
  private int K = 0;
  private int L;
  private int M;
  private int N = 0;
  i U = new i(this, f.e);
  i V = new i(this, f.g);
  i a = new i(this, f.a);
  i b = new i(this, f.c);
  int bottom;
  c c = c.a;
  i d = new i(this, f.r);
  private int data = 0;
  int e = 0;
  float f = FILL;
  protected int flags = 0;
  int g = 0;
  public int h = -1;
  boolean header;
  float height = 0.0F;
  i i = new i(this, f.i);
  private int id = 0;
  private int index = 0;
  h items = null;
  c j = c.a;
  public int k = -1;
  protected int l;
  int left = 0;
  boolean length;
  private int limit = 0;
  int m = 0;
  int mHeight = 0;
  protected int max = 0;
  protected ArrayList<a> n = new ArrayList();
  private String name = null;
  boolean o;
  int offset = 0;
  protected int p = -1;
  private int pos = 0;
  private int position = 0;
  int q;
  i r = new i(this, f.b);
  float right = 0.0F;
  protected int s = 0;
  int size = 0;
  int t = 0;
  private String text = null;
  boolean top;
  h type = null;
  protected int u;
  h v = null;
  private Object view;
  protected int w = 0;
  int width = 0;
  int x = 0;
  protected float y = 0.0F;
  boolean z;
  
  public h()
  {
    a();
  }
  
  private void a()
  {
    n.add(b);
    n.add(a);
    n.add(i);
    n.add(r);
    n.add(H);
    n.add(U);
    n.add(d);
  }
  
  private void a(d paramD, boolean paramBoolean1, boolean paramBoolean2, i paramI1, i paramI2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, boolean paramBoolean3, boolean paramBoolean4, int paramInt5, int paramInt6, int paramInt7)
  {
    Label localLabel3 = paramD.a(paramI1);
    Label localLabel1 = paramD.a(paramI2);
    Label localLabel4 = paramD.a(paramI1.size());
    Label localLabel2 = paramD.a(paramI2.size());
    int i1 = paramI1.b();
    int i2 = paramI2.b();
    if (index == 8)
    {
      paramInt3 = 0;
      paramBoolean2 = true;
    }
    for (;;)
    {
      if ((localLabel4 == null) && (localLabel2 == null))
      {
        paramD.a(paramD.a().a(localLabel3, paramInt1));
        if (paramBoolean3) {
          break;
        }
        if (paramBoolean1)
        {
          paramD.a(d.c(paramD, localLabel1, localLabel3, paramInt4, true));
          return;
        }
        if (paramBoolean2)
        {
          paramD.a(d.c(paramD, localLabel1, localLabel3, paramInt3, false));
          return;
        }
        paramD.a(paramD.a().a(localLabel1, paramInt2));
        return;
      }
      if ((localLabel4 != null) && (localLabel2 == null))
      {
        paramD.a(paramD.a().a(localLabel3, localLabel4, i1));
        if (paramBoolean1)
        {
          paramD.a(d.c(paramD, localLabel1, localLabel3, paramInt4, true));
          return;
        }
        if (paramBoolean3) {
          break;
        }
        if (paramBoolean2)
        {
          paramD.a(paramD.a().a(localLabel1, localLabel3, paramInt3));
          return;
        }
        paramD.a(paramD.a().a(localLabel1, paramInt2));
        return;
      }
      if ((localLabel4 == null) && (localLabel2 != null))
      {
        paramD.a(paramD.a().a(localLabel1, localLabel2, i2 * -1));
        if (paramBoolean1)
        {
          paramD.a(d.c(paramD, localLabel1, localLabel3, paramInt4, true));
          return;
        }
        if (paramBoolean3) {
          break;
        }
        if (paramBoolean2)
        {
          paramD.a(paramD.a().a(localLabel1, localLabel3, paramInt3));
          return;
        }
        paramD.a(paramD.a().a(localLabel3, paramInt1));
        return;
      }
      if (paramBoolean2)
      {
        if (paramBoolean1) {
          paramD.a(d.c(paramD, localLabel1, localLabel3, paramInt4, true));
        }
        while (paramI1.e() != paramI2.e()) {
          if (paramI1.e() == AnchorPosition.c)
          {
            paramD.a(paramD.a().a(localLabel3, localLabel4, i1));
            paramI1 = paramD.c();
            paramI2 = paramD.a();
            paramI2.a(localLabel1, localLabel2, paramI1, i2 * -1);
            paramD.a(paramI2);
            return;
            paramD.a(paramD.a().a(localLabel1, localLabel3, paramInt3));
          }
          else
          {
            paramI1 = paramD.c();
            paramI2 = paramD.a();
            paramI2.b(localLabel3, localLabel4, paramI1, i1);
            paramD.a(paramI2);
            paramD.a(paramD.a().a(localLabel1, localLabel2, i2 * -1));
            return;
          }
        }
        if (localLabel4 == localLabel2)
        {
          paramD.a(d.a(paramD, localLabel3, localLabel4, 0, 0.5F, localLabel2, localLabel1, 0, true));
          return;
        }
        if (paramBoolean4) {
          break;
        }
        if (paramI1.i() != TextOrientationType.d)
        {
          paramBoolean1 = true;
          paramD.a(d.a(paramD, localLabel3, localLabel4, i1, paramBoolean1));
          if (paramI2.i() == TextOrientationType.d) {
            break label626;
          }
        }
        label626:
        for (paramBoolean1 = true;; paramBoolean1 = false)
        {
          paramD.a(d.b(paramD, localLabel1, localLabel2, i2 * -1, paramBoolean1));
          paramD.a(d.a(paramD, localLabel3, localLabel4, i1, paramFloat, localLabel2, localLabel1, i2, false));
          return;
          paramBoolean1 = false;
          break;
        }
      }
      if (paramBoolean3)
      {
        paramD.b(localLabel3, localLabel4, i1, 3);
        paramD.c(localLabel1, localLabel2, i2 * -1, 3);
        paramD.a(d.a(paramD, localLabel3, localLabel4, i1, paramFloat, localLabel2, localLabel1, i2, true));
        return;
      }
      if (paramBoolean4) {
        break;
      }
      if (paramInt5 == 1)
      {
        paramInt1 = paramInt3;
        if (paramInt6 > paramInt3) {
          paramInt1 = paramInt6;
        }
        if (paramInt7 > 0) {
          if (paramInt7 >= paramInt1) {}
        }
        for (;;)
        {
          paramD.a(localLabel1, localLabel3, paramInt7, 3);
          paramD.b(localLabel3, localLabel4, i1, 2);
          paramD.c(localLabel1, localLabel2, -i2, 2);
          paramD.a(localLabel3, localLabel4, i1, paramFloat, localLabel2, localLabel1, i2, 4);
          return;
          paramD.c(localLabel1, localLabel3, paramInt7, 3);
          paramInt7 = paramInt1;
        }
      }
      if ((paramInt6 == 0) && (paramInt7 == 0))
      {
        paramD.a(paramD.a().a(localLabel3, localLabel4, i1));
        paramD.a(paramD.a().a(localLabel1, localLabel2, i2 * -1));
        return;
      }
      if (paramInt7 > 0) {
        paramD.c(localLabel1, localLabel3, paramInt7, 3);
      }
      paramD.b(localLabel3, localLabel4, i1, 2);
      paramD.c(localLabel1, localLabel2, -i2, 2);
      paramD.a(localLabel3, localLabel4, i1, paramFloat, localLabel2, localLabel1, i2, 4);
      return;
    }
  }
  
  public i a(f paramF)
  {
    switch (Item.d[paramF.ordinal()])
    {
    default: 
      return null;
    case 1: 
      return b;
    case 2: 
      return a;
    case 3: 
      return i;
    case 4: 
      return r;
    case 5: 
      return d;
    case 6: 
      return H;
    case 7: 
      return U;
    }
    return V;
  }
  
  public void a(float paramFloat)
  {
    C = paramFloat;
  }
  
  public void a(int paramInt)
  {
    s = paramInt;
  }
  
  public void a(int paramInt1, int paramInt2)
  {
    max = paramInt1;
    flags = paramInt2;
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3)
  {
    t = paramInt1;
    e = paramInt2;
    g = paramInt3;
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i1 = paramInt3 - paramInt1;
    paramInt3 = paramInt4 - paramInt2;
    w = paramInt1;
    s = paramInt2;
    if (index == 8)
    {
      x = 0;
      m = 0;
      return;
    }
    paramInt1 = i1;
    if (c == c.a)
    {
      paramInt1 = i1;
      if (i1 < x) {
        paramInt1 = x;
      }
    }
    paramInt2 = paramInt3;
    if (j == c.a)
    {
      paramInt2 = paramInt3;
      if (paramInt3 < m) {
        paramInt2 = m;
      }
    }
    x = paramInt1;
    m = paramInt2;
    if (m < l) {
      m = l;
    }
    if (x < u) {
      x = u;
    }
  }
  
  public void a(c paramC)
  {
    j = paramC;
    if (j == c.b) {
      e(M);
    }
  }
  
  public void a(f paramF1, h paramH, f paramF2, int paramInt1, int paramInt2)
  {
    a(paramF1).a(paramH.a(paramF2), paramInt1, paramInt2, AnchorPosition.c, 0, true);
  }
  
  public void a(d paramD, int paramInt)
  {
    if ((paramInt == Integer.MAX_VALUE) || (b.j == paramInt)) {}
    for (Label localLabel1 = paramD.a(b);; localLabel1 = null)
    {
      if ((paramInt == Integer.MAX_VALUE) || (i.j == paramInt)) {}
      for (Label localLabel2 = paramD.a(i);; localLabel2 = null)
      {
        if ((paramInt == Integer.MAX_VALUE) || (a.j == paramInt)) {}
        for (Label localLabel3 = paramD.a(a);; localLabel3 = null)
        {
          if ((paramInt == Integer.MAX_VALUE) || (r.j == paramInt)) {}
          for (Label localLabel4 = paramD.a(r);; localLabel4 = null)
          {
            if ((paramInt == Integer.MAX_VALUE) || (d.j == paramInt)) {}
            for (Object localObject1 = paramD.a(d);; localObject1 = null)
            {
              boolean bool1;
              boolean bool2;
              label285:
              Object localObject2;
              Object localObject3;
              label437:
              label522:
              boolean bool3;
              boolean bool4;
              if (v != null) {
                if (((b.b != null) && (b.b.b == b)) || ((i.b != null) && (i.b.b == i)))
                {
                  ((ClassWriter)v).a(this, 0);
                  bool1 = true;
                  if (((a.b != null) && (a.b.b == a)) || ((r.b != null) && (r.b.b == r)))
                  {
                    ((ClassWriter)v).a(this, 1);
                    bool2 = true;
                    if ((v.i() == c.b) && (!bool1))
                    {
                      if ((b.b == null) || (b.b.c != v))
                      {
                        localObject2 = paramD.a(v.b);
                        localObject3 = paramD.a();
                        ((Item)localObject3).b(localLabel1, (Label)localObject2, paramD.c(), 0);
                        paramD.a((Item)localObject3);
                        if ((i.b != null) && (i.b.c == v)) {
                          break label1144;
                        }
                        localObject2 = paramD.a(v.i);
                        localObject3 = paramD.a();
                        ((Item)localObject3).b((Label)localObject2, localLabel2, paramD.c(), 0);
                        paramD.a((Item)localObject3);
                      }
                    }
                    else
                    {
                      if ((v.getIcon() != c.b) || (bool2)) {
                        break label1261;
                      }
                      if ((a.b != null) && (a.b.c == v)) {
                        break label1184;
                      }
                      localObject2 = paramD.a(v.a);
                      localObject3 = paramD.a();
                      ((Item)localObject3).b(localLabel3, (Label)localObject2, paramD.c(), 0);
                      paramD.a((Item)localObject3);
                      if ((r.b != null) && (r.b.c == v)) {
                        break label1224;
                      }
                      localObject2 = paramD.a(v.r);
                      localObject3 = paramD.a();
                      ((Item)localObject3).b((Label)localObject2, localLabel4, paramD.c(), 0);
                      paramD.a((Item)localObject3);
                      bool3 = bool2;
                      bool4 = bool1;
                    }
                  }
                }
              }
              for (;;)
              {
                label597:
                int i1 = x;
                int i3 = i1;
                if (i1 < u) {
                  i3 = u;
                }
                i1 = m;
                int i4 = i1;
                if (i1 < l) {
                  i4 = l;
                }
                if (c != c.c)
                {
                  bool1 = true;
                  label660:
                  if (j == c.c) {
                    break label1278;
                  }
                  bool2 = true;
                  label673:
                  if ((bool1) || (b == null) || (i == null) || ((b.b != null) && (i.b != null))) {
                    break label2291;
                  }
                  bool1 = true;
                }
                label897:
                label917:
                label1095:
                label1144:
                label1184:
                label1224:
                label1261:
                label1278:
                label1428:
                label1434:
                label1491:
                label1531:
                label1847:
                label1853:
                label1920:
                label2150:
                label2271:
                label2282:
                label2285:
                label2291:
                for (;;)
                {
                  if ((!bool2) && (a != null) && (r != null) && ((a.b == null) || (r.b == null)) && ((A == 0) || ((d != null) && ((a.b == null) || (d.b == null))))) {
                    bool2 = true;
                  }
                  for (;;)
                  {
                    int i6 = 0;
                    int i5 = p;
                    float f1 = y;
                    i1 = i5;
                    int i2 = i6;
                    if (y > 0.0F)
                    {
                      i1 = i5;
                      i2 = i6;
                      if (index != 8) {
                        if ((c == c.c) && (j == c.c))
                        {
                          i6 = 1;
                          if ((bool1) && (!bool2))
                          {
                            i1 = 0;
                            i2 = 1;
                          }
                        }
                      }
                    }
                    for (;;)
                    {
                      boolean bool5;
                      boolean bool6;
                      Label localLabel5;
                      if ((i2 != 0) && ((i1 == 0) || (i1 == -1)))
                      {
                        bool5 = true;
                        if ((c != c.b) || (!(this instanceof ClassWriter))) {
                          break label1428;
                        }
                        bool6 = true;
                        if ((k != 2) && ((paramInt == Integer.MAX_VALUE) || ((b.j == paramInt) && (i.j == paramInt))))
                        {
                          if ((!bool5) || (b.b == null) || (i.b == null)) {
                            break label1434;
                          }
                          localObject2 = paramD.a(b);
                          localObject3 = paramD.a(i);
                          localLabel5 = paramD.a(b.size());
                          Label localLabel6 = paramD.a(i.size());
                          paramD.b((Label)localObject2, localLabel5, b.b(), 3);
                          paramD.c((Label)localObject3, localLabel6, i.b() * -1, 3);
                          if (!bool4) {
                            paramD.a((Label)localObject2, localLabel5, b.b(), C, localLabel6, (Label)localObject3, i.b(), 4);
                          }
                        }
                        if (h != 2) {
                          break label1491;
                        }
                        return;
                        if ((b.b == null) || (b.b.c != v)) {
                          break;
                        }
                        b.a(TextOrientationType.d);
                        break;
                        if ((i.b == null) || (i.b.c != v)) {
                          break label437;
                        }
                        i.a(TextOrientationType.d);
                        break label437;
                        if ((a.b == null) || (a.b.c != v)) {
                          break label522;
                        }
                        a.a(TextOrientationType.d);
                        break label522;
                        if ((r.b != null) && (r.b.c == v)) {
                          r.a(TextOrientationType.d);
                        }
                        bool4 = bool1;
                        bool3 = bool2;
                        break label597;
                        bool1 = false;
                        break label660;
                        bool2 = false;
                        break label673;
                        i1 = i5;
                        i2 = i6;
                        if (bool1) {
                          break label2285;
                        }
                        i1 = i5;
                        i2 = i6;
                        if (!bool2) {
                          break label2285;
                        }
                        i1 = 1;
                        i2 = i6;
                        if (p != -1) {
                          break label2285;
                        }
                        f1 = 1.0F / f1;
                        i1 = 1;
                        i2 = 1;
                        continue;
                        if (c == c.c)
                        {
                          i3 = (int)(m * f1);
                          i1 = 0;
                          i2 = 0;
                          bool1 = true;
                          continue;
                        }
                        i1 = i5;
                        i2 = i6;
                        if (j != c.c) {
                          break label2285;
                        }
                        if (p != -1) {
                          break label2282;
                        }
                        f1 = 1.0F / f1;
                      }
                      for (;;)
                      {
                        i4 = (int)(x * f1);
                        i1 = 1;
                        i2 = 0;
                        bool2 = true;
                        break;
                        bool5 = false;
                        break label897;
                        bool6 = false;
                        break label917;
                        a(paramD, bool6, bool1, b, i, w, w + i3, i3, u, C, bool5, bool4, t, e, g);
                        break label1095;
                        if ((j == c.b) && ((this instanceof ClassWriter)))
                        {
                          bool1 = true;
                          if ((i2 == 0) || ((i1 != 1) && (i1 != -1))) {
                            break label1847;
                          }
                          bool4 = true;
                          if (A <= 0) {
                            break label1920;
                          }
                          localObject2 = r;
                          if ((paramInt == Integer.MAX_VALUE) || ((r.j == paramInt) && (d.j == paramInt))) {
                            paramD.a((Label)localObject1, localLabel3, isVisible(), 5);
                          }
                          if (d.b == null) {
                            break label2271;
                          }
                          i3 = A;
                        }
                        for (localObject1 = d;; localObject1 = localObject2)
                        {
                          if ((paramInt == Integer.MAX_VALUE) || ((a.j == paramInt) && (j == paramInt)))
                          {
                            if ((!bool4) || (a.b == null) || (r.b == null)) {
                              break label1853;
                            }
                            localObject1 = paramD.a(a);
                            localObject2 = paramD.a(r);
                            localObject3 = paramD.a(a.size());
                            localLabel5 = paramD.a(r.size());
                            paramD.b((Label)localObject1, (Label)localObject3, a.b(), 3);
                            paramD.c((Label)localObject2, localLabel5, r.b() * -1, 3);
                            if (!bool3) {
                              paramD.a((Label)localObject1, (Label)localObject3, a.b(), f, localLabel5, (Label)localObject2, r.b(), 4);
                            }
                          }
                          for (;;)
                          {
                            if (i2 == 0) {
                              return;
                            }
                            localObject1 = paramD.a();
                            if ((paramInt != Integer.MAX_VALUE) && ((b.j != paramInt) || (i.j != paramInt))) {
                              return;
                            }
                            if (i1 != 0) {
                              break label2150;
                            }
                            paramD.a(((Item)localObject1).a(localLabel2, localLabel1, localLabel4, localLabel3, f1));
                            return;
                            bool1 = false;
                            break;
                            bool4 = false;
                            break label1531;
                            a(paramD, bool1, bool2, a, (i)localObject1, s, s + i3, i3, l, f, bool4, bool3, left, offset, size);
                            paramD.a(localLabel4, localLabel3, i4, 5);
                            continue;
                            if ((paramInt == Integer.MAX_VALUE) || ((a.j == paramInt) && (r.j == paramInt))) {
                              if ((bool4) && (a.b != null) && (r.b != null))
                              {
                                localObject1 = paramD.a(a);
                                localObject2 = paramD.a(r);
                                localObject3 = paramD.a(a.size());
                                localLabel5 = paramD.a(r.size());
                                paramD.b((Label)localObject1, (Label)localObject3, a.b(), 3);
                                paramD.c((Label)localObject2, localLabel5, r.b() * -1, 3);
                                if (!bool3) {
                                  paramD.a((Label)localObject1, (Label)localObject3, a.b(), f, localLabel5, (Label)localObject2, r.b(), 4);
                                }
                              }
                              else
                              {
                                a(paramD, bool1, bool2, a, r, s, s + i4, i4, l, f, bool4, bool3, left, offset, size);
                              }
                            }
                          }
                          if (i1 == 1)
                          {
                            paramD.a(((Item)localObject1).a(localLabel4, localLabel3, localLabel2, localLabel1, f1));
                            return;
                          }
                          if (e > 0) {
                            paramD.b(localLabel2, localLabel1, e, 3);
                          }
                          if (offset > 0) {
                            paramD.b(localLabel4, localLabel3, offset, 3);
                          }
                          ((Item)localObject1).a(localLabel2, localLabel1, localLabel4, localLabel3, f1);
                          localLabel1 = paramD.d();
                          localLabel2 = paramD.d();
                          k = 4;
                          k = 4;
                          ((Item)localObject1).a(localLabel1, localLabel2);
                          paramD.a((Item)localObject1);
                          return;
                          i3 = i4;
                        }
                      }
                    }
                  }
                }
                bool2 = false;
                break label285;
                bool1 = false;
                break;
                bool3 = false;
                bool4 = false;
              }
            }
          }
        }
      }
    }
  }
  
  public void a(android.support.constraint.asm.f paramF)
  {
    b.a(paramF);
    a.a(paramF);
    i.a(paramF);
    r.a(paramF);
    d.a(paramF);
    V.a(paramF);
    H.a(paramF);
    U.a(paramF);
  }
  
  public void a(Object paramObject)
  {
    view = paramObject;
  }
  
  public void append(float paramFloat)
  {
    height = paramFloat;
  }
  
  public int b()
  {
    int i1 = x;
    int i2 = i1;
    if (c == c.c)
    {
      if (t == 1) {
        i1 = Math.max(e, i1);
      }
      for (;;)
      {
        i2 = i1;
        if (g <= 0) {
          break;
        }
        i2 = i1;
        if (g >= i1) {
          break;
        }
        return g;
        if (e > 0)
        {
          i1 = e;
          x = i1;
        }
        else
        {
          i1 = 0;
        }
      }
    }
    return i2;
  }
  
  public void b(float paramFloat)
  {
    f = paramFloat;
  }
  
  public void b(int paramInt)
  {
    w = paramInt;
  }
  
  public void b(int paramInt1, int paramInt2)
  {
    w = paramInt1;
    x = (paramInt2 - paramInt1);
    if (x < u) {
      x = u;
    }
  }
  
  public void b(int paramInt1, int paramInt2, int paramInt3)
  {
    left = paramInt1;
    offset = paramInt2;
    size = paramInt3;
  }
  
  public void b(c paramC)
  {
    c = paramC;
    if (c == c.b) {
      c(L);
    }
  }
  
  public void b(d paramD, int paramInt)
  {
    if (paramInt == Integer.MAX_VALUE)
    {
      a(paramD.b(b), paramD.b(a), paramD.b(i), paramD.b(r));
      return;
    }
    if (paramInt == -2)
    {
      a(K, F, G, N);
      return;
    }
    if (b.j == paramInt) {
      K = paramD.b(b);
    }
    if (a.j == paramInt) {
      F = paramD.b(a);
    }
    if (i.j == paramInt) {
      G = paramD.b(i);
    }
    if (r.j == paramInt) {
      N = paramD.b(r);
    }
  }
  
  public void b(String paramString)
  {
    int i5 = 0;
    int i3 = 0;
    if ((paramString == null) || (paramString.length() == 0))
    {
      y = 0.0F;
      return;
    }
    int i4 = -1;
    int i6 = paramString.length();
    int i7 = paramString.indexOf(',');
    int i2 = i5;
    int i1 = i4;
    String str;
    if (i7 > 0)
    {
      i2 = i5;
      i1 = i4;
      if (i7 < i6 - 1)
      {
        str = paramString.substring(0, i7);
        if (!str.equalsIgnoreCase("W")) {
          break label212;
        }
        i1 = i3;
      }
    }
    for (;;)
    {
      i2 = i7 + 1;
      i3 = paramString.indexOf(':');
      if ((i3 >= 0) && (i3 < i6 - 1))
      {
        str = paramString.substring(i2, i3);
        paramString = paramString.substring(i3 + 1);
        if ((str.length() <= 0) || (paramString.length() <= 0)) {
          break label275;
        }
      }
      for (;;)
      {
        try
        {
          f1 = Float.parseFloat(str);
          f2 = Float.parseFloat(paramString);
          if ((f1 <= 0.0F) || (f2 <= 0.0F)) {
            break label275;
          }
          if (i1 != 1) {
            continue;
          }
          f1 = f2 / f1;
          f1 = Math.abs(f1);
        }
        catch (NumberFormatException paramString)
        {
          float f2;
          label212:
          f1 = 0.0F;
          continue;
        }
        if (f1 <= 0.0F) {
          return;
        }
        y = f1;
        p = i1;
        return;
        if (!str.equalsIgnoreCase("H")) {
          break label280;
        }
        i1 = 1;
        break;
        f1 /= f2;
        float f1 = Math.abs(f1);
        continue;
        paramString = paramString.substring(i2);
        if (paramString.length() > 0) {
          try
          {
            f1 = Float.parseFloat(paramString);
          }
          catch (NumberFormatException paramString)
          {
            f1 = 0.0F;
          }
        } else {
          label275:
          f1 = 0.0F;
        }
      }
      label280:
      i1 = -1;
    }
  }
  
  public void c()
  {
    h localH = next();
    if ((localH != null) && ((localH instanceof ClassWriter)) && (((ClassWriter)next()).exists())) {
      return;
    }
    int i2 = n.size();
    int i1 = 0;
    while (i1 < i2)
    {
      ((i)n.get(i1)).a();
      i1 += 1;
    }
  }
  
  public void c(float paramFloat)
  {
    right = paramFloat;
  }
  
  public void c(int paramInt)
  {
    x = paramInt;
    if (x < u) {
      x = u;
    }
  }
  
  public void c(int paramInt1, int paramInt2)
  {
    s = paramInt1;
    m = (paramInt2 - paramInt1);
    if (m < l) {
      m = l;
    }
  }
  
  public int d()
  {
    return l() + x;
  }
  
  public void d(int paramInt)
  {
    L = paramInt;
  }
  
  public void d(h paramH)
  {
    v = paramH;
  }
  
  public int e()
  {
    return pos + max;
  }
  
  public void e(int paramInt)
  {
    m = paramInt;
    if (m < l) {
      m = l;
    }
  }
  
  public boolean equals()
  {
    return v == null;
  }
  
  protected int f()
  {
    return w + max;
  }
  
  public void g(int paramInt)
  {
    if (paramInt < 0)
    {
      l = 0;
      return;
    }
    l = paramInt;
  }
  
  public int get()
  {
    if (index == 8) {
      return 0;
    }
    return m;
  }
  
  public int getGroupId()
  {
    return L;
  }
  
  public c getIcon()
  {
    return j;
  }
  
  public int getItem()
  {
    return length() + data;
  }
  
  public void getItem(int paramInt)
  {
    mHeight = paramInt;
  }
  
  public int getString()
  {
    return s;
  }
  
  public String getTitle()
  {
    return name;
  }
  
  public int getValue()
  {
    if (index == 8) {
      return 0;
    }
    return x;
  }
  
  public Object getView()
  {
    return view;
  }
  
  public int h()
  {
    return M;
  }
  
  public void h(int paramInt1, int paramInt2)
  {
    w = paramInt1;
    s = paramInt2;
  }
  
  public c i()
  {
    return c;
  }
  
  public void init()
  {
    b.a();
    a.a();
    i.a();
    r.a();
    d.a();
    H.a();
    U.a();
    V.a();
    v = null;
    x = 0;
    m = 0;
    y = 0.0F;
    p = -1;
    w = 0;
    s = 0;
    pos = 0;
    limit = 0;
    position = 0;
    data = 0;
    max = 0;
    flags = 0;
    A = 0;
    u = 0;
    l = 0;
    L = 0;
    M = 0;
    C = FILL;
    f = FILL;
    c = c.a;
    j = c.a;
    view = null;
    id = 0;
    index = 0;
    name = null;
    text = null;
    top = false;
    E = false;
    width = 0;
    mHeight = 0;
    header = false;
    length = false;
    right = 0.0F;
    height = 0.0F;
    k = -1;
    h = -1;
  }
  
  protected int isEnabled()
  {
    return s + flags;
  }
  
  public int isVisible()
  {
    return A;
  }
  
  public ArrayList j()
  {
    return n;
  }
  
  public int k()
  {
    return e() + position;
  }
  
  public int l()
  {
    return w;
  }
  
  public int length()
  {
    return limit + flags;
  }
  
  public void measure(int paramInt)
  {
    A = paramInt;
  }
  
  public boolean n()
  {
    return A > 0;
  }
  
  public h next()
  {
    return v;
  }
  
  public int ordinal()
  {
    return index;
  }
  
  public void putShort(int paramInt)
  {
    index = paramInt;
  }
  
  public void setEnabled(int paramInt)
  {
    if (paramInt < 0)
    {
      u = 0;
      return;
    }
    u = paramInt;
  }
  
  public void setIcon(int paramInt)
  {
    width = paramInt;
  }
  
  public int setTitle()
  {
    return getString() + m;
  }
  
  public int size()
  {
    int i1 = m;
    int i2 = i1;
    if (j == c.c)
    {
      if (left == 1) {
        i1 = Math.max(offset, i1);
      }
      for (;;)
      {
        i2 = i1;
        if (size <= 0) {
          break;
        }
        i2 = i1;
        if (size >= i1) {
          break;
        }
        return size;
        if (offset > 0)
        {
          i1 = offset;
          m = i1;
        }
        else
        {
          i1 = 0;
        }
      }
    }
    return i2;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (text != null)
    {
      str = "type: " + text + " ";
      localStringBuilder = localStringBuilder.append(str);
      if (name == null) {
        break label194;
      }
    }
    label194:
    for (String str = "id: " + name + " ";; str = "")
    {
      return str + "(" + w + ", " + s + ") - (" + x + " x " + m + ")" + " wrap: (" + L + " x " + M + ")";
      str = "";
      break;
    }
  }
  
  public void update(int paramInt)
  {
    M = paramInt;
  }
  
  public void write()
  {
    int i1 = w;
    int i2 = s;
    int i3 = w;
    int i4 = x;
    int i5 = s;
    int i6 = m;
    pos = i1;
    limit = i2;
    position = (i3 + i4 - i1);
    data = (i5 + i6 - i2);
  }
}

package android.support.constraint.asm;

import android.support.constraint.a.b;
import android.support.constraint.a.f.a;
import android.support.constraint.a.g;

public class f
{
  Label[] b = new Label[32];
  f.a<g> c = new e(256);
  f.a<b> n = new e(256);
  
  public f() {}
}

package android.support.constraint.asm;

import android.support.constraint.a.g.a;

public enum c
{
  static
  {
    a = new c("SLACK", 2);
    f = new c("ERROR", 3);
  }
}

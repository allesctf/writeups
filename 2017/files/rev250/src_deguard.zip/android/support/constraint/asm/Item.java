package android.support.constraint.asm;

public class Item
{
  float a = 0.0F;
  final i b;
  Label c = null;
  boolean e = false;
  boolean i = false;
  
  public Item(f paramF)
  {
    b = new i(this, paramF);
  }
  
  public Item a(float paramFloat1, float paramFloat2, float paramFloat3, Label paramLabel1, int paramInt1, Label paramLabel2, int paramInt2, Label paramLabel3, int paramInt3, Label paramLabel4, int paramInt4)
  {
    if ((paramFloat2 == 0.0F) || (paramFloat1 == paramFloat3))
    {
      a = (-paramInt1 - paramInt2 + paramInt3 + paramInt4);
      b.a(paramLabel1, 1.0F);
      b.a(paramLabel2, -1.0F);
      b.a(paramLabel4, 1.0F);
      b.a(paramLabel3, -1.0F);
      return this;
    }
    paramFloat1 = paramFloat1 / paramFloat2 / (paramFloat3 / paramFloat2);
    a = (-paramInt1 - paramInt2 + paramInt3 * paramFloat1 + paramInt4 * paramFloat1);
    b.a(paramLabel1, 1.0F);
    b.a(paramLabel2, -1.0F);
    b.a(paramLabel4, paramFloat1);
    b.a(paramLabel3, -paramFloat1);
    return this;
  }
  
  public Item a(Label paramLabel, int paramInt)
  {
    if (paramInt < 0)
    {
      a = (paramInt * -1);
      b.a(paramLabel, 1.0F);
      return this;
    }
    a = paramInt;
    b.a(paramLabel, -1.0F);
    return this;
  }
  
  public Item a(Label paramLabel1, Label paramLabel2)
  {
    b.a(paramLabel1, 1.0F);
    b.a(paramLabel2, -1.0F);
    return this;
  }
  
  public Item a(Label paramLabel1, Label paramLabel2, int paramInt)
  {
    int j = 0;
    int k = 0;
    if (paramInt != 0)
    {
      j = k;
      k = paramInt;
      if (paramInt < 0)
      {
        k = paramInt * -1;
        j = 1;
      }
      a = k;
    }
    if (j == 0)
    {
      b.a(paramLabel1, -1.0F);
      b.a(paramLabel2, 1.0F);
      return this;
    }
    b.a(paramLabel1, 1.0F);
    b.a(paramLabel2, -1.0F);
    return this;
  }
  
  Item a(Label paramLabel1, Label paramLabel2, int paramInt1, float paramFloat, Label paramLabel3, Label paramLabel4, int paramInt2)
  {
    if (paramLabel2 == paramLabel3)
    {
      b.a(paramLabel1, 1.0F);
      b.a(paramLabel4, 1.0F);
      b.a(paramLabel2, -2.0F);
      return this;
    }
    if (paramFloat == 0.5F)
    {
      b.a(paramLabel1, 1.0F);
      b.a(paramLabel2, -1.0F);
      b.a(paramLabel3, -1.0F);
      b.a(paramLabel4, 1.0F);
      if ((paramInt1 > 0) || (paramInt2 > 0))
      {
        a = (-paramInt1 + paramInt2);
        return this;
      }
    }
    else
    {
      if (paramFloat <= 0.0F)
      {
        b.a(paramLabel1, -1.0F);
        b.a(paramLabel2, 1.0F);
        a = paramInt1;
        return this;
      }
      if (paramFloat >= 1.0F)
      {
        b.a(paramLabel3, -1.0F);
        b.a(paramLabel4, 1.0F);
        a = paramInt2;
        return this;
      }
      b.a(paramLabel1, (1.0F - paramFloat) * 1.0F);
      b.a(paramLabel2, (1.0F - paramFloat) * -1.0F);
      b.a(paramLabel3, -1.0F * paramFloat);
      b.a(paramLabel4, 1.0F * paramFloat);
      if ((paramInt1 > 0) || (paramInt2 > 0)) {
        a = (-paramInt1 * (1.0F - paramFloat) + paramInt2 * paramFloat);
      }
    }
    return this;
  }
  
  Item a(Label paramLabel1, Label paramLabel2, Label paramLabel3, float paramFloat)
  {
    b.a(paramLabel1, -1.0F);
    b.a(paramLabel2, 1.0F - paramFloat);
    b.a(paramLabel3, paramFloat);
    return this;
  }
  
  public Item a(Label paramLabel1, Label paramLabel2, Label paramLabel3, int paramInt)
  {
    int j = 0;
    int k = 0;
    if (paramInt != 0)
    {
      j = k;
      k = paramInt;
      if (paramInt < 0)
      {
        k = paramInt * -1;
        j = 1;
      }
      a = k;
    }
    if (j == 0)
    {
      b.a(paramLabel1, -1.0F);
      b.a(paramLabel2, 1.0F);
      b.a(paramLabel3, -1.0F);
      return this;
    }
    b.a(paramLabel1, 1.0F);
    b.a(paramLabel2, -1.0F);
    b.a(paramLabel3, 1.0F);
    return this;
  }
  
  public Item a(Label paramLabel1, Label paramLabel2, Label paramLabel3, Label paramLabel4, float paramFloat)
  {
    b.a(paramLabel1, -1.0F);
    b.a(paramLabel2, 1.0F);
    b.a(paramLabel3, paramFloat);
    b.a(paramLabel4, -paramFloat);
    return this;
  }
  
  String a()
  {
    String str;
    if (c == null)
    {
      str = "" + "0";
      str = str + " = ";
      if (a == 0.0F) {
        break label361;
      }
      str = str + a;
    }
    label205:
    label358:
    label361:
    for (int j = 1;; j = 0)
    {
      int m = b.i;
      int k = 0;
      Object localObject;
      float f;
      for (;;)
      {
        if (k < m)
        {
          localObject = b.a(k);
          if (localObject == null)
          {
            k += 1;
            continue;
            str = "" + c;
            break;
          }
          f = b.b(k);
          localObject = ((Label)localObject).toString();
          if (j == 0)
          {
            if (f >= 0.0F) {
              break label358;
            }
            str = str + "- ";
            f *= -1.0F;
          }
        }
      }
      for (;;)
      {
        if (f == 1.0F) {}
        for (str = str + (String)localObject;; str = str + f + " " + (String)localObject)
        {
          j = 1;
          break;
          if (f > 0.0F)
          {
            str = str + " + ";
            break label205;
          }
          str = str + " - ";
          f *= -1.0F;
          break label205;
        }
        if (j != 0) {
          break label366;
        }
        return str + "0.0";
      }
    }
    label366:
    return str;
  }
  
  void a(Label paramLabel)
  {
    if (c != null)
    {
      b.a(c, -1.0F);
      c = null;
    }
    float f = b.a(paramLabel) * -1.0F;
    c = paramLabel;
    if (f == 1.0F) {
      return;
    }
    a /= f;
    b.b(f);
  }
  
  boolean a(Item paramItem)
  {
    b.a(this, paramItem);
    return true;
  }
  
  Item b(Label paramLabel, int paramInt)
  {
    c = paramLabel;
    a = paramInt;
    a = paramInt;
    e = true;
    return this;
  }
  
  public Item b(Label paramLabel1, Label paramLabel2, Label paramLabel3, int paramInt)
  {
    int j = 0;
    int k = 0;
    if (paramInt != 0)
    {
      j = k;
      k = paramInt;
      if (paramInt < 0)
      {
        k = paramInt * -1;
        j = 1;
      }
      a = k;
    }
    if (j == 0)
    {
      b.a(paramLabel1, -1.0F);
      b.a(paramLabel2, 1.0F);
      b.a(paramLabel3, 1.0F);
      return this;
    }
    b.a(paramLabel1, 1.0F);
    b.a(paramLabel2, -1.0F);
    b.a(paramLabel3, -1.0F);
    return this;
  }
  
  void b()
  {
    b.a(this);
  }
  
  boolean b(Label paramLabel)
  {
    return b.c(paramLabel);
  }
  
  boolean c()
  {
    return (c != null) && ((c.b == c.c) || (a >= 0.0F));
  }
  
  void clear()
  {
    if (a < 0.0F)
    {
      a *= -1.0F;
      b.b();
    }
  }
  
  public void d()
  {
    c = null;
    b.c();
    a = 0.0F;
    e = false;
  }
  
  Item setTitle(Label paramLabel, int paramInt)
  {
    b.a(paramLabel, paramInt);
    return this;
  }
  
  void setTitle()
  {
    Label localLabel = b.a();
    if (localLabel != null) {
      a(localLabel);
    }
    if (b.i == 0) {
      e = true;
    }
  }
  
  public String toString()
  {
    return a();
  }
}

package android.support.constraint.asm.asm;

import android.support.constraint.asm.f;
import java.util.ArrayList;

public class b
  extends h
{
  protected ArrayList<android.support.constraint.a.a.b> a = new ArrayList();
  
  public b() {}
  
  public void a()
  {
    write();
    if (a == null) {
      return;
    }
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      h localH = (h)a.get(i);
      if ((localH instanceof b)) {
        ((b)localH).a();
      }
      i += 1;
    }
  }
  
  public void a(int paramInt1, int paramInt2)
  {
    super.a(paramInt1, paramInt2);
    paramInt2 = a.size();
    paramInt1 = 0;
    while (paramInt1 < paramInt2)
    {
      ((h)a.get(paramInt1)).a(f(), isEnabled());
      paramInt1 += 1;
    }
  }
  
  public void a(f paramF)
  {
    super.a(paramF);
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      ((h)a.get(i)).a(paramF);
      i += 1;
    }
  }
  
  public void b(h paramH)
  {
    a.remove(paramH);
    paramH.d(null);
  }
  
  public void c(h paramH)
  {
    a.add(paramH);
    if (paramH.next() != null) {
      ((b)paramH.next()).b(paramH);
    }
    paramH.d(this);
  }
  
  public void close()
  {
    a.clear();
  }
  
  public void init()
  {
    a.clear();
    super.init();
  }
  
  public ClassWriter onCreateView()
  {
    Object localObject = next();
    ClassWriter localClassWriter;
    if ((this instanceof ClassWriter)) {
      localClassWriter = (ClassWriter)this;
    }
    for (;;)
    {
      h localH;
      if (localObject != null)
      {
        localH = ((h)localObject).next();
        if ((localObject instanceof ClassWriter))
        {
          localClassWriter = (ClassWriter)localObject;
          localObject = localH;
        }
      }
      else
      {
        return localClassWriter;
      }
      localObject = localH;
      continue;
      localClassWriter = null;
    }
  }
  
  public void write()
  {
    super.write();
    if (a == null) {
      return;
    }
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      h localH = (h)a.get(i);
      localH.a(e(), length());
      if (!(localH instanceof ClassWriter)) {
        localH.write();
      }
      i += 1;
    }
  }
}

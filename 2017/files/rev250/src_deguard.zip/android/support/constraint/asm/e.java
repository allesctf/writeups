package android.support.constraint.asm;

import android.support.constraint.a.f.a;

class e<T>
  implements f.a<T>
{
  private final Object[] a;
  private int k;
  
  e(int paramInt)
  {
    if (paramInt <= 0) {
      throw new IllegalArgumentException("The max pool size must be > 0");
    }
    a = new Object[paramInt];
  }
  
  public Object a()
  {
    if (k > 0)
    {
      int i = k - 1;
      Object localObject = a[i];
      a[i] = null;
      k -= 1;
      return localObject;
    }
    return null;
  }
  
  public void a(Object[] paramArrayOfObject, int paramInt)
  {
    int i = paramInt;
    if (paramInt > paramArrayOfObject.length) {
      i = paramArrayOfObject.length;
    }
    paramInt = 0;
    while (paramInt < i)
    {
      Object localObject = paramArrayOfObject[paramInt];
      if (k < a.length)
      {
        a[k] = localObject;
        k += 1;
      }
      paramInt += 1;
    }
  }
  
  public boolean a(Object paramObject)
  {
    if (k < a.length)
    {
      a[k] = paramObject;
      k += 1;
      return true;
    }
    return false;
  }
}

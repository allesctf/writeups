package android.support.constraint.asm;

import android.support.constraint.a.g;
import java.util.ArrayList;

public class h
{
  ArrayList<g> j = new ArrayList();
  
  public h() {}
  
  private void b(d paramD)
  {
    j.clear();
    int i = 1;
    if (i < c)
    {
      Label localLabel = i.b[i];
      int k = 0;
      while (k < 6)
      {
        e[k] = 0.0F;
        k += 1;
      }
      e[k] = 1.0F;
      if (b != c.f) {}
      for (;;)
      {
        i += 1;
        break;
        j.add(localLabel);
      }
    }
  }
  
  Label a()
  {
    int i1 = j.size();
    int n = 0;
    int k = 0;
    Object localObject2 = null;
    while (n < i1)
    {
      Label localLabel = (Label)j.get(n);
      int i = 5;
      while (i >= 0)
      {
        float f = e[i];
        int m = k;
        Object localObject1 = localObject2;
        if (localObject2 == null)
        {
          m = k;
          localObject1 = localObject2;
          if (f < 0.0F)
          {
            m = k;
            localObject1 = localObject2;
            if (i >= k)
            {
              m = i;
              localObject1 = localLabel;
            }
          }
        }
        k = m;
        localObject2 = localObject1;
        if (f > 0.0F)
        {
          k = m;
          localObject2 = localObject1;
          if (i > m)
          {
            k = i;
            localObject2 = null;
          }
        }
        i -= 1;
      }
      n += 1;
    }
    return localObject2;
  }
  
  void a(d paramD)
  {
    b(paramD);
    int n = j.size();
    int i = 0;
    while (i < n)
    {
      Label localLabel1 = (Label)j.get(i);
      if (i != -1)
      {
        i localI = bi).b;
        int i1 = i;
        int k = 0;
        if (k < i1)
        {
          Label localLabel2 = localI.a(k);
          if (localLabel2 == null) {}
          for (;;)
          {
            k += 1;
            break;
            float f = localI.b(k);
            int m = 0;
            while (m < 6)
            {
              float[] arrayOfFloat = e;
              arrayOfFloat[m] += e[m] * f;
              m += 1;
            }
            if (!j.contains(localLabel2)) {
              j.add(localLabel2);
            }
          }
        }
        localLabel1.a();
      }
      i += 1;
    }
  }
  
  public String toString()
  {
    int k = j.size();
    String str = "Goal: ";
    int i = 0;
    while (i < k)
    {
      Label localLabel = (Label)j.get(i);
      str = str + localLabel.normalize();
      i += 1;
    }
    return str;
  }
}

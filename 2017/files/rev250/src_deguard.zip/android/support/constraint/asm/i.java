package android.support.constraint.asm;

import java.util.Arrays;

public class i
{
  private Label a = null;
  private int[] b = new int[h];
  private int c = -1;
  private float[] e = new float[h];
  private int[] f = new int[h];
  private int h = 8;
  int i = 0;
  private int j = -1;
  private boolean k = false;
  private final Item l;
  private final f v;
  
  i(Item paramItem, f paramF)
  {
    l = paramItem;
    v = paramF;
  }
  
  public final float a(Label paramLabel)
  {
    if (a == paramLabel) {
      a = null;
    }
    if (c == -1) {
      return 0.0F;
    }
    int m = c;
    int n = 0;
    int i1 = -1;
    while ((m != -1) && (n < i))
    {
      int i2 = b[m];
      if (i2 == c)
      {
        if (m == c) {
          c = f[m];
        }
        for (;;)
        {
          v.b[i2].a(l);
          i -= 1;
          b[m] = -1;
          if (k) {
            j = m;
          }
          return e[m];
          f[i1] = f[m];
        }
      }
      int[] arrayOfInt = f;
      n += 1;
      i1 = m;
      m = arrayOfInt[m];
    }
    return 0.0F;
  }
  
  Label a()
  {
    Object localObject2 = null;
    int n = 0;
    int m = c;
    Object localObject1 = null;
    float f1;
    if ((m != -1) && (n < i))
    {
      f1 = e[m];
      if (f1 < 0.0F)
      {
        if (f1 <= -0.001F) {
          break label189;
        }
        e[m] = 0.0F;
        f1 = 0.0F;
      }
    }
    label186:
    label189:
    for (;;)
    {
      Object localObject3;
      if (f1 != 0.0F)
      {
        localObject3 = v.b[b[m]];
        if (b == c.c)
        {
          if (f1 < 0.0F)
          {
            return localObject3;
            if (f1 >= 0.001F) {
              break label189;
            }
            e[m] = 0.0F;
            f1 = 0.0F;
            continue;
          }
          if (localObject1 != null) {
            break label186;
          }
          localObject1 = localObject3;
        }
      }
      for (;;)
      {
        localObject3 = f;
        n += 1;
        m = localObject3[m];
        break;
        if ((f1 < 0.0F) && ((localObject2 == null) || (k < k)))
        {
          localObject2 = localObject3;
          continue;
          if (localObject1 != null) {
            return localObject1;
          }
          return localObject2;
        }
      }
    }
  }
  
  final Label a(int paramInt)
  {
    int n = c;
    int m = 0;
    while ((n != -1) && (m < i))
    {
      if (m == paramInt) {
        return v.b[b[n]];
      }
      n = f[n];
      m += 1;
    }
    return null;
  }
  
  void a(Item paramItem)
  {
    int n = c;
    int m = 0;
    while ((n != -1) && (m < i))
    {
      v.b[b[n]].b(paramItem);
      n = f[n];
      m += 1;
    }
  }
  
  void a(Item paramItem1, Item paramItem2)
  {
    int m = c;
    int n = 0;
    while ((m != -1) && (n < i)) {
      if (b[m] == c.c)
      {
        float f1 = e[m];
        a(c);
        i localI = b;
        n = c;
        m = 0;
        while ((n != -1) && (m < i))
        {
          b(v.b[b[n]], e[n] * f1);
          n = f[n];
          m += 1;
        }
        a += a * f1;
        c.a(paramItem1);
        m = c;
        n = 0;
      }
      else
      {
        m = f[m];
        n += 1;
      }
    }
  }
  
  void a(Item paramItem, Item[] paramArrayOfItem)
  {
    int m = c;
    i localI1 = this;
    int n = 0;
    while ((m != -1) && (n < i))
    {
      Object localObject = v.b[b[m]];
      if (i != -1)
      {
        float f1 = e[m];
        localI1.a((Label)localObject);
        localObject = paramArrayOfItem[i];
        if (!e)
        {
          i localI2 = b;
          n = c;
          m = 0;
          while ((n != -1) && (m < i))
          {
            localI1.b(v.b[b[n]], e[n] * f1);
            n = f[n];
            m += 1;
          }
        }
        a += a * f1;
        c.a(paramItem);
        m = c;
        n = 0;
      }
      else
      {
        m = f[m];
        n += 1;
      }
    }
  }
  
  public final void a(Label paramLabel, float paramFloat)
  {
    if (paramFloat == 0.0F)
    {
      a(paramLabel);
      return;
    }
    if (c == -1)
    {
      c = 0;
      e[c] = paramFloat;
      b[c] = c;
      f[c] = -1;
      i += 1;
      if (!k) {
        j += 1;
      }
    }
    else
    {
      int m = c;
      int n = 0;
      int i2 = -1;
      while ((m != -1) && (n < i))
      {
        if (b[m] == c)
        {
          e[m] = paramFloat;
          return;
        }
        if (b[m] < c) {
          i2 = m;
        }
        int[] arrayOfInt = f;
        n += 1;
        m = arrayOfInt[m];
      }
      m = j + 1;
      int i1;
      if (k)
      {
        if (b[j] == -1) {
          m = j;
        }
      }
      else
      {
        n = m;
        if (m >= b.length)
        {
          n = m;
          if (i < b.length)
          {
            i1 = 0;
            label231:
            n = m;
            if (i1 < b.length)
            {
              if (b[i1] != -1) {
                break label443;
              }
              n = i1;
            }
          }
        }
        m = n;
        if (n >= b.length)
        {
          m = b.length;
          h *= 2;
          k = false;
          j = (m - 1);
          e = Arrays.copyOf(e, h);
          b = Arrays.copyOf(b, h);
          f = Arrays.copyOf(f, h);
        }
        b[m] = c;
        e[m] = paramFloat;
        if (i2 == -1) {
          break label452;
        }
        f[m] = f[i2];
        f[i2] = m;
      }
      for (;;)
      {
        i += 1;
        if (!k) {
          j += 1;
        }
        if (i < b.length) {
          return;
        }
        k = true;
        return;
        m = b.length;
        break;
        label443:
        i1 += 1;
        break label231;
        label452:
        f[m] = c;
        c = m;
      }
    }
  }
  
  final float b(int paramInt)
  {
    int n = c;
    int m = 0;
    while ((n != -1) && (m < i))
    {
      if (m == paramInt) {
        return e[n];
      }
      n = f[n];
      m += 1;
    }
    return 0.0F;
  }
  
  public final float b(Label paramLabel)
  {
    int n = c;
    int m = 0;
    while ((n != -1) && (m < i))
    {
      if (b[n] == c) {
        return e[n];
      }
      n = f[n];
      m += 1;
    }
    return 0.0F;
  }
  
  void b()
  {
    int n = c;
    int m = 0;
    while ((n != -1) && (m < i))
    {
      float[] arrayOfFloat = e;
      arrayOfFloat[n] *= -1.0F;
      n = f[n];
      m += 1;
    }
  }
  
  void b(float paramFloat)
  {
    int n = c;
    int m = 0;
    while ((n != -1) && (m < i))
    {
      float[] arrayOfFloat = e;
      arrayOfFloat[n] /= paramFloat;
      n = f[n];
      m += 1;
    }
  }
  
  public final void b(Label paramLabel, float paramFloat)
  {
    if (paramFloat == 0.0F) {
      return;
    }
    if (c == -1)
    {
      c = 0;
      e[c] = paramFloat;
      b[c] = c;
      f[c] = -1;
      i += 1;
      if (!k) {
        j += 1;
      }
    }
    else
    {
      int m = c;
      int n = 0;
      int i2 = -1;
      int i1;
      while ((m != -1) && (n < i))
      {
        i1 = b[m];
        if (i1 == c)
        {
          paramLabel = e;
          paramLabel[m] += paramFloat;
          if (e[m] != 0.0F) {
            return;
          }
          if (m == c) {
            c = f[m];
          }
          for (;;)
          {
            v.b[i1].a(l);
            if (k) {
              j = m;
            }
            i -= 1;
            return;
            f[i2] = f[m];
          }
        }
        if (b[m] < c) {
          i2 = m;
        }
        int[] arrayOfInt = f;
        n += 1;
        m = arrayOfInt[m];
      }
      m = j + 1;
      if (k)
      {
        if (b[j] == -1) {
          m = j;
        }
      }
      else
      {
        n = m;
        if (m >= b.length)
        {
          n = m;
          if (i < b.length)
          {
            i1 = 0;
            label319:
            n = m;
            if (i1 < b.length)
            {
              if (b[i1] != -1) {
                break label542;
              }
              n = i1;
            }
          }
        }
        m = n;
        if (n >= b.length)
        {
          m = b.length;
          h *= 2;
          k = false;
          j = (m - 1);
          e = Arrays.copyOf(e, h);
          b = Arrays.copyOf(b, h);
          f = Arrays.copyOf(f, h);
        }
        b[m] = c;
        e[m] = paramFloat;
        if (i2 == -1) {
          break label551;
        }
        f[m] = f[i2];
        f[i2] = m;
      }
      for (;;)
      {
        i += 1;
        if (!k) {
          j += 1;
        }
        if (j < b.length) {
          return;
        }
        k = true;
        j = (b.length - 1);
        return;
        m = b.length;
        break;
        label542:
        i1 += 1;
        break label319;
        label551:
        f[m] = c;
        c = m;
      }
    }
  }
  
  public final void c()
  {
    c = -1;
    j = -1;
    k = false;
    i = 0;
  }
  
  final boolean c(Label paramLabel)
  {
    if (c == -1) {
      return false;
    }
    int n = c;
    int m = 0;
    while ((n != -1) && (m < i))
    {
      if (b[n] == c) {
        return true;
      }
      n = f[n];
      m += 1;
    }
    return false;
  }
  
  public String toString()
  {
    String str = "";
    int n = c;
    int m = 0;
    while ((n != -1) && (m < i))
    {
      str = str + " -> ";
      str = str + e[n] + " : ";
      str = str + v.b[b[n]];
      n = f[n];
      m += 1;
    }
    return str;
  }
}

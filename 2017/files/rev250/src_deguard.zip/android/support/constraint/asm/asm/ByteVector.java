package android.support.constraint.asm.asm;

public class ByteVector
{
  public ByteVector() {}
}

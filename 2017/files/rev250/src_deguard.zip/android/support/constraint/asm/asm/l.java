package android.support.constraint.asm.asm;

import android.support.constraint.asm.Label;
import android.support.constraint.asm.d;

public class l
{
  static void a(ClassWriter paramClassWriter, d paramD, int paramInt, h paramH)
  {
    int k = 0;
    int m = 0;
    float f2 = 0.0F;
    Object localObject2 = null;
    Object localObject1 = paramH;
    int i;
    label33:
    label83:
    int j;
    if (localObject1 != null) {
      if (((h)localObject1).ordinal() == 8)
      {
        i = 1;
        if (i != 0) {
          break label730;
        }
        m += 1;
        if (j == c.c) {
          break label232;
        }
        int n = ((h)localObject1).get();
        if (a.b == null) {
          break label220;
        }
        i = a.b();
        if (r.b == null) {
          break label226;
        }
        j = r.b();
        label104:
        k = j + (k + n + i);
      }
    }
    label117:
    label220:
    label226:
    label232:
    label358:
    label384:
    label405:
    label474:
    label515:
    label600:
    label622:
    label628:
    label634:
    label661:
    label675:
    label723:
    label729:
    label730:
    for (;;)
    {
      if (r.b != null) {}
      for (Object localObject3 = r.b.c;; localObject3 = null)
      {
        localObject2 = localObject3;
        if (localObject3 != null) {
          if (a.b != null)
          {
            localObject2 = localObject3;
            if (a.b != null)
            {
              localObject2 = localObject3;
              if (a.b.c == localObject1) {}
            }
          }
          else
          {
            localObject2 = null;
          }
        }
        localObject3 = localObject2;
        localObject2 = localObject1;
        localObject1 = localObject3;
        break;
        i = 0;
        break label33;
        i = 0;
        break label83;
        j = 0;
        break label104;
        f2 = height + f2;
        break label117;
      }
      j = 0;
      if (localObject2 != null)
      {
        if (r.b == null) {
          break label600;
        }
        i = r.b.c.l();
        j = i;
        if (r.b != null)
        {
          j = i;
          if (r.b.c == paramClassWriter) {
            j = paramClassWriter.setTitle();
          }
        }
      }
      float f5 = j - 0 - k;
      float f1 = f5 / (m + 1);
      float f3;
      float f4;
      if (paramInt == 0)
      {
        f3 = f1;
        localObject2 = paramH;
        if (localObject2 == null) {
          break label729;
        }
        if (a.b == null) {
          break label622;
        }
        i = a.b();
        if (r.b == null) {
          break label628;
        }
        j = r.b();
        if (((h)localObject2).ordinal() == 8) {
          break label675;
        }
        f1 += i;
        paramD.a(a.a, (int)(0.5F + f1));
        if (j != c.c) {
          break label661;
        }
        if (f2 != 0.0F) {
          break label634;
        }
        f1 = f3 - i - j + f1;
        paramD.a(r.a, (int)(0.5F + f1));
        f4 = f1;
        if (paramInt == 0) {
          f4 = f1 + f3;
        }
        f1 = f4 + j;
        if (r.b == null) {
          break label723;
        }
      }
      for (localObject1 = r.b.c;; localObject1 = null)
      {
        paramH = (h)localObject1;
        if (localObject1 != null)
        {
          paramH = (h)localObject1;
          if (a.b != null)
          {
            paramH = (h)localObject1;
            if (a.b.c != localObject2) {
              paramH = null;
            }
          }
        }
        localObject1 = paramH;
        if (paramH == paramClassWriter) {
          localObject1 = null;
        }
        localObject2 = localObject1;
        break label358;
        i = 0;
        break;
        f3 = f5 / paramInt;
        f1 = 0.0F;
        localObject2 = paramH;
        break label358;
        i = 0;
        break label384;
        j = 0;
        break label405;
        f1 = height * f5 / f2 - i - j + f1;
        break label474;
        f1 = ((h)localObject2).get() + f1;
        break label474;
        f4 = f1 - f3 / 2.0F;
        paramD.a(a.a, (int)(0.5F + f4));
        paramD.a(r.a, (int)(f4 + 0.5F));
        break label515;
      }
      return;
    }
  }
  
  static void a(ClassWriter paramClassWriter, d paramD, h paramH)
  {
    int k = 1;
    if (j == c.c)
    {
      h = 1;
      return;
    }
    if ((paramClassWriter.j != c.b) && (j == c.d))
    {
      a.a = paramD.a(a);
      r.a = paramD.a(r);
      i = a.i;
      j = paramClassWriter.get() - r.i;
      paramD.a(a.a, i);
      paramD.a(r.a, j);
      if ((A > 0) || (paramH.ordinal() == 8))
      {
        d.a = paramD.a(d);
        paramD.a(d.a, A + i);
      }
      paramH.c(i, j);
      h = 2;
      return;
    }
    float f;
    if ((a.b != null) && (r.b != null))
    {
      if ((a.b.c == paramClassWriter) && (r.b.c == paramClassWriter))
      {
        j = a.b();
        i = j;
        k = r.b();
        if (paramClassWriter.j == c.c) {}
        for (j = paramH.get() + j;; j = paramH.get() + i)
        {
          a.a = paramD.a(a);
          r.a = paramD.a(r);
          paramD.a(a.a, i);
          paramD.a(r.a, j);
          if ((A > 0) || (paramH.ordinal() == 8))
          {
            d.a = paramD.a(d);
            paramD.a(d.a, A + i);
          }
          h = 2;
          paramH.c(i, j);
          return;
          i = paramH.get();
          int m = paramClassWriter.get();
          f = j;
          i = (int)((m - j - k - i) * f + f + 0.5F);
        }
      }
      h = 1;
      return;
    }
    if ((a.b != null) && (a.b.c == paramClassWriter))
    {
      i = a.b();
      j = paramH.get() + i;
      a.a = paramD.a(a);
      r.a = paramD.a(r);
      paramD.a(a.a, i);
      paramD.a(r.a, j);
      if ((A > 0) || (paramH.ordinal() == 8))
      {
        d.a = paramD.a(d);
        paramD.a(d.a, A + i);
      }
      h = 2;
      paramH.c(i, j);
      return;
    }
    if ((r.b != null) && (r.b.c == paramClassWriter))
    {
      a.a = paramD.a(a);
      r.a = paramD.a(r);
      i = paramClassWriter.get() - r.b();
      j = i - paramH.get();
      paramD.a(a.a, j);
      paramD.a(r.a, i);
      if ((A > 0) || (paramH.ordinal() == 8))
      {
        d.a = paramD.a(d);
        paramD.a(d.a, A + j);
      }
      h = 2;
      paramH.c(j, i);
      return;
    }
    if ((a.b != null) && (a.b.c.h == 2))
    {
      paramClassWriter = a.b.a;
      a.a = paramD.a(a);
      r.a = paramD.a(r);
      i = (int)(a + a.b() + 0.5F);
      j = paramH.get() + i;
      paramD.a(a.a, i);
      paramD.a(r.a, j);
      if ((A > 0) || (paramH.ordinal() == 8))
      {
        d.a = paramD.a(d);
        paramD.a(d.a, A + i);
      }
      h = 2;
      paramH.c(i, j);
      return;
    }
    if ((r.b != null) && (r.b.c.h == 2))
    {
      paramClassWriter = r.b.a;
      a.a = paramD.a(a);
      r.a = paramD.a(r);
      i = (int)(a - r.b() + 0.5F);
      j = i - paramH.get();
      paramD.a(a.a, j);
      paramD.a(r.a, i);
      if ((A > 0) || (paramH.ordinal() == 8))
      {
        d.a = paramD.a(d);
        paramD.a(d.a, A + j);
      }
      h = 2;
      paramH.c(j, i);
      return;
    }
    if ((d.b != null) && (d.b.c.h == 2))
    {
      paramClassWriter = d.b.a;
      a.a = paramD.a(a);
      r.a = paramD.a(r);
      i = (int)(a - A + 0.5F);
      j = paramH.get() + i;
      paramD.a(a.a, i);
      paramD.a(r.a, j);
      d.a = paramD.a(d);
      paramD.a(d.a, A + i);
      h = 2;
      paramH.c(i, j);
      return;
    }
    label1337:
    label1347:
    m localM;
    if (d.b != null)
    {
      i = 1;
      if (a.b == null) {
        break label1496;
      }
      j = 1;
      if (r.b == null) {
        break label1502;
      }
      if ((i != 0) || (j != 0) || (k != 0)) {
        return;
      }
      if (!(paramH instanceof m)) {
        break label1549;
      }
      localM = (m)paramH;
      if (localM.getItemId() != 0) {
        return;
      }
      a.a = paramD.a(a);
      r.a = paramD.a(r);
      if (localM.g() == -1) {
        break label1508;
      }
      f = localM.g();
    }
    for (;;)
    {
      i = (int)(f + 0.5F);
      paramD.a(a.a, i);
      paramD.a(r.a, i);
      h = 2;
      k = 2;
      paramH.c(i, i);
      paramH.b(0, paramClassWriter.getValue());
      return;
      i = 0;
      break;
      label1496:
      j = 0;
      break label1337;
      label1502:
      k = 0;
      break label1347;
      label1508:
      if (localM.a() != -1)
      {
        f = paramClassWriter.get() - localM.a();
      }
      else
      {
        f = paramClassWriter.get();
        f = localM.m() * f;
      }
    }
    label1549:
    a.a = paramD.a(a);
    r.a = paramD.a(r);
    int i = paramH.getString();
    int j = paramH.get();
    paramD.a(a.a, i);
    paramD.a(r.a, j + i);
    if ((A > 0) || (paramH.ordinal() == 8))
    {
      d.a = paramD.a(d);
      paramD.a(d.a, i + A);
    }
    h = 2;
  }
  
  static void b(ClassWriter paramClassWriter, d paramD, int paramInt, h paramH)
  {
    int k = 0;
    int m = 0;
    float f2 = 0.0F;
    Object localObject2 = null;
    Object localObject1 = paramH;
    int i;
    label33:
    label83:
    int j;
    if (localObject1 != null) {
      if (((h)localObject1).ordinal() == 8)
      {
        i = 1;
        if (i != 0) {
          break label730;
        }
        m += 1;
        if (c == c.c) {
          break label232;
        }
        int n = ((h)localObject1).getValue();
        if (b.b == null) {
          break label220;
        }
        i = b.b();
        if (i.b == null) {
          break label226;
        }
        j = i.b();
        label104:
        k = j + (k + n + i);
      }
    }
    label117:
    label220:
    label226:
    label232:
    label358:
    label384:
    label405:
    label474:
    label515:
    label600:
    label622:
    label628:
    label634:
    label661:
    label675:
    label723:
    label729:
    label730:
    for (;;)
    {
      if (i.b != null) {}
      for (Object localObject3 = i.b.c;; localObject3 = null)
      {
        localObject2 = localObject3;
        if (localObject3 != null) {
          if (b.b != null)
          {
            localObject2 = localObject3;
            if (b.b != null)
            {
              localObject2 = localObject3;
              if (b.b.c == localObject1) {}
            }
          }
          else
          {
            localObject2 = null;
          }
        }
        localObject3 = localObject2;
        localObject2 = localObject1;
        localObject1 = localObject3;
        break;
        i = 0;
        break label33;
        i = 0;
        break label83;
        j = 0;
        break label104;
        f2 = right + f2;
        break label117;
      }
      j = 0;
      if (localObject2 != null)
      {
        if (i.b == null) {
          break label600;
        }
        i = i.b.c.l();
        j = i;
        if (i.b != null)
        {
          j = i;
          if (i.b.c == paramClassWriter) {
            j = paramClassWriter.d();
          }
        }
      }
      float f5 = j - 0 - k;
      float f1 = f5 / (m + 1);
      float f3;
      float f4;
      if (paramInt == 0)
      {
        f3 = f1;
        localObject2 = paramH;
        if (localObject2 == null) {
          break label729;
        }
        if (b.b == null) {
          break label622;
        }
        i = b.b();
        if (i.b == null) {
          break label628;
        }
        j = i.b();
        if (((h)localObject2).ordinal() == 8) {
          break label675;
        }
        f1 += i;
        paramD.a(b.a, (int)(0.5F + f1));
        if (c != c.c) {
          break label661;
        }
        if (f2 != 0.0F) {
          break label634;
        }
        f1 = f3 - i - j + f1;
        paramD.a(i.a, (int)(0.5F + f1));
        f4 = f1;
        if (paramInt == 0) {
          f4 = f1 + f3;
        }
        f1 = f4 + j;
        if (i.b == null) {
          break label723;
        }
      }
      for (localObject1 = i.b.c;; localObject1 = null)
      {
        paramH = (h)localObject1;
        if (localObject1 != null)
        {
          paramH = (h)localObject1;
          if (b.b != null)
          {
            paramH = (h)localObject1;
            if (b.b.c != localObject2) {
              paramH = null;
            }
          }
        }
        localObject1 = paramH;
        if (paramH == paramClassWriter) {
          localObject1 = null;
        }
        localObject2 = localObject1;
        break label358;
        i = 0;
        break;
        f3 = f5 / paramInt;
        f1 = 0.0F;
        localObject2 = paramH;
        break label358;
        i = 0;
        break label384;
        j = 0;
        break label405;
        f1 = right * f5 / f2 - i - j + f1;
        break label474;
        f1 = ((h)localObject2).getValue() + f1;
        break label474;
        f4 = f1 - f3 / 2.0F;
        paramD.a(b.a, (int)(0.5F + f4));
        paramD.a(i.a, (int)(f4 + 0.5F));
        break label515;
      }
      return;
    }
  }
  
  static void b(ClassWriter paramClassWriter, d paramD, h paramH)
  {
    c localC = c;
    Object localObject = paramH;
    if (localC == c.c)
    {
      k = 1;
      return;
    }
    if (c != c.b)
    {
      localC = c;
      if (localC == c.d)
      {
        b.a = paramD.a(b);
        i.a = paramD.a(i);
        i = b.i;
        j = paramClassWriter.getValue() - i.i;
        paramD.a(b.a, i);
        paramD.a(i.a, j);
        ((h)localObject).b(i, j);
        k = 2;
        return;
      }
    }
    if ((b.b != null) && (i.b != null))
    {
      if ((b.b.c == paramClassWriter) && (i.b.c == paramClassWriter))
      {
        j = b.b();
        i = j;
        int k = i.b();
        if (c == c.c)
        {
          k = paramClassWriter.getValue() - k;
          j = i;
        }
        for (i = k;; i = paramH.getValue() + j)
        {
          b.a = paramD.a(b);
          i.a = paramD.a(i);
          paramD.a(b.a, j);
          paramD.a(i.a, i);
          k = 2;
          paramH.b(j, i);
          return;
          i = paramH.getValue();
          j += (int)((paramClassWriter.getValue() - j - k - i) * C + 0.5F);
        }
      }
      k = 1;
      return;
    }
    if ((b.b != null) && (b.b.c == paramClassWriter))
    {
      i = b.b();
      j = paramH.getValue() + i;
      b.a = paramD.a(b);
      i.a = paramD.a(i);
      paramD.a(b.a, i);
      paramD.a(i.a, j);
      k = 2;
      paramH.b(i, j);
      return;
    }
    if ((i.b != null) && (i.b.c == paramClassWriter))
    {
      b.a = paramD.a(b);
      i.a = paramD.a(i);
      i = paramClassWriter.getValue() - i.b();
      j = i - paramH.getValue();
      paramD.a(b.a, j);
      paramD.a(i.a, i);
      k = 2;
      paramH.b(j, i);
      return;
    }
    if ((b.b != null) && (b.b.c.k == 2))
    {
      paramClassWriter = b.b.a;
      b.a = paramD.a(b);
      i.a = paramD.a(i);
      i = (int)(a + b.b() + 0.5F);
      j = paramH.getValue() + i;
      paramD.a(b.a, i);
      paramD.a(i.a, j);
      k = 2;
      paramH.b(i, j);
      return;
    }
    if ((i.b != null) && (i.b.c.k == 2))
    {
      paramClassWriter = i.b.a;
      b.a = paramD.a(b);
      i.a = paramD.a(i);
      i = (int)(a - i.b() + 0.5F);
      j = i - paramH.getValue();
      paramD.a(b.a, j);
      paramD.a(i.a, i);
      k = 2;
      paramH.b(j, i);
      return;
    }
    label898:
    float f;
    if (b.b != null)
    {
      i = 1;
      if (i.b == null) {
        break label1043;
      }
      j = 1;
      if ((i != 0) || (j != 0)) {
        return;
      }
      if (!(paramH instanceof m)) {
        break label1090;
      }
      localObject = (m)paramH;
      if (((m)localObject).getItemId() != 1) {
        return;
      }
      b.a = paramD.a(b);
      i.a = paramD.a(i);
      if (((m)localObject).g() == -1) {
        break label1049;
      }
      f = ((m)localObject).g();
    }
    for (;;)
    {
      i = (int)(f + 0.5F);
      paramD.a(b.a, i);
      paramD.a(i.a, i);
      k = 2;
      h = 2;
      paramH.b(i, i);
      paramH.c(0, paramClassWriter.get());
      return;
      i = 0;
      break;
      label1043:
      j = 0;
      break label898;
      label1049:
      if (((m)localObject).a() != -1)
      {
        f = paramClassWriter.getValue() - ((m)localObject).a();
      }
      else
      {
        f = paramClassWriter.getValue();
        f = ((m)localObject).m() * f;
      }
    }
    label1090:
    b.a = paramD.a(b);
    i.a = paramD.a(i);
    int i = paramH.l();
    int j = paramH.getValue();
    paramD.a(b.a, i);
    paramD.a(i.a, j + i);
    k = 2;
  }
  
  static void d(ClassWriter paramClassWriter, d paramD, h paramH)
  {
    int i;
    int j;
    if ((c != c.b) && (c == c.d))
    {
      b.a = paramD.a(b);
      i.a = paramD.a(i);
      i = b.i;
      j = paramClassWriter.getValue() - i.i;
      paramD.a(b.a, i);
      paramD.a(i.a, j);
      paramH.b(i, j);
      k = 2;
    }
    if ((paramClassWriter.j != c.b) && (j == c.d))
    {
      a.a = paramD.a(a);
      r.a = paramD.a(r);
      i = a.i;
      j = paramClassWriter.get() - r.i;
      paramD.a(a.a, i);
      paramD.a(r.a, j);
      if ((A > 0) || (paramH.ordinal() == 8))
      {
        d.a = paramD.a(d);
        paramD.a(d.a, A + i);
      }
      paramH.c(i, j);
      h = 2;
    }
  }
}

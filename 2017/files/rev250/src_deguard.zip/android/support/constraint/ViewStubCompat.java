package android.support.constraint;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

public class ViewStubCompat
  extends View
{
  public ViewStubCompat(Context paramContext)
  {
    super(paramContext);
    super.setVisibility(8);
  }
  
  public void draw(Canvas paramCanvas) {}
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    setMeasuredDimension(0, 0);
  }
  
  public void setVisibility(int paramInt) {}
}

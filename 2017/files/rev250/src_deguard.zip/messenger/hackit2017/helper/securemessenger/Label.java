package messenger.hackit2017.helper.securemessenger;

import java.security.SecureRandom;
import org.apache.commons.math3.fraction.Item;

public class Label
{
  private long a = new SecureRandom().nextInt(Integer.MAX_VALUE);
  private byte[] b;
  
  public Label(byte[] paramArrayOfByte)
  {
    b = paramArrayOfByte;
  }
  
  public byte[] a()
  {
    return b;
  }
  
  public long getColor()
  {
    return a;
  }
  
  public String toString()
  {
    return "[" + a + " : " + new String(Item.add(b)) + "]";
  }
}

package messenger.hackit2017.helper.securemessenger;

public class Path
{
  private String id;
  
  public Path(String paramString)
  {
    id = paramString;
  }
  
  public String getId()
  {
    return id;
  }
  
  public String toString()
  {
    return id;
  }
}

package messenger.hackit2017.helper.securemessenger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import messenger.hackit2017.com.securemessenger.f;
import org.whispersystems.curve25519.Curve25519;
import org.whispersystems.curve25519.Curve25519KeyPair;

public class Item
{
  private List<f> a;
  private Map<Long, byte[]> b;
  public String c;
  private Curve25519KeyPair j = Curve25519.get("best").add();
  
  public Item(String paramString)
  {
    c = paramString;
    a = new ArrayList(10);
    b = new HashMap(10);
  }
  
  private Type a(Item paramItem)
  {
    paramItem = new Type(this, paramItem, j.a());
    Iterator localIterator = a.iterator();
    while (localIterator.hasNext())
    {
      Type localType = (Type)localIterator.next();
      if (localType.equals(paramItem)) {
        return localType;
      }
    }
    ByteVector.add(c + "/session/est");
    a.add(paramItem);
    return paramItem;
  }
  
  public Label a()
  {
    Curve25519KeyPair localCurve25519KeyPair = Curve25519.get("best").add();
    Label localLabel = new Label(localCurve25519KeyPair.get());
    b.put(Long.valueOf(localLabel.getColor()), localCurve25519KeyPair.a());
    ByteVector.add(c + "/session/ephemeral/prekey/requested/public/" + localLabel);
    ByteVector.add(c + "/session/ephemeral/prekey/requested/private/", localCurve25519KeyPair.a());
    return localLabel;
  }
  
  public void a(ECKey paramECKey, Item paramItem)
  {
    ByteVector.add(c + "/msg/rcv/" + c + "/enc/" + paramECKey);
    a(paramItem).encrypt(paramECKey, (byte[])b.get(Long.valueOf(paramECKey.equals())));
    b.remove(Long.valueOf(paramECKey.equals()));
  }
  
  public void a(Path paramPath, Item paramItem)
  {
    paramItem.a(a(paramItem).a(paramPath, paramItem.a()), this);
  }
  
  public boolean equals(Object paramObject)
  {
    if ((paramObject instanceof Item)) {
      return Arrays.equals(((Item)paramObject).getJid(), getJid());
    }
    return false;
  }
  
  public byte[] getJid()
  {
    return j.get();
  }
}

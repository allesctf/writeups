package messenger.hackit2017.helper.securemessenger.xy;

public class PositionMetric
  extends a
{
  public PositionMetric() {}
  
  protected int b()
  {
    return 1;
  }
}

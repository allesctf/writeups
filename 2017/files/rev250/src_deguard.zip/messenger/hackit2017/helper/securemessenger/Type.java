package messenger.hackit2017.helper.securemessenger;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import messenger.hackit2017.helper.securemessenger.xy.a;
import org.whispersystems.curve25519.Curve25519;
import org.whispersystems.curve25519.Curve25519KeyPair;

public class Type
{
  private Item a;
  private byte[] b;
  private Item c;
  private long d;
  
  public Type(Item paramItem1, Item paramItem2, byte[] paramArrayOfByte)
  {
    a = paramItem1;
    c = paramItem2;
    b = Curve25519.get("best").add(paramItem2.getJid(), paramArrayOfByte);
    d = 0L;
    ByteVector.add(c + "/session/est/base/", b);
  }
  
  private byte[] a(long paramLong)
  {
    byte[] arrayOfByte = b;
    int i = 0;
    while (i < paramLong)
    {
      arrayOfByte = a.a(3).a(arrayOfByte, "h4ck1t{RotationFlagInfo}".getBytes(), 32);
      i += 1;
    }
    return arrayOfByte;
  }
  
  private Cipher getCipherInstance()
  {
    return Cipher.getInstance("AES/CBC/PKCS5Padding");
  }
  
  public ECKey a(Path paramPath, Label paramLabel)
  {
    Object localObject = Curve25519.get("best");
    Curve25519KeyPair localCurve25519KeyPair = ((Curve25519)localObject).add();
    byte[] arrayOfByte = ((Curve25519)localObject).add(paramLabel.a(), localCurve25519KeyPair.a());
    ByteVector.add(a.c + "/session/ephemeral/shared/", arrayOfByte);
    d += 1L;
    localObject = a.a(3).a(a(d), "WhisperSystems".getBytes(), 16);
    arrayOfByte = a.a(3).a(arrayOfByte, "WhisperSystems".getBytes(), 16);
    Cipher localCipher = getCipherInstance();
    localCipher.init(1, new SecretKeySpec((byte[])localObject, "AES"), new IvParameterSpec(arrayOfByte));
    return new ECKey(localCipher.doFinal(paramPath.getId().getBytes()), d, paramLabel.getColor(), localCurve25519KeyPair.get());
  }
  
  public Path encrypt(ECKey paramECKey, byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = Curve25519.get("best").add(paramECKey.getPrivKeyBytes(), paramArrayOfByte);
    paramArrayOfByte = a.a(3).a(a(paramECKey.getCreationTimeSeconds()), "WhisperSystems".getBytes(), 16);
    arrayOfByte = a.a(3).a(arrayOfByte, "WhisperSystems".getBytes(), 16);
    Cipher localCipher = getCipherInstance();
    localCipher.init(2, new SecretKeySpec(paramArrayOfByte, "AES"), new IvParameterSpec(arrayOfByte));
    return new Path(new String(localCipher.doFinal(paramECKey.getPubKey())));
  }
  
  public boolean equals(Object paramObject)
  {
    return ((paramObject instanceof Type)) && (a.equals(a)) && (c.equals(c));
  }
}

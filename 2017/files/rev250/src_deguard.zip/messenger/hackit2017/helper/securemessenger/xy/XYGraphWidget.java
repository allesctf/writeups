package messenger.hackit2017.helper.securemessenger.xy;

public class XYGraphWidget
  extends a
{
  public XYGraphWidget() {}
  
  protected int b()
  {
    return 0;
  }
}
